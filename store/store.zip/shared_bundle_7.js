import { Polymer, html } from "./shared_bundle_11.js";

Polymer({
    _template: html`
    <style include="iron-flex iron-flex-alignment"></style>
    <style include="shared-styles"></style>
    <style>

      :host {
        display: block;
        position: relative;
      }

      :host([disabled]) {
        pointer-events: none;
      }

      :host([indent]) paper-item {
        padding-left: 24px;
      }

      :host paper-input {
        width: 175px;

        --paper-input-container-input: {
          text-align: right;
        };
      }

    </style>

    <div class="section-title setting-label" tabindex="-1" hidden\$="[[!sectionTitle]]">{{sectionTitle}}
    </div>
    <paper-item class="center horizontal layout" tabindex="-1">
      <paper-item-body class="flex" two-line="">
        <div class="setting-label" hidden\$="[[!mainLabel]]">{{mainLabel}}</div>
        <div class="setting-label" secondary="" hidden\$="[[!secondaryLabel]]">
          {{secondaryLabel}}
        </div>
      </paper-item-body>
      <paper-input id="text" value="{{value}}" minlength="1" maxlength="{{maxLength}}" placeholder="{{placeholder}}" tabindex="0" disabled\$="[[disabled]]" on-blur="_onBlur" on-keyup="_onKeyUp"></paper-input>
    </paper-item>
    <hr hidden\$="[[noseparator]]">

    <app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
    </app-localstorage-document>
`,
    is: "setting-text",
    hostAttributes: {
        role: "group",
        tabIndex: -1
    },
    properties: {
        name: {
            type: String,
            value: "store"
        },
        value: {
            type: String,
            value: "",
            notify: !0
        },
        placeholder: {
            type: String,
            value: "e.g. Text",
            notify: !0
        },
        maxLength: {
            type: Number,
            value: "16",
            notify: !0
        },
        mainLabel: {
            type: String,
            value: ""
        },
        secondaryLabel: {
            type: String,
            value: ""
        },
        sectionTitle: {
            type: String,
            value: ""
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        noseparator: {
            type: Boolean,
            value: !1
        }
    },
    _onBlur: function() {
        Chrome.GA.event(Chrome.GA.EVENT.TEXT, this.name), this.fire("setting-text-changed", {
            value: this.value
        });
    },
    _onKeyUp: function(e) {
        13 === e.keyCode && (Chrome.GA.event(Chrome.GA.EVENT.TEXT, this.name), this.fire("setting-text-changed", {
            value: this.value
        }));
    }
});