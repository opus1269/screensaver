import { SS_IS_SHOWING, LOAD_FILTERED_PHOTOS, LOAD_ALBUM, LOAD_ALBUMS, UPDATE_WEATHER_ALARM, PHOTO_SOURCE_FAILED, SS_CLOSE, SS_SHOW, $photoSourceGoogleDefault as GoogleSource, processDaily, processAll, isUseKey, process, getSelectedSources, update, DEF_WEATHER, updateUnits, isSignedIn, removeCachedToken, $lastErrorDefault as ChromeLastError, localize, error, send, HIGHLIGHT, RESTORE_DEFAULTS, STORE, listen, getBool, get, set, getInt, asyncSet, $timeDefault as ChromeTime, getVersion, isWindows, event, EVENT, page, initialize, EVENT$1, DEBUG } from "./shared_bundle_3.js";

const chromep = new ChromePromise(), _DATA_VERSION = 24, DEFS = {
    version: _DATA_VERSION,
    enabled: !0,
    permPicasa: "notSet",
    permBackground: "notSet",
    permWeather: "notSet",
    allowBackground: !1,
    idleTime: {
        base: 5,
        display: 5,
        unit: 0
    },
    transitionTime: {
        base: 30,
        display: 30,
        unit: 0
    },
    skip: !0,
    shuffle: !0,
    photoSizing: 0,
    photoTransition: 1,
    interactive: !1,
    showTime: 2,
    largeTime: !1,
    showPhotog: !0,
    showLocation: !0,
    background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
    keepAwake: !1,
    chromeFullscreen: !0,
    allDisplays: !1,
    activeStart: "00:00",
    activeStop: "00:00",
    allowSuspend: !1,
    allowPhotoClicks: !0,
    useSpaceReddit: !1,
    useEarthReddit: !1,
    useAnimalReddit: !1,
    useInterestingFlickr: !1,
    useChromecast: !0,
    useAuthors: !1,
    fullResGoogle: !1,
    isAlbumMode: !0,
    useGoogle: !0,
    useGoogleAlbums: !0,
    useGooglePhotos: !1,
    signedInToChrome: !0,
    googlePhotosNoFilter: !0,
    googlePhotosFilter: GoogleSource.DEF_FILTER,
    location: {
        lat: 0,
        lon: 0
    },
    showCurrentWeather: !1,
    weatherTempUnit: 0,
    currentWeather: DEF_WEATHER
};

async function initialize$1() {
    try {
        _addDefaults(), await _setOS();
        const e = await isSignedIn();
        set("signedInToChrome", e), await ChromeLastError.reset(), set("showTime", _getTimeFormat()), 
        set("weatherTempUnit", _getTempUnit()), await processState();
    } catch (e) {
        error(e.message, "AppData.initialize");
    }
    return Promise.resolve();
}

async function update$1() {
    let e = getInt("version");
    if ((Number.isNaN(e) || _DATA_VERSION > e) && set("version", _DATA_VERSION), !Number.isNaN(e)) {
        if (e < 8 && (_convertSliderValue("transitionTime"), _convertSliderValue("idleTime")), 
        e < 10) {
            const e = localStorage.getItem("os");
            e && set("os", e);
        }
        if (e < 12 && set("permPicasa", "allowed"), e < 14 && (set("permBackground", "allowed"), 
        set("allowBackground", !0)), e < 18) {
            set("permPicasa", "notSet");
            try {
                await removeCachedToken(!1, null, null);
            } catch (e) {}
            set("albumSelections", []);
        }
    }
    if (e < 19 && (set("useEditors500px", null), set("usePopular500px", null), set("useYesterday500px", null), 
    set("editors500pxImages", null), set("popular500pxImages", null), set("yesterday500pxImages", null)), 
    e < 20) {
        try {
            const e = await isSignedIn();
            set("signedInToChrome", e);
        } catch (e) {}
        const e = get("transitionTime", DEFS.transitionTime);
        0 === e.unit && (e.base = Math.max(10, e.base), e.display = e.base, set("transitionTime", e));
    }
    if (e < 21) try {
        await _updateToChromeLocaleStorage();
    } catch (e) {}
    e < 22 && (set("gPhotosNeedsUpdate", null), set("gPhotosMaxAlbums", null), set("isAwake", null), 
    set("isShowing", null), set("albumSelections", null)), e < 23 && set("googleImages", null), 
    _addDefaults();
    try {
        await processState();
    } catch (e) {}
    return Promise.resolve();
}

function restoreDefaults() {
    Object.keys(DEFS).forEach(e => {
        e.includes("useGoogle") || "useGoogleAlbums" === e || "useGooglePhotos" === e || "signedInToChrome" === e || "isAlbumMode" === e || "googlePhotosFilter" === e || "permPicasa" === e || set(e, DEFS[e]);
    }), set("showTime", _getTimeFormat()), set("weatherTempUnit", _getTempUnit()), processState().catch(() => {});
}

async function processState(e = "all") {
    try {
        if ("all" === e) _processEnabled(), _processKeepAwake(), _processIdleTime(), await updatePhotoAlarm(), 
        await updateWeatherAlarm(), processAll(!1), get("os") || await _setOS(); else if (isUseKey(e) || "fullResGoogle" === e) {
            let t = e;
            if ("fullResGoogle" === e) {
                if (getBool("useGoogleAlbums", DEFS.useGoogleAlbums)) {
                    t = "useGoogleAlbums";
                    try {
                        await process(t);
                    } catch (e) {
                        const a = PHOTO_SOURCE_FAILED;
                        a.key = t, a.error = e.message, send(a).catch(() => {});
                    }
                }
                if (getBool("useGooglePhotos", DEFS.useGooglePhotos)) {
                    t = "useGooglePhotos";
                    try {
                        await process(t);
                    } catch (e) {
                        const a = PHOTO_SOURCE_FAILED;
                        a.key = t, a.error = e.message, send(a).catch(() => {});
                    }
                }
            } else if ("useGoogleAlbums" !== e && "useGooglePhotos" !== e) try {
                await process(t);
            } catch (e) {
                const a = PHOTO_SOURCE_FAILED;
                a.key = t, a.error = e.message, send(a).catch(() => {});
            }
        } else switch (e) {
          case "enabled":
            _processEnabled();
            break;

          case "idleTime":
            _processIdleTime();
            break;

          case "keepAwake":
          case "activeStart":
          case "activeStop":
          case "allowSuspend":
            _processKeepAwake();
            break;

          case "weatherTempUnit":
            await updateUnits();
        }
    } catch (e) {
        error(e.message, "AppData.processState");
    }
    return Promise.resolve();
}

function getIdleSeconds() {
    return 60 * get("idleTime", DEFS.idleTime).base;
}

async function _updateToChromeLocaleStorage() {
    const e = getSelectedSources();
    for (const t of e) {
        const e = t.getPhotosKey(), a = get(e);
        if (a) {
            if (!await asyncSet(e, a)) {
                const e = t.getDesc();
                error(`Failed to move source: ${e} to chrome.storage`, "AppData._updateToChromeLocaleStorage");
            }
            set(e, null);
        }
    }
}

function _processEnabled() {
    updateBadgeText();
    const e = getBool("enabled", DEFS.enabled), t = localize(e ? "disable" : "enable");
    chromep.contextMenus.update("ENABLE_MENU", {
        title: t
    }).catch(() => {});
}

function _processKeepAwake() {
    getBool("keepAwake", DEFS.keepAwake) ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
    updateKeepAwakeAlarm();
}

function _processIdleTime() {
    chrome.idle.setDetectionInterval(getIdleSeconds());
}

function _getTimeFormat() {
    return "12" === localize("time_format", "12") ? 1 : 2;
}

function _getTempUnit() {
    return "C" === localize("temp_unit", "C") ? 0 : 1;
}

async function _setOS() {
    try {
        const e = await chromep.runtime.getPlatformInfo();
        set("os", e.os);
    } catch (e) {
        set("os", "unknown");
    }
    return Promise.resolve();
}

function _addDefaults() {
    Object.keys(DEFS).forEach(function(e) {
        null === get(e) && set(e, DEFS[e]);
    });
}

function _convertSliderValue(e) {
    const t = get(e);
    if (t) {
        set(e, {
            base: t,
            display: t,
            unit: 0
        });
    }
}

var data = {
    DEFS: DEFS,
    initialize: initialize$1,
    update: update$1,
    restoreDefaults: restoreDefaults,
    processState: processState,
    getIdleSeconds: getIdleSeconds
};

const chromep$1 = new ChromePromise(), _SS_URL = "/html/screensaver.html", _ERR_SHOW = localize("err_show_ss");

function isActive() {
    const e = getBool("enabled"), t = getBool("keepAwake"), a = get("activeStart"), o = get("activeStop"), s = ChromeTime.isInRange(a, o);
    return !(!e || t && !s);
}

async function display(e) {
    try {
        const t = getBool("allDisplays", DEFS.allDisplays);
        !e && t ? await _openOnAllDisplays() : await _open(null);
    } catch (e) {
        error(e.message, "SSControl.display");
    }
    return Promise.resolve();
}

function close() {
    send(SS_CLOSE).catch(() => {});
}

async function _hasFullscreen(e) {
    let t = !1;
    const a = getBool("chromeFullscreen", DEFS.chromeFullscreen);
    try {
        if (a) {
            let a = await chromep$1.windows.getAll({
                populate: !1
            });
            const o = e ? e.bounds.left : 0, s = e ? e.bounds.top : 0;
            for (let r = 0; r < a.length; r++) {
                const n = a[r];
                if ("fullscreen" === n.state && (!e || n.top === s && n.left === o)) {
                    t = !0;
                    break;
                }
            }
        }
    } catch (e) {
        error(e.message, "SSController._hasFullscreen");
    }
    return Promise.resolve(t);
}

async function _isShowing() {
    try {
        return await send(SS_IS_SHOWING), Promise.resolve(!0);
    } catch (e) {
        return Promise.resolve(!1);
    }
}

async function _open(e) {
    const t = {
        url: _SS_URL,
        type: "popup"
    };
    try {
        if (await _hasFullscreen(e)) return Promise.resolve();
        e ? (t.left = e.bounds.left, t.top = e.bounds.top, t.width = e.bounds.width, t.height = e.bounds.height) : t.state = "fullscreen";
        const a = await chromep$1.windows.create(t);
        a && (e && await chromep$1.windows.update(a.id, {
            state: "fullscreen"
        }), await chromep$1.windows.update(a.id, {
            focused: !0
        }));
    } catch (e) {
        error(e.message, "SSControl._open", _ERR_SHOW);
    }
    return Promise.resolve();
}

async function _openOnAllDisplays() {
    try {
        let e = await chromep$1.system.display.getInfo();
        if (1 === e.length) await _open(null); else for (const t of e) await _open(t);
    } catch (e) {
        error(e.message, "SSControl._openOnAllDisplays", _ERR_SHOW);
    }
    return Promise.resolve();
}

async function _onIdleStateChanged(e) {
    try {
        let t = await _isShowing();
        if ("idle" === e) isActive() && !t && await display(!1); else if ("locked" === e) close(); else {
            await isWindows() || close();
        }
    } catch (e) {
        error(e.message, "SSControl._isShowing", _ERR_SHOW);
    }
}

function _onChromeMessage(e, t, a) {
    let o = !1;
    return e.message === SS_SHOW.message && (o = !0, display(!1).catch(() => {})), o;
}

chrome.idle.onStateChanged.addListener(_onIdleStateChanged), listen(_onChromeMessage);

var ss_controller = {
    isActive: isActive,
    display: display,
    close: close
};

const chromep$2 = new ChromePromise(), _ALARMS = {
    ACTIVATE: "ACTIVATE",
    DEACTIVATE: "DEACTIVATE",
    UPDATE_PHOTOS: "UPDATE_PHOTOS",
    BADGE_TEXT: "BADGE_TEXT",
    WEATHER: "WEATHER"
};

function updateKeepAwakeAlarm() {
    const e = getBool("keepAwake", DEFS.keepAwake), t = get("activeStart", DEFS.activeStart), a = get("activeStop", DEFS.activeStop);
    if (e && t !== a) {
        const e = ChromeTime.getTimeDelta(t), o = ChromeTime.getTimeDelta(a);
        chrome.alarms.create(_ALARMS.ACTIVATE, {
            delayInMinutes: e,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), chrome.alarms.create(_ALARMS.DEACTIVATE, {
            delayInMinutes: o,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), ChromeTime.isInRange(t, a) || _setInactiveState();
    } else chrome.alarms.clear(_ALARMS.ACTIVATE), chrome.alarms.clear(_ALARMS.DEACTIVATE);
    updateBadgeText();
}

async function updatePhotoAlarm() {
    try {
        return await chromep$2.alarms.get(_ALARMS.UPDATE_PHOTOS) || chrome.alarms.create(_ALARMS.UPDATE_PHOTOS, {
            when: Date.now() + ChromeTime.MSEC_IN_DAY,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), Promise.resolve();
    } catch (e) {
        error(e.message, "Alarm.updatePhotoAlarm");
    }
    return Promise.resolve();
}

async function updateWeatherAlarm() {
    if (getBool("showCurrentWeather", DEFS.showCurrentWeather)) try {
        await chromep$2.alarms.get(_ALARMS.WEATHER) || chrome.alarms.create(_ALARMS.WEATHER, {
            when: Date.now(),
            periodInMinutes: 10
        });
    } catch (e) {
        error(e.message, "Alarm.updateWeatherAlarm");
    } else chrome.alarms.clear(_ALARMS.WEATHER);
    return Promise.resolve();
}

function updateBadgeText() {
    chrome.alarms.create(_ALARMS.BADGE_TEXT, {
        when: Date.now() + 1e3
    });
}

async function _setActiveState() {
    const e = getBool("keepAwake", DEFS.keepAwake), t = getBool("enabled", DEFS.enabled);
    e && chrome.power.requestKeepAwake("display");
    const a = getIdleSeconds();
    try {
        let e = await chromep$2.idle.queryState(a);
        t && "idle" === e && await display(!1);
    } catch (e) {
        error(e.message, "Alarm._setActiveState");
    }
    return updateBadgeText(), Promise.resolve();
}

function _setInactiveState() {
    getBool("allowSuspend", DEFS.allowSuspend) ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
    close(), updateBadgeText();
}

function _setBadgeText() {
    const e = getBool("enabled", DEFS.enabled), t = getBool("keepAwake", DEFS.keepAwake);
    let a = "";
    a = e ? isActive() ? "" : localize("sleep_abbrev") : localize(t ? "power_abbrev" : "off_abbrev"), 
    chrome.browserAction.setBadgeText({
        text: a
    });
}

async function _updateWeather() {
    let e = null;
    try {
        e = await send(SS_IS_SHOWING);
    } catch (e) {}
    return e && await update(), Promise.resolve();
}

async function _onAlarm(e) {
    try {
        switch (e.name) {
          case _ALARMS.ACTIVATE:
            await _setActiveState();
            break;

          case _ALARMS.DEACTIVATE:
            _setInactiveState();
            break;

          case _ALARMS.UPDATE_PHOTOS:
            processDaily();
            break;

          case _ALARMS.BADGE_TEXT:
            _setBadgeText();
            break;

          case _ALARMS.WEATHER:
            try {
                await _updateWeather();
            } catch (t) {
                const a = localize("err_weather_update");
                error(t.message, "Alarm._onAlarm", a, e.name);
            }
        }
    } catch (e) {
        error(e.message, "Alarm._onAlarm");
    }
}

chrome.alarms.onAlarm.addListener(_onAlarm);

var alarm = {
    updateKeepAwakeAlarm: updateKeepAwakeAlarm,
    updatePhotoAlarm: updatePhotoAlarm,
    updateWeatherAlarm: updateWeatherAlarm,
    updateBadgeText: updateBadgeText
};

const _DISPLAY_MENU = "DISPLAY_MENU", _ENABLE_MENU = "ENABLE_MENU";

async function _toggleEnabled() {
    const e = getBool("enabled", !0);
    return set("enabled", !e), await processState("enabled"), Promise.resolve();
}

function _onInstalled(e) {
    const t = new ChromePromise();
    t.contextMenus.create({
        type: "normal",
        id: _DISPLAY_MENU,
        title: localize("display_now"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    }), t.contextMenus.create({
        type: "normal",
        id: _ENABLE_MENU,
        title: localize("disable"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    }), t.contextMenus.create({
        type: "separator",
        id: "SEP_MENU",
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    });
}

async function _onMenuClicked(e) {
    if (e.menuItemId === _DISPLAY_MENU) event(EVENT.MENU, `${e.menuItemId}`), await display(!1); else if (e.menuItemId === _ENABLE_MENU) {
        const t = getBool("enabled");
        event(EVENT.MENU, `${e.menuItemId}: ${t}`), await _toggleEnabled();
    }
}

async function _onKeyCommand(e) {
    "toggle-enabled" === e ? (event(EVENT.KEY_COMMAND, `${e}`), await _toggleEnabled()) : "show-screensaver" === e && (event(EVENT.KEY_COMMAND, `${e}`), 
    await display(!1));
}

async function _onSignInChanged(e, t) {
    if (set("signedInToChrome", t), !t) {
        event(EVENT$1.CHROME_SIGN_OUT);
        try {
            await asyncSet("albumSelections", []), await asyncSet("googleImages", []);
        } catch (e) {}
        "allowed" === get("permPicasa", "notSet") && error(localize("err_chrome_signout"), "User._onSignInChanged");
    }
}

async function _showOptionsTab() {
    try {
        await send(HIGHLIGHT);
    } catch (e) {
        chrome.tabs.create({
            url: "/html/options.html"
        });
    }
    return Promise.resolve();
}

async function _onInstalled$1(e) {
    if ("install" === e.reason) {
        event(EVENT.INSTALLED, getVersion());
        try {
            await initialize$1(), await _showOptionsTab();
        } catch (e) {
            error(e.message, "Bg.onInstalled");
        }
    } else if ("update" === e.reason) {
        if (!DEBUG) {
            const t = e.previousVersion;
            if (getVersion() === t) return Promise.resolve();
            let a = !1;
            t && !t.startsWith("3") && (a = !0), a && chrome.tabs.create({
                url: "/html/update3.html"
            });
        }
        try {
            await update$1();
        } catch (e) {
            error(e.message, "Bg.onUpdated");
        }
        return Promise.resolve();
    }
}

async function _onStartup() {
    page("/background.html");
    try {
        await processState();
    } catch (e) {
        error(e.message, "Bg._onStartup");
    }
    return Promise.resolve();
}

async function _onIconClicked() {
    try {
        await _showOptionsTab();
    } catch (e) {
        error(e.message, "Bg._onIconClicked");
    }
    return Promise.resolve();
}

async function _onStorageChanged(e) {
    try {
        await processState(e.key);
    } catch (e) {
        error(e.message, "Bg._onStorageChanged");
    }
    return Promise.resolve();
}

function _onChromeMessage$1(e, t, a) {
    let o = !1;
    return e.message === RESTORE_DEFAULTS.message ? restoreDefaults() : e.message === STORE.message ? set(e.key, e.value) : e.message === LOAD_FILTERED_PHOTOS.message ? (o = !0, 
    GoogleSource.loadFilteredPhotos(!0, !0).then(e => (a(e), null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === LOAD_ALBUM.message ? (o = !0, GoogleSource.loadAlbum(e.id, e.name, !0, !0).then(e => (a(e), 
    null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === LOAD_ALBUMS.message ? (o = !0, GoogleSource.loadAlbums(!0, !0).then(e => (a(e), 
    null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === UPDATE_WEATHER_ALARM.message && (o = !0, updateWeatherAlarm().then(() => (a({
        message: "OK"
    }), null)).catch(e => {
        a({
            errorMessage: e.message
        });
    })), o;
}

chrome.runtime.onInstalled.addListener(_onInstalled), chrome.contextMenus.onClicked.addListener(_onMenuClicked), 
chrome.commands.onCommand.addListener(_onKeyCommand), chrome.identity.onSignInChanged.addListener(_onSignInChanged), 
initialize(), chrome.runtime.onInstalled.addListener(_onInstalled$1), chrome.runtime.onStartup.addListener(_onStartup), 
chrome.browserAction.onClicked.addListener(_onIconClicked), addEventListener("storage", _onStorageChanged, !1), 
listen(_onChromeMessage$1);

export { alarm as $alarm, data as $data, ss_controller as $ssController, updateKeepAwakeAlarm, updatePhotoAlarm, updateWeatherAlarm, updateBadgeText, DEFS, initialize$1 as initialize, update$1 as update, restoreDefaults, processState, getIdleSeconds, isActive, display, close };