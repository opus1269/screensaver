import { Polymer, dom, html, afterNextRender, AppLayoutBehavior } from "./shared_bundle_10.js";

Polymer({
    is: "iron-media-query",
    properties: {
        queryMatches: {
            type: Boolean,
            value: !1,
            readOnly: !0,
            notify: !0
        },
        query: {
            type: String,
            observer: "queryChanged"
        },
        full: {
            type: Boolean,
            value: !1
        },
        _boundMQHandler: {
            value: function() {
                return this.queryHandler.bind(this);
            }
        },
        _mq: {
            value: null
        }
    },
    attached: function() {
        this.style.display = "none", this.queryChanged();
    },
    detached: function() {
        this._remove();
    },
    _add: function() {
        this._mq && this._mq.addListener(this._boundMQHandler);
    },
    _remove: function() {
        this._mq && this._mq.removeListener(this._boundMQHandler), this._mq = null;
    },
    queryChanged: function() {
        this._remove();
        var e = this.query;
        e && (this.full || "(" === e[0] || (e = "(" + e + ")"), this._mq = window.matchMedia(e), 
        this._add(), this.queryHandler(this._mq));
    },
    queryHandler: function(e) {
        this._setQueryMatches(e.matches);
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        /**
         * Force app-drawer-layout to have its own stacking context so that its parent can
         * control the stacking of it relative to other elements.
         */
        position: relative;
        z-index: 0;
      }

      :host ::slotted([slot=drawer]) {
        z-index: 1;
      }

      :host([fullbleed]) {
        @apply --layout-fit;
      }

      #contentContainer {
        /* Create a stacking context here so that all children appear below the header. */
        position: relative;
        z-index: 0;
        height: 100%;
        transition: var(--app-drawer-layout-content-transition, none);
      }

      #contentContainer[drawer-position=left] {
        margin-left: var(--app-drawer-width, 256px);
      }

      #contentContainer[drawer-position=right] {
        margin-right: var(--app-drawer-width, 256px);
      }
    </style>

    <slot id="drawerSlot" name="drawer"></slot>

    <div id="contentContainer" drawer-position\$="[[_drawerPosition]]">
      <slot></slot>
    </div>

    <iron-media-query query="[[_computeMediaQuery(forceNarrow, responsiveWidth)]]" on-query-matches-changed="_onQueryMatchesChanged"></iron-media-query>
`,
    is: "app-drawer-layout",
    behaviors: [ AppLayoutBehavior ],
    properties: {
        forceNarrow: {
            type: Boolean,
            value: !1
        },
        responsiveWidth: {
            type: String,
            value: "640px"
        },
        narrow: {
            type: Boolean,
            reflectToAttribute: !0,
            readOnly: !0,
            notify: !0
        },
        openedWhenNarrow: {
            type: Boolean,
            value: !1
        },
        _drawerPosition: {
            type: String
        }
    },
    listeners: {
        click: "_clickHandler"
    },
    observers: [ "_narrowChanged(narrow)" ],
    get drawer() {
        return dom(this.$.drawerSlot).getDistributedNodes()[0];
    },
    attached: function() {
        var e = this.drawer;
        e && e.setAttribute("no-transition", "");
    },
    _clickHandler: function(e) {
        var t = dom(e).localTarget;
        if (t && t.hasAttribute("drawer-toggle")) {
            var r = this.drawer;
            r && !r.persistent && r.toggle();
        }
    },
    _updateLayoutStates: function() {
        var e = this.drawer;
        this.isAttached && e && (this._drawerPosition = this.narrow ? null : e.position, 
        this._drawerNeedsReset && (this.narrow ? (e.opened = this.openedWhenNarrow, e.persistent = !1) : e.opened = e.persistent = !0, 
        e.hasAttribute("no-transition") && afterNextRender(this, function() {
            e.removeAttribute("no-transition");
        }), this._drawerNeedsReset = !1));
    },
    _narrowChanged: function() {
        this._drawerNeedsReset = !0, this.resetLayout();
    },
    _onQueryMatchesChanged: function(e) {
        this._setNarrow(e.detail.value);
    },
    _computeMediaQuery: function(e, t) {
        return e ? "(min-width: 0px)" : "(max-width: " + t + ")";
    }
});