import { property, computed, listen, customElement, query, observe, html as html$2, PolymerElement, Base, html$1, Polymer, dom, html$2 as html, IronButtonStateImpl, IronButtonState, IronControlState, IronA11yKeysBehavior, IronResizableBehavior, useShadow, add, setTouchAction, findOriginalTarget, NeonAnimationRunnerBehavior, IronSelectableBehavior, afterNextRender, animationFrame, microTask, idlePeriod, Debouncer, enqueueDebouncer, flush, BaseElement, error, event, EVENT, page, ChromeLastError, get, asyncSet, asyncGet, set, getBool, getVersion, getFullChromeVersion, DEBUG, isWhiteSpace, OptionalMutableDataBehavior, Templatizer, matches as matches$1, translate, shallowCopy, localize, error$1, send, addListener, removeListener, TYPE as TYPE$1, EVENT$1, initialize, TYPE$1 as TYPE, request, GOOGLE_PHOTOS, removeGooglePhotos, BACKGROUND, isAllowed, remove, WEATHER, DETECT_FACES, GoogleSource, PaperItemBehavior, dashToCamelCase, NeonAnimationBehavior, getUseKeyValues, DEF_LOC_OPTIONS, getLocation, update } from "./shared_bundle_4.js";

class IronMeta {
    constructor(e) {
        IronMeta[" "](e), this.type = e && e.type || "default", this.key = e && e.key, e && "value" in e && (this.value = e.value);
    }
    get value() {
        var e = this.type, t = this.key;
        if (e && t) return IronMeta.types[e] && IronMeta.types[e][t];
    }
    set value(e) {
        var t = this.type, i = this.key;
        t && i && (t = IronMeta.types[t] = IronMeta.types[t] || {}, null == e ? delete t[i] : t[i] = e);
    }
    get list() {
        if (this.type) {
            var e = IronMeta.types[this.type];
            return e ? Object.keys(e).map(function(e) {
                return metaDatas[this.type][e];
            }, this) : [];
        }
    }
    byKey(e) {
        return this.key = e, this.value;
    }
}

IronMeta[" "] = function() {}, IronMeta.types = {};

var metaDatas = IronMeta.types;

Polymer({
    is: "iron-meta",
    properties: {
        type: {
            type: String,
            value: "default"
        },
        key: {
            type: String
        },
        value: {
            type: String,
            notify: !0
        },
        self: {
            type: Boolean,
            observer: "_selfChanged"
        },
        __meta: {
            type: Boolean,
            computed: "__computeMeta(type, key, value)"
        }
    },
    hostAttributes: {
        hidden: !0
    },
    __computeMeta: function(e, t, i) {
        var o = new IronMeta({
            type: e,
            key: t
        });
        return void 0 !== i && i !== o.value ? o.value = i : this.value !== o.value && (this.value = o.value), 
        o;
    },
    get list() {
        return this.__meta && this.__meta.list;
    },
    _selfChanged: function(e) {
        e && (this.value = this);
    },
    byKey: function(e) {
        return new IronMeta({
            type: this.type,
            key: e
        }).value;
    }
});

var ironMeta = {
    IronMeta: IronMeta
};

Polymer({
    _template: html`
    <style>
      :host {
        @apply --layout-inline;
        @apply --layout-center-center;
        position: relative;

        vertical-align: middle;

        fill: var(--iron-icon-fill-color, currentcolor);
        stroke: var(--iron-icon-stroke-color, none);

        width: var(--iron-icon-width, 24px);
        height: var(--iron-icon-height, 24px);
        @apply --iron-icon;
      }

      :host([hidden]) {
        display: none;
      }
    </style>
`,
    is: "iron-icon",
    properties: {
        icon: {
            type: String
        },
        theme: {
            type: String
        },
        src: {
            type: String
        },
        _meta: {
            value: Base.create("iron-meta", {
                type: "iconset"
            })
        }
    },
    observers: [ "_updateIcon(_meta, isAttached)", "_updateIcon(theme, isAttached)", "_srcChanged(src, isAttached)", "_iconChanged(icon, isAttached)" ],
    _DEFAULT_ICONSET: "icons",
    _iconChanged: function(e) {
        var t = (e || "").split(":");
        this._iconName = t.pop(), this._iconsetName = t.pop() || this._DEFAULT_ICONSET, 
        this._updateIcon();
    },
    _srcChanged: function(e) {
        this._updateIcon();
    },
    _usesIconset: function() {
        return this.icon || !this.src;
    },
    _updateIcon: function() {
        this._usesIconset() ? (this._img && this._img.parentNode && dom(this.root).removeChild(this._img), 
        "" === this._iconName ? this._iconset && this._iconset.removeIcon(this) : this._iconsetName && this._meta && (this._iconset = this._meta.byKey(this._iconsetName), 
        this._iconset ? (this._iconset.applyIcon(this, this._iconName, this.theme), this.unlisten(window, "iron-iconset-added", "_updateIcon")) : this.listen(window, "iron-iconset-added", "_updateIcon"))) : (this._iconset && this._iconset.removeIcon(this), 
        this._img || (this._img = document.createElement("img"), this._img.style.width = "100%", 
        this._img.style.height = "100%", this._img.draggable = !1), this._img.src = this.src, 
        dom(this.root).appendChild(this._img));
    }
});

const template = html`
<custom-style>
  <style is="custom-style">
    html {

      --shadow-transition: {
        transition: box-shadow 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      };

      --shadow-none: {
        box-shadow: none;
      };

      /* from http://codepen.io/shyndman/pen/c5394ddf2e8b2a5c9185904b57421cdb */

      --shadow-elevation-2dp: {
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14),
                    0 1px 5px 0 rgba(0, 0, 0, 0.12),
                    0 3px 1px -2px rgba(0, 0, 0, 0.2);
      };

      --shadow-elevation-3dp: {
        box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.14),
                    0 1px 8px 0 rgba(0, 0, 0, 0.12),
                    0 3px 3px -2px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-4dp: {
        box-shadow: 0 4px 5px 0 rgba(0, 0, 0, 0.14),
                    0 1px 10px 0 rgba(0, 0, 0, 0.12),
                    0 2px 4px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-6dp: {
        box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14),
                    0 1px 18px 0 rgba(0, 0, 0, 0.12),
                    0 3px 5px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-8dp: {
        box-shadow: 0 8px 10px 1px rgba(0, 0, 0, 0.14),
                    0 3px 14px 2px rgba(0, 0, 0, 0.12),
                    0 5px 5px -3px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-12dp: {
        box-shadow: 0 12px 16px 1px rgba(0, 0, 0, 0.14),
                    0 4px 22px 3px rgba(0, 0, 0, 0.12),
                    0 6px 7px -4px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-16dp: {
        box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14),
                    0  6px 30px 5px rgba(0, 0, 0, 0.12),
                    0  8px 10px -5px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-24dp: {
        box-shadow: 0 24px 38px 3px rgba(0, 0, 0, 0.14),
                    0 9px 46px 8px rgba(0, 0, 0, 0.12),
                    0 11px 15px -7px rgba(0, 0, 0, 0.4);
      };
    }
  </style>
</custom-style>`;

template.setAttribute("style", "display: none;"), document.head.appendChild(template.content);

const template$1 = html`
<dom-module id="paper-material-styles">
  <template>
    <style>
      html {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      .paper-material {
        @apply --paper-material;
      }
      .paper-material[elevation="1"] {
        @apply --paper-material-elevation-1;
      }
      .paper-material[elevation="2"] {
        @apply --paper-material-elevation-2;
      }
      .paper-material[elevation="3"] {
        @apply --paper-material-elevation-3;
      }
      .paper-material[elevation="4"] {
        @apply --paper-material-elevation-4;
      }
      .paper-material[elevation="5"] {
        @apply --paper-material-elevation-5;
      }

      /* Duplicate the styles because of https://github.com/webcomponents/shadycss/issues/193 */
      :host {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      :host(.paper-material) {
        @apply --paper-material;
      }
      :host(.paper-material[elevation="1"]) {
        @apply --paper-material-elevation-1;
      }
      :host(.paper-material[elevation="2"]) {
        @apply --paper-material-elevation-2;
      }
      :host(.paper-material[elevation="3"]) {
        @apply --paper-material-elevation-3;
      }
      :host(.paper-material[elevation="4"]) {
        @apply --paper-material-elevation-4;
      }
      :host(.paper-material[elevation="5"]) {
        @apply --paper-material-elevation-5;
      }
    </style>
  </template>
</dom-module>`;

template$1.setAttribute("style", "display: none;"), document.head.appendChild(template$1.content);

var Utility = {
    distance: function(e, t, i, o) {
        var n = e - i, a = t - o;
        return Math.sqrt(n * n + a * a);
    },
    now: window.performance && window.performance.now ? window.performance.now.bind(window.performance) : Date.now
};

function ElementMetrics(e) {
    this.element = e, this.width = this.boundingRect.width, this.height = this.boundingRect.height, 
    this.size = Math.max(this.width, this.height);
}

function Ripple(e) {
    this.element = e, this.color = window.getComputedStyle(e).color, this.wave = document.createElement("div"), 
    this.waveContainer = document.createElement("div"), this.wave.style.backgroundColor = this.color, 
    this.wave.classList.add("wave"), this.waveContainer.classList.add("wave-container"), 
    dom(this.waveContainer).appendChild(this.wave), this.resetInteractionState();
}

ElementMetrics.prototype = {
    get boundingRect() {
        return this.element.getBoundingClientRect();
    },
    furthestCornerDistanceFrom: function(e, t) {
        var i = Utility.distance(e, t, 0, 0), o = Utility.distance(e, t, this.width, 0), n = Utility.distance(e, t, 0, this.height), a = Utility.distance(e, t, this.width, this.height);
        return Math.max(i, o, n, a);
    }
}, Ripple.MAX_RADIUS = 300, Ripple.prototype = {
    get recenters() {
        return this.element.recenters;
    },
    get center() {
        return this.element.center;
    },
    get mouseDownElapsed() {
        var e;
        return this.mouseDownStart ? (e = Utility.now() - this.mouseDownStart, this.mouseUpStart && (e -= this.mouseUpElapsed), 
        e) : 0;
    },
    get mouseUpElapsed() {
        return this.mouseUpStart ? Utility.now() - this.mouseUpStart : 0;
    },
    get mouseDownElapsedSeconds() {
        return this.mouseDownElapsed / 1e3;
    },
    get mouseUpElapsedSeconds() {
        return this.mouseUpElapsed / 1e3;
    },
    get mouseInteractionSeconds() {
        return this.mouseDownElapsedSeconds + this.mouseUpElapsedSeconds;
    },
    get initialOpacity() {
        return this.element.initialOpacity;
    },
    get opacityDecayVelocity() {
        return this.element.opacityDecayVelocity;
    },
    get radius() {
        var e = this.containerMetrics.width * this.containerMetrics.width, t = this.containerMetrics.height * this.containerMetrics.height, i = 1.1 * Math.min(Math.sqrt(e + t), Ripple.MAX_RADIUS) + 5, o = 1.1 - i / Ripple.MAX_RADIUS * .2, n = this.mouseInteractionSeconds / o, a = i * (1 - Math.pow(80, -n));
        return Math.abs(a);
    },
    get opacity() {
        return this.mouseUpStart ? Math.max(0, this.initialOpacity - this.mouseUpElapsedSeconds * this.opacityDecayVelocity) : this.initialOpacity;
    },
    get outerOpacity() {
        var e = .3 * this.mouseUpElapsedSeconds, t = this.opacity;
        return Math.max(0, Math.min(e, t));
    },
    get isOpacityFullyDecayed() {
        return this.opacity < .01 && this.radius >= Math.min(this.maxRadius, Ripple.MAX_RADIUS);
    },
    get isRestingAtMaxRadius() {
        return this.opacity >= this.initialOpacity && this.radius >= Math.min(this.maxRadius, Ripple.MAX_RADIUS);
    },
    get isAnimationComplete() {
        return this.mouseUpStart ? this.isOpacityFullyDecayed : this.isRestingAtMaxRadius;
    },
    get translationFraction() {
        return Math.min(1, this.radius / this.containerMetrics.size * 2 / Math.sqrt(2));
    },
    get xNow() {
        return this.xEnd ? this.xStart + this.translationFraction * (this.xEnd - this.xStart) : this.xStart;
    },
    get yNow() {
        return this.yEnd ? this.yStart + this.translationFraction * (this.yEnd - this.yStart) : this.yStart;
    },
    get isMouseDown() {
        return this.mouseDownStart && !this.mouseUpStart;
    },
    resetInteractionState: function() {
        this.maxRadius = 0, this.mouseDownStart = 0, this.mouseUpStart = 0, this.xStart = 0, 
        this.yStart = 0, this.xEnd = 0, this.yEnd = 0, this.slideDistance = 0, this.containerMetrics = new ElementMetrics(this.element);
    },
    draw: function() {
        var e, t, i;
        this.wave.style.opacity = this.opacity, e = this.radius / (this.containerMetrics.size / 2), 
        t = this.xNow - this.containerMetrics.width / 2, i = this.yNow - this.containerMetrics.height / 2, 
        this.waveContainer.style.webkitTransform = "translate(" + t + "px, " + i + "px)", 
        this.waveContainer.style.transform = "translate3d(" + t + "px, " + i + "px, 0)", 
        this.wave.style.webkitTransform = "scale(" + e + "," + e + ")", this.wave.style.transform = "scale3d(" + e + "," + e + ",1)";
    },
    downAction: function(e) {
        var t = this.containerMetrics.width / 2, i = this.containerMetrics.height / 2;
        this.resetInteractionState(), this.mouseDownStart = Utility.now(), this.center ? (this.xStart = t, 
        this.yStart = i, this.slideDistance = Utility.distance(this.xStart, this.yStart, this.xEnd, this.yEnd)) : (this.xStart = e ? e.detail.x - this.containerMetrics.boundingRect.left : this.containerMetrics.width / 2, 
        this.yStart = e ? e.detail.y - this.containerMetrics.boundingRect.top : this.containerMetrics.height / 2), 
        this.recenters && (this.xEnd = t, this.yEnd = i, this.slideDistance = Utility.distance(this.xStart, this.yStart, this.xEnd, this.yEnd)), 
        this.maxRadius = this.containerMetrics.furthestCornerDistanceFrom(this.xStart, this.yStart), 
        this.waveContainer.style.top = (this.containerMetrics.height - this.containerMetrics.size) / 2 + "px", 
        this.waveContainer.style.left = (this.containerMetrics.width - this.containerMetrics.size) / 2 + "px", 
        this.waveContainer.style.width = this.containerMetrics.size + "px", this.waveContainer.style.height = this.containerMetrics.size + "px";
    },
    upAction: function(e) {
        this.isMouseDown && (this.mouseUpStart = Utility.now());
    },
    remove: function() {
        dom(this.waveContainer.parentNode).removeChild(this.waveContainer);
    }
}, Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        position: absolute;
        border-radius: inherit;
        overflow: hidden;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;

        /* See PolymerElements/paper-behaviors/issues/34. On non-Chrome browsers,
         * creating a node (with a position:absolute) in the middle of an event
         * handler "interrupts" that event handler (which happens when the
         * ripple is created on demand) */
        pointer-events: none;
      }

      :host([animating]) {
        /* This resolves a rendering issue in Chrome (as of 40) where the
           ripple is not properly clipped by its parent (which may have
           rounded corners). See: http://jsbin.com/temexa/4

           Note: We only apply this style conditionally. Otherwise, the browser
           will create a new compositing layer for every ripple element on the
           page, and that would be bad. */
        -webkit-transform: translate(0, 0);
        transform: translate3d(0, 0, 0);
      }

      #background,
      #waves,
      .wave-container,
      .wave {
        pointer-events: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }

      #background,
      .wave {
        opacity: 0;
      }

      #waves,
      .wave {
        overflow: hidden;
      }

      .wave-container,
      .wave {
        border-radius: 50%;
      }

      :host(.circle) #background,
      :host(.circle) #waves {
        border-radius: 50%;
      }

      :host(.circle) .wave-container {
        overflow: hidden;
      }
    </style>

    <div id="background"></div>
    <div id="waves"></div>
`,
    is: "paper-ripple",
    behaviors: [ IronA11yKeysBehavior ],
    properties: {
        initialOpacity: {
            type: Number,
            value: .25
        },
        opacityDecayVelocity: {
            type: Number,
            value: .8
        },
        recenters: {
            type: Boolean,
            value: !1
        },
        center: {
            type: Boolean,
            value: !1
        },
        ripples: {
            type: Array,
            value: function() {
                return [];
            }
        },
        animating: {
            type: Boolean,
            readOnly: !0,
            reflectToAttribute: !0,
            value: !1
        },
        holdDown: {
            type: Boolean,
            value: !1,
            observer: "_holdDownChanged"
        },
        noink: {
            type: Boolean,
            value: !1
        },
        _animating: {
            type: Boolean
        },
        _boundAnimate: {
            type: Function,
            value: function() {
                return this.animate.bind(this);
            }
        }
    },
    get target() {
        return this.keyEventTarget;
    },
    keyBindings: {
        "enter:keydown": "_onEnterKeydown",
        "space:keydown": "_onSpaceKeydown",
        "space:keyup": "_onSpaceKeyup"
    },
    attached: function() {
        11 == this.parentNode.nodeType ? this.keyEventTarget = dom(this).getOwnerRoot().host : this.keyEventTarget = this.parentNode;
        var e = this.keyEventTarget;
        this.listen(e, "up", "uiUpAction"), this.listen(e, "down", "uiDownAction");
    },
    detached: function() {
        this.unlisten(this.keyEventTarget, "up", "uiUpAction"), this.unlisten(this.keyEventTarget, "down", "uiDownAction"), 
        this.keyEventTarget = null;
    },
    get shouldKeepAnimating() {
        for (var e = 0; e < this.ripples.length; ++e) if (!this.ripples[e].isAnimationComplete) return !0;
        return !1;
    },
    simulatedRipple: function() {
        this.downAction(null), this.async(function() {
            this.upAction();
        }, 1);
    },
    uiDownAction: function(e) {
        this.noink || this.downAction(e);
    },
    downAction: function(e) {
        this.holdDown && this.ripples.length > 0 || (this.addRipple().downAction(e), this._animating || (this._animating = !0, 
        this.animate()));
    },
    uiUpAction: function(e) {
        this.noink || this.upAction(e);
    },
    upAction: function(e) {
        this.holdDown || (this.ripples.forEach(function(t) {
            t.upAction(e);
        }), this._animating = !0, this.animate());
    },
    onAnimationComplete: function() {
        this._animating = !1, this.$.background.style.backgroundColor = null, this.fire("transitionend");
    },
    addRipple: function() {
        var e = new Ripple(this);
        return dom(this.$.waves).appendChild(e.waveContainer), this.$.background.style.backgroundColor = e.color, 
        this.ripples.push(e), this._setAnimating(!0), e;
    },
    removeRipple: function(e) {
        var t = this.ripples.indexOf(e);
        t < 0 || (this.ripples.splice(t, 1), e.remove(), this.ripples.length || this._setAnimating(!1));
    },
    animate: function() {
        if (this._animating) {
            var e, t;
            for (e = 0; e < this.ripples.length; ++e) (t = this.ripples[e]).draw(), this.$.background.style.opacity = t.outerOpacity, 
            t.isOpacityFullyDecayed && !t.isRestingAtMaxRadius && this.removeRipple(t);
            this.shouldKeepAnimating || 0 !== this.ripples.length ? window.requestAnimationFrame(this._boundAnimate) : this.onAnimationComplete();
        }
    },
    animateRipple: function() {
        return this.animate();
    },
    _onEnterKeydown: function() {
        this.uiDownAction(), this.async(this.uiUpAction, 1);
    },
    _onSpaceKeydown: function() {
        this.uiDownAction();
    },
    _onSpaceKeyup: function() {
        this.uiUpAction();
    },
    _holdDownChanged: function(e, t) {
        void 0 !== t && (e ? this.downAction() : this.upAction());
    }
});

const PaperRippleBehavior = {
    properties: {
        noink: {
            type: Boolean,
            observer: "_noinkChanged"
        },
        _rippleContainer: {
            type: Object
        }
    },
    _buttonStateChanged: function() {
        this.focused && this.ensureRipple();
    },
    _downHandler: function(e) {
        IronButtonStateImpl._downHandler.call(this, e), this.pressed && this.ensureRipple(e);
    },
    ensureRipple: function(e) {
        if (!this.hasRipple()) {
            this._ripple = this._createRipple(), this._ripple.noink = this.noink;
            var t = this._rippleContainer || this.root;
            if (t && dom(t).appendChild(this._ripple), e) {
                var i = dom(this._rippleContainer || this), o = dom(e).rootTarget;
                i.deepContains(o) && this._ripple.uiDownAction(e);
            }
        }
    },
    getRipple: function() {
        return this.ensureRipple(), this._ripple;
    },
    hasRipple: function() {
        return Boolean(this._ripple);
    },
    _createRipple: function() {
        return document.createElement("paper-ripple");
    },
    _noinkChanged: function(e) {
        this.hasRipple() && (this._ripple.noink = e);
    }
};

var paperRippleBehavior = {
    PaperRippleBehavior: PaperRippleBehavior
};

const PaperButtonBehaviorImpl = {
    properties: {
        elevation: {
            type: Number,
            reflectToAttribute: !0,
            readOnly: !0
        }
    },
    observers: [ "_calculateElevation(focused, disabled, active, pressed, receivedFocusFromKeyboard)", "_computeKeyboardClass(receivedFocusFromKeyboard)" ],
    hostAttributes: {
        role: "button",
        tabindex: "0",
        animated: !0
    },
    _calculateElevation: function() {
        var e = 1;
        this.disabled ? e = 0 : this.active || this.pressed ? e = 4 : this.receivedFocusFromKeyboard && (e = 3), 
        this._setElevation(e);
    },
    _computeKeyboardClass: function(e) {
        this.toggleClass("keyboard-focus", e);
    },
    _spaceKeyDownHandler: function(e) {
        IronButtonStateImpl._spaceKeyDownHandler.call(this, e), this.hasRipple() && this.getRipple().ripples.length < 1 && this._ripple.uiDownAction();
    },
    _spaceKeyUpHandler: function(e) {
        IronButtonStateImpl._spaceKeyUpHandler.call(this, e), this.hasRipple() && this._ripple.uiUpAction();
    }
}, PaperButtonBehavior = [ IronButtonState, IronControlState, PaperRippleBehavior, PaperButtonBehaviorImpl ];

var paperButtonBehavior = {
    PaperButtonBehaviorImpl: PaperButtonBehaviorImpl,
    PaperButtonBehavior: PaperButtonBehavior
};

const template$2 = html$1`
  <style include="paper-material-styles">
    /* Need to specify the same specificity as the styles imported from paper-material. */
    :host {
      @apply --layout-inline;
      @apply --layout-center-center;
      position: relative;
      box-sizing: border-box;
      min-width: 5.14em;
      margin: 0 0.29em;
      background: transparent;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -webkit-tap-highlight-color: transparent;
      font: inherit;
      text-transform: uppercase;
      outline-width: 0;
      border-radius: 3px;
      -moz-user-select: none;
      -ms-user-select: none;
      -webkit-user-select: none;
      user-select: none;
      cursor: pointer;
      z-index: 0;
      padding: 0.7em 0.57em;

      @apply --paper-font-common-base;
      @apply --paper-button;
    }

    :host([elevation="1"]) {
      @apply --paper-material-elevation-1;
    }

    :host([elevation="2"]) {
      @apply --paper-material-elevation-2;
    }

    :host([elevation="3"]) {
      @apply --paper-material-elevation-3;
    }

    :host([elevation="4"]) {
      @apply --paper-material-elevation-4;
    }

    :host([elevation="5"]) {
      @apply --paper-material-elevation-5;
    }

    :host([hidden]) {
      display: none !important;
    }

    :host([raised].keyboard-focus) {
      font-weight: bold;
      @apply --paper-button-raised-keyboard-focus;
    }

    :host(:not([raised]).keyboard-focus) {
      font-weight: bold;
      @apply --paper-button-flat-keyboard-focus;
    }

    :host([disabled]) {
      background: none;
      color: #a8a8a8;
      cursor: auto;
      pointer-events: none;

      @apply --paper-button-disabled;
    }

    :host([disabled][raised]) {
      background: #eaeaea;
    }


    :host([animated]) {
      @apply --shadow-transition;
    }

    paper-ripple {
      color: var(--paper-button-ink-color);
    }
  </style>

  <slot></slot>`;

template$2.setAttribute("strip-whitespace", ""), Polymer({
    _template: template$2,
    is: "paper-button",
    behaviors: [ PaperButtonBehavior ],
    properties: {
        raised: {
            type: Boolean,
            reflectToAttribute: !0,
            value: !1,
            observer: "_calculateElevation"
        }
    },
    _calculateElevation: function() {
        this.raised ? PaperButtonBehaviorImpl._calculateElevation.apply(this) : this._setElevation(0);
    }
});

const IronFitBehavior = {
    properties: {
        sizingTarget: {
            type: Object,
            value: function() {
                return this;
            }
        },
        fitInto: {
            type: Object,
            value: window
        },
        noOverlap: {
            type: Boolean
        },
        positionTarget: {
            type: Element
        },
        horizontalAlign: {
            type: String
        },
        verticalAlign: {
            type: String
        },
        dynamicAlign: {
            type: Boolean
        },
        horizontalOffset: {
            type: Number,
            value: 0,
            notify: !0
        },
        verticalOffset: {
            type: Number,
            value: 0,
            notify: !0
        },
        autoFitOnAttach: {
            type: Boolean,
            value: !1
        },
        _fitInfo: {
            type: Object
        }
    },
    get _fitWidth() {
        return this.fitInto === window ? this.fitInto.innerWidth : this.fitInto.getBoundingClientRect().width;
    },
    get _fitHeight() {
        return this.fitInto === window ? this.fitInto.innerHeight : this.fitInto.getBoundingClientRect().height;
    },
    get _fitLeft() {
        return this.fitInto === window ? 0 : this.fitInto.getBoundingClientRect().left;
    },
    get _fitTop() {
        return this.fitInto === window ? 0 : this.fitInto.getBoundingClientRect().top;
    },
    get _defaultPositionTarget() {
        var e = dom(this).parentNode;
        return e && e.nodeType === Node.DOCUMENT_FRAGMENT_NODE && (e = e.host), e;
    },
    get _localeHorizontalAlign() {
        if (this._isRTL) {
            if ("right" === this.horizontalAlign) return "left";
            if ("left" === this.horizontalAlign) return "right";
        }
        return this.horizontalAlign;
    },
    get __shouldPosition() {
        return (this.horizontalAlign || this.verticalAlign) && this.positionTarget;
    },
    attached: function() {
        void 0 === this._isRTL && (this._isRTL = "rtl" == window.getComputedStyle(this).direction), 
        this.positionTarget = this.positionTarget || this._defaultPositionTarget, this.autoFitOnAttach && ("none" === window.getComputedStyle(this).display ? setTimeout(function() {
            this.fit();
        }.bind(this)) : (window.ShadyDOM && ShadyDOM.flush(), this.fit()));
    },
    detached: function() {
        this.__deferredFit && (clearTimeout(this.__deferredFit), this.__deferredFit = null);
    },
    fit: function() {
        this.position(), this.constrain(), this.center();
    },
    _discoverInfo: function() {
        if (!this._fitInfo) {
            var e = window.getComputedStyle(this), t = window.getComputedStyle(this.sizingTarget);
            this._fitInfo = {
                inlineStyle: {
                    top: this.style.top || "",
                    left: this.style.left || "",
                    position: this.style.position || ""
                },
                sizerInlineStyle: {
                    maxWidth: this.sizingTarget.style.maxWidth || "",
                    maxHeight: this.sizingTarget.style.maxHeight || "",
                    boxSizing: this.sizingTarget.style.boxSizing || ""
                },
                positionedBy: {
                    vertically: "auto" !== e.top ? "top" : "auto" !== e.bottom ? "bottom" : null,
                    horizontally: "auto" !== e.left ? "left" : "auto" !== e.right ? "right" : null
                },
                sizedBy: {
                    height: "none" !== t.maxHeight,
                    width: "none" !== t.maxWidth,
                    minWidth: parseInt(t.minWidth, 10) || 0,
                    minHeight: parseInt(t.minHeight, 10) || 0
                },
                margin: {
                    top: parseInt(e.marginTop, 10) || 0,
                    right: parseInt(e.marginRight, 10) || 0,
                    bottom: parseInt(e.marginBottom, 10) || 0,
                    left: parseInt(e.marginLeft, 10) || 0
                }
            };
        }
    },
    resetFit: function() {
        var e = this._fitInfo || {};
        for (var t in e.sizerInlineStyle) this.sizingTarget.style[t] = e.sizerInlineStyle[t];
        for (var t in e.inlineStyle) this.style[t] = e.inlineStyle[t];
        this._fitInfo = null;
    },
    refit: function() {
        var e = this.sizingTarget.scrollLeft, t = this.sizingTarget.scrollTop;
        this.resetFit(), this.fit(), this.sizingTarget.scrollLeft = e, this.sizingTarget.scrollTop = t;
    },
    position: function() {
        if (this.__shouldPosition) {
            this._discoverInfo(), this.style.position = "fixed", this.sizingTarget.style.boxSizing = "border-box", 
            this.style.left = "0px", this.style.top = "0px";
            var e = this.getBoundingClientRect(), t = this.__getNormalizedRect(this.positionTarget), i = this.__getNormalizedRect(this.fitInto), o = this._fitInfo.margin, n = {
                width: e.width + o.left + o.right,
                height: e.height + o.top + o.bottom
            }, a = this.__getPosition(this._localeHorizontalAlign, this.verticalAlign, n, e, t, i), r = a.left + o.left, s = a.top + o.top, l = Math.min(i.right - o.right, r + e.width), c = Math.min(i.bottom - o.bottom, s + e.height);
            r = Math.max(i.left + o.left, Math.min(r, l - this._fitInfo.sizedBy.minWidth)), 
            s = Math.max(i.top + o.top, Math.min(s, c - this._fitInfo.sizedBy.minHeight)), this.sizingTarget.style.maxWidth = Math.max(l - r, this._fitInfo.sizedBy.minWidth) + "px", 
            this.sizingTarget.style.maxHeight = Math.max(c - s, this._fitInfo.sizedBy.minHeight) + "px", 
            this.style.left = r - e.left + "px", this.style.top = s - e.top + "px";
        }
    },
    constrain: function() {
        if (!this.__shouldPosition) {
            this._discoverInfo();
            var e = this._fitInfo;
            e.positionedBy.vertically || (this.style.position = "fixed", this.style.top = "0px"), 
            e.positionedBy.horizontally || (this.style.position = "fixed", this.style.left = "0px"), 
            this.sizingTarget.style.boxSizing = "border-box";
            var t = this.getBoundingClientRect();
            e.sizedBy.height || this.__sizeDimension(t, e.positionedBy.vertically, "top", "bottom", "Height"), 
            e.sizedBy.width || this.__sizeDimension(t, e.positionedBy.horizontally, "left", "right", "Width");
        }
    },
    _sizeDimension: function(e, t, i, o, n) {
        this.__sizeDimension(e, t, i, o, n);
    },
    __sizeDimension: function(e, t, i, o, n) {
        var a = this._fitInfo, r = this.__getNormalizedRect(this.fitInto), s = "Width" === n ? r.width : r.height, l = t === o, c = l ? s - e[o] : e[i], p = a.margin[l ? i : o], d = "offset" + n, h = this[d] - this.sizingTarget[d];
        this.sizingTarget.style["max" + n] = s - p - c - h + "px";
    },
    center: function() {
        if (!this.__shouldPosition) {
            this._discoverInfo();
            var e = this._fitInfo.positionedBy;
            if (!e.vertically || !e.horizontally) {
                this.style.position = "fixed", e.vertically || (this.style.top = "0px"), e.horizontally || (this.style.left = "0px");
                var t = this.getBoundingClientRect(), i = this.__getNormalizedRect(this.fitInto);
                if (!e.vertically) {
                    var o = i.top - t.top + (i.height - t.height) / 2;
                    this.style.top = o + "px";
                }
                if (!e.horizontally) {
                    var n = i.left - t.left + (i.width - t.width) / 2;
                    this.style.left = n + "px";
                }
            }
        }
    },
    __getNormalizedRect: function(e) {
        return e === document.documentElement || e === window ? {
            top: 0,
            left: 0,
            width: window.innerWidth,
            height: window.innerHeight,
            right: window.innerWidth,
            bottom: window.innerHeight
        } : e.getBoundingClientRect();
    },
    __getOffscreenArea: function(e, t, i) {
        var o = Math.min(0, e.top) + Math.min(0, i.bottom - (e.top + t.height)), n = Math.min(0, e.left) + Math.min(0, i.right - (e.left + t.width));
        return Math.abs(o) * t.width + Math.abs(n) * t.height;
    },
    __getPosition: function(e, t, i, o, n, a) {
        var r, s = [ {
            verticalAlign: "top",
            horizontalAlign: "left",
            top: n.top + this.verticalOffset,
            left: n.left + this.horizontalOffset
        }, {
            verticalAlign: "top",
            horizontalAlign: "right",
            top: n.top + this.verticalOffset,
            left: n.right - i.width - this.horizontalOffset
        }, {
            verticalAlign: "bottom",
            horizontalAlign: "left",
            top: n.bottom - i.height - this.verticalOffset,
            left: n.left + this.horizontalOffset
        }, {
            verticalAlign: "bottom",
            horizontalAlign: "right",
            top: n.bottom - i.height - this.verticalOffset,
            left: n.right - i.width - this.horizontalOffset
        } ];
        if (this.noOverlap) {
            for (var l = 0, c = s.length; l < c; l++) {
                var p = {};
                for (var d in s[l]) p[d] = s[l][d];
                s.push(p);
            }
            s[0].top = s[1].top += n.height, s[2].top = s[3].top -= n.height, s[4].left = s[6].left += n.width, 
            s[5].left = s[7].left -= n.width;
        }
        t = "auto" === t ? null : t, (e = "auto" === e ? null : e) && "center" !== e || (s.push({
            verticalAlign: "top",
            horizontalAlign: "center",
            top: n.top + this.verticalOffset + (this.noOverlap ? n.height : 0),
            left: n.left - o.width / 2 + n.width / 2 + this.horizontalOffset
        }), s.push({
            verticalAlign: "bottom",
            horizontalAlign: "center",
            top: n.bottom - i.height - this.verticalOffset - (this.noOverlap ? n.height : 0),
            left: n.left - o.width / 2 + n.width / 2 + this.horizontalOffset
        })), t && "middle" !== t || (s.push({
            verticalAlign: "middle",
            horizontalAlign: "left",
            top: n.top - o.height / 2 + n.height / 2 + this.verticalOffset,
            left: n.left + this.horizontalOffset + (this.noOverlap ? n.width : 0)
        }), s.push({
            verticalAlign: "middle",
            horizontalAlign: "right",
            top: n.top - o.height / 2 + n.height / 2 + this.verticalOffset,
            left: n.right - i.width - this.horizontalOffset - (this.noOverlap ? n.width : 0)
        })), "middle" === t && "center" === e && s.push({
            verticalAlign: "middle",
            horizontalAlign: "center",
            top: n.top - o.height / 2 + n.height / 2 + this.verticalOffset,
            left: n.left - o.width / 2 + n.width / 2 + this.horizontalOffset
        });
        for (l = 0; l < s.length; l++) {
            var h = s[l], u = h.verticalAlign === t, m = h.horizontalAlign === e;
            if (!this.dynamicAlign && !this.noOverlap && u && m) {
                r = h;
                break;
            }
            var g = (!t || u) && (!e || m);
            if (this.dynamicAlign || g) {
                if (h.offscreenArea = this.__getOffscreenArea(h, i, a), 0 === h.offscreenArea && g) {
                    r = h;
                    break;
                }
                r = r || h;
                var f = h.offscreenArea - r.offscreenArea;
                (f < 0 || 0 === f && (u || m)) && (r = h);
            }
        }
        return r;
    }
};

var ironFitBehavior = {
    IronFitBehavior: IronFitBehavior
}, p = Element.prototype, matches = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector;

const IronFocusablesHelper = {
    getTabbableNodes: function(e) {
        var t = [];
        return this._collectTabbableNodes(e, t) ? this._sortByTabIndex(t) : t;
    },
    isFocusable: function(e) {
        return matches.call(e, "input, select, textarea, button, object") ? matches.call(e, ":not([disabled])") : matches.call(e, "a[href], area[href], iframe, [tabindex], [contentEditable]");
    },
    isTabbable: function(e) {
        return this.isFocusable(e) && matches.call(e, ':not([tabindex="-1"])') && this._isVisible(e);
    },
    _normalizedTabIndex: function(e) {
        if (this.isFocusable(e)) {
            var t = e.getAttribute("tabindex") || 0;
            return Number(t);
        }
        return -1;
    },
    _collectTabbableNodes: function(e, t) {
        if (e.nodeType !== Node.ELEMENT_NODE || !this._isVisible(e)) return !1;
        var i, o = e, n = this._normalizedTabIndex(o), a = n > 0;
        n >= 0 && t.push(o), i = "content" === o.localName || "slot" === o.localName ? dom(o).getDistributedNodes() : dom(o.root || o).children;
        for (var r = 0; r < i.length; r++) a = this._collectTabbableNodes(i[r], t) || a;
        return a;
    },
    _isVisible: function(e) {
        var t = e.style;
        return "hidden" !== t.visibility && "none" !== t.display && ("hidden" !== (t = window.getComputedStyle(e)).visibility && "none" !== t.display);
    },
    _sortByTabIndex: function(e) {
        var t = e.length;
        if (t < 2) return e;
        var i = Math.ceil(t / 2), o = this._sortByTabIndex(e.slice(0, i)), n = this._sortByTabIndex(e.slice(i));
        return this._mergeSortByTabIndex(o, n);
    },
    _mergeSortByTabIndex: function(e, t) {
        for (var i = []; e.length > 0 && t.length > 0; ) this._hasLowerTabOrder(e[0], t[0]) ? i.push(t.shift()) : i.push(e.shift());
        return i.concat(e, t);
    },
    _hasLowerTabOrder: function(e, t) {
        var i = Math.max(e.tabIndex, 0), o = Math.max(t.tabIndex, 0);
        return 0 === i || 0 === o ? o > i : i > o;
    }
};

var ironFocusablesHelper = {
    IronFocusablesHelper: IronFocusablesHelper
};

Polymer({
    _template: html`
    <style>
      :host {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: var(--iron-overlay-backdrop-background-color, #000);
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
        @apply --iron-overlay-backdrop;
      }

      :host(.opened) {
        opacity: var(--iron-overlay-backdrop-opacity, 0.6);
        pointer-events: auto;
        @apply --iron-overlay-backdrop-opened;
      }
    </style>

    <slot></slot>
`,
    is: "iron-overlay-backdrop",
    properties: {
        opened: {
            reflectToAttribute: !0,
            type: Boolean,
            value: !1,
            observer: "_openedChanged"
        }
    },
    listeners: {
        transitionend: "_onTransitionend"
    },
    created: function() {
        this.__openedRaf = null;
    },
    attached: function() {
        this.opened && this._openedChanged(this.opened);
    },
    prepare: function() {
        this.opened && !this.parentNode && dom(document.body).appendChild(this);
    },
    open: function() {
        this.opened = !0;
    },
    close: function() {
        this.opened = !1;
    },
    complete: function() {
        this.opened || this.parentNode !== document.body || dom(this.parentNode).removeChild(this);
    },
    _onTransitionend: function(e) {
        e && e.target === this && this.complete();
    },
    _openedChanged: function(e) {
        if (e) this.prepare(); else {
            var t = window.getComputedStyle(this);
            "0s" !== t.transitionDuration && 0 != t.opacity || this.complete();
        }
        this.isAttached && (this.__openedRaf && (window.cancelAnimationFrame(this.__openedRaf), 
        this.__openedRaf = null), this.scrollTop = this.scrollTop, this.__openedRaf = window.requestAnimationFrame(function() {
            this.__openedRaf = null, this.toggleClass("opened", this.opened);
        }.bind(this)));
    }
});

const IronOverlayManagerClass = function() {
    this._overlays = [], this._minimumZ = 101, this._backdropElement = null, add(document.documentElement, "tap", function() {}), 
    document.addEventListener("tap", this._onCaptureClick.bind(this), !0), document.addEventListener("focus", this._onCaptureFocus.bind(this), !0), 
    document.addEventListener("keydown", this._onCaptureKeyDown.bind(this), !0);
};

IronOverlayManagerClass.prototype = {
    constructor: IronOverlayManagerClass,
    get backdropElement() {
        return this._backdropElement || (this._backdropElement = document.createElement("iron-overlay-backdrop")), 
        this._backdropElement;
    },
    get deepActiveElement() {
        var e = document.activeElement;
        for (e && e instanceof Element != !1 || (e = document.body); e.root && dom(e.root).activeElement; ) e = dom(e.root).activeElement;
        return e;
    },
    _bringOverlayAtIndexToFront: function(e) {
        var t = this._overlays[e];
        if (t) {
            var i = this._overlays.length - 1, o = this._overlays[i];
            if (o && this._shouldBeBehindOverlay(t, o) && i--, !(e >= i)) {
                var n = Math.max(this.currentOverlayZ(), this._minimumZ);
                for (this._getZ(t) <= n && this._applyOverlayZ(t, n); e < i; ) this._overlays[e] = this._overlays[e + 1], 
                e++;
                this._overlays[i] = t;
            }
        }
    },
    addOrRemoveOverlay: function(e) {
        e.opened ? this.addOverlay(e) : this.removeOverlay(e);
    },
    addOverlay: function(e) {
        var t = this._overlays.indexOf(e);
        if (t >= 0) return this._bringOverlayAtIndexToFront(t), void this.trackBackdrop();
        var i = this._overlays.length, o = this._overlays[i - 1], n = Math.max(this._getZ(o), this._minimumZ), a = this._getZ(e);
        if (o && this._shouldBeBehindOverlay(e, o)) {
            this._applyOverlayZ(o, n), i--;
            var r = this._overlays[i - 1];
            n = Math.max(this._getZ(r), this._minimumZ);
        }
        a <= n && this._applyOverlayZ(e, n), this._overlays.splice(i, 0, e), this.trackBackdrop();
    },
    removeOverlay: function(e) {
        var t = this._overlays.indexOf(e);
        -1 !== t && (this._overlays.splice(t, 1), this.trackBackdrop());
    },
    currentOverlay: function() {
        var e = this._overlays.length - 1;
        return this._overlays[e];
    },
    currentOverlayZ: function() {
        return this._getZ(this.currentOverlay());
    },
    ensureMinimumZ: function(e) {
        this._minimumZ = Math.max(this._minimumZ, e);
    },
    focusOverlay: function() {
        var e = this.currentOverlay();
        e && e._applyFocus();
    },
    trackBackdrop: function() {
        var e = this._overlayWithBackdrop();
        (e || this._backdropElement) && (this.backdropElement.style.zIndex = this._getZ(e) - 1, 
        this.backdropElement.opened = !!e, this.backdropElement.prepare());
    },
    getBackdrops: function() {
        for (var e = [], t = 0; t < this._overlays.length; t++) this._overlays[t].withBackdrop && e.push(this._overlays[t]);
        return e;
    },
    backdropZ: function() {
        return this._getZ(this._overlayWithBackdrop()) - 1;
    },
    _overlayWithBackdrop: function() {
        for (var e = this._overlays.length - 1; e >= 0; e--) if (this._overlays[e].withBackdrop) return this._overlays[e];
    },
    _getZ: function(e) {
        var t = this._minimumZ;
        if (e) {
            var i = Number(e.style.zIndex || window.getComputedStyle(e).zIndex);
            i == i && (t = i);
        }
        return t;
    },
    _setZ: function(e, t) {
        e.style.zIndex = t;
    },
    _applyOverlayZ: function(e, t) {
        this._setZ(e, t + 2);
    },
    _overlayInPath: function(e) {
        e = e || [];
        for (var t = 0; t < e.length; t++) if (e[t]._manager === this) return e[t];
    },
    _onCaptureClick: function(e) {
        var t = this._overlays.length - 1;
        if (-1 !== t) for (var i, o = dom(e).path; (i = this._overlays[t]) && this._overlayInPath(o) !== i && (i._onCaptureClick(e), 
        i.allowClickThrough); ) t--;
    },
    _onCaptureFocus: function(e) {
        var t = this.currentOverlay();
        t && t._onCaptureFocus(e);
    },
    _onCaptureKeyDown: function(e) {
        var t = this.currentOverlay();
        t && (IronA11yKeysBehavior.keyboardEventMatchesKeys(e, "esc") ? t._onCaptureEsc(e) : IronA11yKeysBehavior.keyboardEventMatchesKeys(e, "tab") && t._onCaptureTab(e));
    },
    _shouldBeBehindOverlay: function(e, t) {
        return !e.alwaysOnTop && t.alwaysOnTop;
    }
};

const IronOverlayManager = new IronOverlayManagerClass();

var _boundScrollHandler, currentLockingElement, ironOverlayManager = {
    IronOverlayManagerClass: IronOverlayManagerClass,
    IronOverlayManager: IronOverlayManager
}, lastTouchPosition = {
    pageX: 0,
    pageY: 0
}, lastRootTarget = null, lastScrollableNodes = [], scrollEvents = [ "wheel", "mousewheel", "DOMMouseScroll", "touchstart", "touchmove" ];

function elementIsScrollLocked(e) {
    var t, i = currentLockingElement;
    return void 0 !== i && (!!_hasCachedLockedElement(e) || !_hasCachedUnlockedElement(e) && ((t = !!i && i !== e && !_composedTreeContains(i, e)) ? _lockedElementCache.push(e) : _unlockedElementCache.push(e), 
    t));
}

function pushScrollLock(e) {
    _lockingElements.indexOf(e) >= 0 || (0 === _lockingElements.length && _lockScrollInteractions(), 
    _lockingElements.push(e), currentLockingElement = _lockingElements[_lockingElements.length - 1], 
    _lockedElementCache = [], _unlockedElementCache = []);
}

function removeScrollLock(e) {
    var t = _lockingElements.indexOf(e);
    -1 !== t && (_lockingElements.splice(t, 1), currentLockingElement = _lockingElements[_lockingElements.length - 1], 
    _lockedElementCache = [], _unlockedElementCache = [], 0 === _lockingElements.length && _unlockScrollInteractions());
}

const _lockingElements = [];

let _lockedElementCache = null, _unlockedElementCache = null;

function _hasCachedLockedElement(e) {
    return _lockedElementCache.indexOf(e) > -1;
}

function _hasCachedUnlockedElement(e) {
    return _unlockedElementCache.indexOf(e) > -1;
}

function _composedTreeContains(e, t) {
    var i, o, n, a;
    if (e.contains(t)) return !0;
    for (i = dom(e).querySelectorAll("content,slot"), n = 0; n < i.length; ++n) for (o = dom(i[n]).getDistributedNodes(), 
    a = 0; a < o.length; ++a) if (o[a].nodeType === Node.ELEMENT_NODE && _composedTreeContains(o[a], t)) return !0;
    return !1;
}

function _scrollInteractionHandler(e) {
    if (e.cancelable && _shouldPreventScrolling(e) && e.preventDefault(), e.targetTouches) {
        var t = e.targetTouches[0];
        lastTouchPosition.pageX = t.pageX, lastTouchPosition.pageY = t.pageY;
    }
}

function _lockScrollInteractions() {
    _boundScrollHandler = _boundScrollHandler || _scrollInteractionHandler.bind(void 0);
    for (var e = 0, t = scrollEvents.length; e < t; e++) document.addEventListener(scrollEvents[e], _boundScrollHandler, {
        capture: !0,
        passive: !1
    });
}

function _unlockScrollInteractions() {
    for (var e = 0, t = scrollEvents.length; e < t; e++) document.removeEventListener(scrollEvents[e], _boundScrollHandler, {
        capture: !0,
        passive: !1
    });
}

function _shouldPreventScrolling(e) {
    var t = dom(e).rootTarget;
    if ("touchmove" !== e.type && lastRootTarget !== t && (lastRootTarget = t, lastScrollableNodes = _getScrollableNodes(dom(e).path)), 
    !lastScrollableNodes.length) return !0;
    if ("touchstart" === e.type) return !1;
    var i = _getScrollInfo(e);
    return !_getScrollingNode(lastScrollableNodes, i.deltaX, i.deltaY);
}

function _getScrollableNodes(e) {
    for (var t = [], i = e.indexOf(currentLockingElement), o = 0; o <= i; o++) if (e[o].nodeType === Node.ELEMENT_NODE) {
        var n = e[o], a = n.style;
        "scroll" !== a.overflow && "auto" !== a.overflow && (a = window.getComputedStyle(n)), 
        "scroll" !== a.overflow && "auto" !== a.overflow || t.push(n);
    }
    return t;
}

function _getScrollingNode(e, t, i) {
    if (t || i) for (var o = Math.abs(i) >= Math.abs(t), n = 0; n < e.length; n++) {
        var a = e[n];
        if (o ? i < 0 ? a.scrollTop > 0 : a.scrollTop < a.scrollHeight - a.clientHeight : t < 0 ? a.scrollLeft > 0 : a.scrollLeft < a.scrollWidth - a.clientWidth) return a;
    }
}

function _getScrollInfo(e) {
    var t = {
        deltaX: e.deltaX,
        deltaY: e.deltaY
    };
    if ("deltaX" in e) ; else if ("wheelDeltaX" in e && "wheelDeltaY" in e) t.deltaX = -e.wheelDeltaX, 
    t.deltaY = -e.wheelDeltaY; else if ("wheelDelta" in e) t.deltaX = 0, t.deltaY = -e.wheelDelta; else if ("axis" in e) t.deltaX = 1 === e.axis ? e.detail : 0, 
    t.deltaY = 2 === e.axis ? e.detail : 0; else if (e.targetTouches) {
        var i = e.targetTouches[0];
        t.deltaX = lastTouchPosition.pageX - i.pageX, t.deltaY = lastTouchPosition.pageY - i.pageY;
    }
    return t;
}

var ironScrollManager = {
    get currentLockingElement() {
        return currentLockingElement;
    },
    elementIsScrollLocked: elementIsScrollLocked,
    pushScrollLock: pushScrollLock,
    removeScrollLock: removeScrollLock,
    _lockingElements: _lockingElements,
    get _lockedElementCache() {
        return _lockedElementCache;
    },
    get _unlockedElementCache() {
        return _unlockedElementCache;
    },
    _hasCachedLockedElement: _hasCachedLockedElement,
    _hasCachedUnlockedElement: _hasCachedUnlockedElement,
    _composedTreeContains: _composedTreeContains,
    _scrollInteractionHandler: _scrollInteractionHandler,
    get _boundScrollHandler() {
        return _boundScrollHandler;
    },
    _lockScrollInteractions: _lockScrollInteractions,
    _unlockScrollInteractions: _unlockScrollInteractions,
    _shouldPreventScrolling: _shouldPreventScrolling,
    _getScrollableNodes: _getScrollableNodes,
    _getScrollingNode: _getScrollingNode,
    _getScrollInfo: _getScrollInfo
};

const IronOverlayBehaviorImpl = {
    properties: {
        opened: {
            observer: "_openedChanged",
            type: Boolean,
            value: !1,
            notify: !0
        },
        canceled: {
            observer: "_canceledChanged",
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        withBackdrop: {
            observer: "_withBackdropChanged",
            type: Boolean
        },
        noAutoFocus: {
            type: Boolean,
            value: !1
        },
        noCancelOnEscKey: {
            type: Boolean,
            value: !1
        },
        noCancelOnOutsideClick: {
            type: Boolean,
            value: !1
        },
        closingReason: {
            type: Object
        },
        restoreFocusOnClose: {
            type: Boolean,
            value: !1
        },
        allowClickThrough: {
            type: Boolean
        },
        alwaysOnTop: {
            type: Boolean
        },
        scrollAction: {
            type: String
        },
        _manager: {
            type: Object,
            value: IronOverlayManager
        },
        _focusedChild: {
            type: Object
        }
    },
    listeners: {
        "iron-resize": "_onIronResize"
    },
    observers: [ "__updateScrollObservers(isAttached, opened, scrollAction)" ],
    get backdropElement() {
        return this._manager.backdropElement;
    },
    get _focusNode() {
        return this._focusedChild || dom(this).querySelector("[autofocus]") || this;
    },
    get _focusableNodes() {
        return IronFocusablesHelper.getTabbableNodes(this);
    },
    ready: function() {
        this.__isAnimating = !1, this.__shouldRemoveTabIndex = !1, this.__firstFocusableNode = this.__lastFocusableNode = null, 
        this.__rafs = {}, this.__restoreFocusNode = null, this.__scrollTop = this.__scrollLeft = null, 
        this.__onCaptureScroll = this.__onCaptureScroll.bind(this), this.__rootNodes = null, 
        this._ensureSetup();
    },
    attached: function() {
        this.opened && this._openedChanged(this.opened), this._observer = dom(this).observeNodes(this._onNodesChange);
    },
    detached: function() {
        for (var e in dom(this).unobserveNodes(this._observer), this._observer = null, this.__rafs) null !== this.__rafs[e] && cancelAnimationFrame(this.__rafs[e]);
        this.__rafs = {}, this._manager.removeOverlay(this), this.__isAnimating && (this.opened ? this._finishRenderOpened() : (this._applyFocus(), 
        this._finishRenderClosed()));
    },
    toggle: function() {
        this._setCanceled(!1), this.opened = !this.opened;
    },
    open: function() {
        this._setCanceled(!1), this.opened = !0;
    },
    close: function() {
        this._setCanceled(!1), this.opened = !1;
    },
    cancel: function(e) {
        this.fire("iron-overlay-canceled", e, {
            cancelable: !0
        }).defaultPrevented || (this._setCanceled(!0), this.opened = !1);
    },
    invalidateTabbables: function() {
        this.__firstFocusableNode = this.__lastFocusableNode = null;
    },
    _ensureSetup: function() {
        this._overlaySetup || (this._overlaySetup = !0, this.style.outline = "none", this.style.display = "none");
    },
    _openedChanged: function(e) {
        e ? this.removeAttribute("aria-hidden") : this.setAttribute("aria-hidden", "true"), 
        this.isAttached && (this.__isAnimating = !0, this.__deraf("__openedChanged", this.__openedChanged));
    },
    _canceledChanged: function() {
        this.closingReason = this.closingReason || {}, this.closingReason.canceled = this.canceled;
    },
    _withBackdropChanged: function() {
        this.withBackdrop && !this.hasAttribute("tabindex") ? (this.setAttribute("tabindex", "-1"), 
        this.__shouldRemoveTabIndex = !0) : this.__shouldRemoveTabIndex && (this.removeAttribute("tabindex"), 
        this.__shouldRemoveTabIndex = !1), this.opened && this.isAttached && this._manager.trackBackdrop();
    },
    _prepareRenderOpened: function() {
        this.__restoreFocusNode = this._manager.deepActiveElement, this._preparePositioning(), 
        this.refit(), this._finishPositioning(), this.noAutoFocus && document.activeElement === this._focusNode && (this._focusNode.blur(), 
        this.__restoreFocusNode.focus());
    },
    _renderOpened: function() {
        this._finishRenderOpened();
    },
    _renderClosed: function() {
        this._finishRenderClosed();
    },
    _finishRenderOpened: function() {
        this.notifyResize(), this.__isAnimating = !1, this.fire("iron-overlay-opened");
    },
    _finishRenderClosed: function() {
        this.style.display = "none", this.style.zIndex = "", this.notifyResize(), this.__isAnimating = !1, 
        this.fire("iron-overlay-closed", this.closingReason);
    },
    _preparePositioning: function() {
        this.style.transition = this.style.webkitTransition = "none", this.style.transform = this.style.webkitTransform = "none", 
        this.style.display = "";
    },
    _finishPositioning: function() {
        this.style.display = "none", this.scrollTop = this.scrollTop, this.style.transition = this.style.webkitTransition = "", 
        this.style.transform = this.style.webkitTransform = "", this.style.display = "", 
        this.scrollTop = this.scrollTop;
    },
    _applyFocus: function() {
        if (this.opened) this.noAutoFocus || this._focusNode.focus(); else {
            if (this.restoreFocusOnClose && this.__restoreFocusNode) {
                var e = this._manager.deepActiveElement;
                (e === document.body || dom(this).deepContains(e)) && this.__restoreFocusNode.focus();
            }
            this.__restoreFocusNode = null, this._focusNode.blur(), this._focusedChild = null;
        }
    },
    _onCaptureClick: function(e) {
        this.noCancelOnOutsideClick || this.cancel(e);
    },
    _onCaptureFocus: function(e) {
        if (this.withBackdrop) {
            var t = dom(e).path;
            -1 === t.indexOf(this) ? (e.stopPropagation(), this._applyFocus()) : this._focusedChild = t[0];
        }
    },
    _onCaptureEsc: function(e) {
        this.noCancelOnEscKey || this.cancel(e);
    },
    _onCaptureTab: function(e) {
        if (this.withBackdrop) {
            this.__ensureFirstLastFocusables();
            var t = e.shiftKey, i = t ? this.__firstFocusableNode : this.__lastFocusableNode, o = t ? this.__lastFocusableNode : this.__firstFocusableNode, n = !1;
            if (i === o) n = !0; else {
                var a = this._manager.deepActiveElement;
                n = a === i || a === this;
            }
            n && (e.preventDefault(), this._focusedChild = o, this._applyFocus());
        }
    },
    _onIronResize: function() {
        this.opened && !this.__isAnimating && this.__deraf("refit", this.refit);
    },
    _onNodesChange: function() {
        this.opened && !this.__isAnimating && (this.invalidateTabbables(), this.notifyResize());
    },
    __ensureFirstLastFocusables: function() {
        var e = this._focusableNodes;
        this.__firstFocusableNode = e[0], this.__lastFocusableNode = e[e.length - 1];
    },
    __openedChanged: function() {
        this.opened ? (this._prepareRenderOpened(), this._manager.addOverlay(this), this._applyFocus(), 
        this._renderOpened()) : (this._manager.removeOverlay(this), this._applyFocus(), 
        this._renderClosed());
    },
    __deraf: function(e, t) {
        var i = this.__rafs;
        null !== i[e] && cancelAnimationFrame(i[e]), i[e] = requestAnimationFrame(function() {
            i[e] = null, t.call(this);
        }.bind(this));
    },
    __updateScrollObservers: function(e, t, i) {
        e && t && this.__isValidScrollAction(i) ? ("lock" === i && (this.__saveScrollPosition(), 
        pushScrollLock(this)), this.__addScrollListeners()) : (removeScrollLock(this), this.__removeScrollListeners());
    },
    __addScrollListeners: function() {
        if (!this.__rootNodes) {
            if (this.__rootNodes = [], useShadow) for (var e = this; e; ) e.nodeType === Node.DOCUMENT_FRAGMENT_NODE && e.host && this.__rootNodes.push(e), 
            e = e.host || e.assignedSlot || e.parentNode;
            this.__rootNodes.push(document);
        }
        this.__rootNodes.forEach(function(e) {
            e.addEventListener("scroll", this.__onCaptureScroll, {
                capture: !0,
                passive: !0
            });
        }, this);
    },
    __removeScrollListeners: function() {
        this.__rootNodes && this.__rootNodes.forEach(function(e) {
            e.removeEventListener("scroll", this.__onCaptureScroll, {
                capture: !0,
                passive: !0
            });
        }, this), this.isAttached || (this.__rootNodes = null);
    },
    __isValidScrollAction: function(e) {
        return "lock" === e || "refit" === e || "cancel" === e;
    },
    __onCaptureScroll: function(e) {
        if (!(this.__isAnimating || dom(e).path.indexOf(this) >= 0)) switch (this.scrollAction) {
          case "lock":
            this.__restoreScrollPosition();
            break;

          case "refit":
            this.__deraf("refit", this.refit);
            break;

          case "cancel":
            this.cancel(e);
        }
    },
    __saveScrollPosition: function() {
        document.scrollingElement ? (this.__scrollTop = document.scrollingElement.scrollTop, 
        this.__scrollLeft = document.scrollingElement.scrollLeft) : (this.__scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop), 
        this.__scrollLeft = Math.max(document.documentElement.scrollLeft, document.body.scrollLeft));
    },
    __restoreScrollPosition: function() {
        document.scrollingElement ? (document.scrollingElement.scrollTop = this.__scrollTop, 
        document.scrollingElement.scrollLeft = this.__scrollLeft) : (document.documentElement.scrollTop = document.body.scrollTop = this.__scrollTop, 
        document.documentElement.scrollLeft = document.body.scrollLeft = this.__scrollLeft);
    }
}, IronOverlayBehavior = [ IronFitBehavior, IronResizableBehavior, IronOverlayBehaviorImpl ];

var ironOverlayBehavior = {
    IronOverlayBehaviorImpl: IronOverlayBehaviorImpl,
    IronOverlayBehavior: IronOverlayBehavior
};

const PaperDialogBehaviorImpl = {
    hostAttributes: {
        role: "dialog",
        tabindex: "-1"
    },
    properties: {
        modal: {
            type: Boolean,
            value: !1
        },
        __readied: {
            type: Boolean,
            value: !1
        }
    },
    observers: [ "_modalChanged(modal, __readied)" ],
    listeners: {
        tap: "_onDialogClick"
    },
    ready: function() {
        this.__prevNoCancelOnOutsideClick = this.noCancelOnOutsideClick, this.__prevNoCancelOnEscKey = this.noCancelOnEscKey, 
        this.__prevWithBackdrop = this.withBackdrop, this.__readied = !0;
    },
    _modalChanged: function(e, t) {
        t && (e ? (this.__prevNoCancelOnOutsideClick = this.noCancelOnOutsideClick, this.__prevNoCancelOnEscKey = this.noCancelOnEscKey, 
        this.__prevWithBackdrop = this.withBackdrop, this.noCancelOnOutsideClick = !0, this.noCancelOnEscKey = !0, 
        this.withBackdrop = !0) : (this.noCancelOnOutsideClick = this.noCancelOnOutsideClick && this.__prevNoCancelOnOutsideClick, 
        this.noCancelOnEscKey = this.noCancelOnEscKey && this.__prevNoCancelOnEscKey, this.withBackdrop = this.withBackdrop && this.__prevWithBackdrop));
    },
    _updateClosingReasonConfirmed: function(e) {
        this.closingReason = this.closingReason || {}, this.closingReason.confirmed = e;
    },
    _onDialogClick: function(e) {
        for (var t = dom(e).path, i = 0, o = t.indexOf(this); i < o; i++) {
            var n = t[i];
            if (n.hasAttribute && (n.hasAttribute("dialog-dismiss") || n.hasAttribute("dialog-confirm"))) {
                this._updateClosingReasonConfirmed(n.hasAttribute("dialog-confirm")), this.close(), 
                e.stopPropagation();
                break;
            }
        }
    }
}, PaperDialogBehavior = [ IronOverlayBehavior, PaperDialogBehaviorImpl ];

var paperDialogBehavior = {
    PaperDialogBehaviorImpl: PaperDialogBehaviorImpl,
    PaperDialogBehavior: PaperDialogBehavior
};

Polymer({
    _template: html`
    <style>

      :host {
        display: block;
        @apply --layout-relative;
      }

      :host(.is-scrolled:not(:first-child))::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      :host(.can-scroll:not(.scrolled-to-bottom):not(:last-child))::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      .scrollable {
        padding: 0 24px;

        @apply --layout-scroll;
        @apply --paper-dialog-scrollable;
      }

      .fit {
        @apply --layout-fit;
      }
    </style>

    <div id="scrollable" class="scrollable" on-scroll="updateScrollState">
      <slot></slot>
    </div>
`,
    is: "paper-dialog-scrollable",
    properties: {
        dialogElement: {
            type: Object
        }
    },
    get scrollTarget() {
        return this.$.scrollable;
    },
    ready: function() {
        this._ensureTarget(), this.classList.add("no-padding");
    },
    attached: function() {
        this._ensureTarget(), requestAnimationFrame(this.updateScrollState.bind(this));
    },
    updateScrollState: function() {
        this.toggleClass("is-scrolled", this.scrollTarget.scrollTop > 0), this.toggleClass("can-scroll", this.scrollTarget.offsetHeight < this.scrollTarget.scrollHeight), 
        this.toggleClass("scrolled-to-bottom", this.scrollTarget.scrollTop + this.scrollTarget.offsetHeight >= this.scrollTarget.scrollHeight);
    },
    _ensureTarget: function() {
        this.dialogElement = this.dialogElement || this.parentElement, this.dialogElement && this.dialogElement.behaviors && this.dialogElement.behaviors.indexOf(PaperDialogBehaviorImpl) >= 0 ? (this.dialogElement.sizingTarget = this.scrollTarget, 
        this.scrollTarget.classList.remove("fit")) : this.dialogElement && this.scrollTarget.classList.add("fit");
    }
});

const $_documentContainer = document.createElement("template");

$_documentContainer.setAttribute("style", "display: none;"), $_documentContainer.innerHTML = '<dom-module id="paper-dialog-shared-styles">\n  <template>\n    <style>\n      :host {\n        display: block;\n        margin: 24px 40px;\n\n        background: var(--paper-dialog-background-color, var(--primary-background-color));\n        color: var(--paper-dialog-color, var(--primary-text-color));\n\n        @apply --paper-font-body1;\n        @apply --shadow-elevation-16dp;\n        @apply --paper-dialog;\n      }\n\n      :host > ::slotted(*) {\n        margin-top: 20px;\n        padding: 0 24px;\n      }\n\n      :host > ::slotted(.no-padding) {\n        padding: 0;\n      }\n\n      \n      :host > ::slotted(*:first-child) {\n        margin-top: 24px;\n      }\n\n      :host > ::slotted(*:last-child) {\n        margin-bottom: 24px;\n      }\n\n      /* In 1.x, this selector was `:host > ::content h2`. In 2.x <slot> allows\n      to select direct children only, which increases the weight of this\n      selector, so we have to re-define first-child/last-child margins below. */\n      :host > ::slotted(h2) {\n        position: relative;\n        margin: 0;\n\n        @apply --paper-font-title;\n        @apply --paper-dialog-title;\n      }\n\n      /* Apply mixin again, in case it sets margin-top. */\n      :host > ::slotted(h2:first-child) {\n        margin-top: 24px;\n        @apply --paper-dialog-title;\n      }\n\n      /* Apply mixin again, in case it sets margin-bottom. */\n      :host > ::slotted(h2:last-child) {\n        margin-bottom: 24px;\n        @apply --paper-dialog-title;\n      }\n\n      :host > ::slotted(.paper-dialog-buttons),\n      :host > ::slotted(.buttons) {\n        position: relative;\n        padding: 8px 8px 8px 24px;\n        margin: 0;\n\n        color: var(--paper-dialog-button-color, var(--primary-color));\n\n        @apply --layout-horizontal;\n        @apply --layout-end-justified;\n      }\n    </style>\n  </template>\n</dom-module>', 
document.head.appendChild($_documentContainer.content), Polymer({
    _template: html`
    <style include="paper-dialog-shared-styles"></style>
    <slot></slot>
`,
    is: "paper-dialog",
    behaviors: [ PaperDialogBehavior, NeonAnimationRunnerBehavior ],
    listeners: {
        "neon-animation-finish": "_onNeonAnimationFinish"
    },
    _renderOpened: function() {
        this.cancelAnimation(), this.playAnimation("entry");
    },
    _renderClosed: function() {
        this.cancelAnimation(), this.playAnimation("exit");
    },
    _onNeonAnimationFinish: function() {
        this.opened ? this._finishRenderOpened() : this._finishRenderClosed();
    }
});

const PaperInkyFocusBehaviorImpl = {
    observers: [ "_focusedChanged(receivedFocusFromKeyboard)" ],
    _focusedChanged: function(e) {
        e && this.ensureRipple(), this.hasRipple() && (this._ripple.holdDown = e);
    },
    _createRipple: function() {
        var e = PaperRippleBehavior._createRipple();
        return e.id = "ink", e.setAttribute("center", ""), e.classList.add("circle"), e;
    }
}, PaperInkyFocusBehavior = [ IronButtonState, IronControlState, PaperRippleBehavior, PaperInkyFocusBehaviorImpl ];

var paperInkyFocusBehavior = {
    PaperInkyFocusBehaviorImpl: PaperInkyFocusBehaviorImpl,
    PaperInkyFocusBehavior: PaperInkyFocusBehavior
};

Polymer({
    is: "paper-icon-button",
    _template: html`
    <style>
      :host {
        display: inline-block;
        position: relative;
        padding: 8px;
        outline: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        cursor: pointer;
        z-index: 0;
        line-height: 1;

        width: 40px;
        height: 40px;

        /*
          NOTE: Both values are needed, since some phones require the value to
          be \`transparent\`.
        */
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent;

        /* Because of polymer/2558, this style has lower specificity than * */
        box-sizing: border-box !important;

        @apply --paper-icon-button;
      }

      :host #ink {
        color: var(--paper-icon-button-ink-color, var(--primary-text-color));
        opacity: 0.6;
      }

      :host([disabled]) {
        color: var(--paper-icon-button-disabled-text, var(--disabled-text-color));
        pointer-events: none;
        cursor: auto;

        @apply --paper-icon-button-disabled;
      }

      :host([hidden]) {
        display: none !important;
      }

      :host(:hover) {
        @apply --paper-icon-button-hover;
      }

      iron-icon {
        --iron-icon-width: 100%;
        --iron-icon-height: 100%;
      }
    </style>

    <iron-icon id="icon" src="[[src]]" icon="[[icon]]"
               alt$="[[alt]]"></iron-icon>
  `,
    hostAttributes: {
        role: "button",
        tabindex: "0"
    },
    behaviors: [ PaperInkyFocusBehavior ],
    registered: function() {
        this._template.setAttribute("strip-whitespace", "");
    },
    properties: {
        src: {
            type: String
        },
        icon: {
            type: String
        },
        alt: {
            type: String,
            observer: "_altChanged"
        }
    },
    _altChanged: function(e, t) {
        var i = this.getAttribute("aria-label");
        i && t != i || this.setAttribute("aria-label", e);
    }
});

const IronMultiSelectableBehaviorImpl = {
    properties: {
        multi: {
            type: Boolean,
            value: !1,
            observer: "multiChanged"
        },
        selectedValues: {
            type: Array,
            notify: !0,
            value: function() {
                return [];
            }
        },
        selectedItems: {
            type: Array,
            readOnly: !0,
            notify: !0,
            value: function() {
                return [];
            }
        }
    },
    observers: [ "_updateSelected(selectedValues.splices)" ],
    select: function(e) {
        this.multi ? this._toggleSelected(e) : this.selected = e;
    },
    multiChanged: function(e) {
        this._selection.multi = e, this._updateSelected();
    },
    get _shouldUpdateSelection() {
        return null != this.selected || null != this.selectedValues && this.selectedValues.length;
    },
    _updateAttrForSelected: function() {
        this.multi ? this.selectedItems && this.selectedItems.length > 0 && (this.selectedValues = this.selectedItems.map(function(e) {
            return this._indexToValue(this.indexOf(e));
        }, this).filter(function(e) {
            return null != e;
        }, this)) : IronSelectableBehavior._updateAttrForSelected.apply(this);
    },
    _updateSelected: function() {
        this.multi ? this._selectMulti(this.selectedValues) : this._selectSelected(this.selected);
    },
    _selectMulti: function(e) {
        e = e || [];
        var t = (this._valuesToItems(e) || []).filter(function(e) {
            return null != e;
        });
        this._selection.clear(t);
        for (var i = 0; i < t.length; i++) this._selection.setItemSelected(t[i], !0);
        this.fallbackSelection && !this._selection.get().length && (this._valueToItem(this.fallbackSelection) && this.select(this.fallbackSelection));
    },
    _selectionChange: function() {
        var e = this._selection.get();
        this.multi ? (this._setSelectedItems(e), this._setSelectedItem(e.length ? e[0] : null)) : null != e ? (this._setSelectedItems([ e ]), 
        this._setSelectedItem(e)) : (this._setSelectedItems([]), this._setSelectedItem(null));
    },
    _toggleSelected: function(e) {
        var t = this.selectedValues.indexOf(e);
        t < 0 ? this.push("selectedValues", e) : this.splice("selectedValues", t, 1);
    },
    _valuesToItems: function(e) {
        return null == e ? null : e.map(function(e) {
            return this._valueToItem(e);
        }, this);
    }
}, IronMultiSelectableBehavior = [ IronSelectableBehavior, IronMultiSelectableBehaviorImpl ];

var ironMultiSelectable = {
    IronMultiSelectableBehaviorImpl: IronMultiSelectableBehaviorImpl,
    IronMultiSelectableBehavior: IronMultiSelectableBehavior
};

const IronMenuBehaviorImpl = {
    properties: {
        focusedItem: {
            observer: "_focusedItemChanged",
            readOnly: !0,
            type: Object
        },
        attrForItemTitle: {
            type: String
        },
        disabled: {
            type: Boolean,
            value: !1,
            observer: "_disabledChanged"
        }
    },
    _MODIFIER_KEYS: [ "Alt", "AltGraph", "CapsLock", "Control", "Fn", "FnLock", "Hyper", "Meta", "NumLock", "OS", "ScrollLock", "Shift", "Super", "Symbol", "SymbolLock" ],
    _SEARCH_RESET_TIMEOUT_MS: 1e3,
    _previousTabIndex: 0,
    hostAttributes: {
        role: "menu"
    },
    observers: [ "_updateMultiselectable(multi)" ],
    listeners: {
        focus: "_onFocus",
        keydown: "_onKeydown",
        "iron-items-changed": "_onIronItemsChanged"
    },
    keyBindings: {
        up: "_onUpKey",
        down: "_onDownKey",
        esc: "_onEscKey",
        "shift+tab:keydown": "_onShiftTabDown"
    },
    attached: function() {
        this._resetTabindices();
    },
    select: function(e) {
        this._defaultFocusAsync && (this.cancelAsync(this._defaultFocusAsync), this._defaultFocusAsync = null);
        var t = this._valueToItem(e);
        t && t.hasAttribute("disabled") || (this._setFocusedItem(t), IronMultiSelectableBehaviorImpl.select.apply(this, arguments));
    },
    _resetTabindices: function() {
        var e = this.multi ? this.selectedItems && this.selectedItems[0] : this.selectedItem;
        this.items.forEach(function(t) {
            t.setAttribute("tabindex", t === e ? "0" : "-1"), t.setAttribute("aria-selected", this._selection.isSelected(t));
        }, this);
    },
    _updateMultiselectable: function(e) {
        e ? this.setAttribute("aria-multiselectable", "true") : this.removeAttribute("aria-multiselectable");
    },
    _focusWithKeyboardEvent: function(e) {
        if (-1 === this._MODIFIER_KEYS.indexOf(e.key)) {
            this.cancelDebouncer("_clearSearchText");
            for (var t, i = this._searchText || "", o = (i += (e.key && 1 == e.key.length ? e.key : String.fromCharCode(e.keyCode)).toLocaleLowerCase()).length, n = 0; t = this.items[n]; n++) if (!t.hasAttribute("disabled")) {
                var a = this.attrForItemTitle || "textContent", r = (t[a] || t.getAttribute(a) || "").trim();
                if (!(r.length < o) && r.slice(0, o).toLocaleLowerCase() == i) {
                    this._setFocusedItem(t);
                    break;
                }
            }
            this._searchText = i, this.debounce("_clearSearchText", this._clearSearchText, this._SEARCH_RESET_TIMEOUT_MS);
        }
    },
    _clearSearchText: function() {
        this._searchText = "";
    },
    _focusPrevious: function() {
        for (var e = this.items.length, t = Number(this.indexOf(this.focusedItem)), i = 1; i < e + 1; i++) {
            var o = this.items[(t - i + e) % e];
            if (!o.hasAttribute("disabled")) {
                var n = dom(o).getOwnerRoot() || document;
                if (this._setFocusedItem(o), dom(n).activeElement == o) return;
            }
        }
    },
    _focusNext: function() {
        for (var e = this.items.length, t = Number(this.indexOf(this.focusedItem)), i = 1; i < e + 1; i++) {
            var o = this.items[(t + i) % e];
            if (!o.hasAttribute("disabled")) {
                var n = dom(o).getOwnerRoot() || document;
                if (this._setFocusedItem(o), dom(n).activeElement == o) return;
            }
        }
    },
    _applySelection: function(e, t) {
        t ? e.setAttribute("aria-selected", "true") : e.setAttribute("aria-selected", "false"), 
        IronSelectableBehavior._applySelection.apply(this, arguments);
    },
    _focusedItemChanged: function(e, t) {
        t && t.setAttribute("tabindex", "-1"), !e || e.hasAttribute("disabled") || this.disabled || (e.setAttribute("tabindex", "0"), 
        e.focus());
    },
    _onIronItemsChanged: function(e) {
        e.detail.addedNodes.length && this._resetTabindices();
    },
    _onShiftTabDown: function(e) {
        var t = this.getAttribute("tabindex");
        IronMenuBehaviorImpl._shiftTabPressed = !0, this._setFocusedItem(null), this.setAttribute("tabindex", "-1"), 
        this.async(function() {
            this.setAttribute("tabindex", t), IronMenuBehaviorImpl._shiftTabPressed = !1;
        }, 1);
    },
    _onFocus: function(e) {
        if (!IronMenuBehaviorImpl._shiftTabPressed) {
            var t = dom(e).rootTarget;
            (t === this || void 0 === t.tabIndex || this.isLightDescendant(t)) && (this._defaultFocusAsync = this.async(function() {
                var e = this.multi ? this.selectedItems && this.selectedItems[0] : this.selectedItem;
                this._setFocusedItem(null), e ? this._setFocusedItem(e) : this.items[0] && this._focusNext();
            }));
        }
    },
    _onUpKey: function(e) {
        this._focusPrevious(), e.detail.keyboardEvent.preventDefault();
    },
    _onDownKey: function(e) {
        this._focusNext(), e.detail.keyboardEvent.preventDefault();
    },
    _onEscKey: function(e) {
        var t = this.focusedItem;
        t && t.blur();
    },
    _onKeydown: function(e) {
        this.keyboardEventMatchesKeys(e, "up down esc") || this._focusWithKeyboardEvent(e), 
        e.stopPropagation();
    },
    _activateHandler: function(e) {
        IronSelectableBehavior._activateHandler.call(this, e), e.stopPropagation();
    },
    _disabledChanged: function(e) {
        e ? (this._previousTabIndex = this.hasAttribute("tabindex") ? this.tabIndex : 0, 
        this.removeAttribute("tabindex")) : this.hasAttribute("tabindex") || this.setAttribute("tabindex", this._previousTabIndex);
    },
    _shiftTabPressed: !1
}, IronMenuBehavior = [ IronMultiSelectableBehavior, IronA11yKeysBehavior, IronMenuBehaviorImpl ];

var ironMenuBehavior = {
    IronMenuBehaviorImpl: IronMenuBehaviorImpl,
    IronMenuBehavior: IronMenuBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        padding: 8px 0;

        background: var(--paper-listbox-background-color, var(--primary-background-color));
        color: var(--paper-listbox-color, var(--primary-text-color));

        @apply --paper-listbox;
      }
    </style>

    <slot></slot>
`,
    is: "paper-listbox",
    behaviors: [ IronMenuBehavior ],
    hostAttributes: {
        role: "listbox"
    }
});

const template$3 = html`
<dom-module id="paper-material-shared-styles">
  <template>
    <style>
      :host {
        display: block;
        position: relative;
      }

      :host([elevation="1"]) {
        @apply --shadow-elevation-2dp;
      }

      :host([elevation="2"]) {
        @apply --shadow-elevation-4dp;
      }

      :host([elevation="3"]) {
        @apply --shadow-elevation-6dp;
      }

      :host([elevation="4"]) {
        @apply --shadow-elevation-8dp;
      }

      :host([elevation="5"]) {
        @apply --shadow-elevation-16dp;
      }
    </style>
  </template>
</dom-module>
`;

template$3.setAttribute("style", "display: none;"), document.body.appendChild(template$3.content), 
Polymer({
    _template: html`
    <style include="paper-material-shared-styles"></style>
    <style>
      :host([animated]) {
        @apply --shadow-transition;
      }
      :host {
        @apply --paper-material;
      }
    </style>

    <slot></slot>
`,
    is: "paper-material",
    properties: {
        elevation: {
            type: Number,
            reflectToAttribute: !0,
            value: 1
        },
        animated: {
            type: Boolean,
            reflectToAttribute: !0,
            value: !1
        }
    }
}), Polymer({
    is: "iron-media-query",
    properties: {
        queryMatches: {
            type: Boolean,
            value: !1,
            readOnly: !0,
            notify: !0
        },
        query: {
            type: String,
            observer: "queryChanged"
        },
        full: {
            type: Boolean,
            value: !1
        },
        _boundMQHandler: {
            value: function() {
                return this.queryHandler.bind(this);
            }
        },
        _mq: {
            value: null
        }
    },
    attached: function() {
        this.style.display = "none", this.queryChanged();
    },
    detached: function() {
        this._remove();
    },
    _add: function() {
        this._mq && this._mq.addListener(this._boundMQHandler);
    },
    _remove: function() {
        this._mq && this._mq.removeListener(this._boundMQHandler), this._mq = null;
    },
    queryChanged: function() {
        this._remove();
        var e = this.query;
        e && (this.full || "(" === e[0] || (e = "(" + e + ")"), this._mq = window.matchMedia(e), 
        this._add(), this.queryHandler(this._mq));
    },
    queryHandler: function(e) {
        this._setQueryMatches(e.matches);
    }
});

const AppLayoutBehavior = [ IronResizableBehavior, {
    listeners: {
        "app-reset-layout": "_appResetLayoutHandler",
        "iron-resize": "resetLayout"
    },
    attached: function() {
        this.fire("app-reset-layout");
    },
    _appResetLayoutHandler: function(e) {
        dom(e).path[0] !== this && (this.resetLayout(), e.stopPropagation());
    },
    _updateLayoutStates: function() {
        console.error("unimplemented");
    },
    resetLayout: function() {
        var e = this._updateLayoutStates.bind(this);
        this._layoutDebouncer = Debouncer.debounce(this._layoutDebouncer, animationFrame, e), 
        enqueueDebouncer(this._layoutDebouncer), this._notifyDescendantResize();
    },
    _notifyLayoutChanged: function() {
        var e = this;
        requestAnimationFrame(function() {
            e.fire("app-reset-layout");
        });
    },
    _notifyDescendantResize: function() {
        this.isAttached && this._interestedResizables.forEach(function(e) {
            this.resizerShouldNotify(e) && this._notifyDescendant(e);
        }, this);
    }
} ];

var appLayoutBehavior = {
    AppLayoutBehavior: AppLayoutBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        /**
         * Force app-drawer-layout to have its own stacking context so that its parent can
         * control the stacking of it relative to other elements.
         */
        position: relative;
        z-index: 0;
      }

      :host ::slotted([slot=drawer]) {
        z-index: 1;
      }

      :host([fullbleed]) {
        @apply --layout-fit;
      }

      #contentContainer {
        /* Create a stacking context here so that all children appear below the header. */
        position: relative;
        z-index: 0;
        height: 100%;
        transition: var(--app-drawer-layout-content-transition, none);
      }

      #contentContainer[drawer-position=left] {
        margin-left: var(--app-drawer-width, 256px);
      }

      #contentContainer[drawer-position=right] {
        margin-right: var(--app-drawer-width, 256px);
      }
    </style>

    <slot id="drawerSlot" name="drawer"></slot>

    <div id="contentContainer" drawer-position\$="[[_drawerPosition]]">
      <slot></slot>
    </div>

    <iron-media-query query="[[_computeMediaQuery(forceNarrow, responsiveWidth)]]" on-query-matches-changed="_onQueryMatchesChanged"></iron-media-query>
`,
    is: "app-drawer-layout",
    behaviors: [ AppLayoutBehavior ],
    properties: {
        forceNarrow: {
            type: Boolean,
            value: !1
        },
        responsiveWidth: {
            type: String,
            value: "640px"
        },
        narrow: {
            type: Boolean,
            reflectToAttribute: !0,
            readOnly: !0,
            notify: !0
        },
        openedWhenNarrow: {
            type: Boolean,
            value: !1
        },
        _drawerPosition: {
            type: String
        }
    },
    listeners: {
        click: "_clickHandler"
    },
    observers: [ "_narrowChanged(narrow)" ],
    get drawer() {
        return dom(this.$.drawerSlot).getDistributedNodes()[0];
    },
    attached: function() {
        var e = this.drawer;
        e && e.setAttribute("no-transition", "");
    },
    _clickHandler: function(e) {
        var t = dom(e).localTarget;
        if (t && t.hasAttribute("drawer-toggle")) {
            var i = this.drawer;
            i && !i.persistent && i.toggle();
        }
    },
    _updateLayoutStates: function() {
        var e = this.drawer;
        this.isAttached && e && (this._drawerPosition = this.narrow ? null : e.position, 
        this._drawerNeedsReset && (this.narrow ? (e.opened = this.openedWhenNarrow, e.persistent = !1) : e.opened = e.persistent = !0, 
        e.hasAttribute("no-transition") && afterNextRender(this, function() {
            e.removeAttribute("no-transition");
        }), this._drawerNeedsReset = !1));
    },
    _narrowChanged: function() {
        this._drawerNeedsReset = !0, this.resetLayout();
    },
    _onQueryMatchesChanged: function(e) {
        this._setNarrow(e.detail.value);
    },
    _computeMediaQuery: function(e, t) {
        return e ? "(min-width: 0px)" : "(max-width: " + t + ")";
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        position: fixed;
        top: -120px;
        right: 0;
        bottom: -120px;
        left: 0;

        visibility: hidden;

        transition-property: visibility;
      }

      :host([opened]) {
        visibility: visible;
      }

      :host([persistent]) {
        width: var(--app-drawer-width, 256px);
      }

      :host([persistent][position=left]) {
        right: auto;
      }

      :host([persistent][position=right]) {
        left: auto;
      }

      #contentContainer {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;

        width: var(--app-drawer-width, 256px);
        padding: 120px 0;

        transition-property: -webkit-transform;
        transition-property: transform;
        -webkit-transform: translate3d(-100%, 0, 0);
        transform: translate3d(-100%, 0, 0);

        background-color: #FFF;

        @apply --app-drawer-content-container;
      }

      #contentContainer[persistent] {
        width: 100%;
      }

      #contentContainer[position=right] {
        right: 0;
        left: auto;

        -webkit-transform: translate3d(100%, 0, 0);
        transform: translate3d(100%, 0, 0);
      }

      #contentContainer[swipe-open]::after {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 100%;

        visibility: visible;

        width: 20px;

        content: '';
      }

      #contentContainer[swipe-open][position=right]::after {
        right: 100%;
        left: auto;
      }

      #contentContainer[opened] {
        -webkit-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0);
      }

      #scrim {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;

        transition-property: opacity;
        -webkit-transform: translateZ(0);
        transform:  translateZ(0);

        opacity: 0;
        background: var(--app-drawer-scrim-background, rgba(0, 0, 0, 0.5));
      }

      #scrim.visible {
        opacity: 1;
      }

      :host([no-transition]) #contentContainer {
        transition-property: none;
      }
    </style>

    <div id="scrim" on-click="close"></div>

    <!-- HACK(keanulee): Bind attributes here (in addition to :host) for styling to workaround Safari
    bug. https://bugs.webkit.org/show_bug.cgi?id=170762 -->
    <div id="contentContainer" opened\$="[[opened]]" persistent\$="[[persistent]]" position\$="[[position]]" swipe-open\$="[[swipeOpen]]">
      <slot></slot>
    </div>
`,
    is: "app-drawer",
    properties: {
        opened: {
            type: Boolean,
            value: !1,
            notify: !0,
            reflectToAttribute: !0
        },
        persistent: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        },
        transitionDuration: {
            type: Number,
            value: 200
        },
        align: {
            type: String,
            value: "left"
        },
        position: {
            type: String,
            readOnly: !0,
            reflectToAttribute: !0
        },
        swipeOpen: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        },
        noFocusTrap: {
            type: Boolean,
            value: !1
        },
        disableSwipe: {
            type: Boolean,
            value: !1
        }
    },
    observers: [ "resetLayout(position, isAttached)", "_resetPosition(align, isAttached)", "_styleTransitionDuration(transitionDuration)", "_openedPersistentChanged(opened, persistent)" ],
    _translateOffset: 0,
    _trackDetails: null,
    _drawerState: 0,
    _boundEscKeydownHandler: null,
    _firstTabStop: null,
    _lastTabStop: null,
    attached: function() {
        afterNextRender(this, function() {
            this._boundEscKeydownHandler = this._escKeydownHandler.bind(this), this.addEventListener("keydown", this._tabKeydownHandler.bind(this)), 
            this.listen(this, "track", "_track"), this.setScrollDirection("y");
        }), this.fire("app-reset-layout");
    },
    detached: function() {
        document.removeEventListener("keydown", this._boundEscKeydownHandler);
    },
    open: function() {
        this.opened = !0;
    },
    close: function() {
        this.opened = !1;
    },
    toggle: function() {
        this.opened = !this.opened;
    },
    getWidth: function() {
        return this._savedWidth || this.$.contentContainer.offsetWidth;
    },
    _isRTL: function() {
        return "rtl" === window.getComputedStyle(this).direction;
    },
    _resetPosition: function() {
        switch (this.align) {
          case "start":
            return void this._setPosition(this._isRTL() ? "right" : "left");

          case "end":
            return void this._setPosition(this._isRTL() ? "left" : "right");
        }
        this._setPosition(this.align);
    },
    _escKeydownHandler: function(e) {
        27 === e.keyCode && (e.preventDefault(), this.close());
    },
    _track: function(e) {
        if (!this.persistent && !this.disableSwipe) switch (e.preventDefault(), e.detail.state) {
          case "start":
            this._trackStart(e);
            break;

          case "track":
            this._trackMove(e);
            break;

          case "end":
            this._trackEnd(e);
        }
    },
    _trackStart: function(e) {
        this._drawerState = this._DRAWER_STATE.TRACKING;
        var t = this.$.contentContainer.getBoundingClientRect();
        this._savedWidth = t.width, "left" === this.position ? this._translateOffset = t.left : this._translateOffset = t.right - window.innerWidth, 
        this._trackDetails = [], this._styleTransitionDuration(0), this.style.visibility = "visible";
    },
    _trackMove: function(e) {
        this._translateDrawer(e.detail.dx + this._translateOffset), this._trackDetails.push({
            dx: e.detail.dx,
            timeStamp: Date.now()
        });
    },
    _trackEnd: function(e) {
        var t = e.detail.dx + this._translateOffset, i = this.getWidth(), o = "left" === this.position ? t >= 0 || t <= -i : t <= 0 || t >= i;
        if (!o) {
            var n = this._trackDetails;
            if (this._trackDetails = null, this._flingDrawer(e, n), this._drawerState === this._DRAWER_STATE.FLINGING) return;
        }
        var a = i / 2;
        e.detail.dx < -a ? this.opened = "right" === this.position : e.detail.dx > a && (this.opened = "left" === this.position), 
        o ? this.debounce("_resetDrawerState", this._resetDrawerState) : this.debounce("_resetDrawerState", this._resetDrawerState, this.transitionDuration), 
        this._styleTransitionDuration(this.transitionDuration), this._resetDrawerTranslate(), 
        this.style.visibility = "";
    },
    _calculateVelocity: function(e, t) {
        for (var i, o = Date.now(), n = o - 100, a = 0, r = t.length - 1; a <= r; ) {
            var s = a + r >> 1, l = t[s];
            l.timeStamp >= n ? (i = l, r = s - 1) : a = s + 1;
        }
        return i ? (e.detail.dx - i.dx) / (o - i.timeStamp || 1) : 0;
    },
    _flingDrawer: function(e, t) {
        var i = this._calculateVelocity(e, t);
        if (!(Math.abs(i) < this._MIN_FLING_THRESHOLD)) {
            this._drawerState = this._DRAWER_STATE.FLINGING;
            var o, n = e.detail.dx + this._translateOffset, a = this.getWidth(), r = "left" === this.position, s = i > 0;
            o = !s && r ? -(n + a) : s && !r ? a - n : -n, s ? (i = Math.max(i, this._MIN_TRANSITION_VELOCITY), 
            this.opened = "left" === this.position) : (i = Math.min(i, -this._MIN_TRANSITION_VELOCITY), 
            this.opened = "right" === this.position);
            var l = this._FLING_INITIAL_SLOPE * o / i;
            this._styleTransitionDuration(l), this._styleTransitionTimingFunction(this._FLING_TIMING_FUNCTION), 
            this._resetDrawerTranslate(), this.debounce("_resetDrawerState", this._resetDrawerState, l);
        }
    },
    _styleTransitionDuration: function(e) {
        this.style.transitionDuration = e + "ms", this.$.contentContainer.style.transitionDuration = e + "ms", 
        this.$.scrim.style.transitionDuration = e + "ms";
    },
    _styleTransitionTimingFunction: function(e) {
        this.$.contentContainer.style.transitionTimingFunction = e, this.$.scrim.style.transitionTimingFunction = e;
    },
    _translateDrawer: function(e) {
        var t = this.getWidth();
        "left" === this.position ? (e = Math.max(-t, Math.min(e, 0)), this.$.scrim.style.opacity = 1 + e / t) : (e = Math.max(0, Math.min(e, t)), 
        this.$.scrim.style.opacity = 1 - e / t), this.translate3d(e + "px", "0", "0", this.$.contentContainer);
    },
    _resetDrawerTranslate: function() {
        this.$.scrim.style.opacity = "", this.transform("", this.$.contentContainer);
    },
    _resetDrawerState: function() {
        var e = this._drawerState;
        e === this._DRAWER_STATE.FLINGING && (this._styleTransitionDuration(this.transitionDuration), 
        this._styleTransitionTimingFunction(""), this.style.visibility = ""), this._savedWidth = null, 
        this.opened ? this._drawerState = this.persistent ? this._DRAWER_STATE.OPENED_PERSISTENT : this._DRAWER_STATE.OPENED : this._drawerState = this._DRAWER_STATE.CLOSED, 
        e !== this._drawerState && (this._drawerState === this._DRAWER_STATE.OPENED ? (this._setKeyboardFocusTrap(), 
        document.addEventListener("keydown", this._boundEscKeydownHandler), document.body.style.overflow = "hidden") : (document.removeEventListener("keydown", this._boundEscKeydownHandler), 
        document.body.style.overflow = ""), e !== this._DRAWER_STATE.INIT && this.fire("app-drawer-transitioned"));
    },
    resetLayout: function() {
        this.fire("app-reset-layout");
    },
    _setKeyboardFocusTrap: function() {
        if (!this.noFocusTrap) {
            var e = [ 'a[href]:not([tabindex="-1"])', 'area[href]:not([tabindex="-1"])', 'input:not([disabled]):not([tabindex="-1"])', 'select:not([disabled]):not([tabindex="-1"])', 'textarea:not([disabled]):not([tabindex="-1"])', 'button:not([disabled]):not([tabindex="-1"])', 'iframe:not([tabindex="-1"])', '[tabindex]:not([tabindex="-1"])', '[contentEditable=true]:not([tabindex="-1"])' ].join(","), t = dom(this).querySelectorAll(e);
            t.length > 0 ? (this._firstTabStop = t[0], this._lastTabStop = t[t.length - 1]) : (this._firstTabStop = null, 
            this._lastTabStop = null);
            var i = this.getAttribute("tabindex");
            i && parseInt(i, 10) > -1 ? this.focus() : this._firstTabStop && this._firstTabStop.focus();
        }
    },
    _tabKeydownHandler: function(e) {
        if (!this.noFocusTrap) {
            this._drawerState === this._DRAWER_STATE.OPENED && 9 === e.keyCode && (e.shiftKey ? this._firstTabStop && dom(e).localTarget === this._firstTabStop && (e.preventDefault(), 
            this._lastTabStop.focus()) : this._lastTabStop && dom(e).localTarget === this._lastTabStop && (e.preventDefault(), 
            this._firstTabStop.focus()));
        }
    },
    _openedPersistentChanged: function(e, t) {
        this.toggleClass("visible", e && !t, this.$.scrim), this.debounce("_resetDrawerState", this._resetDrawerState, this.transitionDuration);
    },
    _MIN_FLING_THRESHOLD: .2,
    _MIN_TRANSITION_VELOCITY: 1.2,
    _FLING_TIMING_FUNCTION: "cubic-bezier(0.667, 1, 0.667, 1)",
    _FLING_INITIAL_SLOPE: 1.5,
    _DRAWER_STATE: {
        INIT: 0,
        OPENED: 1,
        OPENED_PERSISTENT: 2,
        CLOSED: 3,
        TRACKING: 4,
        FLINGING: 5
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        /**
         * Force app-header-layout to have its own stacking context so that its parent can
         * control the stacking of it relative to other elements (e.g. app-drawer-layout).
         * This could be done using \`isolation: isolate\`, but that's not well supported
         * across browsers.
         */
        position: relative;
        z-index: 0;
      }

      #wrapper ::slotted([slot=header]) {
        @apply --layout-fixed-top;
        z-index: 1;
      }

      #wrapper.initializing ::slotted([slot=header]) {
        position: relative;
      }

      :host([has-scrolling-region]) {
        height: 100%;
      }

      :host([has-scrolling-region]) #wrapper ::slotted([slot=header]) {
        position: absolute;
      }

      :host([has-scrolling-region]) #wrapper.initializing ::slotted([slot=header]) {
        position: relative;
      }

      :host([has-scrolling-region]) #wrapper #contentContainer {
        @apply --layout-fit;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
      }

      :host([has-scrolling-region]) #wrapper.initializing #contentContainer {
        position: relative;
      }

      :host([fullbleed]) {
        @apply --layout-vertical;
        @apply --layout-fit;
      }

      :host([fullbleed]) #wrapper,
      :host([fullbleed]) #wrapper #contentContainer {
        @apply --layout-vertical;
        @apply --layout-flex;
      }

      #contentContainer {
        /* Create a stacking context here so that all children appear below the header. */
        position: relative;
        z-index: 0;
      }

      @media print {
        :host([has-scrolling-region]) #wrapper #contentContainer {
          overflow-y: visible;
        }
      }

    </style>

    <div id="wrapper" class="initializing">
      <slot id="headerSlot" name="header"></slot>

      <div id="contentContainer">
        <slot></slot>
      </div>
    </div>
`,
    is: "app-header-layout",
    behaviors: [ AppLayoutBehavior ],
    properties: {
        hasScrollingRegion: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        }
    },
    observers: [ "resetLayout(isAttached, hasScrollingRegion)" ],
    get header() {
        return dom(this.$.headerSlot).getDistributedNodes()[0];
    },
    _updateLayoutStates: function() {
        var e = this.header;
        if (this.isAttached && e) {
            this.$.wrapper.classList.remove("initializing"), e.scrollTarget = this.hasScrollingRegion ? this.$.contentContainer : this.ownerDocument.documentElement;
            var t = e.offsetHeight;
            this.hasScrollingRegion ? (e.style.left = "", e.style.right = "") : requestAnimationFrame(function() {
                var t = this.getBoundingClientRect(), i = document.documentElement.clientWidth - t.right;
                e.style.left = t.left + "px", e.style.right = i + "px";
            }.bind(this));
            var i = this.$.contentContainer.style;
            e.fixed && !e.condenses && this.hasScrollingRegion ? (i.marginTop = t + "px", i.paddingTop = "") : (i.paddingTop = t + "px", 
            i.marginTop = "");
        }
    }
});

const IronScrollTargetBehavior = {
    properties: {
        scrollTarget: {
            type: HTMLElement,
            value: function() {
                return this._defaultScrollTarget;
            }
        }
    },
    observers: [ "_scrollTargetChanged(scrollTarget, isAttached)" ],
    _shouldHaveListener: !0,
    _scrollTargetChanged: function(e, t) {
        if (this._oldScrollTarget && (this._toggleScrollListener(!1, this._oldScrollTarget), 
        this._oldScrollTarget = null), t) if ("document" === e) this.scrollTarget = this._doc; else if ("string" == typeof e) {
            var i = this.domHost;
            this.scrollTarget = i && i.$ ? i.$[e] : dom(this.ownerDocument).querySelector("#" + e);
        } else this._isValidScrollTarget() && (this._oldScrollTarget = e, this._toggleScrollListener(this._shouldHaveListener, e));
    },
    _scrollHandler: function() {},
    get _defaultScrollTarget() {
        return this._doc;
    },
    get _doc() {
        return this.ownerDocument.documentElement;
    },
    get _scrollTop() {
        return this._isValidScrollTarget() ? this.scrollTarget === this._doc ? window.pageYOffset : this.scrollTarget.scrollTop : 0;
    },
    get _scrollLeft() {
        return this._isValidScrollTarget() ? this.scrollTarget === this._doc ? window.pageXOffset : this.scrollTarget.scrollLeft : 0;
    },
    set _scrollTop(e) {
        this.scrollTarget === this._doc ? window.scrollTo(window.pageXOffset, e) : this._isValidScrollTarget() && (this.scrollTarget.scrollTop = e);
    },
    set _scrollLeft(e) {
        this.scrollTarget === this._doc ? window.scrollTo(e, window.pageYOffset) : this._isValidScrollTarget() && (this.scrollTarget.scrollLeft = e);
    },
    scroll: function(e, t) {
        var i;
        "object" == typeof e ? (i = e.left, t = e.top) : i = e, i = i || 0, t = t || 0, 
        this.scrollTarget === this._doc ? window.scrollTo(i, t) : this._isValidScrollTarget() && (this.scrollTarget.scrollLeft = i, 
        this.scrollTarget.scrollTop = t);
    },
    get _scrollTargetWidth() {
        return this._isValidScrollTarget() ? this.scrollTarget === this._doc ? window.innerWidth : this.scrollTarget.offsetWidth : 0;
    },
    get _scrollTargetHeight() {
        return this._isValidScrollTarget() ? this.scrollTarget === this._doc ? window.innerHeight : this.scrollTarget.offsetHeight : 0;
    },
    _isValidScrollTarget: function() {
        return this.scrollTarget instanceof HTMLElement;
    },
    _toggleScrollListener: function(e, t) {
        var i = t === this._doc ? window : t;
        e ? this._boundScrollHandler || (this._boundScrollHandler = this._scrollHandler.bind(this), 
        i.addEventListener("scroll", this._boundScrollHandler)) : this._boundScrollHandler && (i.removeEventListener("scroll", this._boundScrollHandler), 
        this._boundScrollHandler = null);
    },
    toggleScrollListener: function(e) {
        this._shouldHaveListener = e, this._toggleScrollListener(e, this.scrollTarget);
    }
};

var ironScrollTargetBehavior = {
    IronScrollTargetBehavior: IronScrollTargetBehavior
};

const _scrollEffects = {};

let _scrollTimer = null;

const scrollTimingFunction = function(e, t, i, o) {
    return -i * (e /= o) * (e - 2) + t;
}, registerEffect = function(e, t) {
    if (null != _scrollEffects[e]) throw new Error("effect `" + e + "` is already registered.");
    _scrollEffects[e] = t;
}, queryAllRoot = function(e, t) {
    for (var i = [ t ], o = []; i.length > 0; ) {
        var n = i.shift();
        o.push.apply(o, n.querySelectorAll(e));
        for (var a = 0; n.children[a]; a++) n.children[a].shadowRoot && i.push(n.children[a].shadowRoot);
    }
    return o;
}, scroll = function(e) {
    e = e || {};
    var t = document.documentElement, i = e.target || t, o = "scrollBehavior" in i.style && i.scroll, n = e.top || 0, a = e.left || 0, r = i === t ? window.scrollTo : function(e, t) {
        i.scrollLeft = e, i.scrollTop = t;
    };
    if ("smooth" === e.behavior) if (o) i.scroll(e); else {
        var s = scrollTimingFunction, l = Date.now(), c = i === t ? window.pageYOffset : i.scrollTop, p = i === t ? window.pageXOffset : i.scrollLeft, d = n - c, h = a - p;
        (function e() {
            var t = Date.now() - l;
            t < 300 ? (r(s(t, p, h, 300), s(t, c, d, 300)), requestAnimationFrame(e)) : r(a, n);
        }).bind(this)();
    } else if ("silent" === e.behavior) {
        var u = queryAllRoot("app-header", document.body);
        u.forEach(function(e) {
            e.setAttribute("silent-scroll", "");
        }), _scrollTimer && window.cancelAnimationFrame(_scrollTimer), _scrollTimer = window.requestAnimationFrame(function() {
            u.forEach(function(e) {
                e.removeAttribute("silent-scroll");
            }), _scrollTimer = null;
        }), r(a, n);
    } else r(a, n);
};

var helpers = {
    _scrollEffects: _scrollEffects,
    get _scrollTimer() {
        return _scrollTimer;
    },
    scrollTimingFunction: scrollTimingFunction,
    registerEffect: registerEffect,
    queryAllRoot: queryAllRoot,
    scroll: scroll
};

const AppScrollEffectsBehavior = [ IronScrollTargetBehavior, {
    properties: {
        effects: {
            type: String
        },
        effectsConfig: {
            type: Object,
            value: function() {
                return {};
            }
        },
        disabled: {
            type: Boolean,
            reflectToAttribute: !0,
            value: !1
        },
        threshold: {
            type: Number,
            value: 0
        },
        thresholdTriggered: {
            type: Boolean,
            notify: !0,
            readOnly: !0,
            reflectToAttribute: !0
        }
    },
    observers: [ "_effectsChanged(effects, effectsConfig, isAttached)" ],
    _updateScrollState: function(e) {},
    isOnScreen: function() {
        return !1;
    },
    isContentBelow: function() {
        return !1;
    },
    _effectsRunFn: null,
    _effects: null,
    get _clampedScrollTop() {
        return Math.max(0, this._scrollTop);
    },
    attached: function() {
        this._scrollStateChanged();
    },
    detached: function() {
        this._tearDownEffects();
    },
    createEffect: function(e, t) {
        var i = _scrollEffects[e];
        if (!i) throw new ReferenceError(this._getUndefinedMsg(e));
        var o = this._boundEffect(i, t || {});
        return o.setUp(), o;
    },
    _effectsChanged: function(e, t, i) {
        this._tearDownEffects(), e && i && (e.split(" ").forEach(function(e) {
            var i;
            "" !== e && ((i = _scrollEffects[e]) ? this._effects.push(this._boundEffect(i, t[e])) : console.warn(this._getUndefinedMsg(e)));
        }, this), this._setUpEffect());
    },
    _layoutIfDirty: function() {
        return this.offsetWidth;
    },
    _boundEffect: function(e, t) {
        t = t || {};
        var i = parseFloat(t.startsAt || 0), o = parseFloat(t.endsAt || 1), n = o - i, a = function() {}, r = 0 === i && 1 === o ? e.run : function(t, o) {
            e.run.call(this, Math.max(0, (t - i) / n), o);
        };
        return {
            setUp: e.setUp ? e.setUp.bind(this, t) : a,
            run: e.run ? r.bind(this) : a,
            tearDown: e.tearDown ? e.tearDown.bind(this) : a
        };
    },
    _setUpEffect: function() {
        this.isAttached && this._effects && (this._effectsRunFn = [], this._effects.forEach(function(e) {
            !1 !== e.setUp() && this._effectsRunFn.push(e.run);
        }, this));
    },
    _tearDownEffects: function() {
        this._effects && this._effects.forEach(function(e) {
            e.tearDown();
        }), this._effectsRunFn = [], this._effects = [];
    },
    _runEffects: function(e, t) {
        this._effectsRunFn && this._effectsRunFn.forEach(function(i) {
            i(e, t);
        });
    },
    _scrollHandler: function() {
        this._scrollStateChanged();
    },
    _scrollStateChanged: function() {
        if (!this.disabled) {
            var e = this._clampedScrollTop;
            this._updateScrollState(e), this.threshold > 0 && this._setThresholdTriggered(e >= this.threshold);
        }
    },
    _getDOMRef: function(e) {
        console.warn("_getDOMRef", "`" + e + "` is undefined");
    },
    _getUndefinedMsg: function(e) {
        return "Scroll effect `" + e + "` is undefined. Did you forget to import app-layout/app-scroll-effects/effects/" + e + ".html ?";
    }
} ];

var appScrollEffectsBehavior = {
    AppScrollEffectsBehavior: AppScrollEffectsBehavior
};

function interpolate(e, t, i, o) {
    i.apply(o, t.map(function(t) {
        return t[0] + (t[1] - t[0]) * e;
    }));
}

Polymer({
    _template: html`
    <style>
      :host {
        position: relative;
        display: block;
        transition-timing-function: linear;
        transition-property: -webkit-transform;
        transition-property: transform;
      }

      :host::before {
        position: absolute;
        right: 0px;
        bottom: -5px;
        left: 0px;
        width: 100%;
        height: 5px;
        content: "";
        transition: opacity 0.4s;
        pointer-events: none;
        opacity: 0;
        box-shadow: inset 0px 5px 6px -3px rgba(0, 0, 0, 0.4);
        will-change: opacity;
        @apply --app-header-shadow;
      }

      :host([shadow])::before {
        opacity: 1;
      }

      #background {
        @apply --layout-fit;
        overflow: hidden;
      }

      #backgroundFrontLayer,
      #backgroundRearLayer {
        @apply --layout-fit;
        height: 100%;
        pointer-events: none;
        background-size: cover;
      }

      #backgroundFrontLayer {
        @apply --app-header-background-front-layer;
      }

      #backgroundRearLayer {
        opacity: 0;
        @apply --app-header-background-rear-layer;
      }

      #contentContainer {
        position: relative;
        width: 100%;
        height: 100%;
      }

      :host([disabled]),
      :host([disabled])::after,
      :host([disabled]) #backgroundFrontLayer,
      :host([disabled]) #backgroundRearLayer,
      /* Silent scrolling should not run CSS transitions */
      :host([silent-scroll]),
      :host([silent-scroll])::after,
      :host([silent-scroll]) #backgroundFrontLayer,
      :host([silent-scroll]) #backgroundRearLayer {
        transition: none !important;
      }

      :host([disabled]) ::slotted(app-toolbar:first-of-type),
      :host([disabled]) ::slotted([sticky]),
      /* Silent scrolling should not run CSS transitions */
      :host([silent-scroll]) ::slotted(app-toolbar:first-of-type),
      :host([silent-scroll]) ::slotted([sticky]) {
        transition: none !important;
      }

    </style>
    <div id="contentContainer">
      <slot id="slot"></slot>
    </div>
`,
    is: "app-header",
    behaviors: [ AppScrollEffectsBehavior, AppLayoutBehavior ],
    properties: {
        condenses: {
            type: Boolean,
            value: !1
        },
        fixed: {
            type: Boolean,
            value: !1
        },
        reveals: {
            type: Boolean,
            value: !1
        },
        shadow: {
            type: Boolean,
            reflectToAttribute: !0,
            value: !1
        }
    },
    observers: [ "_configChanged(isAttached, condenses, fixed)" ],
    _height: 0,
    _dHeight: 0,
    _stickyElTop: 0,
    _stickyElRef: null,
    _top: 0,
    _progress: 0,
    _wasScrollingDown: !1,
    _initScrollTop: 0,
    _initTimestamp: 0,
    _lastTimestamp: 0,
    _lastScrollTop: 0,
    get _maxHeaderTop() {
        return this.fixed ? this._dHeight : this._height + 5;
    },
    get _stickyEl() {
        if (this._stickyElRef) return this._stickyElRef;
        for (var e, t = dom(this.$.slot).getDistributedNodes(), i = 0; e = t[i]; i++) if (e.nodeType === Node.ELEMENT_NODE) {
            if (e.hasAttribute("sticky")) {
                this._stickyElRef = e;
                break;
            }
            this._stickyElRef || (this._stickyElRef = e);
        }
        return this._stickyElRef;
    },
    _configChanged: function() {
        this.resetLayout(), this._notifyLayoutChanged();
    },
    _updateLayoutStates: function() {
        if (0 !== this.offsetWidth || 0 !== this.offsetHeight) {
            var e = this._clampedScrollTop, t = 0 === this._height || 0 === e, i = this.disabled;
            this._height = this.offsetHeight, this._stickyElRef = null, this.disabled = !0, 
            t || this._updateScrollState(0, !0), this._mayMove() ? this._dHeight = this._stickyEl ? this._height - this._stickyEl.offsetHeight : 0 : this._dHeight = 0, 
            this._stickyElTop = this._stickyEl ? this._stickyEl.offsetTop : 0, this._setUpEffect(), 
            t ? this._updateScrollState(e, !0) : (this._updateScrollState(this._lastScrollTop, !0), 
            this._layoutIfDirty()), this.disabled = i;
        }
    },
    _updateScrollState: function(e, t) {
        if (0 !== this._height) {
            var i = 0, o = 0, n = this._top, a = (this._lastScrollTop, this._maxHeaderTop), r = e - this._lastScrollTop, s = Math.abs(r), l = e > this._lastScrollTop, c = performance.now();
            if (this._mayMove() && (o = this._clamp(this.reveals ? n + r : e, 0, a)), e >= this._dHeight && (o = this.condenses && !this.fixed ? Math.max(this._dHeight, o) : o, 
            this.style.transitionDuration = "0ms"), this.reveals && !this.disabled && s < 100 && ((c - this._initTimestamp > 300 || this._wasScrollingDown !== l) && (this._initScrollTop = e, 
            this._initTimestamp = c), e >= a)) if (Math.abs(this._initScrollTop - e) > 30 || s > 10) {
                l && e >= a ? o = a : !l && e >= this._dHeight && (o = this.condenses && !this.fixed ? this._dHeight : 0);
                var p = r / (c - this._lastTimestamp);
                this.style.transitionDuration = this._clamp((o - n) / p, 0, 300) + "ms";
            } else o = this._top;
            i = 0 === this._dHeight ? e > 0 ? 1 : 0 : o / this._dHeight, t || (this._lastScrollTop = e, 
            this._top = o, this._wasScrollingDown = l, this._lastTimestamp = c), (t || i !== this._progress || n !== o || 0 === e) && (this._progress = i, 
            this._runEffects(i, o), this._transformHeader(o));
        }
    },
    _mayMove: function() {
        return this.condenses || !this.fixed;
    },
    willCondense: function() {
        return this._dHeight > 0 && this.condenses;
    },
    isOnScreen: function() {
        return 0 !== this._height && this._top < this._height;
    },
    isContentBelow: function() {
        return 0 === this._top ? this._clampedScrollTop > 0 : this._clampedScrollTop - this._maxHeaderTop >= 0;
    },
    _transformHeader: function(e) {
        this.translate3d(0, -e + "px", 0), this._stickyEl && this.translate3d(0, this.condenses && e >= this._stickyElTop ? Math.min(e, this._dHeight) - this._stickyElTop + "px" : 0, 0, this._stickyEl);
    },
    _clamp: function(e, t, i) {
        return Math.min(i, Math.max(t, e));
    },
    _ensureBgContainers: function() {
        this._bgContainer || (this._bgContainer = document.createElement("div"), this._bgContainer.id = "background", 
        this._bgRear = document.createElement("div"), this._bgRear.id = "backgroundRearLayer", 
        this._bgContainer.appendChild(this._bgRear), this._bgFront = document.createElement("div"), 
        this._bgFront.id = "backgroundFrontLayer", this._bgContainer.appendChild(this._bgFront), 
        dom(this.root).insertBefore(this._bgContainer, this.$.contentContainer));
    },
    _getDOMRef: function(e) {
        switch (e) {
          case "backgroundFrontLayer":
            return this._ensureBgContainers(), this._bgFront;

          case "backgroundRearLayer":
            return this._ensureBgContainers(), this._bgRear;

          case "background":
            return this._ensureBgContainers(), this._bgContainer;

          case "mainTitle":
            return dom(this).querySelector("[main-title]");

          case "condensedTitle":
            return dom(this).querySelector("[condensed-title]");
        }
        return null;
    },
    getScrollState: function() {
        return {
            progress: this._progress,
            top: this._top
        };
    }
}), registerEffect("blend-background", {
    setUp: function() {
        var e = {};
        e.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), e.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), 
        e.backgroundFrontLayer.style.willChange = "opacity", e.backgroundFrontLayer.style.transform = "translateZ(0)", 
        e.backgroundRearLayer.style.willChange = "opacity", e.backgroundRearLayer.style.transform = "translateZ(0)", 
        e.backgroundRearLayer.style.opacity = 0, this._fxBlendBackground = e;
    },
    run: function(e, t) {
        var i = this._fxBlendBackground;
        i.backgroundFrontLayer.style.opacity = 1 - e, i.backgroundRearLayer.style.opacity = e;
    },
    tearDown: function() {
        delete this._fxBlendBackground;
    }
}), registerEffect("fade-background", {
    setUp: function(e) {
        var t = {}, i = e.duration || "0.5s";
        t.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), t.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), 
        t.backgroundFrontLayer.style.willChange = "opacity", t.backgroundFrontLayer.style.webkitTransform = "translateZ(0)", 
        t.backgroundFrontLayer.style.transitionProperty = "opacity", t.backgroundFrontLayer.style.transitionDuration = i, 
        t.backgroundRearLayer.style.willChange = "opacity", t.backgroundRearLayer.style.webkitTransform = "translateZ(0)", 
        t.backgroundRearLayer.style.transitionProperty = "opacity", t.backgroundRearLayer.style.transitionDuration = i, 
        this._fxFadeBackground = t;
    },
    run: function(e, t) {
        var i = this._fxFadeBackground;
        e >= 1 ? (i.backgroundFrontLayer.style.opacity = 0, i.backgroundRearLayer.style.opacity = 1) : (i.backgroundFrontLayer.style.opacity = 1, 
        i.backgroundRearLayer.style.opacity = 0);
    },
    tearDown: function() {
        delete this._fxFadeBackground;
    }
}), registerEffect("waterfall", {
    run: function() {
        this.shadow = this.isOnScreen() && this.isContentBelow();
    }
}), registerEffect("resize-title", {
    setUp: function() {
        var e = this._getDOMRef("mainTitle"), t = this._getDOMRef("condensedTitle");
        if (!t) return console.warn("Scroll effect `resize-title`: undefined `condensed-title`"), 
        !1;
        if (!e) return console.warn("Scroll effect `resize-title`: undefined `main-title`"), 
        !1;
        t.style.willChange = "opacity", t.style.webkitTransform = "translateZ(0)", t.style.transform = "translateZ(0)", 
        t.style.webkitTransformOrigin = "left top", t.style.transformOrigin = "left top", 
        e.style.willChange = "opacity", e.style.webkitTransformOrigin = "left top", e.style.transformOrigin = "left top", 
        e.style.webkitTransform = "translateZ(0)", e.style.transform = "translateZ(0)";
        var i = e.getBoundingClientRect(), o = t.getBoundingClientRect(), n = {};
        n.scale = parseInt(window.getComputedStyle(t)["font-size"], 10) / parseInt(window.getComputedStyle(e)["font-size"], 10), 
        n.titleDX = i.left - o.left, n.titleDY = i.top - o.top, n.condensedTitle = t, n.title = e, 
        this._fxResizeTitle = n;
    },
    run: function(e, t) {
        var i = this._fxResizeTitle;
        this.condenses || (t = 0), e >= 1 ? (i.title.style.opacity = 0, i.condensedTitle.style.opacity = 1) : (i.title.style.opacity = 1, 
        i.condensedTitle.style.opacity = 0), interpolate(Math.min(1, e), [ [ 1, i.scale ], [ 0, -i.titleDX ], [ t, t - i.titleDY ] ], function(e, t, o) {
            this.transform("translate(" + t + "px, " + o + "px) scale3d(" + e + ", " + e + ", 1)", i.title);
        }, this);
    },
    tearDown: function() {
        delete this._fxResizeTitle;
    }
}), registerEffect("parallax-background", {
    setUp: function(e) {
        var t = {}, i = parseFloat(e.scalar);
        t.background = this._getDOMRef("background"), t.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), 
        t.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), t.deltaBg = t.backgroundFrontLayer.offsetHeight - t.background.offsetHeight, 
        0 === t.deltaBg ? (isNaN(i) && (i = .8), t.deltaBg = (this._dHeight || 0) * i) : (isNaN(i) && (i = 1), 
        t.deltaBg = t.deltaBg * i), this._fxParallaxBackground = t;
    },
    run: function(e, t) {
        var i = this._fxParallaxBackground;
        this.transform("translate3d(0px, " + i.deltaBg * Math.min(1, e) + "px, 0px)", i.backgroundFrontLayer), 
        i.backgroundRearLayer && this.transform("translate3d(0px, " + i.deltaBg * Math.min(1, e) + "px, 0px)", i.backgroundRearLayer);
    },
    tearDown: function() {
        delete this._fxParallaxBackground;
    }
}), registerEffect("material", {
    setUp: function() {
        return this.effects = "waterfall resize-title blend-background parallax-background", 
        !1;
    }
}), registerEffect("resize-snapped-title", {
    setUp: function(e) {
        var t = this._getDOMRef("mainTitle"), i = this._getDOMRef("condensedTitle"), o = e.duration || "0.2s", n = {};
        return i ? t ? (t.style.transitionProperty = "opacity", t.style.transitionDuration = o, 
        i.style.transitionProperty = "opacity", i.style.transitionDuration = o, n.condensedTitle = i, 
        n.title = t, void (this._fxResizeSnappedTitle = n)) : (console.warn("Scroll effect `resize-snapped-title`: undefined `main-title`"), 
        !1) : (console.warn("Scroll effect `resize-snapped-title`: undefined `condensed-title`"), 
        !1);
    },
    run: function(e, t) {
        var i = this._fxResizeSnappedTitle;
        e > 0 ? (i.title.style.opacity = 0, i.condensedTitle.style.opacity = 1) : (i.title.style.opacity = 1, 
        i.condensedTitle.style.opacity = 0);
    },
    tearDown: function() {
        var e = this._fxResizeSnappedTitle;
        e.title.style.transition = "", e.condensedTitle.style.transition = "", delete this._fxResizeSnappedTitle;
    }
}), Polymer({
    _template: html`
    <style>

      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        position: relative;
        height: 64px;
        padding: 0 16px;
        pointer-events: none;
        font-size: var(--app-toolbar-font-size, 20px);
      }

      :host ::slotted(*) {
        pointer-events: auto;
      }

      :host ::slotted(paper-icon-button) {
        /* paper-icon-button/issues/33 */
        font-size: 0;
      }

      :host ::slotted([main-title]),
      :host ::slotted([condensed-title]) {
        pointer-events: none;
        @apply --layout-flex;
      }

      :host ::slotted([bottom-item]) {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
      }

      :host ::slotted([top-item]) {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
      }

      :host ::slotted([spacer]) {
        margin-left: 64px;
      }
    </style>

    <slot></slot>
`,
    is: "app-toolbar"
});

const IronFormElementBehavior = {
    properties: {
        name: {
            type: String
        },
        value: {
            notify: !0,
            type: String
        },
        required: {
            type: Boolean,
            value: !1
        }
    },
    attached: function() {},
    detached: function() {}
};

var ironFormElementBehavior = {
    IronFormElementBehavior: IronFormElementBehavior
};

let IronValidatableBehaviorMeta = null;

const IronValidatableBehavior = {
    properties: {
        validator: {
            type: String
        },
        invalid: {
            notify: !0,
            reflectToAttribute: !0,
            type: Boolean,
            value: !1,
            observer: "_invalidChanged"
        }
    },
    registered: function() {
        IronValidatableBehaviorMeta = new IronMeta({
            type: "validator"
        });
    },
    _invalidChanged: function() {
        this.invalid ? this.setAttribute("aria-invalid", "true") : this.removeAttribute("aria-invalid");
    },
    get _validator() {
        return IronValidatableBehaviorMeta && IronValidatableBehaviorMeta.byKey(this.validator);
    },
    hasValidator: function() {
        return null != this._validator;
    },
    validate: function(e) {
        return void 0 === e && void 0 !== this.value ? this.invalid = !this._getValidity(this.value) : this.invalid = !this._getValidity(e), 
        !this.invalid;
    },
    _getValidity: function(e) {
        return !this.hasValidator() || this._validator.validate(e);
    }
};

var ironValidatableBehavior = {
    get IronValidatableBehaviorMeta() {
        return IronValidatableBehaviorMeta;
    },
    IronValidatableBehavior: IronValidatableBehavior
};

const IronCheckedElementBehaviorImpl = {
    properties: {
        checked: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0,
            notify: !0,
            observer: "_checkedChanged"
        },
        toggles: {
            type: Boolean,
            value: !0,
            reflectToAttribute: !0
        },
        value: {
            type: String,
            value: "on",
            observer: "_valueChanged"
        }
    },
    observers: [ "_requiredChanged(required)" ],
    created: function() {
        this._hasIronCheckedElementBehavior = !0;
    },
    _getValidity: function(e) {
        return this.disabled || !this.required || this.checked;
    },
    _requiredChanged: function() {
        this.required ? this.setAttribute("aria-required", "true") : this.removeAttribute("aria-required");
    },
    _checkedChanged: function() {
        this.active = this.checked, this.fire("iron-change");
    },
    _valueChanged: function() {
        void 0 !== this.value && null !== this.value || (this.value = "on");
    }
}, IronCheckedElementBehavior = [ IronFormElementBehavior, IronValidatableBehavior, IronCheckedElementBehaviorImpl ];

var ironCheckedElementBehavior = {
    IronCheckedElementBehaviorImpl: IronCheckedElementBehaviorImpl,
    IronCheckedElementBehavior: IronCheckedElementBehavior
};

const PaperCheckedElementBehaviorImpl = {
    _checkedChanged: function() {
        IronCheckedElementBehaviorImpl._checkedChanged.call(this), this.hasRipple() && (this.checked ? this._ripple.setAttribute("checked", "") : this._ripple.removeAttribute("checked"));
    },
    _buttonStateChanged: function() {
        PaperRippleBehavior._buttonStateChanged.call(this), this.disabled || this.isAttached && (this.checked = this.active);
    }
}, PaperCheckedElementBehavior = [ PaperInkyFocusBehavior, IronCheckedElementBehavior, PaperCheckedElementBehaviorImpl ];

var paperCheckedElementBehavior = {
    PaperCheckedElementBehaviorImpl: PaperCheckedElementBehaviorImpl,
    PaperCheckedElementBehavior: PaperCheckedElementBehavior
};

const template$4 = html`<style>
  :host {
    display: inline-block;
    white-space: nowrap;
    cursor: pointer;
    --calculated-paper-checkbox-size: var(--paper-checkbox-size, 18px);
    /* -1px is a sentinel for the default and is replaced in \`attached\`. */
    --calculated-paper-checkbox-ink-size: var(--paper-checkbox-ink-size, -1px);
    @apply --paper-font-common-base;
    line-height: 0;
    -webkit-tap-highlight-color: transparent;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host(:focus) {
    outline: none;
  }

  .hidden {
    display: none;
  }

  #checkboxContainer {
    display: inline-block;
    position: relative;
    width: var(--calculated-paper-checkbox-size);
    height: var(--calculated-paper-checkbox-size);
    min-width: var(--calculated-paper-checkbox-size);
    margin: var(--paper-checkbox-margin, initial);
    vertical-align: var(--paper-checkbox-vertical-align, middle);
    background-color: var(--paper-checkbox-unchecked-background-color, transparent);
  }

  #ink {
    position: absolute;

    /* Center the ripple in the checkbox by negative offsetting it by
     * (inkWidth - rippleWidth) / 2 */
    top: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    left: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    width: var(--calculated-paper-checkbox-ink-size);
    height: var(--calculated-paper-checkbox-ink-size);
    color: var(--paper-checkbox-unchecked-ink-color, var(--primary-text-color));
    opacity: 0.6;
    pointer-events: none;
  }

  #ink:dir(rtl) {
    right: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    left: auto;
  }

  #ink[checked] {
    color: var(--paper-checkbox-checked-ink-color, var(--primary-color));
  }

  #checkbox {
    position: relative;
    box-sizing: border-box;
    height: 100%;
    border: solid 2px;
    border-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
    border-radius: 2px;
    pointer-events: none;
    -webkit-transition: background-color 140ms, border-color 140ms;
    transition: background-color 140ms, border-color 140ms;

    -webkit-transition-duration: var(--paper-checkbox-animation-duration, 140ms);
    transition-duration: var(--paper-checkbox-animation-duration, 140ms);
  }

  /* checkbox checked animations */
  #checkbox.checked #checkmark {
    -webkit-animation: checkmark-expand 140ms ease-out forwards;
    animation: checkmark-expand 140ms ease-out forwards;

    -webkit-animation-duration: var(--paper-checkbox-animation-duration, 140ms);
    animation-duration: var(--paper-checkbox-animation-duration, 140ms);
  }

  @-webkit-keyframes checkmark-expand {
    0% {
      -webkit-transform: scale(0, 0) rotate(45deg);
    }
    100% {
      -webkit-transform: scale(1, 1) rotate(45deg);
    }
  }

  @keyframes checkmark-expand {
    0% {
      transform: scale(0, 0) rotate(45deg);
    }
    100% {
      transform: scale(1, 1) rotate(45deg);
    }
  }

  #checkbox.checked {
    background-color: var(--paper-checkbox-checked-color, var(--primary-color));
    border-color: var(--paper-checkbox-checked-color, var(--primary-color));
  }

  #checkmark {
    position: absolute;
    width: 36%;
    height: 70%;
    border-style: solid;
    border-top: none;
    border-left: none;
    border-right-width: calc(2/15 * var(--calculated-paper-checkbox-size));
    border-bottom-width: calc(2/15 * var(--calculated-paper-checkbox-size));
    border-color: var(--paper-checkbox-checkmark-color, white);
    -webkit-transform-origin: 97% 86%;
    transform-origin: 97% 86%;
    box-sizing: content-box; /* protect against page-level box-sizing */
  }

  #checkmark:dir(rtl) {
    -webkit-transform-origin: 50% 14%;
    transform-origin: 50% 14%;
  }

  /* label */
  #checkboxLabel {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    padding-left: var(--paper-checkbox-label-spacing, 8px);
    white-space: normal;
    line-height: normal;
    color: var(--paper-checkbox-label-color, var(--primary-text-color));
    @apply --paper-checkbox-label;
  }

  :host([checked]) #checkboxLabel {
    color: var(--paper-checkbox-label-checked-color, var(--paper-checkbox-label-color, var(--primary-text-color)));
    @apply --paper-checkbox-label-checked;
  }

  #checkboxLabel:dir(rtl) {
    padding-right: var(--paper-checkbox-label-spacing, 8px);
    padding-left: 0;
  }

  #checkboxLabel[hidden] {
    display: none;
  }

  /* disabled state */

  :host([disabled]) #checkbox {
    opacity: 0.5;
    border-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
  }

  :host([disabled][checked]) #checkbox {
    background-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
    opacity: 0.5;
  }

  :host([disabled]) #checkboxLabel  {
    opacity: 0.65;
  }

  /* invalid state */
  #checkbox.invalid:not(.checked) {
    border-color: var(--paper-checkbox-error-color, var(--error-color));
  }
</style>

<div id="checkboxContainer">
  <div id="checkbox" class$="[[_computeCheckboxClass(checked, invalid)]]">
    <div id="checkmark" class$="[[_computeCheckmarkClass(checked)]]"></div>
  </div>
</div>

<div id="checkboxLabel"><slot></slot></div>`;

template$4.setAttribute("strip-whitespace", ""), Polymer({
    _template: template$4,
    is: "paper-checkbox",
    behaviors: [ PaperCheckedElementBehavior ],
    hostAttributes: {
        role: "checkbox",
        "aria-checked": !1,
        tabindex: 0
    },
    properties: {
        ariaActiveAttribute: {
            type: String,
            value: "aria-checked"
        }
    },
    attached: function() {
        afterNextRender(this, function() {
            if ("-1px" === this.getComputedStyleValue("--calculated-paper-checkbox-ink-size").trim()) {
                var e = this.getComputedStyleValue("--calculated-paper-checkbox-size").trim(), t = "px", i = e.match(/[A-Za-z]+$/);
                null !== i && (t = i[0]);
                var o = parseFloat(e), n = 8 / 3 * o;
                "px" === t && (n = Math.floor(n)) % 2 != o % 2 && n++, this.updateStyles({
                    "--paper-checkbox-ink-size": n + t
                });
            }
        });
    },
    _computeCheckboxClass: function(e, t) {
        var i = "";
        return e && (i += "checked "), t && (i += "invalid"), i;
    },
    _computeCheckmarkClass: function(e) {
        return e ? "" : "hidden";
    },
    _createRipple: function() {
        return this._rippleContainer = this.$.checkboxContainer, PaperInkyFocusBehaviorImpl._createRipple.call(this);
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        overflow: hidden; /* needed for text-overflow: ellipsis to work on ff */
        @apply --layout-vertical;
        @apply --layout-center-justified;
        @apply --layout-flex;
      }

      :host([two-line]) {
        min-height: var(--paper-item-body-two-line-min-height, 72px);
      }

      :host([three-line]) {
        min-height: var(--paper-item-body-three-line-min-height, 88px);
      }

      :host > ::slotted(*) {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      :host > ::slotted([secondary]) {
        @apply --paper-font-body1;

        color: var(--paper-item-body-secondary-color, var(--secondary-text-color));

        @apply --paper-item-body-secondary;
      }
    </style>

    <slot></slot>
`,
    is: "paper-item-body"
});

const template$5 = html`

    <style>
      :host {
        display: inline-block;
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-common-base;
      }

      :host([disabled]) {
        pointer-events: none;
      }

      :host(:focus) {
        outline:none;
      }

      .toggle-bar {
        position: absolute;
        height: 100%;
        width: 100%;
        border-radius: 8px;
        pointer-events: none;
        opacity: 0.4;
        transition: background-color linear .08s;
        background-color: var(--paper-toggle-button-unchecked-bar-color, #000000);

        @apply --paper-toggle-button-unchecked-bar;
      }

      .toggle-button {
        position: absolute;
        top: -3px;
        left: 0;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.6);
        transition: -webkit-transform linear .08s, background-color linear .08s;
        transition: transform linear .08s, background-color linear .08s;
        will-change: transform;
        background-color: var(--paper-toggle-button-unchecked-button-color, var(--paper-grey-50));

        @apply --paper-toggle-button-unchecked-button;
      }

      .toggle-button.dragging {
        -webkit-transition: none;
        transition: none;
      }

      :host([checked]:not([disabled])) .toggle-bar {
        opacity: 0.5;
        background-color: var(--paper-toggle-button-checked-bar-color, var(--primary-color));

        @apply --paper-toggle-button-checked-bar;
      }

      :host([disabled]) .toggle-bar {
        background-color: #000;
        opacity: 0.12;
      }

      :host([checked]) .toggle-button {
        -webkit-transform: translate(16px, 0);
        transform: translate(16px, 0);
      }

      :host([checked]:not([disabled])) .toggle-button {
        background-color: var(--paper-toggle-button-checked-button-color, var(--primary-color));

        @apply --paper-toggle-button-checked-button;
      }

      :host([disabled]) .toggle-button {
        background-color: #bdbdbd;
        opacity: 1;
      }

      .toggle-ink {
        position: absolute;
        top: -14px;
        left: -14px;
        right: auto;
        bottom: auto;
        width: 48px;
        height: 48px;
        opacity: 0.5;
        pointer-events: none;
        color: var(--paper-toggle-button-unchecked-ink-color, var(--primary-text-color));

        @apply --paper-toggle-button-unchecked-ink;
      }

      :host([checked]) .toggle-ink {
        color: var(--paper-toggle-button-checked-ink-color, var(--primary-color));

        @apply --paper-toggle-button-checked-ink;
      }

      .toggle-container {
        display: inline-block;
        position: relative;
        width: 36px;
        height: 14px;
        /* The toggle button has an absolute position of -3px; The extra 1px
        /* accounts for the toggle button shadow box. */
        margin: 4px 1px;
      }

      .toggle-label {
        position: relative;
        display: inline-block;
        vertical-align: middle;
        padding-left: var(--paper-toggle-button-label-spacing, 8px);
        pointer-events: none;
        color: var(--paper-toggle-button-label-color, var(--primary-text-color));
      }

      /* invalid state */
      :host([invalid]) .toggle-bar {
        background-color: var(--paper-toggle-button-invalid-bar-color, var(--error-color));
      }

      :host([invalid]) .toggle-button {
        background-color: var(--paper-toggle-button-invalid-button-color, var(--error-color));
      }

      :host([invalid]) .toggle-ink {
        color: var(--paper-toggle-button-invalid-ink-color, var(--error-color));
      }
    </style>

    <div class="toggle-container">
      <div id="toggleBar" class="toggle-bar"></div>
      <div id="toggleButton" class="toggle-button"></div>
    </div>

    <div class="toggle-label"><slot></slot></div>

  `;

function getEmail() {
    return "photoscreensaver@gmail.com";
}

function getEmailBody() {
    return `Extension version: ${getVersion()}\n` + `Chrome version: ${getFullChromeVersion()}\n` + `OS: ${get("os")}\n\n\n`;
}

function getEmailUrl(e, t) {
    return `mailto:${encodeURIComponent(getEmail())}?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(t)}`;
}

function getGithubPath() {
    return "https://github.com/opus1269/screensaver/";
}

function getGithubPagesPath() {
    return DEBUG ? "http://127.0.0.1:4000/" : "https://opus1269.github.io/screensaver/";
}

template$5.setAttribute("strip-whitespace", ""), Polymer({
    _template: template$5,
    is: "paper-toggle-button",
    behaviors: [ PaperCheckedElementBehavior ],
    hostAttributes: {
        role: "button",
        "aria-pressed": "false",
        tabindex: 0
    },
    properties: {},
    listeners: {
        track: "_ontrack"
    },
    attached: function() {
        afterNextRender(this, function() {
            setTouchAction(this, "pan-y");
        });
    },
    _ontrack: function(e) {
        var t = e.detail;
        "start" === t.state ? this._trackStart(t) : "track" === t.state ? this._trackMove(t) : "end" === t.state && this._trackEnd(t);
    },
    _trackStart: function(e) {
        this._width = this.$.toggleBar.offsetWidth / 2, this._trackChecked = this.checked, 
        this.$.toggleButton.classList.add("dragging");
    },
    _trackMove: function(e) {
        var t = e.dx;
        this._x = Math.min(this._width, Math.max(0, this._trackChecked ? this._width + t : t)), 
        this.translate3d(this._x + "px", 0, 0, this.$.toggleButton), this._userActivate(this._x > this._width / 2);
    },
    _trackEnd: function(e) {
        this.$.toggleButton.classList.remove("dragging"), this.transform("", this.$.toggleButton);
    },
    _createRipple: function() {
        this._rippleContainer = this.$.toggleButton;
        var e = PaperRippleBehavior._createRipple();
        return e.id = "ink", e.setAttribute("recenters", ""), e.classList.add("circle", "toggle-ink"), 
        e;
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        position: absolute;
        outline: none;
        z-index: 1002;
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        user-select: none;
        cursor: default;
      }

      #tooltip {
        display: block;
        outline: none;
        @apply --paper-font-common-base;
        font-size: 10px;
        line-height: 1;
        background-color: var(--paper-tooltip-background, #616161);
        color: var(--paper-tooltip-text-color, white);
        padding: 8px;
        border-radius: 2px;
        @apply --paper-tooltip;
      }

      @keyframes keyFrameScaleUp {
        0% {
          transform: scale(0.0);
        }
        100% {
          transform: scale(1.0);
        }
      }

      @keyframes keyFrameScaleDown {
        0% {
          transform: scale(1.0);
        }
        100% {
          transform: scale(0.0);
        }
      }

      @keyframes keyFrameFadeInOpacity {
        0% {
          opacity: 0;
        }
        100% {
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
      }

      @keyframes keyFrameFadeOutOpacity {
        0% {
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
        100% {
          opacity: 0;
        }
      }

      @keyframes keyFrameSlideDownIn {
        0% {
          transform: translateY(-2000px);
          opacity: 0;
        }
        10% {
          opacity: 0.2;
        }
        100% {
          transform: translateY(0);
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
      }

      @keyframes keyFrameSlideDownOut {
        0% {
          transform: translateY(0);
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
        10% {
          opacity: 0.2;
        }
        100% {
          transform: translateY(-2000px);
          opacity: 0;
        }
      }

      .fade-in-animation {
        opacity: 0;
        animation-delay: var(--paper-tooltip-delay-in, 500ms);
        animation-name: keyFrameFadeInOpacity;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-in, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .fade-out-animation {
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 0ms);
        animation-name: keyFrameFadeOutOpacity;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .scale-up-animation {
        transform: scale(0);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-in, 500ms);
        animation-name: keyFrameScaleUp;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-in, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .scale-down-animation {
        transform: scale(1);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameScaleDown;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .slide-down-animation {
        transform: translateY(-2000px);
        opacity: 0;
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameSlideDownIn;
        animation-iteration-count: 1;
        animation-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .slide-down-animation-out {
        transform: translateY(0);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameSlideDownOut;
        animation-iteration-count: 1;
        animation-timing-function: cubic-bezier(0.4, 0.0, 1, 1);
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .cancel-animation {
        animation-delay: -30s !important;
      }

      /* Thanks IE 10. */

      .hidden {
        display: none !important;
      }
    </style>

    <div id="tooltip" class="hidden">
      <slot></slot>
    </div>
`,
    is: "paper-tooltip",
    hostAttributes: {
        role: "tooltip",
        tabindex: -1
    },
    properties: {
        for: {
            type: String,
            observer: "_findTarget"
        },
        manualMode: {
            type: Boolean,
            value: !1,
            observer: "_manualModeChanged"
        },
        position: {
            type: String,
            value: "bottom"
        },
        fitToVisibleBounds: {
            type: Boolean,
            value: !1
        },
        offset: {
            type: Number,
            value: 14
        },
        marginTop: {
            type: Number,
            value: 14
        },
        animationDelay: {
            type: Number,
            value: 500,
            observer: "_delayChange"
        },
        animationEntry: {
            type: String,
            value: ""
        },
        animationExit: {
            type: String,
            value: ""
        },
        animationConfig: {
            type: Object,
            value: function() {
                return {
                    entry: [ {
                        name: "fade-in-animation",
                        node: this,
                        timing: {
                            delay: 0
                        }
                    } ],
                    exit: [ {
                        name: "fade-out-animation",
                        node: this
                    } ]
                };
            }
        },
        _showing: {
            type: Boolean,
            value: !1
        }
    },
    listeners: {
        webkitAnimationEnd: "_onAnimationEnd"
    },
    get target() {
        var e = dom(this).parentNode, t = dom(this).getOwnerRoot();
        return this.for ? dom(t).querySelector("#" + this.for) : e.nodeType == Node.DOCUMENT_FRAGMENT_NODE ? t.host : e;
    },
    attached: function() {
        this._findTarget();
    },
    detached: function() {
        this.manualMode || this._removeListeners();
    },
    playAnimation: function(e) {
        "entry" === e ? this.show() : "exit" === e && this.hide();
    },
    cancelAnimation: function() {
        this.$.tooltip.classList.add("cancel-animation");
    },
    show: function() {
        if (!this._showing) {
            if ("" === dom(this).textContent.trim()) {
                for (var e = !0, t = dom(this).getEffectiveChildNodes(), i = 0; i < t.length; i++) if ("" !== t[i].textContent.trim()) {
                    e = !1;
                    break;
                }
                if (e) return;
            }
            this._showing = !0, this.$.tooltip.classList.remove("hidden"), this.$.tooltip.classList.remove("cancel-animation"), 
            this.$.tooltip.classList.remove(this._getAnimationType("exit")), this.updatePosition(), 
            this._animationPlaying = !0, this.$.tooltip.classList.add(this._getAnimationType("entry"));
        }
    },
    hide: function() {
        if (this._showing) {
            if (this._animationPlaying) return this._showing = !1, void this._cancelAnimation();
            this._onAnimationFinish(), this._showing = !1, this._animationPlaying = !0;
        }
    },
    updatePosition: function() {
        if (this._target && this.offsetParent) {
            var e = this.offset;
            14 != this.marginTop && 14 == this.offset && (e = this.marginTop);
            var t, i, o = this.offsetParent.getBoundingClientRect(), n = this._target.getBoundingClientRect(), a = this.getBoundingClientRect(), r = (n.width - a.width) / 2, s = (n.height - a.height) / 2, l = n.left - o.left, c = n.top - o.top;
            switch (this.position) {
              case "top":
                t = l + r, i = c - a.height - e;
                break;

              case "bottom":
                t = l + r, i = c + n.height + e;
                break;

              case "left":
                t = l - a.width - e, i = c + s;
                break;

              case "right":
                t = l + n.width + e, i = c + s;
            }
            this.fitToVisibleBounds ? (o.left + t + a.width > window.innerWidth ? (this.style.right = "0px", 
            this.style.left = "auto") : (this.style.left = Math.max(0, t) + "px", this.style.right = "auto"), 
            o.top + i + a.height > window.innerHeight ? (this.style.bottom = o.height - c + e + "px", 
            this.style.top = "auto") : (this.style.top = Math.max(-o.top, i) + "px", this.style.bottom = "auto")) : (this.style.left = t + "px", 
            this.style.top = i + "px");
        }
    },
    _addListeners: function() {
        this._target && (this.listen(this._target, "mouseenter", "show"), this.listen(this._target, "focus", "show"), 
        this.listen(this._target, "mouseleave", "hide"), this.listen(this._target, "blur", "hide"), 
        this.listen(this._target, "tap", "hide")), this.listen(this.$.tooltip, "animationend", "_onAnimationEnd"), 
        this.listen(this, "mouseenter", "hide");
    },
    _findTarget: function() {
        this.manualMode || this._removeListeners(), this._target = this.target, this.manualMode || this._addListeners();
    },
    _delayChange: function(e) {
        500 !== e && this.updateStyles({
            "--paper-tooltip-delay-in": e + "ms"
        });
    },
    _manualModeChanged: function() {
        this.manualMode ? this._removeListeners() : this._addListeners();
    },
    _cancelAnimation: function() {
        this.$.tooltip.classList.remove(this._getAnimationType("entry")), this.$.tooltip.classList.remove(this._getAnimationType("exit")), 
        this.$.tooltip.classList.remove("cancel-animation"), this.$.tooltip.classList.add("hidden");
    },
    _onAnimationFinish: function() {
        this._showing && (this.$.tooltip.classList.remove(this._getAnimationType("entry")), 
        this.$.tooltip.classList.remove("cancel-animation"), this.$.tooltip.classList.add(this._getAnimationType("exit")));
    },
    _onAnimationEnd: function() {
        this._animationPlaying = !1, this._showing || (this.$.tooltip.classList.remove(this._getAnimationType("exit")), 
        this.$.tooltip.classList.add("hidden"));
    },
    _getAnimationType: function(e) {
        if ("entry" === e && "" !== this.animationEntry) return this.animationEntry;
        if ("exit" === e && "" !== this.animationExit) return this.animationExit;
        if (this.animationConfig[e] && "string" == typeof this.animationConfig[e][0].name) {
            if (this.animationConfig[e][0].timing && this.animationConfig[e][0].timing.delay && 0 !== this.animationConfig[e][0].timing.delay) {
                var t = this.animationConfig[e][0].timing.delay;
                "entry" === e ? this.updateStyles({
                    "--paper-tooltip-delay-in": t + "ms"
                }) : "exit" === e && this.updateStyles({
                    "--paper-tooltip-delay-out": t + "ms"
                });
            }
            return this.animationConfig[e][0].name;
        }
    },
    _removeListeners: function() {
        this._target && (this.unlisten(this._target, "mouseenter", "show"), this.unlisten(this._target, "focus", "show"), 
        this.unlisten(this._target, "mouseleave", "hide"), this.unlisten(this._target, "blur", "hide"), 
        this.unlisten(this._target, "tap", "hide")), this.unlisten(this.$.tooltip, "animationend", "_onAnimationEnd"), 
        this.unlisten(this, "mouseenter", "hide");
    }
});

var my_utils = {
    getEmail: getEmail,
    getEmailBody: getEmailBody,
    getEmailUrl: getEmailUrl,
    getGithubPath: getGithubPath,
    getGithubPagesPath: getGithubPagesPath
}, __decorate = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let ErrorPageElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.lastError = new ChromeLastError();
    }
    get stack() {
        return this.lastError.message ? this.lastError.stack : "";
    }
    get title() {
        return this.lastError.message ? this.lastError.title : "";
    }
    connectedCallback() {
        super.connectedCallback(), chrome.storage.onChanged.addListener(this.chromeStorageChanged.bind(this));
    }
    disconnectedCallback() {
        super.disconnectedCallback(), chrome.storage.onChanged.removeListener(this.chromeStorageChanged.bind(this));
    }
    ready() {
        super.ready(), setTimeout(async () => {
            try {
                const e = await ChromeLastError.load();
                this.set("lastError", e);
            } catch (e) {
                error(e.message, "ErrorPage.ready");
            }
        }, 0);
    }
    onEmailTapped() {
        let e = getEmailBody();
        e += `${this.lastError.title}\n\n${this.lastError.message}\n\n${this.lastError.stack}`;
        const t = getEmailUrl("Last Error", e += e + "\n\nPlease provide any additional info. on what led to the error.\n\n");
        event(EVENT.ICON, "LastError email"), chrome.tabs.create({
            url: t
        });
    }
    onRemoveTapped() {
        ChromeLastError.reset().catch(() => {}), event(EVENT.ICON, "LastError delete");
    }
    chromeStorageChanged(e) {
        for (const t of Object.keys(e)) if ("lastError" === t) {
            const i = e[t];
            this.set("lastError", i.newValue);
            break;
        }
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">

  :host {
    display: block;
    position: relative;
  }

  .page-container {
    max-width: 1000px;
    height: 100%;
    margin-bottom: 16px;
  }

  #errorViewer {
    min-height: 75vh;
    white-space: pre-wrap;
    overflow: hidden;
    padding-left: 16px;
    padding-right: 16px;
    margin: 0;
  }

  .error-title {
    @apply --paper-font-title;
    padding: 0;
    margin: 0;
  }

  .error-text {
    @apply --paper-font-subhead;
    padding: 0;
    margin: 0;
  }

</style>

<paper-material elevation="1" class="page-container">

  <!-- Tool bar -->
  <paper-material elevation="1">
    <app-toolbar class="page-toolbar">
      <span class="space"></span>
      <div class="middle middle-container center horizontal layout flex">
        <div class="flex">{{localize('last_error_viewer_title')}}</div>
        <paper-icon-button id="email" icon="myicons:mail" disabled$="[[!lastError.message]]">
        </paper-icon-button>
        <paper-tooltip for="email" position="left" offset="0">
          Send email to support
        </paper-tooltip>
        <paper-icon-button id="remove" icon="myicons:delete" disabled$="[[!lastError.message]]">
        </paper-icon-button>
        <paper-tooltip for="remove" position="left" offset="0">
          Delete the error
        </paper-tooltip>
      </div>
    </app-toolbar>
  </paper-material>

  <!-- Content -->
  <div class="page-content">
    <div id="errorViewer">
      <paper-item class="error-title">[[title]]</paper-item>
      <paper-item class="error-text">[[lastError.message]]</paper-item>
      <paper-item class="error-text">[[stack]]</paper-item>
    </div>
  </div>
</paper-material>
`;
    }
};

__decorate([ property({
    type: Object
}) ], ErrorPageElement.prototype, "lastError", void 0), __decorate([ computed("lastError") ], ErrorPageElement.prototype, "stack", null), 
__decorate([ computed("lastError") ], ErrorPageElement.prototype, "title", null), 
__decorate([ listen("tap", "email") ], ErrorPageElement.prototype, "onEmailTapped", null), 
__decorate([ listen("tap", "remove") ], ErrorPageElement.prototype, "onRemoveTapped", null), 
ErrorPageElement = __decorate([ customElement("error-page") ], ErrorPageElement);

var errorPage = {
    get ErrorPageElement() {
        return ErrorPageElement;
    }
};

Polymer({
    is: "iron-iconset-svg",
    properties: {
        name: {
            type: String,
            observer: "_nameChanged"
        },
        size: {
            type: Number,
            value: 24
        },
        rtlMirroring: {
            type: Boolean,
            value: !1
        },
        useGlobalRtlAttribute: {
            type: Boolean,
            value: !1
        }
    },
    created: function() {
        this._meta = new IronMeta({
            type: "iconset",
            key: null,
            value: null
        });
    },
    attached: function() {
        this.style.display = "none";
    },
    getIconNames: function() {
        return this._icons = this._createIconMap(), Object.keys(this._icons).map(function(e) {
            return this.name + ":" + e;
        }, this);
    },
    applyIcon: function(e, t) {
        this.removeIcon(e);
        var i = this._cloneIcon(t, this.rtlMirroring && this._targetIsRTL(e));
        if (i) {
            var o = dom(e.root || e);
            return o.insertBefore(i, o.childNodes[0]), e._svgIcon = i;
        }
        return null;
    },
    removeIcon: function(e) {
        e._svgIcon && (dom(e.root || e).removeChild(e._svgIcon), e._svgIcon = null);
    },
    _targetIsRTL: function(e) {
        if (null == this.__targetIsRTL) if (this.useGlobalRtlAttribute) {
            var t = document.body && document.body.hasAttribute("dir") ? document.body : document.documentElement;
            this.__targetIsRTL = "rtl" === t.getAttribute("dir");
        } else e && e.nodeType !== Node.ELEMENT_NODE && (e = e.host), this.__targetIsRTL = e && "rtl" === window.getComputedStyle(e).direction;
        return this.__targetIsRTL;
    },
    _nameChanged: function() {
        this._meta.value = null, this._meta.key = this.name, this._meta.value = this, this.async(function() {
            this.fire("iron-iconset-added", this, {
                node: window
            });
        });
    },
    _createIconMap: function() {
        var e = Object.create(null);
        return dom(this).querySelectorAll("[id]").forEach(function(t) {
            e[t.id] = t;
        }), e;
    },
    _cloneIcon: function(e, t) {
        return this._icons = this._icons || this._createIconMap(), this._prepareSvgClone(this._icons[e], this.size, t);
    },
    _prepareSvgClone: function(e, t, i) {
        if (e) {
            var o = e.cloneNode(!0), n = document.createElementNS("http://www.w3.org/2000/svg", "svg"), a = o.getAttribute("viewBox") || "0 0 " + t + " " + t, r = "pointer-events: none; display: block; width: 100%; height: 100%;";
            return i && o.hasAttribute("mirror-in-rtl") && (r += "-webkit-transform:scale(-1,1);transform:scale(-1,1);transform-origin:center;"), 
            n.setAttribute("viewBox", a), n.setAttribute("preserveAspectRatio", "xMidYMid meet"), 
            n.setAttribute("focusable", "false"), n.style.cssText = r, n.appendChild(o).removeAttribute("id"), 
            n;
        }
        return null;
    }
});

const $_documentContainer$1 = document.createElement("template");

$_documentContainer$1.innerHTML = '<iron-iconset-svg size="24" name="myicons">\n  <svg><defs>\n    <g id="account-circle"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"></path></g>\n    <g id="check-box"><path d="M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path></g>\n    <g id="check-box-outline-blank"><path d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"></path></g>\n    <g id="cloud"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"></path></g>\n    <g id="delete"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"></path></g>\n    <g id="error"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></g>\n    <g id="extension"><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"></path></g>\n    <g id="github"><path d="M12,2C6.48,2 2,6.48 2,12C2,16.42 4.87,20.17 8.84,21.5C9.34,21.58 9.5,21.27 9.5,21C9.5,20.77 9.5,20.14 9.5,19.31C6.73,19.91 6.14,17.97 6.14,17.97C5.68,16.81 5.03,16.5 5.03,16.5C4.12,15.88 5.1,15.9 5.1,15.9C6.1,15.97 6.63,16.93 6.63,16.93C7.5,18.45 8.97,18 9.54,17.76C9.63,17.11 9.89,16.67 10.17,16.42C7.95,16.17 5.62,15.31 5.62,11.5C5.62,10.39 6,9.5 6.65,8.79C6.55,8.54 6.2,7.5 6.75,6.15C6.75,6.15 7.59,5.88 9.5,7.17C10.29,6.95 11.15,6.84 12,6.84C12.85,6.84 13.71,6.95 14.5,7.17C16.41,5.88 17.25,6.15 17.25,6.15C17.8,7.5 17.45,8.54 17.35,8.79C18,9.5 18.38,10.39 18.38,11.5C18.38,15.32 16.04,16.16 13.81,16.41C14.17,16.72 14.5,17.33 14.5,18.26C14.5,19.6 14.5,20.68 14.5,21C14.5,21.27 14.66,21.59 15.17,21.5C19.14,20.16 22,16.42 22,12C22,6.48 17.52,2 12,2Z"></path></g>\n    <g id="grade"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"></path></g>\n    <g id="help"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"></path></g>\n    <g id="info"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path></g>\n    <g id="mail"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"></path></g>\n    <g id="menu"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></g>\n    <g id="pageview"><path d="M11.5 9C10.12 9 9 10.12 9 11.5s1.12 2.5 2.5 2.5 2.5-1.12 2.5-2.5S12.88 9 11.5 9zM20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-3.21 14.21l-2.91-2.91c-.69.44-1.51.7-2.39.7C9.01 16 7 13.99 7 11.5S9.01 7 11.5 7 16 9.01 16 11.5c0 .88-.26 1.69-.7 2.39l2.91 2.9-1.42 1.42z"></path></g>\n    <g id="photo"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"></path></g>\n    <g id="photo-album"><path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4zm0 15l3-3.86 2.14 2.58 3-3.86L18 19H6z"></path></g>\n    <g id="perm-data-setting"><path d="M18.99 11.5c.34 0 .67.03 1 .07L20 0 0 20h11.56c-.04-.33-.07-.66-.07-1 0-4.14 3.36-7.5 7.5-7.5zm3.71 7.99c.02-.16.04-.32.04-.49 0-.17-.01-.33-.04-.49l1.06-.83c.09-.08.12-.21.06-.32l-1-1.73c-.06-.11-.19-.15-.31-.11l-1.24.5c-.26-.2-.54-.37-.85-.49l-.19-1.32c-.01-.12-.12-.21-.24-.21h-2c-.12 0-.23.09-.25.21l-.19 1.32c-.3.13-.59.29-.85.49l-1.24-.5c-.11-.04-.24 0-.31.11l-1 1.73c-.06.11-.04.24.06.32l1.06.83c-.02.16-.03.32-.03.49 0 .17.01.33.03.49l-1.06.83c-.09.08-.12.21-.06.32l1 1.73c.06.11.19.15.31.11l1.24-.5c.26.2.54.37.85.49l.19 1.32c.02.12.12.21.25.21h2c.12 0 .23-.09.25-.21l.19-1.32c.3-.13.59-.29.84-.49l1.25.5c.11.04.24 0 .31-.11l1-1.73c.06-.11.03-.24-.06-.32l-1.07-.83zm-3.71 1.01c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"></path></g>\n    <g id="refresh"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"></path></g>\n    <g id="settings"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"></path></g>\n    <g id="settings-backup-restore"><path d="M14 12c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2zm-2-9c-4.97 0-9 4.03-9 9H0l4 4 4-4H5c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.51 0-2.91-.49-4.06-1.3l-1.42 1.44C8.04 20.3 9.94 21 12 21c4.97 0 9-4.03 9-9s-4.03-9-9-9z"></path></g>\n  </defs></svg>\n</iron-iconset-svg>', 
document.head.appendChild($_documentContainer$1.content);

const IronLabel = Polymer({
    is: "iron-label",
    listeners: {
        tap: "_tapHandler"
    },
    properties: {
        for: {
            type: String,
            value: "",
            reflectToAttribute: !0,
            observer: "_forChanged"
        },
        _forElement: Object
    },
    attached: function() {
        this._forChanged();
    },
    ready: function() {
        this._generateLabelId();
    },
    _generateLabelId: function() {
        if (!this.id) {
            var e = "iron-label-" + IronLabel._labelNumber++;
            dom(this).setAttribute("id", e);
        }
    },
    _findTarget: function() {
        if (this.for) {
            var e = dom(this).getOwnerRoot();
            return dom(e).querySelector("#" + this.for);
        }
        var t = dom(this).querySelector("[iron-label-target]");
        return t || (t = dom(this).firstElementChild), t;
    },
    _tapHandler: function(e) {
        this._forElement && (dom(e).localTarget !== this._forElement && (this._forElement.focus(), 
        this._forElement.click()));
    },
    _applyLabelledBy: function() {
        this._forElement && dom(this._forElement).setAttribute("aria-labelledby", this.id);
    },
    _forChanged: function() {
        this._forElement && dom(this._forElement).removeAttribute("aria-labelledby"), this._forElement = this._findTarget(), 
        this._applyLabelledBy();
    }
});

IronLabel._labelNumber = 0;

var ironLabel = {
    IronLabel: IronLabel
}, IOS = navigator.userAgent.match(/iP(?:hone|ad;(?: U;)? CPU) OS (\d+)/), IOS_TOUCH_SCROLLING = IOS && IOS[1] >= 8, DEFAULT_PHYSICAL_COUNT = 3, HIDDEN_Y = "-10000px", SECRET_TABINDEX = -100;

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }

      @media only screen and (-webkit-max-device-pixel-ratio: 1) {
        :host {
          will-change: transform;
        }
      }

      #items {
        @apply --iron-list-items-container;
        position: relative;
      }

      :host(:not([grid])) #items > ::slotted(*) {
        width: 100%;
      }

      #items > ::slotted(*) {
        box-sizing: border-box;
        margin: 0;
        position: absolute;
        top: 0;
        will-change: transform;
      }
    </style>

    <array-selector id="selector" items="{{items}}" selected="{{selectedItems}}" selected-item="{{selectedItem}}"></array-selector>

    <div id="items">
      <slot></slot>
    </div>
`,
    is: "iron-list",
    properties: {
        items: {
            type: Array
        },
        as: {
            type: String,
            value: "item"
        },
        indexAs: {
            type: String,
            value: "index"
        },
        selectedAs: {
            type: String,
            value: "selected"
        },
        grid: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0,
            observer: "_gridChanged"
        },
        selectionEnabled: {
            type: Boolean,
            value: !1
        },
        selectedItem: {
            type: Object,
            notify: !0
        },
        selectedItems: {
            type: Object,
            notify: !0
        },
        multiSelection: {
            type: Boolean,
            value: !1
        },
        scrollOffset: {
            type: Number,
            value: 0
        }
    },
    observers: [ "_itemsChanged(items.*)", "_selectionEnabledChanged(selectionEnabled)", "_multiSelectionChanged(multiSelection)", "_setOverflow(scrollTarget, scrollOffset)" ],
    behaviors: [ Templatizer, IronResizableBehavior, IronScrollTargetBehavior, OptionalMutableDataBehavior ],
    _ratio: .5,
    _scrollerPaddingTop: 0,
    _scrollPosition: 0,
    _physicalSize: 0,
    _physicalAverage: 0,
    _physicalAverageCount: 0,
    _physicalTop: 0,
    _virtualCount: 0,
    _estScrollHeight: 0,
    _scrollHeight: 0,
    _viewportHeight: 0,
    _viewportWidth: 0,
    _physicalItems: null,
    _physicalSizes: null,
    _firstVisibleIndexVal: null,
    _lastVisibleIndexVal: null,
    _maxPages: 2,
    _focusedItem: null,
    _focusedVirtualIndex: -1,
    _focusedPhysicalIndex: -1,
    _offscreenFocusedItem: null,
    _focusBackfillItem: null,
    _itemsPerRow: 1,
    _itemWidth: 0,
    _rowHeight: 0,
    _templateCost: 0,
    _parentModel: !0,
    get _physicalBottom() {
        return this._physicalTop + this._physicalSize;
    },
    get _scrollBottom() {
        return this._scrollPosition + this._viewportHeight;
    },
    get _virtualEnd() {
        return this._virtualStart + this._physicalCount - 1;
    },
    get _hiddenContentSize() {
        return (this.grid ? this._physicalRows * this._rowHeight : this._physicalSize) - this._viewportHeight;
    },
    get _itemsParent() {
        return dom(dom(this._userTemplate).parentNode);
    },
    get _maxScrollTop() {
        return this._estScrollHeight - this._viewportHeight + this._scrollOffset;
    },
    get _maxVirtualStart() {
        var e = this._convertIndexToCompleteRow(this._virtualCount);
        return Math.max(0, e - this._physicalCount);
    },
    set _virtualStart(e) {
        e = this._clamp(e, 0, this._maxVirtualStart), this.grid && (e -= e % this._itemsPerRow), 
        this._virtualStartVal = e;
    },
    get _virtualStart() {
        return this._virtualStartVal || 0;
    },
    set _physicalStart(e) {
        (e %= this._physicalCount) < 0 && (e = this._physicalCount + e), this.grid && (e -= e % this._itemsPerRow), 
        this._physicalStartVal = e;
    },
    get _physicalStart() {
        return this._physicalStartVal || 0;
    },
    get _physicalEnd() {
        return (this._physicalStart + this._physicalCount - 1) % this._physicalCount;
    },
    set _physicalCount(e) {
        this._physicalCountVal = e;
    },
    get _physicalCount() {
        return this._physicalCountVal || 0;
    },
    get _optPhysicalSize() {
        return 0 === this._viewportHeight ? 1 / 0 : this._viewportHeight * this._maxPages;
    },
    get _isVisible() {
        return Boolean(this.offsetWidth || this.offsetHeight);
    },
    get firstVisibleIndex() {
        var e = this._firstVisibleIndexVal;
        if (null == e) {
            var t = this._physicalTop + this._scrollOffset;
            e = this._iterateItems(function(e, i) {
                return (t += this._getPhysicalSizeIncrement(e)) > this._scrollPosition ? this.grid ? i - i % this._itemsPerRow : i : this.grid && this._virtualCount - 1 === i ? i - i % this._itemsPerRow : void 0;
            }) || 0, this._firstVisibleIndexVal = e;
        }
        return e;
    },
    get lastVisibleIndex() {
        var e = this._lastVisibleIndexVal;
        if (null == e) {
            if (this.grid) e = Math.min(this._virtualCount, this.firstVisibleIndex + this._estRowsInView * this._itemsPerRow - 1); else {
                var t = this._physicalTop + this._scrollOffset;
                this._iterateItems(function(i, o) {
                    t < this._scrollBottom && (e = o), t += this._getPhysicalSizeIncrement(i);
                });
            }
            this._lastVisibleIndexVal = e;
        }
        return e;
    },
    get _defaultScrollTarget() {
        return this;
    },
    get _virtualRowCount() {
        return Math.ceil(this._virtualCount / this._itemsPerRow);
    },
    get _estRowsInView() {
        return Math.ceil(this._viewportHeight / this._rowHeight);
    },
    get _physicalRows() {
        return Math.ceil(this._physicalCount / this._itemsPerRow);
    },
    get _scrollOffset() {
        return this._scrollerPaddingTop + this.scrollOffset;
    },
    ready: function() {
        this.addEventListener("focus", this._didFocus.bind(this), !0);
    },
    attached: function() {
        this._debounce("_render", this._render, animationFrame), this.listen(this, "iron-resize", "_resizeHandler"), 
        this.listen(this, "keydown", "_keydownHandler");
    },
    detached: function() {
        this.unlisten(this, "iron-resize", "_resizeHandler"), this.unlisten(this, "keydown", "_keydownHandler");
    },
    _setOverflow: function(e) {
        this.style.webkitOverflowScrolling = e === this ? "touch" : "", this.style.overflowY = e === this ? "auto" : "", 
        this._lastVisibleIndexVal = null, this._firstVisibleIndexVal = null, this._debounce("_render", this._render, animationFrame);
    },
    updateViewportBoundaries: function() {
        var e = window.getComputedStyle(this);
        this._scrollerPaddingTop = this.scrollTarget === this ? 0 : parseInt(e["padding-top"], 10), 
        this._isRTL = Boolean("rtl" === e.direction), this._viewportWidth = this.$.items.offsetWidth, 
        this._viewportHeight = this._scrollTargetHeight, this.grid && this._updateGridMetrics();
    },
    _scrollHandler: function() {
        var e = Math.max(0, Math.min(this._maxScrollTop, this._scrollTop)), t = e - this._scrollPosition, i = t >= 0;
        if (this._scrollPosition = e, this._firstVisibleIndexVal = null, this._lastVisibleIndexVal = null, 
        Math.abs(t) > this._physicalSize && this._physicalSize > 0) {
            t -= this._scrollOffset;
            var o = Math.round(t / this._physicalAverage) * this._itemsPerRow;
            this._virtualStart = this._virtualStart + o, this._physicalStart = this._physicalStart + o, 
            this._physicalTop = Math.floor(this._virtualStart / this._itemsPerRow) * this._physicalAverage, 
            this._update();
        } else if (this._physicalCount > 0) {
            var n = this._getReusables(i);
            i ? (this._physicalTop = n.physicalTop, this._virtualStart = this._virtualStart + n.indexes.length, 
            this._physicalStart = this._physicalStart + n.indexes.length) : (this._virtualStart = this._virtualStart - n.indexes.length, 
            this._physicalStart = this._physicalStart - n.indexes.length), this._update(n.indexes, i ? null : n.indexes), 
            this._debounce("_increasePoolIfNeeded", this._increasePoolIfNeeded.bind(this, 0), microTask);
        }
    },
    _getReusables: function(e) {
        var t, i, o, n = [], a = this._hiddenContentSize * this._ratio, r = this._virtualStart, s = this._virtualEnd, l = this._physicalCount, c = this._physicalTop + this._scrollOffset, p = this._physicalBottom + this._scrollOffset, d = this._scrollTop, h = this._scrollBottom;
        for (e ? (t = this._physicalStart, this._physicalEnd, i = d - c) : (t = this._physicalEnd, 
        this._physicalStart, i = p - h); i -= o = this._getPhysicalSizeIncrement(t), !(n.length >= l || i <= a); ) if (e) {
            if (s + n.length + 1 >= this._virtualCount) break;
            if (c + o >= d - this._scrollOffset) break;
            n.push(t), c += o, t = (t + 1) % l;
        } else {
            if (r - n.length <= 0) break;
            if (c + this._physicalSize - o <= h) break;
            n.push(t), c -= o, t = 0 === t ? l - 1 : t - 1;
        }
        return {
            indexes: n,
            physicalTop: c - this._scrollOffset
        };
    },
    _update: function(e, t) {
        if (!(e && 0 === e.length || 0 === this._physicalCount)) {
            if (this._manageFocus(), this._assignModels(e), this._updateMetrics(e), t) for (;t.length; ) {
                var i = t.pop();
                this._physicalTop -= this._getPhysicalSizeIncrement(i);
            }
            this._positionItems(), this._updateScrollerSize();
        }
    },
    _createPool: function(e) {
        var t, i;
        this._ensureTemplatized();
        var o = new Array(e);
        for (t = 0; t < e; t++) i = this.stamp(null), o[t] = i.root.querySelector("*"), 
        this._itemsParent.appendChild(i.root);
        return o;
    },
    _isClientFull: function() {
        return 0 != this._scrollBottom && this._physicalBottom - 1 >= this._scrollBottom && this._physicalTop <= this._scrollPosition;
    },
    _increasePoolIfNeeded: function(e) {
        var t = this._clamp(this._physicalCount + e, DEFAULT_PHYSICAL_COUNT, this._virtualCount - this._virtualStart);
        if (t = this._convertIndexToCompleteRow(t), this.grid) {
            var i = t % this._itemsPerRow;
            i && t - i <= this._physicalCount && (t += this._itemsPerRow), t -= i;
        }
        var o = t - this._physicalCount, n = Math.round(.5 * this._physicalCount);
        if (!(o < 0)) {
            if (o > 0) {
                var a = window.performance.now();
                [].push.apply(this._physicalItems, this._createPool(o));
                for (var r = 0; r < o; r++) this._physicalSizes.push(0);
                this._physicalCount = this._physicalCount + o, this._physicalStart > this._physicalEnd && this._isIndexRendered(this._focusedVirtualIndex) && this._getPhysicalIndex(this._focusedVirtualIndex) < this._physicalEnd && (this._physicalStart = this._physicalStart + o), 
                this._update(), this._templateCost = (window.performance.now() - a) / o, n = Math.round(.5 * this._physicalCount);
            }
            this._virtualEnd >= this._virtualCount - 1 || 0 === n || (this._isClientFull() ? this._physicalSize < this._optPhysicalSize && this._debounce("_increasePoolIfNeeded", this._increasePoolIfNeeded.bind(this, this._clamp(Math.round(50 / this._templateCost), 1, n)), idlePeriod) : this._debounce("_increasePoolIfNeeded", this._increasePoolIfNeeded.bind(this, n), microTask));
        }
    },
    _render: function() {
        if (this.isAttached && this._isVisible) if (0 !== this._physicalCount) {
            var e = this._getReusables(!0);
            this._physicalTop = e.physicalTop, this._virtualStart = this._virtualStart + e.indexes.length, 
            this._physicalStart = this._physicalStart + e.indexes.length, this._update(e.indexes), 
            this._update(), this._increasePoolIfNeeded(0);
        } else this._virtualCount > 0 && (this.updateViewportBoundaries(), this._increasePoolIfNeeded(DEFAULT_PHYSICAL_COUNT));
    },
    _ensureTemplatized: function() {
        if (!this.ctor) {
            this._userTemplate = this.queryEffectiveChildren("template"), this._userTemplate || console.warn("iron-list requires a template to be provided in light-dom");
            var e = {
                __key__: !0
            };
            e[this.as] = !0, e[this.indexAs] = !0, e[this.selectedAs] = !0, e.tabIndex = !0, 
            this._instanceProps = e, this.templatize(this._userTemplate, this.mutableData);
        }
    },
    _gridChanged: function(e, t) {
        void 0 !== t && (this.notifyResize(), flush(), e && this._updateGridMetrics());
    },
    _itemsChanged: function(e) {
        if ("items" === e.path) this._virtualStart = 0, this._physicalTop = 0, this._virtualCount = this.items ? this.items.length : 0, 
        this._physicalIndexForKey = {}, this._firstVisibleIndexVal = null, this._lastVisibleIndexVal = null, 
        this._physicalCount = this._physicalCount || 0, this._physicalItems = this._physicalItems || [], 
        this._physicalSizes = this._physicalSizes || [], this._physicalStart = 0, this._scrollTop > this._scrollOffset && this._resetScrollPosition(0), 
        this._removeFocusedItem(), this._debounce("_render", this._render, animationFrame); else if ("items.splices" === e.path) {
            if (this._adjustVirtualIndex(e.value.indexSplices), this._virtualCount = this.items ? this.items.length : 0, 
            e.value.indexSplices.some(function(e) {
                return e.addedCount > 0 || e.removed.length > 0;
            })) {
                var t = this._getActiveElement();
                this.contains(t) && t.blur();
            }
            var i = e.value.indexSplices.some(function(e) {
                return e.index + e.addedCount >= this._virtualStart && e.index <= this._virtualEnd;
            }, this);
            this._isClientFull() && !i || this._debounce("_render", this._render, animationFrame);
        } else "items.length" !== e.path && this._forwardItemPath(e.path, e.value);
    },
    _forwardItemPath: function(e, t) {
        var i, o, n, a = (e = e.slice(6)).indexOf(".");
        -1 === a && (a = e.length);
        var r = this.modelForElement(this._offscreenFocusedItem), s = parseInt(e.substring(0, a), 10);
        (i = this._isIndexRendered(s)) ? (o = this._getPhysicalIndex(s), n = this.modelForElement(this._physicalItems[o])) : r && (n = r), 
        n && n[this.indexAs] === s && (e = e.substring(a + 1), e = this.as + (e ? "." + e : ""), 
        n._setPendingPropertyOrPath(e, t, !1, !0), n._flushProperties && n._flushProperties(!0), 
        i && (this._updateMetrics([ o ]), this._positionItems(), this._updateScrollerSize()));
    },
    _adjustVirtualIndex: function(e) {
        e.forEach(function(e) {
            if (e.removed.forEach(this._removeItem, this), e.index < this._virtualStart) {
                var t = Math.max(e.addedCount - e.removed.length, e.index - this._virtualStart);
                this._virtualStart = this._virtualStart + t, this._focusedVirtualIndex >= 0 && (this._focusedVirtualIndex = this._focusedVirtualIndex + t);
            }
        }, this);
    },
    _removeItem: function(e) {
        this.$.selector.deselect(e), this._focusedItem && this.modelForElement(this._focusedItem)[this.as] === e && this._removeFocusedItem();
    },
    _iterateItems: function(e, t) {
        var i, o, n, a;
        if (2 === arguments.length && t) {
            for (a = 0; a < t.length; a++) if (i = t[a], o = this._computeVidx(i), null != (n = e.call(this, i, o))) return n;
        } else {
            for (i = this._physicalStart, o = this._virtualStart; i < this._physicalCount; i++, 
            o++) if (null != (n = e.call(this, i, o))) return n;
            for (i = 0; i < this._physicalStart; i++, o++) if (null != (n = e.call(this, i, o))) return n;
        }
    },
    _computeVidx: function(e) {
        return e >= this._physicalStart ? this._virtualStart + (e - this._physicalStart) : this._virtualStart + (this._physicalCount - this._physicalStart) + e;
    },
    _assignModels: function(e) {
        this._iterateItems(function(e, t) {
            var i = this._physicalItems[e], o = this.items && this.items[t];
            if (null != o) {
                var n = this.modelForElement(i);
                n.__key__ = null, this._forwardProperty(n, this.as, o), this._forwardProperty(n, this.selectedAs, this.$.selector.isSelected(o)), 
                this._forwardProperty(n, this.indexAs, t), this._forwardProperty(n, "tabIndex", this._focusedVirtualIndex === t ? 0 : -1), 
                this._physicalIndexForKey[n.__key__] = e, n._flushProperties && n._flushProperties(!0), 
                i.removeAttribute("hidden");
            } else i.setAttribute("hidden", "");
        }, e);
    },
    _updateMetrics: function(e) {
        flush();
        var t = 0, i = 0, o = this._physicalAverageCount, n = this._physicalAverage;
        this._iterateItems(function(e, o) {
            i += this._physicalSizes[e], this._physicalSizes[e] = this._physicalItems[e].offsetHeight, 
            t += this._physicalSizes[e], this._physicalAverageCount += this._physicalSizes[e] ? 1 : 0;
        }, e), this.grid ? (this._updateGridMetrics(), this._physicalSize = Math.ceil(this._physicalCount / this._itemsPerRow) * this._rowHeight) : (i = 1 === this._itemsPerRow ? i : Math.ceil(this._physicalCount / this._itemsPerRow) * this._rowHeight, 
        this._physicalSize = this._physicalSize + t - i, this._itemsPerRow = 1), this._physicalAverageCount !== o && (this._physicalAverage = Math.round((n * o + t) / this._physicalAverageCount));
    },
    _updateGridMetrics: function() {
        this._itemWidth = this._physicalCount > 0 ? this._physicalItems[0].getBoundingClientRect().width : 200, 
        this._rowHeight = this._physicalCount > 0 ? this._physicalItems[0].offsetHeight : 200, 
        this._itemsPerRow = this._itemWidth ? Math.floor(this._viewportWidth / this._itemWidth) : this._itemsPerRow;
    },
    _positionItems: function() {
        this._adjustScrollPosition();
        var e = this._physicalTop;
        if (this.grid) {
            var t = this._itemsPerRow * this._itemWidth, i = (this._viewportWidth - t) / 2;
            this._iterateItems(function(t, o) {
                var n = o % this._itemsPerRow, a = Math.floor(n * this._itemWidth + i);
                this._isRTL && (a *= -1), this.translate3d(a + "px", e + "px", 0, this._physicalItems[t]), 
                this._shouldRenderNextRow(o) && (e += this._rowHeight);
            });
        } else this._iterateItems(function(t, i) {
            this.translate3d(0, e + "px", 0, this._physicalItems[t]), e += this._physicalSizes[t];
        });
    },
    _getPhysicalSizeIncrement: function(e) {
        return this.grid ? this._computeVidx(e) % this._itemsPerRow != this._itemsPerRow - 1 ? 0 : this._rowHeight : this._physicalSizes[e];
    },
    _shouldRenderNextRow: function(e) {
        return e % this._itemsPerRow == this._itemsPerRow - 1;
    },
    _adjustScrollPosition: function() {
        var e = 0 === this._virtualStart ? this._physicalTop : Math.min(this._scrollPosition + this._physicalTop, 0);
        if (0 !== e) {
            this._physicalTop = this._physicalTop - e;
            var t = this._scrollTop;
            !IOS_TOUCH_SCROLLING && t > 0 && this._resetScrollPosition(t - e);
        }
    },
    _resetScrollPosition: function(e) {
        this.scrollTarget && e >= 0 && (this._scrollTop = e, this._scrollPosition = this._scrollTop);
    },
    _updateScrollerSize: function(e) {
        this.grid ? this._estScrollHeight = this._virtualRowCount * this._rowHeight : this._estScrollHeight = this._physicalBottom + Math.max(this._virtualCount - this._physicalCount - this._virtualStart, 0) * this._physicalAverage, 
        ((e = (e = (e = e || 0 === this._scrollHeight) || this._scrollPosition >= this._estScrollHeight - this._physicalSize) || this.grid && this.$.items.style.height < this._estScrollHeight) || Math.abs(this._estScrollHeight - this._scrollHeight) >= this._viewportHeight) && (this.$.items.style.height = this._estScrollHeight + "px", 
        this._scrollHeight = this._estScrollHeight);
    },
    scrollToItem: function(e) {
        return this.scrollToIndex(this.items.indexOf(e));
    },
    scrollToIndex: function(e) {
        if (!("number" != typeof e || e < 0 || e > this.items.length - 1) && (flush(), 0 !== this._physicalCount)) {
            e = this._clamp(e, 0, this._virtualCount - 1), (!this._isIndexRendered(e) || e >= this._maxVirtualStart) && (this._virtualStart = this.grid ? e - 2 * this._itemsPerRow : e - 1), 
            this._manageFocus(), this._assignModels(), this._updateMetrics(), this._physicalTop = Math.floor(this._virtualStart / this._itemsPerRow) * this._physicalAverage;
            for (var t = this._physicalStart, i = this._virtualStart, o = 0, n = this._hiddenContentSize; i < e && o <= n; ) o += this._getPhysicalSizeIncrement(t), 
            t = (t + 1) % this._physicalCount, i++;
            this._updateScrollerSize(!0), this._positionItems(), this._resetScrollPosition(this._physicalTop + this._scrollOffset + o), 
            this._increasePoolIfNeeded(0), this._firstVisibleIndexVal = null, this._lastVisibleIndexVal = null;
        }
    },
    _resetAverage: function() {
        this._physicalAverage = 0, this._physicalAverageCount = 0;
    },
    _resizeHandler: function() {
        this._debounce("_render", function() {
            this._firstVisibleIndexVal = null, this._lastVisibleIndexVal = null, this._isVisible ? (this.updateViewportBoundaries(), 
            this.toggleScrollListener(!0), this._resetAverage(), this._render()) : this.toggleScrollListener(!1);
        }, animationFrame);
    },
    selectItem: function(e) {
        return this.selectIndex(this.items.indexOf(e));
    },
    selectIndex: function(e) {
        if (!(e < 0 || e >= this._virtualCount)) {
            if (!this.multiSelection && this.selectedItem && this.clearSelection(), this._isIndexRendered(e)) {
                var t = this.modelForElement(this._physicalItems[this._getPhysicalIndex(e)]);
                t && (t[this.selectedAs] = !0), this.updateSizeForIndex(e);
            }
            this.$.selector.selectIndex(e);
        }
    },
    deselectItem: function(e) {
        return this.deselectIndex(this.items.indexOf(e));
    },
    deselectIndex: function(e) {
        if (!(e < 0 || e >= this._virtualCount)) {
            if (this._isIndexRendered(e)) this.modelForElement(this._physicalItems[this._getPhysicalIndex(e)])[this.selectedAs] = !1, 
            this.updateSizeForIndex(e);
            this.$.selector.deselectIndex(e);
        }
    },
    toggleSelectionForItem: function(e) {
        return this.toggleSelectionForIndex(this.items.indexOf(e));
    },
    toggleSelectionForIndex: function(e) {
        (this.$.selector.isIndexSelected ? this.$.selector.isIndexSelected(e) : this.$.selector.isSelected(this.items[e])) ? this.deselectIndex(e) : this.selectIndex(e);
    },
    clearSelection: function() {
        this._iterateItems(function(e, t) {
            this.modelForElement(this._physicalItems[e])[this.selectedAs] = !1;
        }), this.$.selector.clearSelection();
    },
    _selectionEnabledChanged: function(e) {
        (e ? this.listen : this.unlisten).call(this, this, "tap", "_selectionHandler");
    },
    _selectionHandler: function(e) {
        var t = this.modelForElement(e.target);
        if (t) {
            var i, o, n = dom(e).path[0], a = this._getActiveElement(), r = this._physicalItems[this._getPhysicalIndex(t[this.indexAs])];
            "input" !== n.localName && "button" !== n.localName && "select" !== n.localName && (i = t.tabIndex, 
            t.tabIndex = SECRET_TABINDEX, o = a ? a.tabIndex : -1, t.tabIndex = i, a && r !== a && r.contains(a) && o !== SECRET_TABINDEX || this.toggleSelectionForItem(t[this.as]));
        }
    },
    _multiSelectionChanged: function(e) {
        this.clearSelection(), this.$.selector.multi = e;
    },
    updateSizeForItem: function(e) {
        return this.updateSizeForIndex(this.items.indexOf(e));
    },
    updateSizeForIndex: function(e) {
        return this._isIndexRendered(e) ? (this._updateMetrics([ this._getPhysicalIndex(e) ]), 
        this._positionItems(), null) : null;
    },
    _manageFocus: function() {
        var e = this._focusedVirtualIndex;
        e >= 0 && e < this._virtualCount ? this._isIndexRendered(e) ? this._restoreFocusedItem() : this._createFocusBackfillItem() : this._virtualCount > 0 && this._physicalCount > 0 && (this._focusedPhysicalIndex = this._physicalStart, 
        this._focusedVirtualIndex = this._virtualStart, this._focusedItem = this._physicalItems[this._physicalStart]);
    },
    _convertIndexToCompleteRow: function(e) {
        return this._itemsPerRow = this._itemsPerRow || 1, this.grid ? Math.ceil(e / this._itemsPerRow) * this._itemsPerRow : e;
    },
    _isIndexRendered: function(e) {
        return e >= this._virtualStart && e <= this._virtualEnd;
    },
    _isIndexVisible: function(e) {
        return e >= this.firstVisibleIndex && e <= this.lastVisibleIndex;
    },
    _getPhysicalIndex: function(e) {
        return (this._physicalStart + (e - this._virtualStart)) % this._physicalCount;
    },
    focusItem: function(e) {
        this._focusPhysicalItem(e);
    },
    _focusPhysicalItem: function(e) {
        if (!(e < 0 || e >= this._virtualCount)) {
            this._restoreFocusedItem(), this._isIndexRendered(e) || this.scrollToIndex(e);
            var t, i = this._physicalItems[this._getPhysicalIndex(e)], o = this.modelForElement(i);
            o.tabIndex = SECRET_TABINDEX, i.tabIndex === SECRET_TABINDEX && (t = i), t || (t = dom(i).querySelector('[tabindex="' + SECRET_TABINDEX + '"]')), 
            o.tabIndex = 0, this._focusedVirtualIndex = e, t && t.focus();
        }
    },
    _removeFocusedItem: function() {
        this._offscreenFocusedItem && this._itemsParent.removeChild(this._offscreenFocusedItem), 
        this._offscreenFocusedItem = null, this._focusBackfillItem = null, this._focusedItem = null, 
        this._focusedVirtualIndex = -1, this._focusedPhysicalIndex = -1;
    },
    _createFocusBackfillItem: function() {
        var e = this._focusedPhysicalIndex;
        if (!(this._offscreenFocusedItem || this._focusedVirtualIndex < 0)) {
            if (!this._focusBackfillItem) {
                var t = this.stamp(null);
                this._focusBackfillItem = t.root.querySelector("*"), this._itemsParent.appendChild(t.root);
            }
            this._offscreenFocusedItem = this._physicalItems[e], this.modelForElement(this._offscreenFocusedItem).tabIndex = 0, 
            this._physicalItems[e] = this._focusBackfillItem, this._focusedPhysicalIndex = e, 
            this.translate3d(0, HIDDEN_Y, 0, this._offscreenFocusedItem);
        }
    },
    _restoreFocusedItem: function() {
        if (this._offscreenFocusedItem && !(this._focusedVirtualIndex < 0)) {
            this._assignModels();
            var e = this._focusedPhysicalIndex = this._getPhysicalIndex(this._focusedVirtualIndex), t = this._physicalItems[e];
            if (t) {
                var i = this.modelForElement(t), o = this.modelForElement(this._offscreenFocusedItem);
                i[this.as] === o[this.as] ? (this._focusBackfillItem = t, i.tabIndex = -1, this._physicalItems[e] = this._offscreenFocusedItem, 
                this.translate3d(0, HIDDEN_Y, 0, this._focusBackfillItem)) : (this._removeFocusedItem(), 
                this._focusBackfillItem = null), this._offscreenFocusedItem = null;
            }
        }
    },
    _didFocus: function(e) {
        var t = this.modelForElement(e.target), i = this.modelForElement(this._focusedItem), o = null !== this._offscreenFocusedItem, n = this._focusedVirtualIndex;
        t && (i === t ? this._isIndexVisible(n) || this.scrollToIndex(n) : (this._restoreFocusedItem(), 
        i && (i.tabIndex = -1), t.tabIndex = 0, n = t[this.indexAs], this._focusedVirtualIndex = n, 
        this._focusedPhysicalIndex = this._getPhysicalIndex(n), this._focusedItem = this._physicalItems[this._focusedPhysicalIndex], 
        o && !this._offscreenFocusedItem && this._update()));
    },
    _keydownHandler: function(e) {
        switch (e.keyCode) {
          case 40:
            this._focusedVirtualIndex < this._virtualCount - 1 && e.preventDefault(), this._focusPhysicalItem(this._focusedVirtualIndex + (this.grid ? this._itemsPerRow : 1));
            break;

          case 39:
            this.grid && this._focusPhysicalItem(this._focusedVirtualIndex + (this._isRTL ? -1 : 1));
            break;

          case 38:
            this._focusedVirtualIndex > 0 && e.preventDefault(), this._focusPhysicalItem(this._focusedVirtualIndex - (this.grid ? this._itemsPerRow : 1));
            break;

          case 37:
            this.grid && this._focusPhysicalItem(this._focusedVirtualIndex + (this._isRTL ? 1 : -1));
            break;

          case 13:
            this._focusPhysicalItem(this._focusedVirtualIndex), this.selectionEnabled && this._selectionHandler(e);
        }
    },
    _clamp: function(e, t, i) {
        return Math.min(i, Math.max(t, e));
    },
    _debounce: function(e, t, i) {
        this._debouncers = this._debouncers || {}, this._debouncers[e] = Debouncer.debounce(this._debouncers[e], i, t.bind(this)), 
        enqueueDebouncer(this._debouncers[e]);
    },
    _forwardProperty: function(e, t, i) {
        e._setPendingProperty(t, i);
    },
    _forwardHostPropV2: function(e, t) {
        (this._physicalItems || []).concat([ this._offscreenFocusedItem, this._focusBackfillItem ]).forEach(function(i) {
            i && this.modelForElement(i).forwardHostProp(e, t);
        }, this);
    },
    _notifyInstancePropV2: function(e, t, i) {
        if (matches$1(this.as, t)) {
            var o = e[this.indexAs];
            t == this.as && (this.items[o] = i), this.notifyPath(translate(this.as, "items." + o, t), i);
        }
    },
    _getStampedChildren: function() {
        return this._physicalItems;
    },
    _forwardInstancePath: function(e, t, i) {
        0 === t.indexOf(this.as + ".") && this.notifyPath("items." + e.__key__ + "." + t.slice(this.as.length + 1), i);
    },
    _forwardParentPath: function(e, t) {
        (this._physicalItems || []).concat([ this._offscreenFocusedItem, this._focusBackfillItem ]).forEach(function(i) {
            i && this.modelForElement(i).notifyPath(e, t, !0);
        }, this);
    },
    _forwardParentProp: function(e, t) {
        (this._physicalItems || []).concat([ this._offscreenFocusedItem, this._focusBackfillItem ]).forEach(function(i) {
            i && (this.modelForElement(i)[e] = t);
        }, this);
    },
    _getActiveElement: function() {
        var e = this._itemsParent.node.domHost;
        return dom(e ? e.root : document).activeElement;
    }
});

/**
    @license
    Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
    This code may only be used under the BSD style license found at
    http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
    http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
    found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
    part of the polymer project is also subject to an additional IP rights grant
    found at http://polymer.github.io/PATENTS.txt
    */
const $_documentContainer$2 = document.createElement("template");

$_documentContainer$2.setAttribute("style", "display: none;"), $_documentContainer$2.innerHTML = "<dom-module id=\"paper-spinner-styles\">\n  <template>\n    <style>\n      /*\n      /**************************/\n      /* STYLES FOR THE SPINNER */\n      /**************************/\n\n      /*\n       * Constants:\n       *      ARCSIZE     = 270 degrees (amount of circle the arc takes up)\n       *      ARCTIME     = 1333ms (time it takes to expand and contract arc)\n       *      ARCSTARTROT = 216 degrees (how much the start location of the arc\n       *                                should rotate each time, 216 gives us a\n       *                                5 pointed star shape (it's 360/5 * 3).\n       *                                For a 7 pointed star, we might do\n       *                                360/7 * 3 = 154.286)\n       *      SHRINK_TIME = 400ms\n       */\n\n      :host {\n        display: inline-block;\n        position: relative;\n        width: 28px;\n        height: 28px;\n\n        /* 360 * ARCTIME / (ARCSTARTROT + (360-ARCSIZE)) */\n        --paper-spinner-container-rotation-duration: 1568ms;\n\n        /* ARCTIME */\n        --paper-spinner-expand-contract-duration: 1333ms;\n\n        /* 4 * ARCTIME */\n        --paper-spinner-full-cycle-duration: 5332ms;\n\n        /* SHRINK_TIME */\n        --paper-spinner-cooldown-duration: 400ms;\n      }\n\n      #spinnerContainer {\n        width: 100%;\n        height: 100%;\n\n        /* The spinner does not have any contents that would have to be\n         * flipped if the direction changes. Always use ltr so that the\n         * style works out correctly in both cases. */\n        direction: ltr;\n      }\n\n      #spinnerContainer.active {\n        -webkit-animation: container-rotate var(--paper-spinner-container-rotation-duration) linear infinite;\n        animation: container-rotate var(--paper-spinner-container-rotation-duration) linear infinite;\n      }\n\n      @-webkit-keyframes container-rotate {\n        to { -webkit-transform: rotate(360deg) }\n      }\n\n      @keyframes container-rotate {\n        to { transform: rotate(360deg) }\n      }\n\n      .spinner-layer {\n        position: absolute;\n        width: 100%;\n        height: 100%;\n        opacity: 0;\n        white-space: nowrap;\n        color: var(--paper-spinner-color, var(--google-blue-500));\n      }\n\n      .layer-1 {\n        color: var(--paper-spinner-layer-1-color, var(--google-blue-500));\n      }\n\n      .layer-2 {\n        color: var(--paper-spinner-layer-2-color, var(--google-red-500));\n      }\n\n      .layer-3 {\n        color: var(--paper-spinner-layer-3-color, var(--google-yellow-500));\n      }\n\n      .layer-4 {\n        color: var(--paper-spinner-layer-4-color, var(--google-green-500));\n      }\n\n      /**\n       * IMPORTANT NOTE ABOUT CSS ANIMATION PROPERTIES (keanulee):\n       *\n       * iOS Safari (tested on iOS 8.1) does not handle animation-delay very well - it doesn't\n       * guarantee that the animation will start _exactly_ after that value. So we avoid using\n       * animation-delay and instead set custom keyframes for each color (as layer-2undant as it\n       * seems).\n       */\n      .active .spinner-layer {\n        -webkit-animation-name: fill-unfill-rotate;\n        -webkit-animation-duration: var(--paper-spinner-full-cycle-duration);\n        -webkit-animation-timing-function: cubic-bezier(0.4, 0.0, 0.2, 1);\n        -webkit-animation-iteration-count: infinite;\n        animation-name: fill-unfill-rotate;\n        animation-duration: var(--paper-spinner-full-cycle-duration);\n        animation-timing-function: cubic-bezier(0.4, 0.0, 0.2, 1);\n        animation-iteration-count: infinite;\n        opacity: 1;\n      }\n\n      .active .spinner-layer.layer-1 {\n        -webkit-animation-name: fill-unfill-rotate, layer-1-fade-in-out;\n        animation-name: fill-unfill-rotate, layer-1-fade-in-out;\n      }\n\n      .active .spinner-layer.layer-2 {\n        -webkit-animation-name: fill-unfill-rotate, layer-2-fade-in-out;\n        animation-name: fill-unfill-rotate, layer-2-fade-in-out;\n      }\n\n      .active .spinner-layer.layer-3 {\n        -webkit-animation-name: fill-unfill-rotate, layer-3-fade-in-out;\n        animation-name: fill-unfill-rotate, layer-3-fade-in-out;\n      }\n\n      .active .spinner-layer.layer-4 {\n        -webkit-animation-name: fill-unfill-rotate, layer-4-fade-in-out;\n        animation-name: fill-unfill-rotate, layer-4-fade-in-out;\n      }\n\n      @-webkit-keyframes fill-unfill-rotate {\n        12.5% { -webkit-transform: rotate(135deg) } /* 0.5 * ARCSIZE */\n        25%   { -webkit-transform: rotate(270deg) } /* 1   * ARCSIZE */\n        37.5% { -webkit-transform: rotate(405deg) } /* 1.5 * ARCSIZE */\n        50%   { -webkit-transform: rotate(540deg) } /* 2   * ARCSIZE */\n        62.5% { -webkit-transform: rotate(675deg) } /* 2.5 * ARCSIZE */\n        75%   { -webkit-transform: rotate(810deg) } /* 3   * ARCSIZE */\n        87.5% { -webkit-transform: rotate(945deg) } /* 3.5 * ARCSIZE */\n        to    { -webkit-transform: rotate(1080deg) } /* 4   * ARCSIZE */\n      }\n\n      @keyframes fill-unfill-rotate {\n        12.5% { transform: rotate(135deg) } /* 0.5 * ARCSIZE */\n        25%   { transform: rotate(270deg) } /* 1   * ARCSIZE */\n        37.5% { transform: rotate(405deg) } /* 1.5 * ARCSIZE */\n        50%   { transform: rotate(540deg) } /* 2   * ARCSIZE */\n        62.5% { transform: rotate(675deg) } /* 2.5 * ARCSIZE */\n        75%   { transform: rotate(810deg) } /* 3   * ARCSIZE */\n        87.5% { transform: rotate(945deg) } /* 3.5 * ARCSIZE */\n        to    { transform: rotate(1080deg) } /* 4   * ARCSIZE */\n      }\n\n      @-webkit-keyframes layer-1-fade-in-out {\n        0% { opacity: 1 }\n        25% { opacity: 1 }\n        26% { opacity: 0 }\n        89% { opacity: 0 }\n        90% { opacity: 1 }\n        to { opacity: 1 }\n      }\n\n      @keyframes layer-1-fade-in-out {\n        0% { opacity: 1 }\n        25% { opacity: 1 }\n        26% { opacity: 0 }\n        89% { opacity: 0 }\n        90% { opacity: 1 }\n        to { opacity: 1 }\n      }\n\n      @-webkit-keyframes layer-2-fade-in-out {\n        0% { opacity: 0 }\n        15% { opacity: 0 }\n        25% { opacity: 1 }\n        50% { opacity: 1 }\n        51% { opacity: 0 }\n        to { opacity: 0 }\n      }\n\n      @keyframes layer-2-fade-in-out {\n        0% { opacity: 0 }\n        15% { opacity: 0 }\n        25% { opacity: 1 }\n        50% { opacity: 1 }\n        51% { opacity: 0 }\n        to { opacity: 0 }\n      }\n\n      @-webkit-keyframes layer-3-fade-in-out {\n        0% { opacity: 0 }\n        40% { opacity: 0 }\n        50% { opacity: 1 }\n        75% { opacity: 1 }\n        76% { opacity: 0 }\n        to { opacity: 0 }\n      }\n\n      @keyframes layer-3-fade-in-out {\n        0% { opacity: 0 }\n        40% { opacity: 0 }\n        50% { opacity: 1 }\n        75% { opacity: 1 }\n        76% { opacity: 0 }\n        to { opacity: 0 }\n      }\n\n      @-webkit-keyframes layer-4-fade-in-out {\n        0% { opacity: 0 }\n        65% { opacity: 0 }\n        75% { opacity: 1 }\n        90% { opacity: 1 }\n        to { opacity: 0 }\n      }\n\n      @keyframes layer-4-fade-in-out {\n        0% { opacity: 0 }\n        65% { opacity: 0 }\n        75% { opacity: 1 }\n        90% { opacity: 1 }\n        to { opacity: 0 }\n      }\n\n      .circle-clipper {\n        display: inline-block;\n        position: relative;\n        width: 50%;\n        height: 100%;\n        overflow: hidden;\n      }\n\n      /**\n       * Patch the gap that appear between the two adjacent div.circle-clipper while the\n       * spinner is rotating (appears on Chrome 50, Safari 9.1.1, and Edge).\n       */\n      .spinner-layer::after {\n        content: '';\n        left: 45%;\n        width: 10%;\n        border-top-style: solid;\n      }\n\n      .spinner-layer::after,\n      .circle-clipper .circle {\n        box-sizing: border-box;\n        position: absolute;\n        top: 0;\n        border-width: var(--paper-spinner-stroke-width, 3px);\n        border-radius: 50%;\n      }\n\n      .circle-clipper .circle {\n        bottom: 0;\n        width: 200%;\n        border-style: solid;\n        border-bottom-color: transparent !important;\n      }\n\n      .circle-clipper.left .circle {\n        left: 0;\n        border-right-color: transparent !important;\n        -webkit-transform: rotate(129deg);\n        transform: rotate(129deg);\n      }\n\n      .circle-clipper.right .circle {\n        left: -100%;\n        border-left-color: transparent !important;\n        -webkit-transform: rotate(-129deg);\n        transform: rotate(-129deg);\n      }\n\n      .active .gap-patch::after,\n      .active .circle-clipper .circle {\n        -webkit-animation-duration: var(--paper-spinner-expand-contract-duration);\n        -webkit-animation-timing-function: cubic-bezier(0.4, 0.0, 0.2, 1);\n        -webkit-animation-iteration-count: infinite;\n        animation-duration: var(--paper-spinner-expand-contract-duration);\n        animation-timing-function: cubic-bezier(0.4, 0.0, 0.2, 1);\n        animation-iteration-count: infinite;\n      }\n\n      .active .circle-clipper.left .circle {\n        -webkit-animation-name: left-spin;\n        animation-name: left-spin;\n      }\n\n      .active .circle-clipper.right .circle {\n        -webkit-animation-name: right-spin;\n        animation-name: right-spin;\n      }\n\n      @-webkit-keyframes left-spin {\n        0% { -webkit-transform: rotate(130deg) }\n        50% { -webkit-transform: rotate(-5deg) }\n        to { -webkit-transform: rotate(130deg) }\n      }\n\n      @keyframes left-spin {\n        0% { transform: rotate(130deg) }\n        50% { transform: rotate(-5deg) }\n        to { transform: rotate(130deg) }\n      }\n\n      @-webkit-keyframes right-spin {\n        0% { -webkit-transform: rotate(-130deg) }\n        50% { -webkit-transform: rotate(5deg) }\n        to { -webkit-transform: rotate(-130deg) }\n      }\n\n      @keyframes right-spin {\n        0% { transform: rotate(-130deg) }\n        50% { transform: rotate(5deg) }\n        to { transform: rotate(-130deg) }\n      }\n\n      #spinnerContainer.cooldown {\n        -webkit-animation: container-rotate var(--paper-spinner-container-rotation-duration) linear infinite, fade-out var(--paper-spinner-cooldown-duration) cubic-bezier(0.4, 0.0, 0.2, 1);\n        animation: container-rotate var(--paper-spinner-container-rotation-duration) linear infinite, fade-out var(--paper-spinner-cooldown-duration) cubic-bezier(0.4, 0.0, 0.2, 1);\n      }\n\n      @-webkit-keyframes fade-out {\n        0% { opacity: 1 }\n        to { opacity: 0 }\n      }\n\n      @keyframes fade-out {\n        0% { opacity: 1 }\n        to { opacity: 0 }\n      }\n    </style>\n  </template>\n</dom-module>", 
document.head.appendChild($_documentContainer$2.content);

const PaperSpinnerBehavior = {
    properties: {
        active: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0,
            observer: "__activeChanged"
        },
        alt: {
            type: String,
            value: "loading",
            observer: "__altChanged"
        },
        __coolingDown: {
            type: Boolean,
            value: !1
        }
    },
    __computeContainerClasses: function(e, t) {
        return [ e || t ? "active" : "", t ? "cooldown" : "" ].join(" ");
    },
    __activeChanged: function(e, t) {
        this.__setAriaHidden(!e), this.__coolingDown = !e && t;
    },
    __altChanged: function(e) {
        "loading" === e ? this.alt = this.getAttribute("aria-label") || e : (this.__setAriaHidden("" === e), 
        this.setAttribute("aria-label", e));
    },
    __setAriaHidden: function(e) {
        e ? this.setAttribute("aria-hidden", "true") : this.removeAttribute("aria-hidden");
    },
    __reset: function() {
        this.active = !1, this.__coolingDown = !1;
    }
};

var paperSpinnerBehavior = {
    PaperSpinnerBehavior: PaperSpinnerBehavior
};

const template$6 = html`
  <style include="paper-spinner-styles"></style>

  <div id="spinnerContainer" class-name="[[__computeContainerClasses(active, __coolingDown)]]" on-animationend="__reset" on-webkit-animation-end="__reset">
    <div class="spinner-layer layer-1">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>

    <div class="spinner-layer layer-2">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>

    <div class="spinner-layer layer-3">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>

    <div class="spinner-layer layer-4">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
`;

template$6.setAttribute("strip-whitespace", ""), Polymer({
    _template: template$6,
    is: "paper-spinner",
    behaviors: [ PaperSpinnerBehavior ]
});

var __decorate$1 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let WaiterElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.active = !1, this.label = "Working...", this.statusLabel = "";
    }
    statusLabelChanged() {
        this.status.innerHTML = this.statusLabel.replace(/\n/g, "<br/>");
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .waiter {
    margin: 40px auto;
  }

  /*noinspection CssUnresolvedCustomPropertySet*/
  :host paper-item {
    @apply --paper-font-title;
    text-align: center;
  }
</style>

<div class="waiter vertical layout center" hidden$="[[!active]]">
  <paper-spinner active="[[active]]" tabindex="-1"></paper-spinner>
  <paper-item>[[label]]</paper-item>
  <paper-item id="status"></paper-item>
</div>
`;
    }
};

__decorate$1([ property({
    type: Boolean,
    notify: !0
}) ], WaiterElement.prototype, "active", void 0), __decorate$1([ property({
    type: String,
    notify: !0
}) ], WaiterElement.prototype, "label", void 0), __decorate$1([ property({
    type: String
}) ], WaiterElement.prototype, "statusLabel", void 0), __decorate$1([ query("#status") ], WaiterElement.prototype, "status", void 0), 
__decorate$1([ observe("statusLabel") ], WaiterElement.prototype, "statusLabelChanged", null), 
WaiterElement = __decorate$1([ customElement("waiter-element") ], WaiterElement);

var waiterElement = {
    get WaiterElement() {
        return WaiterElement;
    }
};

let Options;

window.addEventListener("load", () => {
    Options = document.querySelector("app-main");
});

var AlbumsViewElement_1, options = {
    get Options() {
        return Options;
    }
}, __decorate$2 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

const MAX_ALBUMS = GoogleSource.MAX_ALBUMS, MAX_PHOTOS = GoogleSource.MAX_PHOTOS;

let selections = [], AlbumsViewElement = AlbumsViewElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.waitForLoad = !1, this.permPicasa = "notSet", this.albums = [], 
        this.disabled = !1, this.waiterStatus = "";
    }
    static async updateSavedAlbums() {
        const e = "AlbumViews.updateSavedAlbums";
        try {
            const t = shallowCopy(TYPE.LOAD_ALBUMS), i = await send(t);
            if (!Array.isArray(i)) {
                const t = localize("err_status"), o = i.message;
                return Options.showErrorDialog(t, o, e), !1;
            }
            if (!await asyncSet("albumSelections", i, "useGoogleAlbums")) return selections = await asyncGet("albumSelections", []), 
            Options.showStorageErrorDialog(e), !1;
            selections = i;
        } catch (t) {
            const i = localize("err_status"), o = t.message;
            return Options.showErrorDialog(i, o, e), !1;
        }
        return !0;
    }
    static async getTotalPhotoCount() {
        let e = 0;
        const t = await asyncGet("albumSelections", []);
        for (const i of t) i.photos = i.photos || [], e += i.photos.length;
        return e;
    }
    get isHidden() {
        let e = !0;
        return this.waitForLoad || "allowed" !== this.permPicasa || (e = !1), e;
    }
    connectedCallback() {
        super.connectedCallback(), addListener(this.onChromeMessage.bind(this));
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListener(this.onChromeMessage.bind(this));
    }
    async loadAlbumList(e) {
        const t = "AlbumsView.loadAlbumList", i = localize("err_load_album_list");
        let o;
        this.set("waitForLoad", !0);
        try {
            if (!await request(GOOGLE_PHOTOS)) {
                await removeGooglePhotos();
                const e = i, o = localize("err_auth_picasa");
                return void Options.showErrorDialog(e, o, t);
            }
            if (o = (o = await GoogleSource.loadAlbumList()) || [], this.set("albums", o), 0 === o.length) {
                const e = localize("err_no_albums");
                error$1(e, t, i);
                const o = new CustomEvent("no-albums", {
                    bubbles: !0,
                    composed: !0
                });
                return void this.dispatchEvent(o);
            }
            e && await AlbumsViewElement_1.updateSavedAlbums(), await this.selectSavedAlbums();
        } catch (e) {
            const o = e.message;
            Options.showErrorDialog(i, o, t);
        } finally {
            this.set("waitForLoad", !1);
        }
    }
    async selectAllAlbums() {
        this.set("waitForLoad", !0);
        try {
            for (const e of this.albums) if (!e.checked) {
                if (this.set("albums." + e.index + ".checked", !0), !await this.loadAlbum(e, !1)) break;
            }
        } catch (e) {} finally {
            this.set("waitForLoad", !1);
        }
    }
    removeSelectedAlbums() {
        this.albums.forEach((e, t) => {
            e.checked && this.set("albums." + t + ".checked", !1);
        }), selections = [], asyncSet("albumSelections", []).catch(() => {});
    }
    waitForLoadChanged(e, t) {
        e || (this.ironList._render(), t && this.set("waiterStatus", ""));
    }
    async onAlbumSelectChanged(e) {
        const t = e.model.album;
        event(EVENT.CHECK, `selectGoogleAlbum: ${t.checked}`);
        try {
            if (t.checked) await this.loadAlbum(t, !0); else {
                const e = selections.findIndex(e => e.id === t.id);
                -1 !== e && selections.splice(e, 1), await asyncSet("albumSelections", selections, "useGoogleAlbums") || (selections.pop(), 
                this.set("albums." + t.index + ".checked", !1), Options.showStorageErrorDialog("AlbumViews.onAlbumSelectChanged"));
            }
        } catch (e) {}
    }
    onChromeMessage(e, t, i) {
        if (e.message === TYPE.ALBUM_COUNT.message) {
            const t = e.name || "", o = e.count || 0, n = `${t}\n${localize("photo_count")} ${o.toString()}`;
            this.set("waiterStatus", n), i({
                message: "OK"
            });
        }
        return !1;
    }
    async loadAlbum(e, t = !0) {
        const i = "AlbumViews.loadAlbum", o = localize("err_load_album");
        let n, a = !1;
        try {
            if (selections.length >= MAX_ALBUMS) {
                event(EVENT$1.ALBUMS_LIMITED, `limit: ${MAX_ALBUMS}`), this.set("albums." + e.index + ".checked", !1);
                const t = localize("err_max_albums");
                return Options.showErrorDialog(o, t, i), a;
            }
            const r = await AlbumsViewElement_1.getTotalPhotoCount();
            if (r >= MAX_PHOTOS) {
                event(EVENT$1.PHOTO_SELECTIONS_LIMITED, `limit: ${r}`), this.set("albums." + e.index + ".checked", !1);
                const t = localize("err_max_photos");
                return Options.showErrorDialog(o, t, i), a;
            }
            t && this.set("waitForLoad", !0);
            const s = shallowCopy(TYPE.LOAD_ALBUM);
            s.id = e.id, s.name = e.name;
            const l = await send(s);
            if (l && l.photos) {
                if (selections.push({
                    id: e.id,
                    name: l.name,
                    photos: l.photos
                }), event(EVENT$1.SELECT_ALBUM, `maxPhotos: ${e.ct}, actualPhotosLoaded: ${l.ct}`), 
                !await asyncSet("albumSelections", selections, "useGoogleAlbums")) return selections.pop(), 
                this.set("albums." + e.index + ".checked", !1), Options.showStorageErrorDialog(i), 
                a;
                this.set("albums." + e.index + ".ct", l.ct);
            } else n = new Error(l.message), this.set("albums." + e.index + ".checked", !1);
        } catch (e) {
            n = e;
        } finally {
            t && this.set("waitForLoad", !1);
        }
        return n ? Options.showErrorDialog(o, n.message, i) : a = !0, a;
    }
    async selectSavedAlbums() {
        selections = await asyncGet("albumSelections", []);
        for (let e = 0; e < this.albums.length; e++) for (const t of selections) if (this.albums[e].id === t.id) {
            this.set("albums." + e + ".checked", !0), this.set("albums." + e + ".ct", t.photos.length);
            break;
        }
    }
    computePhotoLabel(e) {
        let t = `${e} ${localize("photos")}`;
        return 1 === e && (t = `${e} ${localize("photo")}`), t;
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .waiter {
    margin: 40px auto;
  }

  :host .waiter paper-item {
    @apply --paper-font-title;
    margin: 40px auto;
  }

  :host .list-note {
    height: 48px;
    @apply --paper-font-title;
    border: 1px #CCCCCC;
    border-bottom-style: solid;
    padding: 8px 16px 8px 16px;
    white-space: normal;
  }

  :host .list-item {
    position: relative;
    border: 1px #CCCCCC;
    border-bottom-style: solid;
    padding: 0 0 0 5px;
    cursor: pointer;
  }

  :host .list-item paper-item-body {
    padding-left: 10px;
  }

  :host .list-item paper-item {
    padding-right: 0;
  }

  :host .list-item iron-image {
    height: 72px;
    width: 72px;
  }

  :host .list-item[disabled] iron-image {
    opacity: .2;
  }

  :host .list-item[disabled] {
    pointer-events: none;
  }

  :host .list-item[disabled] .setting-label {
    color: var(--disabled-text-color);
  }

  :host #ironList {
    /* browser viewport height minus both toolbars and note*/
    height: calc(100vh - 193px);
  }
</style>

<waiter-element active="[[waitForLoad]]" label="[[localize('google_loading')]]"
                status-label="[[waiterStatus]]"></waiter-element>

<div class="list-container" hidden$="[[isHidden]]">
  <paper-item class="list-note">
    [[localize('google_shared_albums_note')]]
  </paper-item>

  <iron-list id="ironList" mutable-data="true" items="{{albums}}" as="album">
    <template>
      <iron-label>
        <div class="list-item" id="[[album.uid]]" disabled$="[[disabled]]">
          <paper-item class="center horizontal layout" tabindex="-1">
            <paper-checkbox iron-label-target="" checked="{{album.checked}}" on-change="onAlbumSelectChanged"
                            disabled$="[[disabled]]"></paper-checkbox>
            <paper-item-body class="flex" two-line="">
              <div class="setting-label">[[album.name]]</div>
              <div class="setting-label" secondary="">[[computePhotoLabel(album.ct)]]</div>
              <paper-ripple center=""></paper-ripple>
            </paper-item-body>
            <iron-image src="[[album.thumb]]" sizing="cover" preload="" disabled$="[[disabled]]"></iron-image>
          </paper-item>
        </div>
      </iron-label>
    </template>
  </iron-list>

  <app-localstorage-document key="permPicasa" data="{{permPicasa}}" storage="window.localStorage">
  </app-localstorage-document>

</div>

`;
    }
};

__decorate$2([ property({
    type: Boolean
}) ], AlbumsViewElement.prototype, "waitForLoad", void 0), __decorate$2([ property({
    type: String,
    notify: !0
}) ], AlbumsViewElement.prototype, "permPicasa", void 0), __decorate$2([ property({
    type: Array,
    notify: !0
}) ], AlbumsViewElement.prototype, "albums", void 0), __decorate$2([ property({
    type: Boolean
}) ], AlbumsViewElement.prototype, "disabled", void 0), __decorate$2([ property({
    type: Boolean
}) ], AlbumsViewElement.prototype, "waiterStatus", void 0), __decorate$2([ computed("waitForLoad", "permPicasa") ], AlbumsViewElement.prototype, "isHidden", null), 
__decorate$2([ query("#ironList") ], AlbumsViewElement.prototype, "ironList", void 0), 
__decorate$2([ observe("waitForLoad", "waiterStatus") ], AlbumsViewElement.prototype, "waitForLoadChanged", null), 
AlbumsViewElement = AlbumsViewElement_1 = __decorate$2([ customElement("albums-view") ], AlbumsViewElement);

var albumsView = {
    get AlbumsViewElement() {
        return AlbumsViewElement;
    }
}, __decorate$3 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SettingBase = class extends BaseElement {
    constructor() {
        super(...arguments), this.name = "store", this.sectionTitle = "", this.disabled = !1, 
        this.noseparator = !1;
    }
    static get mainContent() {
        return html$2`Forget to override mainContent?`;
    }
    static get template() {
        return html$2`
<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }
  
</style>

<div id="test" class="section-title setting-label" tabindex="-1" hidden$="[[!sectionTitle]]">
  [[sectionTitle]]
</div>

<div>${this.mainContent}</div>

<hr class="divider" hidden$="[[noseparator]]">
`;
    }
};

__decorate$3([ property({
    type: String
}) ], SettingBase.prototype, "name", void 0), __decorate$3([ property({
    type: String
}) ], SettingBase.prototype, "sectionTitle", void 0), __decorate$3([ property({
    type: Boolean
}) ], SettingBase.prototype, "disabled", void 0), __decorate$3([ property({
    type: Boolean
}) ], SettingBase.prototype, "noseparator", void 0), SettingBase = __decorate$3([ customElement("setting-base") ], SettingBase);

var settingBase = {
    get SettingBase() {
        return SettingBase;
    }
}, __decorate$4 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SettingToggleElement = class extends SettingBase {
    setChecked(e) {
        this.set("checked", e), event(EVENT.TOGGLE, `${this.name}: ${this.checked}`);
    }
    onChange() {
        event(EVENT.TOGGLE, `${this.name}: ${this.checked}`);
    }
    onTap(e) {
        e.stopPropagation();
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host iron-label {
    display: block;
    position: relative;
    cursor: pointer;
  }

  :host([indent]) paper-item {
    padding-left: 24px;
  }
</style>

<iron-label for="toggle">
  <paper-item class="center horizontal layout" tabindex="-1">
    <paper-item-body class="flex" two-line="">
      <div class="setting-label" hidden$="[[!mainLabel]]">
        [[mainLabel]]
      </div>
      <div class="setting-label" secondary="" hidden$="[[!secondaryLabel]]">
        [[secondaryLabel]]
      </div>
      <paper-ripple center=""></paper-ripple>
    </paper-item-body>
    <paper-toggle-button id="toggle" class="setting-toggle-button" checked="{{checked}}"
                         disabled$="[[disabled]]">
    </paper-toggle-button>
  </paper-item>
</iron-label>

<app-localstorage-document key="[[name]]" data="{{checked}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$4([ property({
    type: Boolean,
    notify: !0
}) ], SettingToggleElement.prototype, "checked", void 0), __decorate$4([ property({
    type: String
}) ], SettingToggleElement.prototype, "mainLabel", void 0), __decorate$4([ property({
    type: String
}) ], SettingToggleElement.prototype, "secondaryLabel", void 0), __decorate$4([ listen("change", "toggle") ], SettingToggleElement.prototype, "onChange", null), 
__decorate$4([ listen("tap", "toggle") ], SettingToggleElement.prototype, "onTap", null), 
SettingToggleElement = __decorate$4([ customElement("setting-toggle") ], SettingToggleElement);

var settingToggle = {
    get SettingToggleElement() {
        return SettingToggleElement;
    }
}, __decorate$5 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let PhotoCatElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.checked = !1, this.label = "", this.sectionTitle = "", 
        this.disabled = !1;
    }
    onCheckedChange(e) {
        const t = e.target.checked;
        event(EVENT.CHECK, `${this.id}: ${t}`);
        const i = new CustomEvent("value-changed", {
            bubbles: !0,
            composed: !0,
            detail: {
                value: t
            }
        });
        this.dispatchEvent(i);
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host iron-label {
    display: block;
    position: relative;
    cursor: pointer;
  }

</style>

<iron-label for="checkbox">
  <paper-item class="center horizontal layout" tabindex="-1">
    <paper-item class="setting-label flex">
      [[label]]
      <paper-ripple center=""></paper-ripple>
    </paper-item>
    <paper-checkbox id="checkbox" name="include" checked="{{checked}}"
                    disabled$="[[disabled]]">
      [[localize('include')]]
    </paper-checkbox>
  </paper-item>
</iron-label>
`;
    }
};

__decorate$5([ property({
    type: Boolean,
    notify: !0
}) ], PhotoCatElement.prototype, "checked", void 0), __decorate$5([ property({
    type: String
}) ], PhotoCatElement.prototype, "label", void 0), __decorate$5([ property({
    type: String
}) ], PhotoCatElement.prototype, "sectionTitle", void 0), __decorate$5([ property({
    type: Boolean
}) ], PhotoCatElement.prototype, "disabled", void 0), __decorate$5([ listen("change", "checkbox") ], PhotoCatElement.prototype, "onCheckedChange", null), 
PhotoCatElement = __decorate$5([ customElement("photo-cat") ], PhotoCatElement);

var photo_cat = {
    get PhotoCatElement() {
        return PhotoCatElement;
    }
}, __decorate$6 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let PhotosViewElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.needsPhotoRefresh = !0, this.noFilter = !0, this.permPicasa = "notSet", 
        this.disabled = !1, this.waitForLoad = !1, this.cats = [ {
            name: "LANDSCAPES",
            label: localize("photo_cat_landscapes")
        }, {
            name: "CITYSCAPES",
            label: localize("photo_cat_cityscapes")
        }, {
            name: "LANDMARKS",
            label: localize("photo_cat_landmarks")
        }, {
            name: "PEOPLE",
            label: localize("photo_cat_people")
        }, {
            name: "ANIMALS",
            label: localize("photo_cat_animals")
        }, {
            name: "PETS",
            label: localize("photo_cat_pets")
        }, {
            name: "PERFORMANCES",
            label: localize("photo_cat_performances")
        }, {
            name: "SPORT",
            label: localize("photo_cat_sport")
        }, {
            name: "FOOD",
            label: localize("photo_cat_food")
        }, {
            name: "SELFIES",
            label: localize("photo_cat_selfies")
        } ], this.photoCount = 0, this.waiterStatus = "";
    }
    get isHidden() {
        let e = !0;
        return this.waitForLoad || "allowed" !== this.permPicasa || (e = !1), e;
    }
    get isFilterDisabled() {
        return this.disabled || this.noFilter;
    }
    get isRefreshDisabled() {
        return this.disabled || !this.needsPhotoRefresh;
    }
    connectedCallback() {
        super.connectedCallback(), addListener(this.onChromeMessage.bind(this)), chrome.storage.onChanged.addListener(this.chromeStorageChanged.bind(this));
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListener(this.onChromeMessage.bind(this)), chrome.storage.onChanged.removeListener(this.chromeStorageChanged.bind(this));
    }
    ready() {
        super.ready(), setTimeout(() => {
            this.setPhotoCount().catch(() => {}), this._setPhotoCats();
        }, 0);
    }
    async loadPhotos() {
        const e = "PhotosView.loadPhotos";
        let t;
        try {
            if (!await request(GOOGLE_PHOTOS)) {
                await removeGooglePhotos();
                const t = localize("err_load_photos"), i = localize("err_auth_picasa");
                return void Options.showErrorDialog(t, i, e);
            }
            this.set("waitForLoad", !0);
            const i = await send(TYPE.LOAD_FILTERED_PHOTOS);
            if (Array.isArray(i)) {
                await asyncSet("googleImages", i, "useGooglePhotos") ? this.set("needsPhotoRefresh", !1) : (Options.showStorageErrorDialog(e), 
                this.set("needsPhotoRefresh", !0)), await this.setPhotoCount();
            } else t = new Error(i.message);
        } catch (e) {
            t = e;
        } finally {
            this.set("waitForLoad", !1);
        }
        if (t) {
            const i = localize("err_load_photos"), o = t.message;
            Options.showErrorDialog(i, o, e);
        }
    }
    async setPhotoCount() {
        const e = await asyncGet("googleImages", []);
        this.set("photoCount", e.length);
    }
    onRefreshPhotosClicked() {
        this.loadPhotos().catch(() => {}), event(EVENT.BUTTON, "refreshPhotos");
    }
    chromeStorageChanged(e) {
        for (const t of Object.keys(e)) if ("googleImages" === t) {
            this.setPhotoCount().catch(() => {}), this.set("needsPhotoRefresh", !0);
            break;
        }
    }
    waitForLoadChanged(e, t) {
        !e && t && this.set("waiterStatus", "");
    }
    _noFilterChanged(e, t) {
        void 0 !== e && void 0 !== t && e !== t && this.set("needsPhotoRefresh", !0);
    }
    _setPhotoCats() {
        const e = this.shadowRoot.querySelectorAll("photo-cat"), t = get("googlePhotosFilter", GoogleSource.DEF_FILTER);
        t.contentFilter = t.contentFilter || {};
        const i = t.contentFilter.includedContentCategories || [];
        for (const t of e) {
            const e = t.id, o = i.findIndex(t => t === e);
            t.set("checked", -1 !== o);
        }
    }
    _onPhotoCatChanged(e) {
        const t = e.target.id, i = e.detail.value, o = get("googlePhotosFilter", GoogleSource.DEF_FILTER);
        o.contentFilter = o.contentFilter || {};
        const n = o.contentFilter.includedContentCategories || [], a = n.findIndex(e => e === t);
        i ? -1 === a && n.push(t) : -1 !== a && n.splice(a, 1), o.contentFilter.includedContentCategories = n, 
        this.set("needsPhotoRefresh", !0), set("googlePhotosFilter", o);
    }
    onChromeMessage(e, t, i) {
        if (e.message === TYPE.FILTERED_PHOTOS_COUNT.message) {
            const t = e.count || 0, o = `${localize("photo_count")} ${t.toString()}`;
            this.set("waiterStatus", o), i({
                message: "OK"
            });
        }
        return !1;
    }
    static get template() {
        return html$2`
<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .album-note {
    @apply --paper-font-title;
    border: 1px #CCCCCC;
    border-top-style: solid;
    padding: 8px 16px 8px 16px;
    margin-right: 0;
    white-space: normal;
  }

  :host .photo-count-container {
    border: 1px #CCCCCC;
    border-bottom-style: solid;
    padding: 16px 0 16px 0;
    white-space: normal;
  }

  :host .photo-count-container paper-button {
    margin: 0 8px 0 0;
    @apply --paper-font-title;
  }

  :host .photo-count-container #photoCount {
    @apply --paper-font-title;
    padding-right: 0;
  }

</style>

<waiter-element active="[[waitForLoad]]" label="[[localize('google_loading')]]"
                status-label="[[waiterStatus]]"></waiter-element>

<div class="photos-container" hidden$="[[isHidden]]">
  <div class="photo-count-container horizontal layout">
    <paper-item class="flex" id="photoCount" disabled$="[[disabled]]">
      <span>[[localize('photo_count')]]</span>&nbsp <span>[[photoCount]]</span>
    </paper-item>
    <paper-button id="refreshButton" raised disabled$="[[isRefreshDisabled]]">
      [[localize('button_needs_refresh')]]
    </paper-button>
  </div>

  <setting-toggle name="noFilter" main-label="{{localize('photo_no_filter')}}"
                  secondary-label="{{localize('photo_no_filter_desc')}}"
                  checked="{{noFilter}}" disabled$="[[disabled]]"></setting-toggle>

  <div class="section-title">[[localize('photo_cat_title')]]</div>

  <template id="t" is="dom-repeat" items="[[cats]]" as="cat">
    <photo-cat id="[[cat.name]]"
               label="[[cat.label]]"
               on-value-changed="_onPhotoCatChanged"
               disabled$="[[isFilterDisabled]]"></photo-cat>
  </template>

  <paper-item class="album-note">
    {{localize('note_albums')}}
  </paper-item>

  <app-localstorage-document key="permPicasa" data="{{permPicasa}}" storage="window.localStorage">
  </app-localstorage-document>
  <app-localstorage-document key="googlePhotosNoFilter" data="{{noFilter}}" storage="window.localStorage">
  </app-localstorage-document>

</div>
`;
    }
};

__decorate$6([ property({
    type: Boolean,
    notify: !0
}) ], PhotosViewElement.prototype, "needsPhotoRefresh", void 0), __decorate$6([ property({
    type: Boolean,
    notify: !0,
    observer: "_noFilterChanged"
}) ], PhotosViewElement.prototype, "noFilter", void 0), __decorate$6([ property({
    type: String,
    notify: !0
}) ], PhotosViewElement.prototype, "permPicasa", void 0), __decorate$6([ property({
    type: Boolean
}) ], PhotosViewElement.prototype, "disabled", void 0), __decorate$6([ property({
    type: Boolean
}) ], PhotosViewElement.prototype, "waitForLoad", void 0), __decorate$6([ property({
    type: Array
}) ], PhotosViewElement.prototype, "cats", void 0), __decorate$6([ property({
    type: Number,
    notify: !0
}) ], PhotosViewElement.prototype, "photoCount", void 0), __decorate$6([ property({
    type: Boolean
}) ], PhotosViewElement.prototype, "waiterStatus", void 0), __decorate$6([ computed("waitForLoad", "permPicasa") ], PhotosViewElement.prototype, "isHidden", null), 
__decorate$6([ computed("disabled", "noFilter") ], PhotosViewElement.prototype, "isFilterDisabled", null), 
__decorate$6([ computed("disabled", "needsPhotoRefresh") ], PhotosViewElement.prototype, "isRefreshDisabled", null), 
__decorate$6([ listen("click", "refreshButton") ], PhotosViewElement.prototype, "onRefreshPhotosClicked", null), 
__decorate$6([ observe("waitForLoad", "waiterStatus") ], PhotosViewElement.prototype, "waitForLoadChanged", null), 
PhotosViewElement = __decorate$6([ customElement("photos-view") ], PhotosViewElement);

var photosView = {
    get PhotosViewElement() {
        return PhotosViewElement;
    }
}, __decorate$7 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let GooglePhotosPageElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.isAlbumMode = !0, this.useGoogle = !0, this.useGoogleAlbums = !0, 
        this.useGooglePhotos = !1;
    }
    get pageTitle() {
        return this.isAlbumMode ? localize("google_title") : localize("google_title_photos");
    }
    get refreshTooltipLabel() {
        return this.isAlbumMode ? localize("tooltip_refresh") : localize("tooltip_refresh_photos");
    }
    get modeTooltipLabel() {
        return this.isAlbumMode ? localize("tooltip_google_mode_albums") : localize("tooltip_google_mode_photos");
    }
    get modeIcon() {
        return this.isAlbumMode ? "myicons:photo-album" : "myicons:photo";
    }
    get isAlbumIconDisabled() {
        return !(this.useGoogle && this.isAlbumMode);
    }
    ready() {
        super.ready(), setTimeout(() => {
            this.isAlbumMode && this.loadAlbumList().catch(() => {});
        }, 0);
    }
    async loadAlbumList(e = !1) {
        try {
            this.isAlbumMode && await this.albumsView.loadAlbumList(e);
        } catch (e) {}
    }
    onModeTapped() {
        const e = localize("desc_mode_switch"), t = localize("title_mode_switch"), i = localize("button_mode_switch");
        Options.showConfirmDialog(e, t, i, this.changeMode.bind(this)), event(EVENT.ICON, "changeGooglePhotosMode");
    }
    onRefreshTapped() {
        this.isAlbumMode ? this.loadAlbumList().catch(() => {}) : this.loadPhotos().catch(() => {});
        const e = this.isAlbumMode ? "refreshGoogleAlbums" : "refreshGooglePhotos";
        event(EVENT.ICON, e);
    }
    onHelpTapped() {
        event(EVENT.ICON, "googlePhotosHelp");
        const e = this.isAlbumMode ? "albums" : "photos", t = `${getGithubPagesPath()}help/google_photos.html#${e}`;
        chrome.tabs.create({
            url: t
        });
    }
    onDeselectAllTapped() {
        this.albumsView.removeSelectedAlbums(), event(EVENT.ICON, "deselectAllGoogleAlbums");
    }
    onSelectAllTapped() {
        this.albumsView.selectAllAlbums().catch(() => {}), event(EVENT.ICON, "selectAllGoogleAlbums");
    }
    onUseGoogleChanged() {
        const e = this.googlePhotosToggle.checked;
        e && (this.isAlbumMode ? this.loadAlbumList(!0).catch(() => {}) : this.loadPhotos().catch(() => {})), 
        event(EVENT.TOGGLE, `useGoogle: ${e}`);
    }
    onNoAlbums() {
        this.changeMode();
    }
    uiStateChanged(e, t) {
        if (void 0 === e || void 0 === t) return;
        const i = t && e, o = t && !e;
        this.set("useGoogleAlbums", i), this.set("useGooglePhotos", o);
    }
    async loadPhotos() {
        try {
            !this.isAlbumMode && this.useGoogle && await this.photosView.loadPhotos();
        } catch (e) {}
    }
    changeMode() {
        this.set("isAlbumMode", !this.isAlbumMode), this.isAlbumMode ? (asyncSet("googleImages", []).catch(() => {}), 
        this.loadAlbumList().catch(() => {})) : (this.albumsView.removeSelectedAlbums(), 
        this.photosView.setPhotoCount().catch(() => {}));
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .page-toolbar {
    margin: 0;
  }

  :host .page-container {
    margin-bottom: 0;
  }

  :host .page-content {
    min-height: calc(100vh - 128px);
    margin: 0;
  }

</style>

<paper-material elevation="1" class="page-container">
  
  <paper-material elevation="1">
    <app-toolbar class="page-toolbar">
      <div class="flex">[[pageTitle]]</div>
      <paper-icon-button
          id="mode"
          icon="[[modeIcon]]"
          disabled$="[[!useGoogle]]"></paper-icon-button>
      <paper-tooltip for="mode" position="left" offset="0">
        [[modeTooltipLabel]]
      </paper-tooltip>
      <paper-icon-button id="select" icon="myicons:check-box""
                         disabled$="[[isAlbumIconDisabled]]"></paper-icon-button>
      <paper-tooltip for="select" position="left" offset="0">
        [[localize('tooltip_select')]]
      </paper-tooltip>
      <paper-icon-button id="deselect" icon="myicons:check-box-outline-blank"
                         disabled$="[[isAlbumIconDisabled]]"></paper-icon-button>
      <paper-tooltip for="deselect" position="left" offset="0">
        [[localize('tooltip_deselect')]]
      </paper-tooltip>
      <paper-icon-button id="refresh" icon="myicons:refresh"
                         disabled$="[[!useGoogle]]"></paper-icon-button>
      <paper-tooltip for="refresh" position="left" offset="0">
        [[refreshTooltipLabel]]
      </paper-tooltip>
      <paper-icon-button id="help" icon="myicons:help"></paper-icon-button>
      <paper-tooltip for="help" position="left" offset="0">
        [[localize('help')]]
      </paper-tooltip>
      <paper-toggle-button id="googlePhotosToggle"
                           checked="{{useGoogle}}"></paper-toggle-button>
      <paper-tooltip for="googlePhotosToggle" position="left" offset="0">
        [[localize('tooltip_google_toggle')]]
      </paper-tooltip>
    </app-toolbar>
  </paper-material>

  <div class="page-content">

    <!-- Albums UI -->
    <div hidden$="[[!isAlbumMode]]">
      <albums-view id="albumsView" disabled$="[[!useGoogle]]"></albums-view>
    </div>

    <!-- Photos UI -->
    <div hidden$="[[isAlbumMode]]">
      <photos-view id="photosView" disabled$="[[!useGoogle]]"></photos-view>
    </div>

  </div>

  <app-localstorage-document key="isAlbumMode" data="{{isAlbumMode}}" storage="window.localStorage">
  </app-localstorage-document>
  <app-localstorage-document key="useGoogle" data="{{useGoogle}}" storage="window.localStorage">
  </app-localstorage-document>
  <app-localstorage-document key="useGoogleAlbums" data="{{useGoogleAlbums}}" storage="window.localStorage">
  </app-localstorage-document>
  <app-localstorage-document key="useGooglePhotos" data="{{useGooglePhotos}}" storage="window.localStorage">
  </app-localstorage-document>

  <slot></slot>

</paper-material>
`;
    }
};

__decorate$7([ property({
    type: Boolean,
    notify: !0
}) ], GooglePhotosPageElement.prototype, "isAlbumMode", void 0), __decorate$7([ property({
    type: Boolean,
    notify: !0
}) ], GooglePhotosPageElement.prototype, "useGoogle", void 0), __decorate$7([ property({
    type: Boolean,
    notify: !0
}) ], GooglePhotosPageElement.prototype, "useGoogleAlbums", void 0), __decorate$7([ property({
    type: Boolean,
    notify: !0
}) ], GooglePhotosPageElement.prototype, "useGooglePhotos", void 0), __decorate$7([ computed("isAlbumMode") ], GooglePhotosPageElement.prototype, "pageTitle", null), 
__decorate$7([ computed("isAlbumMode") ], GooglePhotosPageElement.prototype, "refreshTooltipLabel", null), 
__decorate$7([ computed("isAlbumMode") ], GooglePhotosPageElement.prototype, "modeTooltipLabel", null), 
__decorate$7([ computed("isAlbumMode") ], GooglePhotosPageElement.prototype, "modeIcon", null), 
__decorate$7([ computed("useGoogle", "isAlbumMode") ], GooglePhotosPageElement.prototype, "isAlbumIconDisabled", null), 
__decorate$7([ query("#photosView") ], GooglePhotosPageElement.prototype, "photosView", void 0), 
__decorate$7([ query("#albumsView") ], GooglePhotosPageElement.prototype, "albumsView", void 0), 
__decorate$7([ query("#googlePhotosToggle") ], GooglePhotosPageElement.prototype, "googlePhotosToggle", void 0), 
__decorate$7([ listen("tap", "mode") ], GooglePhotosPageElement.prototype, "onModeTapped", null), 
__decorate$7([ listen("tap", "refresh") ], GooglePhotosPageElement.prototype, "onRefreshTapped", null), 
__decorate$7([ listen("tap", "help") ], GooglePhotosPageElement.prototype, "onHelpTapped", null), 
__decorate$7([ listen("tap", "deselect") ], GooglePhotosPageElement.prototype, "onDeselectAllTapped", null), 
__decorate$7([ listen("tap", "select") ], GooglePhotosPageElement.prototype, "onSelectAllTapped", null), 
__decorate$7([ listen("change", "googlePhotosToggle") ], GooglePhotosPageElement.prototype, "onUseGoogleChanged", null), 
__decorate$7([ listen("no-albums", "albumsView") ], GooglePhotosPageElement.prototype, "onNoAlbums", null), 
__decorate$7([ observe("isAlbumMode", "useGoogle") ], GooglePhotosPageElement.prototype, "uiStateChanged", null), 
GooglePhotosPageElement = __decorate$7([ customElement("google-photos-page") ], GooglePhotosPageElement);

var googlePhotosPage = {
    get GooglePhotosPageElement() {
        return GooglePhotosPageElement;
    }
};

Polymer({
    _template: html`
    <style include="paper-item-shared-styles"></style>
    <style>
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
        @apply --paper-icon-item;
      }

      .content-icon {
        @apply --layout-horizontal;
        @apply --layout-center;

        width: var(--paper-item-icon-width, 56px);
        @apply --paper-item-icon;
      }
    </style>

    <div id="contentIcon" class="content-icon">
      <slot name="item-icon"></slot>
    </div>
    <slot></slot>
`,
    is: "paper-icon-item",
    behaviors: [ PaperItemBehavior ]
});

var __decorate$8 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */ let SettingLinkElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.label = "", this.icon = "", this.url = "";
    }
    onLinkTapped() {
        event(EVENT.LINK, this.name), chrome.tabs.create({
            url: this.url
        });
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host paper-icon-item {
    --paper-item-focused-before: {
      background: transparent;
    };
    --paper-item-selected: {
      background: transparent;
    };
    --paper-item-icon-width: 32px;
    padding-left: 48px;
    padding-top: 4px;
    padding-bottom: 4px;
    cursor: pointer;
  }

  :host .divider {
    margin-left: 48px;
    margin-right: 0;
  }
</style>

<paper-icon-item id="item" class="flex">
  <paper-ripple center=""></paper-ripple>
  <iron-icon class="setting-link-icon" icon="[[icon]]" slot="item-icon"></iron-icon>
  <span class="setting-label">[[label]]</span>
</paper-icon-item>
`;
    }
};

__decorate$8([ property({
    type: String
}) ], SettingLinkElement.prototype, "label", void 0), __decorate$8([ property({
    type: String
}) ], SettingLinkElement.prototype, "icon", void 0), __decorate$8([ property({
    type: String
}) ], SettingLinkElement.prototype, "url", void 0), __decorate$8([ listen("tap", "item") ], SettingLinkElement.prototype, "onLinkTapped", null), 
SettingLinkElement = __decorate$8([ customElement("setting-link") ], SettingLinkElement);

var settingLink = {
    get SettingLinkElement() {
        return SettingLinkElement;
    }
}, __decorate$9 = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let HelpPageElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.githubPath = getGithubPath(), this.githubPagesPath = getGithubPagesPath(), 
        this.version = encodeURIComponent(getVersion());
    }
    computeMailToUrl(e) {
        return getEmailUrl(e, getEmailBody());
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">

  :host {
    display: block;
    position: relative;
  }

  :host hr {
    margin-left: 0;
    margin-right: 0;
  }

</style>

<paper-material elevation="1" class="page-container">
  <paper-material elevation="1">
    <app-toolbar class="page-toolbar">
      <div>{{localize('help_title')}}</div>
    </app-toolbar>
  </paper-material>
  <div class="page-content">
    <setting-link section-title="{{localize('help_section_feedback')}}" name="questionMail"
                  label="{{localize('help_question')}}" icon="myicons:mail"
                  url="[[computeMailToUrl('Question')]]"></setting-link>
    <setting-link label="{{localize('help_bug')}}" name="bugMail" icon="myicons:mail"
                  url="[[computeMailToUrl('Bug report')]]"></setting-link>
    <setting-link label="{{localize('help_feature')}}" name="featureMail" icon="myicons:mail"
                  url="[[computeMailToUrl('Feature request')]]"></setting-link>
    <setting-link label="{{localize('help_feedback')}}" name="feedbackMail" icon="myicons:mail"
                  url="[[computeMailToUrl('General feedback')]]"></setting-link>
    <setting-link label="{{localize('help_issue')}}" name="submitGitHubIssue" noseparator="" icon="myicons:github"
                  url="[[githubPath]]issues/new"></setting-link>
    <hr>
    <setting-link section-title="{{localize('help')}}" name="documentation"
                  label="{{localize('help_documentation')}}" icon="myicons:info"
                  url="[[githubPagesPath]]documentation.html"></setting-link>
    <setting-link label="{{localize('help_faq')}}" name="faq" icon="myicons:help"
                  url="[[githubPagesPath]]faq.html"></setting-link>
    <setting-link label="{{localize('help_translations')}}" name="translations"
                  icon="myicons:info" url="[[githubPagesPath]]translate.html"></setting-link>
    <setting-link label="{{localize('help_release_notes')}}" name="releaseNotes" icon="myicons:github"
                  url="[[githubPath]]releases/tag/v[[version]]"></setting-link>
    <setting-link label="{{localize('help_contributors')}}" name="contributors" icon="myicons:github"
                  url="[[githubPath]]blob/master/CONTRIBUTORS.md"></setting-link>
    <setting-link label="{{localize('help_licenses')}}" name="licenses" icon="myicons:github"
                  url="[[githubPath]]blob/master/LICENSES.md"></setting-link>
    <setting-link label="{{localize('help_source_code')}}" name="sourceCode" noseparator=""
                  icon="myicons:github" url="[[githubPath]]"></setting-link>
  </div>
</paper-material>
`;
    }
};

__decorate$9([ property({
    type: String
}) ], HelpPageElement.prototype, "githubPath", void 0), __decorate$9([ property({
    type: String
}) ], HelpPageElement.prototype, "githubPagesPath", void 0), __decorate$9([ property({
    type: String
}) ], HelpPageElement.prototype, "version", void 0), HelpPageElement = __decorate$9([ customElement("help-page") ], HelpPageElement);

var helpPage = {
    get HelpPageElement() {
        return HelpPageElement;
    }
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }

      :host > ::slotted(:not(slot):not(.iron-selected)) {
        display: none !important;
      }
    </style>

    <slot></slot>
`,
    is: "iron-pages",
    behaviors: [ IronResizableBehavior, IronSelectableBehavior ],
    properties: {
        activateEvent: {
            type: String,
            value: null
        }
    },
    observers: [ "_selectedPageChanged(selected)" ],
    _selectedPageChanged: function(e, t) {
        this.async(this.notifyResize);
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        @apply --layout-inline;
        @apply --layout-center;
        @apply --layout-center-justified;
        @apply --layout-flex-auto;

        position: relative;
        padding: 0 12px;
        overflow: hidden;
        cursor: pointer;
        vertical-align: middle;

        @apply --paper-font-common-base;
        @apply --paper-tab;
      }

      :host(:focus) {
        outline: none;
      }

      :host([link]) {
        padding: 0;
      }

      .tab-content {
        height: 100%;
        transform: translateZ(0);
          -webkit-transform: translateZ(0);
        transition: opacity 0.1s cubic-bezier(0.4, 0.0, 1, 1);
        @apply --layout-horizontal;
        @apply --layout-center-center;
        @apply --layout-flex-auto;
        @apply --paper-tab-content;
      }

      :host(:not(.iron-selected)) > .tab-content {
        opacity: 0.8;

        @apply --paper-tab-content-unselected;
      }

      :host(:focus) .tab-content {
        opacity: 1;
        font-weight: 700;
      }

      paper-ripple {
        color: var(--paper-tab-ink, var(--paper-yellow-a100));
      }

      .tab-content > ::slotted(a) {
        @apply --layout-flex-auto;

        height: 100%;
      }
    </style>

    <div class="tab-content">
      <slot></slot>
    </div>
`,
    is: "paper-tab",
    behaviors: [ IronControlState, IronButtonState, PaperRippleBehavior ],
    properties: {
        link: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        }
    },
    hostAttributes: {
        role: "tab"
    },
    listeners: {
        down: "_updateNoink",
        tap: "_onTap"
    },
    attached: function() {
        this._updateNoink();
    },
    get _parentNoink() {
        var e = dom(this).parentNode;
        return !!e && !!e.noink;
    },
    _updateNoink: function() {
        this.noink = !!this.noink || !!this._parentNoink;
    },
    _onTap: function(e) {
        if (this.link) {
            var t = this.queryEffectiveChildren("a");
            if (!t) return;
            if (e.target === t) return;
            t.click();
        }
    }
});

const template$7 = html`<iron-iconset-svg name="paper-tabs" size="24">
<svg><defs>
<g id="chevron-left"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></g>
<g id="chevron-right"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></g>
</defs></svg>
</iron-iconset-svg>`;

document.head.appendChild(template$7.content);

const IronMenubarBehaviorImpl = {
    hostAttributes: {
        role: "menubar"
    },
    keyBindings: {
        left: "_onLeftKey",
        right: "_onRightKey"
    },
    _onUpKey: function(e) {
        this.focusedItem.click(), e.detail.keyboardEvent.preventDefault();
    },
    _onDownKey: function(e) {
        this.focusedItem.click(), e.detail.keyboardEvent.preventDefault();
    },
    get _isRTL() {
        return "rtl" === window.getComputedStyle(this).direction;
    },
    _onLeftKey: function(e) {
        this._isRTL ? this._focusNext() : this._focusPrevious(), e.detail.keyboardEvent.preventDefault();
    },
    _onRightKey: function(e) {
        this._isRTL ? this._focusPrevious() : this._focusNext(), e.detail.keyboardEvent.preventDefault();
    },
    _onKeydown: function(e) {
        this.keyboardEventMatchesKeys(e, "up down left right esc") || this._focusWithKeyboardEvent(e);
    }
}, IronMenubarBehavior = [ IronMenuBehavior, IronMenubarBehaviorImpl ];

var ironMenubarBehavior = {
    IronMenubarBehaviorImpl: IronMenubarBehaviorImpl,
    IronMenubarBehavior: IronMenubarBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        @apply --layout;
        @apply --layout-center;

        height: 48px;
        font-size: 14px;
        font-weight: 500;
        overflow: hidden;
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        user-select: none;

        /* NOTE: Both values are needed, since some phones require the value to be \`transparent\`. */
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent;

        @apply --paper-tabs;
      }

      :host(:dir(rtl)) {
        @apply --layout-horizontal-reverse;
      }

      #tabsContainer {
        position: relative;
        height: 100%;
        white-space: nowrap;
        overflow: hidden;
        @apply --layout-flex-auto;
        @apply --paper-tabs-container;
      }

      #tabsContent {
        height: 100%;
        -moz-flex-basis: auto;
        -ms-flex-basis: auto;
        flex-basis: auto;
        @apply --paper-tabs-content;
      }

      #tabsContent.scrollable {
        position: absolute;
        white-space: nowrap;
      }

      #tabsContent:not(.scrollable),
      #tabsContent.scrollable.fit-container {
        @apply --layout-horizontal;
      }

      #tabsContent.scrollable.fit-container {
        min-width: 100%;
      }

      #tabsContent.scrollable.fit-container > ::slotted(*) {
        /* IE - prevent tabs from compressing when they should scroll. */
        -ms-flex: 1 0 auto;
        -webkit-flex: 1 0 auto;
        flex: 1 0 auto;
      }

      .hidden {
        display: none;
      }

      .not-visible {
        opacity: 0;
        cursor: default;
      }

      paper-icon-button {
        width: 48px;
        height: 48px;
        padding: 12px;
        margin: 0 4px;
      }

      #selectionBar {
        position: absolute;
        height: 0;
        bottom: 0;
        left: 0;
        right: 0;
        border-bottom: 2px solid var(--paper-tabs-selection-bar-color, var(--paper-yellow-a100));
          -webkit-transform: scale(0);
        transform: scale(0);
          -webkit-transform-origin: left center;
        transform-origin: left center;
          transition: -webkit-transform;
        transition: transform;

        @apply --paper-tabs-selection-bar;
      }

      #selectionBar.align-bottom {
        top: 0;
        bottom: auto;
      }

      #selectionBar.expand {
        transition-duration: 0.15s;
        transition-timing-function: cubic-bezier(0.4, 0.0, 1, 1);
      }

      #selectionBar.contract {
        transition-duration: 0.18s;
        transition-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
      }

      #tabsContent > ::slotted(:not(#selectionBar)) {
        height: 100%;
      }
    </style>

    <paper-icon-button icon="paper-tabs:chevron-left" class\$="[[_computeScrollButtonClass(_leftHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onLeftScrollButtonDown" tabindex="-1"></paper-icon-button>

    <div id="tabsContainer" on-track="_scroll" on-down="_down">
      <div id="tabsContent" class\$="[[_computeTabsContentClass(scrollable, fitContainer)]]">
        <div id="selectionBar" class\$="[[_computeSelectionBarClass(noBar, alignBottom)]]" on-transitionend="_onBarTransitionEnd"></div>
        <slot></slot>
      </div>
    </div>

    <paper-icon-button icon="paper-tabs:chevron-right" class\$="[[_computeScrollButtonClass(_rightHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onRightScrollButtonDown" tabindex="-1"></paper-icon-button>
`,
    is: "paper-tabs",
    behaviors: [ IronResizableBehavior, IronMenubarBehavior ],
    properties: {
        noink: {
            type: Boolean,
            value: !1,
            observer: "_noinkChanged"
        },
        noBar: {
            type: Boolean,
            value: !1
        },
        noSlide: {
            type: Boolean,
            value: !1
        },
        scrollable: {
            type: Boolean,
            value: !1
        },
        fitContainer: {
            type: Boolean,
            value: !1
        },
        disableDrag: {
            type: Boolean,
            value: !1
        },
        hideScrollButtons: {
            type: Boolean,
            value: !1
        },
        alignBottom: {
            type: Boolean,
            value: !1
        },
        selectable: {
            type: String,
            value: "paper-tab"
        },
        autoselect: {
            type: Boolean,
            value: !1
        },
        autoselectDelay: {
            type: Number,
            value: 0
        },
        _step: {
            type: Number,
            value: 10
        },
        _holdDelay: {
            type: Number,
            value: 1
        },
        _leftHidden: {
            type: Boolean,
            value: !1
        },
        _rightHidden: {
            type: Boolean,
            value: !1
        },
        _previousTab: {
            type: Object
        }
    },
    hostAttributes: {
        role: "tablist"
    },
    listeners: {
        "iron-resize": "_onTabSizingChanged",
        "iron-items-changed": "_onTabSizingChanged",
        "iron-select": "_onIronSelect",
        "iron-deselect": "_onIronDeselect"
    },
    keyBindings: {
        "left:keyup right:keyup": "_onArrowKeyup"
    },
    created: function() {
        this._holdJob = null, this._pendingActivationItem = void 0, this._pendingActivationTimeout = void 0, 
        this._bindDelayedActivationHandler = this._delayedActivationHandler.bind(this), 
        this.addEventListener("blur", this._onBlurCapture.bind(this), !0);
    },
    ready: function() {
        this.setScrollDirection("y", this.$.tabsContainer);
    },
    detached: function() {
        this._cancelPendingActivation();
    },
    _noinkChanged: function(e) {
        dom(this).querySelectorAll("paper-tab").forEach(e ? this._setNoinkAttribute : this._removeNoinkAttribute);
    },
    _setNoinkAttribute: function(e) {
        e.setAttribute("noink", "");
    },
    _removeNoinkAttribute: function(e) {
        e.removeAttribute("noink");
    },
    _computeScrollButtonClass: function(e, t, i) {
        return !t || i ? "hidden" : e ? "not-visible" : "";
    },
    _computeTabsContentClass: function(e, t) {
        return e ? "scrollable" + (t ? " fit-container" : "") : " fit-container";
    },
    _computeSelectionBarClass: function(e, t) {
        return e ? "hidden" : t ? "align-bottom" : "";
    },
    _onTabSizingChanged: function() {
        this.debounce("_onTabSizingChanged", function() {
            this._scroll(), this._tabChanged(this.selectedItem);
        }, 10);
    },
    _onIronSelect: function(e) {
        this._tabChanged(e.detail.item, this._previousTab), this._previousTab = e.detail.item, 
        this.cancelDebouncer("tab-changed");
    },
    _onIronDeselect: function(e) {
        this.debounce("tab-changed", function() {
            this._tabChanged(null, this._previousTab), this._previousTab = null;
        }, 1);
    },
    _activateHandler: function() {
        this._cancelPendingActivation(), IronMenuBehaviorImpl._activateHandler.apply(this, arguments);
    },
    _scheduleActivation: function(e, t) {
        this._pendingActivationItem = e, this._pendingActivationTimeout = this.async(this._bindDelayedActivationHandler, t);
    },
    _delayedActivationHandler: function() {
        var e = this._pendingActivationItem;
        this._pendingActivationItem = void 0, this._pendingActivationTimeout = void 0, e.fire(this.activateEvent, null, {
            bubbles: !0,
            cancelable: !0
        });
    },
    _cancelPendingActivation: function() {
        void 0 !== this._pendingActivationTimeout && (this.cancelAsync(this._pendingActivationTimeout), 
        this._pendingActivationItem = void 0, this._pendingActivationTimeout = void 0);
    },
    _onArrowKeyup: function(e) {
        this.autoselect && this._scheduleActivation(this.focusedItem, this.autoselectDelay);
    },
    _onBlurCapture: function(e) {
        e.target === this._pendingActivationItem && this._cancelPendingActivation();
    },
    get _tabContainerScrollSize() {
        return Math.max(0, this.$.tabsContainer.scrollWidth - this.$.tabsContainer.offsetWidth);
    },
    _scroll: function(e, t) {
        if (this.scrollable) {
            var i = t && -t.ddx || 0;
            this._affectScroll(i);
        }
    },
    _down: function(e) {
        this.async(function() {
            this._defaultFocusAsync && (this.cancelAsync(this._defaultFocusAsync), this._defaultFocusAsync = null);
        }, 1);
    },
    _affectScroll: function(e) {
        this.$.tabsContainer.scrollLeft += e;
        var t = this.$.tabsContainer.scrollLeft;
        this._leftHidden = 0 === t, this._rightHidden = t === this._tabContainerScrollSize;
    },
    _onLeftScrollButtonDown: function() {
        this._scrollToLeft(), this._holdJob = setInterval(this._scrollToLeft.bind(this), this._holdDelay);
    },
    _onRightScrollButtonDown: function() {
        this._scrollToRight(), this._holdJob = setInterval(this._scrollToRight.bind(this), this._holdDelay);
    },
    _onScrollButtonUp: function() {
        clearInterval(this._holdJob), this._holdJob = null;
    },
    _scrollToLeft: function() {
        this._affectScroll(-this._step);
    },
    _scrollToRight: function() {
        this._affectScroll(this._step);
    },
    _tabChanged: function(e, t) {
        if (!e) return this.$.selectionBar.classList.remove("expand"), this.$.selectionBar.classList.remove("contract"), 
        void this._positionBar(0, 0);
        var i = this.$.tabsContent.getBoundingClientRect(), o = i.width, n = e.getBoundingClientRect(), a = n.left - i.left;
        if (this._pos = {
            width: this._calcPercent(n.width, o),
            left: this._calcPercent(a, o)
        }, this.noSlide || null == t) return this.$.selectionBar.classList.remove("expand"), 
        this.$.selectionBar.classList.remove("contract"), void this._positionBar(this._pos.width, this._pos.left);
        var r = t.getBoundingClientRect(), s = this.items.indexOf(t), l = this.items.indexOf(e);
        this.$.selectionBar.classList.add("expand");
        var c = s < l;
        this._isRTL && (c = !c), c ? this._positionBar(this._calcPercent(n.left + n.width - r.left, o) - 5, this._left) : this._positionBar(this._calcPercent(r.left + r.width - n.left, o) - 5, this._calcPercent(a, o) + 5), 
        this.scrollable && this._scrollToSelectedIfNeeded(n.width, a);
    },
    _scrollToSelectedIfNeeded: function(e, t) {
        var i = t - this.$.tabsContainer.scrollLeft;
        i < 0 ? this.$.tabsContainer.scrollLeft += i : (i += e - this.$.tabsContainer.offsetWidth) > 0 && (this.$.tabsContainer.scrollLeft += i);
    },
    _calcPercent: function(e, t) {
        return 100 * e / t;
    },
    _positionBar: function(e, t) {
        e = e || 0, t = t || 0, this._width = e, this._left = t, this.transform("translateX(" + t + "%) scaleX(" + e / 100 + ")", this.$.selectionBar);
    },
    _onBarTransitionEnd: function(e) {
        var t = this.$.selectionBar.classList;
        t.contains("expand") ? (t.remove("expand"), t.add("contract"), this._positionBar(this._pos.width, this._pos.left)) : t.contains("contract") && t.remove("contract");
    }
}), Polymer({
    is: "iron-selector",
    behaviors: [ IronMultiSelectableBehavior ]
});

var __decorate$a = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let SettingBackgroundElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.value = "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)", 
        this.selected = "b1", this.mainLabel = "", this.secondaryLabel = "";
    }
    onTap() {
        this.dialog.open();
    }
    onOK() {
        const e = this.shadowRoot.getElementById(this.selected);
        e && (this.set("value", "background:" + e.style.background), event(EVENT.BUTTON, `SettingBackground.OK: ${this.selected}`));
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host paper-item {
    display: block;
    position: relative;
    cursor: pointer;
  }

  :host([indent]) paper-item {
    padding-left: 24px;
  }

  :host .container {
    width: 440px;
  }

  :host .background {
    width: 200px;
    height: 112px;
    border: 2px solid white;
  }

  :host .iron-selected {
    border: 2px solid red;
  }

  :host .selected-background {
    width: 100px;
    height: 56px;
  }

  .selected-background[disabled] {
    opacity: .2;
  }
</style>

<paper-dialog id="dialog" entry-animation="scale-up-animation" exit-animation="fade-out-animation">
  <h2>[[localize('setting_bg_dialog_title')]]</h2>
  <iron-selector class="container horizontal layout wrap" attr-for-selected="id" selected="{{selected}}">
    <div id="b1" class="background" style="background:linear-gradient(to bottom, #3A3A3A, #B5BDC8);"></div>
    <div id="b2" class="background" style="background:linear-gradient(to bottom, #003973 10%, #E5E5BE 90%);"></div>
    <div id="b3" class="background" style="background:linear-gradient(to top, #649173 10%, #DBD5A4 90%);"></div>
    <div id="b4" class="background"
         style="background:radial-gradient(ellipse at center, #EBE9F9 0%, #EBE9F9 23%, #D8D0EF 50%, #CEC7EC 51%, #EBE9F9 77%, #C1BFEA 100%);"></div>
    <div id="b5" class="background"
         style="background:radial-gradient(ellipse farthest-corner at 0px 0px , #FD5C6E 0%, rgba(0, 0, 255, 0) 50%, #0CE4E1 95%);"></div>
    <div id="b6" class="background" style="background:black;"></div>
  </iron-selector>
  <div class="buttons">
    <paper-button dialog-dismiss="">[[localize('cancel')]]</paper-button>
    <paper-button id="confirmButton" dialog-confirm="" autofocus="">
      [[localize('ok')]]
    </paper-button>
  </div>
</paper-dialog>

<paper-item id="item" class="center horizontal layout" tabindex="-1">
  <paper-item-body class="flex" two-line="">
    <div class="setting-label" hidden$="[[!mainLabel]]">
      [[mainLabel]]
    </div>
    <div class="setting-label" secondary="" hidden$="[[!secondaryLabel]]">
      [[secondaryLabel]]
    </div>
  </paper-item-body>
  <div class="selected-background" style$="[[value]]" tabindex="0" disabled$="[[disabled]]"></div>
  <paper-ripple center=""></paper-ripple>
</paper-item>

<app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
</app-localstorage-document>
`;
    }
};

__decorate$a([ property({
    type: String,
    notify: !0
}) ], SettingBackgroundElement.prototype, "value", void 0), __decorate$a([ property({
    type: String,
    notify: !0
}) ], SettingBackgroundElement.prototype, "selected", void 0), __decorate$a([ property({
    type: String
}) ], SettingBackgroundElement.prototype, "mainLabel", void 0), __decorate$a([ property({
    type: String
}) ], SettingBackgroundElement.prototype, "secondaryLabel", void 0), __decorate$a([ query("#dialog") ], SettingBackgroundElement.prototype, "dialog", void 0), 
__decorate$a([ listen("tap", "item") ], SettingBackgroundElement.prototype, "onTap", null), 
__decorate$a([ listen("tap", "confirmButton") ], SettingBackgroundElement.prototype, "onOK", null), 
SettingBackgroundElement = __decorate$a([ customElement("setting-background") ], SettingBackgroundElement);

var settingBackground = {
    get SettingBackgroundElement() {
        return SettingBackgroundElement;
    }
};

const IronA11yAnnouncer = Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        position: fixed;
        clip: rect(0px,0px,0px,0px);
      }
    </style>
    <div aria-live$="[[mode]]">[[_text]]</div>
`,
    is: "iron-a11y-announcer",
    properties: {
        mode: {
            type: String,
            value: "polite"
        },
        _text: {
            type: String,
            value: ""
        }
    },
    created: function() {
        IronA11yAnnouncer.instance || (IronA11yAnnouncer.instance = this), document.body.addEventListener("iron-announce", this._onIronAnnounce.bind(this));
    },
    announce: function(e) {
        this._text = "", this.async(function() {
            this._text = e;
        }, 100);
    },
    _onIronAnnounce: function(e) {
        e.detail && e.detail.text && this.announce(e.detail.text);
    }
});

IronA11yAnnouncer.instance = null, IronA11yAnnouncer.requestAvailability = function() {
    IronA11yAnnouncer.instance || (IronA11yAnnouncer.instance = document.createElement("iron-a11y-announcer")), 
    document.body.appendChild(IronA11yAnnouncer.instance);
};

var ironA11yAnnouncer = {
    IronA11yAnnouncer: IronA11yAnnouncer
};

Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
      }
    </style>
    <slot id="content"></slot>
`,
    is: "iron-input",
    behaviors: [ IronValidatableBehavior ],
    properties: {
        bindValue: {
            type: String,
            value: ""
        },
        value: {
            type: String,
            computed: "_computeValue(bindValue)"
        },
        allowedPattern: {
            type: String
        },
        autoValidate: {
            type: Boolean,
            value: !1
        },
        _inputElement: Object
    },
    observers: [ "_bindValueChanged(bindValue, _inputElement)" ],
    listeners: {
        input: "_onInput",
        keypress: "_onKeypress"
    },
    created: function() {
        IronA11yAnnouncer.requestAvailability(), this._previousValidInput = "", this._patternAlreadyChecked = !1;
    },
    attached: function() {
        this._observer = dom(this).observeNodes(function(e) {
            this._initSlottedInput();
        }.bind(this));
    },
    detached: function() {
        this._observer && (dom(this).unobserveNodes(this._observer), this._observer = null);
    },
    get inputElement() {
        return this._inputElement;
    },
    _initSlottedInput: function() {
        this._inputElement = this.getEffectiveChildren()[0], this.inputElement && this.inputElement.value && (this.bindValue = this.inputElement.value), 
        this.fire("iron-input-ready");
    },
    get _patternRegExp() {
        var e;
        if (this.allowedPattern) e = new RegExp(this.allowedPattern); else switch (this.inputElement.type) {
          case "number":
            e = /[0-9.,e-]/;
        }
        return e;
    },
    _bindValueChanged: function(e, t) {
        t && (void 0 === e ? t.value = null : e !== t.value && (this.inputElement.value = e), 
        this.autoValidate && this.validate(), this.fire("bind-value-changed", {
            value: e
        }));
    },
    _onInput: function() {
        this.allowedPattern && !this._patternAlreadyChecked && (this._checkPatternValidity() || (this._announceInvalidCharacter("Invalid string of characters not entered."), 
        this.inputElement.value = this._previousValidInput));
        this.bindValue = this._previousValidInput = this.inputElement.value, this._patternAlreadyChecked = !1;
    },
    _isPrintable: function(e) {
        var t = 8 == e.keyCode || 9 == e.keyCode || 13 == e.keyCode || 27 == e.keyCode, i = 19 == e.keyCode || 20 == e.keyCode || 45 == e.keyCode || 46 == e.keyCode || 144 == e.keyCode || 145 == e.keyCode || e.keyCode > 32 && e.keyCode < 41 || e.keyCode > 111 && e.keyCode < 124;
        return !(t || 0 == e.charCode && i);
    },
    _onKeypress: function(e) {
        if (this.allowedPattern || "number" === this.inputElement.type) {
            var t = this._patternRegExp;
            if (t && !(e.metaKey || e.ctrlKey || e.altKey)) {
                this._patternAlreadyChecked = !0;
                var i = String.fromCharCode(e.charCode);
                this._isPrintable(e) && !t.test(i) && (e.preventDefault(), this._announceInvalidCharacter("Invalid character " + i + " not entered."));
            }
        }
    },
    _checkPatternValidity: function() {
        var e = this._patternRegExp;
        if (!e) return !0;
        for (var t = 0; t < this.inputElement.value.length; t++) if (!e.test(this.inputElement.value[t])) return !1;
        return !0;
    },
    validate: function() {
        if (!this.inputElement) return this.invalid = !1, !0;
        var e = this.inputElement.checkValidity();
        return e && (this.required && "" === this.bindValue ? e = !1 : this.hasValidator() && (e = IronValidatableBehavior.validate.call(this, this.bindValue))), 
        this.invalid = !e, this.fire("iron-input-validate"), e;
    },
    _announceInvalidCharacter: function(e) {
        this.fire("iron-announce", {
            text: e
        });
    },
    _computeValue: function(e) {
        return e;
    }
});

const PaperInputAddonBehavior = {
    attached: function() {
        this.fire("addon-attached");
    },
    update: function(e) {}
};

var paperInputAddonBehavior = {
    PaperInputAddonBehavior: PaperInputAddonBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        float: right;

        @apply --paper-font-caption;
        @apply --paper-input-char-counter;
      }

      :host([hidden]) {
        display: none !important;
      }

      :host(:dir(rtl)) {
        float: left;
      }
    </style>

    <span>[[_charCounterStr]]</span>
`,
    is: "paper-input-char-counter",
    behaviors: [ PaperInputAddonBehavior ],
    properties: {
        _charCounterStr: {
            type: String,
            value: "0"
        }
    },
    update: function(e) {
        if (e.inputElement) {
            e.value = e.value || "";
            var t = e.value.toString().length.toString();
            e.inputElement.hasAttribute("maxlength") && (t += "/" + e.inputElement.getAttribute("maxlength")), 
            this._charCounterStr = t;
        }
    }
});

const template$8 = html`
<custom-style>
  <style is="custom-style">
    html {
      --paper-input-container-shared-input-style: {
        position: relative; /* to make a stacking context */
        outline: none;
        box-shadow: none;
        padding: 0;
        margin: 0;
        width: 100%;
        max-width: 100%;
        background: transparent;
        border: none;
        color: var(--paper-input-container-input-color, var(--primary-text-color));
        -webkit-appearance: none;
        text-align: inherit;
        vertical-align: var(--paper-input-container-input-align, bottom);

        @apply --paper-font-subhead;
      };
    }
  </style>
</custom-style>
`;

template$8.setAttribute("style", "display: none;"), document.head.appendChild(template$8.content), 
Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        padding: 8px 0;
        @apply --paper-input-container;
      }

      :host([inline]) {
        display: inline-block;
      }

      :host([disabled]) {
        pointer-events: none;
        opacity: 0.33;

        @apply --paper-input-container-disabled;
      }

      :host([hidden]) {
        display: none !important;
      }

      [hidden] {
        display: none !important;
      }

      .floated-label-placeholder {
        @apply --paper-font-caption;
      }

      .underline {
        height: 2px;
        position: relative;
      }

      .focused-line {
        @apply --layout-fit;
        border-bottom: 2px solid var(--paper-input-container-focus-color, var(--primary-color));

        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: scale3d(0,1,1);
        transform: scale3d(0,1,1);

        @apply --paper-input-container-underline-focus;
      }

      .underline.is-highlighted .focused-line {
        -webkit-transform: none;
        transform: none;
        -webkit-transition: -webkit-transform 0.25s;
        transition: transform 0.25s;

        @apply --paper-transition-easing;
      }

      .underline.is-invalid .focused-line {
        border-color: var(--paper-input-container-invalid-color, var(--error-color));
        -webkit-transform: none;
        transform: none;
        -webkit-transition: -webkit-transform 0.25s;
        transition: transform 0.25s;

        @apply --paper-transition-easing;
      }

      .unfocused-line {
        @apply --layout-fit;
        border-bottom: 1px solid var(--paper-input-container-color, var(--secondary-text-color));
        @apply --paper-input-container-underline;
      }

      :host([disabled]) .unfocused-line {
        border-bottom: 1px dashed;
        border-color: var(--paper-input-container-color, var(--secondary-text-color));
        @apply --paper-input-container-underline-disabled;
      }

      .input-wrapper {
        @apply --layout-horizontal;
        @apply --layout-center;
        position: relative;
      }

      .input-content {
        @apply --layout-flex-auto;
        @apply --layout-relative;
        max-width: 100%;
      }

      .input-content ::slotted(label),
      .input-content ::slotted(.paper-input-label) {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        font: inherit;
        color: var(--paper-input-container-color, var(--secondary-text-color));
        -webkit-transition: -webkit-transform 0.25s, width 0.25s;
        transition: transform 0.25s, width 0.25s;
        -webkit-transform-origin: left top;
        transform-origin: left top;
        /* Fix for safari not focusing 0-height date/time inputs with -webkit-apperance: none; */
        min-height: 1px;

        @apply --paper-font-common-nowrap;
        @apply --paper-font-subhead;
        @apply --paper-input-container-label;
        @apply --paper-transition-easing;
      }

      .input-content.label-is-floating ::slotted(label),
      .input-content.label-is-floating ::slotted(.paper-input-label) {
        -webkit-transform: translateY(-75%) scale(0.75);
        transform: translateY(-75%) scale(0.75);

        /* Since we scale to 75/100 of the size, we actually have 100/75 of the
        original space now available */
        width: 133%;

        @apply --paper-input-container-label-floating;
      }

      :host(:dir(rtl)) .input-content.label-is-floating ::slotted(label),
      :host(:dir(rtl)) .input-content.label-is-floating ::slotted(.paper-input-label) {
        right: 0;
        left: auto;
        -webkit-transform-origin: right top;
        transform-origin: right top;
      }

      .input-content.label-is-highlighted ::slotted(label),
      .input-content.label-is-highlighted ::slotted(.paper-input-label) {
        color: var(--paper-input-container-focus-color, var(--primary-color));

        @apply --paper-input-container-label-focus;
      }

      .input-content.is-invalid ::slotted(label),
      .input-content.is-invalid ::slotted(.paper-input-label) {
        color: var(--paper-input-container-invalid-color, var(--error-color));
      }

      .input-content.label-is-hidden ::slotted(label),
      .input-content.label-is-hidden ::slotted(.paper-input-label) {
        visibility: hidden;
      }

      .input-content ::slotted(input),
      .input-content ::slotted(iron-input),
      .input-content ::slotted(textarea),
      .input-content ::slotted(iron-autogrow-textarea),
      .input-content ::slotted(.paper-input-input) {
        @apply --paper-input-container-shared-input-style;
        /* The apply shim doesn't apply the nested color custom property,
          so we have to re-apply it here. */
        color: var(--paper-input-container-input-color, var(--primary-text-color));
        @apply --paper-input-container-input;
      }

      .input-content ::slotted(input)::-webkit-outer-spin-button,
      .input-content ::slotted(input)::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      .input-content.focused ::slotted(input),
      .input-content.focused ::slotted(iron-input),
      .input-content.focused ::slotted(textarea),
      .input-content.focused ::slotted(iron-autogrow-textarea),
      .input-content.focused ::slotted(.paper-input-input) {
        @apply --paper-input-container-input-focus;
      }

      .input-content.is-invalid ::slotted(input),
      .input-content.is-invalid ::slotted(iron-input),
      .input-content.is-invalid ::slotted(textarea),
      .input-content.is-invalid ::slotted(iron-autogrow-textarea),
      .input-content.is-invalid ::slotted(.paper-input-input) {
        @apply --paper-input-container-input-invalid;
      }

      .prefix ::slotted(*) {
        display: inline-block;
        @apply --paper-font-subhead;
        @apply --layout-flex-none;
        @apply --paper-input-prefix;
      }

      .suffix ::slotted(*) {
        display: inline-block;
        @apply --paper-font-subhead;
        @apply --layout-flex-none;

        @apply --paper-input-suffix;
      }

      /* Firefox sets a min-width on the input, which can cause layout issues */
      .input-content ::slotted(input) {
        min-width: 0;
      }

      .input-content ::slotted(textarea) {
        resize: none;
      }

      .add-on-content {
        position: relative;
      }

      .add-on-content.is-invalid ::slotted(*) {
        color: var(--paper-input-container-invalid-color, var(--error-color));
      }

      .add-on-content.is-highlighted ::slotted(*) {
        color: var(--paper-input-container-focus-color, var(--primary-color));
      }
    </style>

    <div class="floated-label-placeholder" aria-hidden="true" hidden="[[noLabelFloat]]">&nbsp;</div>

    <div class="input-wrapper">
      <span class="prefix"><slot name="prefix"></slot></span>

      <div class$="[[_computeInputContentClass(noLabelFloat,alwaysFloatLabel,focused,invalid,_inputHasContent)]]" id="labelAndInputContainer">
        <slot name="label"></slot>
        <slot name="input"></slot>
      </div>

      <span class="suffix"><slot name="suffix"></slot></span>
    </div>

    <div class$="[[_computeUnderlineClass(focused,invalid)]]">
      <div class="unfocused-line"></div>
      <div class="focused-line"></div>
    </div>

    <div class$="[[_computeAddOnContentClass(focused,invalid)]]">
      <slot name="add-on"></slot>
    </div>
`,
    is: "paper-input-container",
    properties: {
        noLabelFloat: {
            type: Boolean,
            value: !1
        },
        alwaysFloatLabel: {
            type: Boolean,
            value: !1
        },
        attrForValue: {
            type: String,
            value: "bind-value"
        },
        autoValidate: {
            type: Boolean,
            value: !1
        },
        invalid: {
            observer: "_invalidChanged",
            type: Boolean,
            value: !1
        },
        focused: {
            readOnly: !0,
            type: Boolean,
            value: !1,
            notify: !0
        },
        _addons: {
            type: Array
        },
        _inputHasContent: {
            type: Boolean,
            value: !1
        },
        _inputSelector: {
            type: String,
            value: "input,iron-input,textarea,.paper-input-input"
        },
        _boundOnFocus: {
            type: Function,
            value: function() {
                return this._onFocus.bind(this);
            }
        },
        _boundOnBlur: {
            type: Function,
            value: function() {
                return this._onBlur.bind(this);
            }
        },
        _boundOnInput: {
            type: Function,
            value: function() {
                return this._onInput.bind(this);
            }
        },
        _boundValueChanged: {
            type: Function,
            value: function() {
                return this._onValueChanged.bind(this);
            }
        }
    },
    listeners: {
        "addon-attached": "_onAddonAttached",
        "iron-input-validate": "_onIronInputValidate"
    },
    get _valueChangedEvent() {
        return this.attrForValue + "-changed";
    },
    get _propertyForValue() {
        return dashToCamelCase(this.attrForValue);
    },
    get _inputElement() {
        return dom(this).querySelector(this._inputSelector);
    },
    get _inputElementValue() {
        return this._inputElement[this._propertyForValue] || this._inputElement.value;
    },
    ready: function() {
        this.__isFirstValueUpdate = !0, this._addons || (this._addons = []), this.addEventListener("focus", this._boundOnFocus, !0), 
        this.addEventListener("blur", this._boundOnBlur, !0);
    },
    attached: function() {
        this.attrForValue ? this._inputElement.addEventListener(this._valueChangedEvent, this._boundValueChanged) : this.addEventListener("input", this._onInput), 
        this._inputElementValue && "" != this._inputElementValue ? this._handleValueAndAutoValidate(this._inputElement) : this._handleValue(this._inputElement);
    },
    _onAddonAttached: function(e) {
        this._addons || (this._addons = []);
        var t = e.target;
        -1 === this._addons.indexOf(t) && (this._addons.push(t), this.isAttached && this._handleValue(this._inputElement));
    },
    _onFocus: function() {
        this._setFocused(!0);
    },
    _onBlur: function() {
        this._setFocused(!1), this._handleValueAndAutoValidate(this._inputElement);
    },
    _onInput: function(e) {
        this._handleValueAndAutoValidate(e.target);
    },
    _onValueChanged: function(e) {
        var t = e.target;
        this.__isFirstValueUpdate && (this.__isFirstValueUpdate = !1, void 0 === t.value || "" === t.value) || this._handleValueAndAutoValidate(e.target);
    },
    _handleValue: function(e) {
        var t = this._inputElementValue;
        t || 0 === t || "number" === e.type && !e.checkValidity() ? this._inputHasContent = !0 : this._inputHasContent = !1, 
        this.updateAddons({
            inputElement: e,
            value: t,
            invalid: this.invalid
        });
    },
    _handleValueAndAutoValidate: function(e) {
        var t;
        this.autoValidate && e && (t = e.validate ? e.validate(this._inputElementValue) : e.checkValidity(), 
        this.invalid = !t);
        this._handleValue(e);
    },
    _onIronInputValidate: function(e) {
        this.invalid = this._inputElement.invalid;
    },
    _invalidChanged: function() {
        this._addons && this.updateAddons({
            invalid: this.invalid
        });
    },
    updateAddons: function(e) {
        for (var t, i = 0; t = this._addons[i]; i++) t.update(e);
    },
    _computeInputContentClass: function(e, t, i, o, n) {
        var a = "input-content";
        if (e) n && (a += " label-is-hidden"), o && (a += " is-invalid"); else {
            var r = this.querySelector("label");
            t || n ? (a += " label-is-floating", this.$.labelAndInputContainer.style.position = "static", 
            o ? a += " is-invalid" : i && (a += " label-is-highlighted")) : (r && (this.$.labelAndInputContainer.style.position = "relative"), 
            o && (a += " is-invalid"));
        }
        return i && (a += " focused"), a;
    },
    _computeUnderlineClass: function(e, t) {
        var i = "underline";
        return t ? i += " is-invalid" : e && (i += " is-highlighted"), i;
    },
    _computeAddOnContentClass: function(e, t) {
        var i = "add-on-content";
        return t ? i += " is-invalid" : e && (i += " is-highlighted"), i;
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        visibility: hidden;

        color: var(--paper-input-container-invalid-color, var(--error-color));

        @apply --paper-font-caption;
        @apply --paper-input-error;
        position: absolute;
        left:0;
        right:0;
      }

      :host([invalid]) {
        visibility: visible;
      }

      #a11yWrapper {
        visibility: hidden;
      }

      :host([invalid]) #a11yWrapper {
        visibility: visible;
      }
    </style>

    <!--
    If the paper-input-error element is directly referenced by an
    \`aria-describedby\` attribute, such as when used as a paper-input add-on,
    then applying \`visibility: hidden;\` to the paper-input-error element itself
    does not hide the error.

    For more information, see:
    https://www.w3.org/TR/accname-1.1/#mapping_additional_nd_description
    -->
    <div id="a11yWrapper">
      <slot></slot>
    </div>
`,
    is: "paper-input-error",
    behaviors: [ PaperInputAddonBehavior ],
    properties: {
        invalid: {
            readOnly: !0,
            reflectToAttribute: !0,
            type: Boolean
        }
    },
    update: function(e) {
        this._setInvalid(e.invalid);
    }
});

const PaperInputHelper = {
    NextLabelID: 1,
    NextAddonID: 1,
    NextInputID: 1
}, PaperInputBehaviorImpl = {
    properties: {
        label: {
            type: String
        },
        value: {
            notify: !0,
            type: String
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        invalid: {
            type: Boolean,
            value: !1,
            notify: !0
        },
        allowedPattern: {
            type: String
        },
        type: {
            type: String
        },
        list: {
            type: String
        },
        pattern: {
            type: String
        },
        required: {
            type: Boolean,
            value: !1
        },
        errorMessage: {
            type: String
        },
        charCounter: {
            type: Boolean,
            value: !1
        },
        noLabelFloat: {
            type: Boolean,
            value: !1
        },
        alwaysFloatLabel: {
            type: Boolean,
            value: !1
        },
        autoValidate: {
            type: Boolean,
            value: !1
        },
        validator: {
            type: String
        },
        autocomplete: {
            type: String,
            value: "off"
        },
        autofocus: {
            type: Boolean,
            observer: "_autofocusChanged"
        },
        inputmode: {
            type: String
        },
        minlength: {
            type: Number
        },
        maxlength: {
            type: Number
        },
        min: {
            type: String
        },
        max: {
            type: String
        },
        step: {
            type: String
        },
        name: {
            type: String
        },
        placeholder: {
            type: String,
            value: ""
        },
        readonly: {
            type: Boolean,
            value: !1
        },
        size: {
            type: Number
        },
        autocapitalize: {
            type: String,
            value: "none"
        },
        autocorrect: {
            type: String,
            value: "off"
        },
        autosave: {
            type: String
        },
        results: {
            type: Number
        },
        accept: {
            type: String
        },
        multiple: {
            type: Boolean
        },
        _ariaDescribedBy: {
            type: String,
            value: ""
        },
        _ariaLabelledBy: {
            type: String,
            value: ""
        },
        _inputId: {
            type: String,
            value: ""
        }
    },
    listeners: {
        "addon-attached": "_onAddonAttached"
    },
    keyBindings: {
        "shift+tab:keydown": "_onShiftTabDown"
    },
    hostAttributes: {
        tabindex: 0
    },
    get inputElement() {
        return this.$ || (this.$ = {}), this.$.input || (this._generateInputId(), this.$.input = this.$$("#" + this._inputId)), 
        this.$.input;
    },
    get _focusableElement() {
        return this.inputElement;
    },
    created: function() {
        this._typesThatHaveText = [ "date", "datetime", "datetime-local", "month", "time", "week", "file" ];
    },
    attached: function() {
        this._updateAriaLabelledBy(), !PolymerElement && this.inputElement && -1 !== this._typesThatHaveText.indexOf(this.inputElement.type) && (this.alwaysFloatLabel = !0);
    },
    _appendStringWithSpace: function(e, t) {
        return e = e ? e + " " + t : t;
    },
    _onAddonAttached: function(e) {
        var t = dom(e).rootTarget;
        if (t.id) this._ariaDescribedBy = this._appendStringWithSpace(this._ariaDescribedBy, t.id); else {
            var i = "paper-input-add-on-" + PaperInputHelper.NextAddonID++;
            t.id = i, this._ariaDescribedBy = this._appendStringWithSpace(this._ariaDescribedBy, i);
        }
    },
    validate: function() {
        return this.inputElement.validate();
    },
    _focusBlurHandler: function(e) {
        IronControlState._focusBlurHandler.call(this, e), this.focused && !this._shiftTabPressed && this._focusableElement && this._focusableElement.focus();
    },
    _onShiftTabDown: function(e) {
        var t = this.getAttribute("tabindex");
        this._shiftTabPressed = !0, this.setAttribute("tabindex", "-1"), this.async(function() {
            this.setAttribute("tabindex", t), this._shiftTabPressed = !1;
        }, 1);
    },
    _handleAutoValidate: function() {
        this.autoValidate && this.validate();
    },
    updateValueAndPreserveCaret: function(e) {
        try {
            var t = this.inputElement.selectionStart;
            this.value = e, this.inputElement.selectionStart = t, this.inputElement.selectionEnd = t;
        } catch (t) {
            this.value = e;
        }
    },
    _computeAlwaysFloatLabel: function(e, t) {
        return t || e;
    },
    _updateAriaLabelledBy: function() {
        var e, t = dom(this.root).querySelector("label");
        t ? (t.id ? e = t.id : (e = "paper-input-label-" + PaperInputHelper.NextLabelID++, 
        t.id = e), this._ariaLabelledBy = e) : this._ariaLabelledBy = "";
    },
    _generateInputId: function() {
        this._inputId && "" !== this._inputId || (this._inputId = "input-" + PaperInputHelper.NextInputID++);
    },
    _onChange: function(e) {
        this.shadowRoot && this.fire(e.type, {
            sourceEvent: e
        }, {
            node: this,
            bubbles: e.bubbles,
            cancelable: e.cancelable
        });
    },
    _autofocusChanged: function() {
        if (this.autofocus && this._focusableElement) {
            var e = document.activeElement;
            e instanceof HTMLElement && e !== document.body && e !== document.documentElement || this._focusableElement.focus();
        }
    }
}, PaperInputBehavior = [ IronControlState, IronA11yKeysBehavior, PaperInputBehaviorImpl ];

var paperInputBehavior = {
    PaperInputHelper: PaperInputHelper,
    PaperInputBehaviorImpl: PaperInputBehaviorImpl,
    PaperInputBehavior: PaperInputBehavior
};

Polymer({
    is: "paper-input",
    _template: html`
    <style>
      :host {
        display: block;
      }

      :host([focused]) {
        outline: none;
      }

      :host([hidden]) {
        display: none !important;
      }

      input {
        /* Firefox sets a min-width on the input, which can cause layout issues */
        min-width: 0;
      }

      /* In 1.x, the <input> is distributed to paper-input-container, which styles it.
      In 2.x the <iron-input> is distributed to paper-input-container, which styles
      it, but in order for this to work correctly, we need to reset some
      of the native input's properties to inherit (from the iron-input) */
      iron-input > input {
        @apply --paper-input-container-shared-input-style;
        font-family: inherit;
        font-weight: inherit;
        font-size: inherit;
        letter-spacing: inherit;
        word-spacing: inherit;
        line-height: inherit;
        text-shadow: inherit;
        color: inherit;
        cursor: inherit;
      }

      input:disabled {
        @apply --paper-input-container-input-disabled;
      }

      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      input::-webkit-clear-button {
        @apply --paper-input-container-input-webkit-clear;
      }

      input::-webkit-calendar-picker-indicator {
        @apply --paper-input-container-input-webkit-calendar-picker-indicator;
      }

      input::-webkit-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input:-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-ms-clear {
        @apply --paper-input-container-ms-clear;
      }

      input::-ms-reveal {
        @apply --paper-input-container-ms-reveal;
      }

      input:-ms-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      label {
        pointer-events: none;
      }
    </style>

    <paper-input-container id="container" no-label-float="[[noLabelFloat]]" always-float-label="[[_computeAlwaysFloatLabel(alwaysFloatLabel,placeholder)]]" auto-validate$="[[autoValidate]]" disabled$="[[disabled]]" invalid="[[invalid]]">

      <slot name="prefix" slot="prefix"></slot>

      <label hidden$="[[!label]]" aria-hidden="true" for$="[[_inputId]]" slot="label">[[label]]</label>

      <!-- Need to bind maxlength so that the paper-input-char-counter works correctly -->
      <iron-input bind-value="{{value}}" slot="input" class="input-element" id$="[[_inputId]]" maxlength$="[[maxlength]]" allowed-pattern="[[allowedPattern]]" invalid="{{invalid}}" validator="[[validator]]">
        <input aria-labelledby$="[[_ariaLabelledBy]]" aria-describedby$="[[_ariaDescribedBy]]" disabled$="[[disabled]]" title$="[[title]]" type$="[[type]]" pattern$="[[pattern]]" required$="[[required]]" autocomplete$="[[autocomplete]]" autofocus$="[[autofocus]]" inputmode$="[[inputmode]]" minlength$="[[minlength]]" maxlength$="[[maxlength]]" min$="[[min]]" max$="[[max]]" step$="[[step]]" name$="[[name]]" placeholder$="[[placeholder]]" readonly$="[[readonly]]" list$="[[list]]" size$="[[size]]" autocapitalize$="[[autocapitalize]]" autocorrect$="[[autocorrect]]" on-change="_onChange" tabindex$="[[tabIndex]]" autosave$="[[autosave]]" results$="[[results]]" accept$="[[accept]]" multiple$="[[multiple]]">
      </iron-input>

      <slot name="suffix" slot="suffix"></slot>

      <template is="dom-if" if="[[errorMessage]]">
        <paper-input-error aria-live="assertive" slot="add-on">[[errorMessage]]</paper-input-error>
      </template>

      <template is="dom-if" if="[[charCounter]]">
        <paper-input-char-counter slot="add-on"></paper-input-char-counter>
      </template>

    </paper-input-container>
  `,
    behaviors: [ PaperInputBehavior, IronFormElementBehavior ],
    properties: {
        value: {
            type: String
        }
    },
    get _focusableElement() {
        return this.inputElement._inputElement;
    },
    listeners: {
        "iron-input-ready": "_onIronInputReady"
    },
    _onIronInputReady: function() {
        this.$.nativeInput || (this.$.nativeInput = this.$$("input")), this.inputElement && -1 !== this._typesThatHaveText.indexOf(this.$.nativeInput.type) && (this.alwaysFloatLabel = !0), 
        this.inputElement.bindValue && this.$.container._handleValueAndAutoValidate(this.inputElement);
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        position: fixed;
      }

      #contentWrapper ::slotted(*) {
        overflow: auto;
      }

      #contentWrapper.animating ::slotted(*) {
        overflow: hidden;
        pointer-events: none;
      }
    </style>

    <div id="contentWrapper">
      <slot id="content" name="dropdown-content"></slot>
    </div>
`,
    is: "iron-dropdown",
    behaviors: [ IronControlState, IronA11yKeysBehavior, IronOverlayBehavior, NeonAnimationRunnerBehavior ],
    properties: {
        horizontalAlign: {
            type: String,
            value: "left",
            reflectToAttribute: !0
        },
        verticalAlign: {
            type: String,
            value: "top",
            reflectToAttribute: !0
        },
        openAnimationConfig: {
            type: Object
        },
        closeAnimationConfig: {
            type: Object
        },
        focusTarget: {
            type: Object
        },
        noAnimations: {
            type: Boolean,
            value: !1
        },
        allowOutsideScroll: {
            type: Boolean,
            value: !1,
            observer: "_allowOutsideScrollChanged"
        }
    },
    listeners: {
        "neon-animation-finish": "_onNeonAnimationFinish"
    },
    observers: [ "_updateOverlayPosition(positionTarget, verticalAlign, horizontalAlign, verticalOffset, horizontalOffset)" ],
    get containedElement() {
        for (var e = dom(this.$.content).getDistributedNodes(), t = 0, i = e.length; t < i; t++) if (e[t].nodeType === Node.ELEMENT_NODE) return e[t];
    },
    ready: function() {
        this.scrollAction || (this.scrollAction = this.allowOutsideScroll ? "refit" : "lock"), 
        this._readied = !0;
    },
    attached: function() {
        this.sizingTarget && this.sizingTarget !== this || (this.sizingTarget = this.containedElement || this);
    },
    detached: function() {
        this.cancelAnimation();
    },
    _openedChanged: function() {
        this.opened && this.disabled ? this.cancel() : (this.cancelAnimation(), this._updateAnimationConfig(), 
        IronOverlayBehaviorImpl._openedChanged.apply(this, arguments));
    },
    _renderOpened: function() {
        !this.noAnimations && this.animationConfig.open ? (this.$.contentWrapper.classList.add("animating"), 
        this.playAnimation("open")) : IronOverlayBehaviorImpl._renderOpened.apply(this, arguments);
    },
    _renderClosed: function() {
        !this.noAnimations && this.animationConfig.close ? (this.$.contentWrapper.classList.add("animating"), 
        this.playAnimation("close")) : IronOverlayBehaviorImpl._renderClosed.apply(this, arguments);
    },
    _onNeonAnimationFinish: function() {
        this.$.contentWrapper.classList.remove("animating"), this.opened ? this._finishRenderOpened() : this._finishRenderClosed();
    },
    _updateAnimationConfig: function() {
        for (var e = this.containedElement, t = [].concat(this.openAnimationConfig || []).concat(this.closeAnimationConfig || []), i = 0; i < t.length; i++) t[i].node = e;
        this.animationConfig = {
            open: this.openAnimationConfig,
            close: this.closeAnimationConfig
        };
    },
    _updateOverlayPosition: function() {
        this.isAttached && this.notifyResize();
    },
    _allowOutsideScrollChanged: function(e) {
        this._readied && (e ? this.scrollAction && "lock" !== this.scrollAction || (this.scrollAction = "refit") : this.scrollAction = "lock");
    },
    _applyFocus: function() {
        var e = this.focusTarget || this.containedElement;
        e && this.opened && !this.noAutoFocus ? e.focus() : IronOverlayBehaviorImpl._applyFocus.apply(this, arguments);
    }
}), Polymer({
    is: "paper-menu-grow-height-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = t.getBoundingClientRect().height;
        return this._effect = new KeyframeEffect(t, [ {
            height: i / 2 + "px"
        }, {
            height: i + "px"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "paper-menu-grow-width-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = t.getBoundingClientRect().width;
        return this._effect = new KeyframeEffect(t, [ {
            width: i / 2 + "px"
        }, {
            width: i + "px"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "paper-menu-shrink-width-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = t.getBoundingClientRect().width;
        return this._effect = new KeyframeEffect(t, [ {
            width: i + "px"
        }, {
            width: i - i / 20 + "px"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "paper-menu-shrink-height-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = t.getBoundingClientRect().height;
        return this.setPrefixedProperty(t, "transformOrigin", "0 0"), this._effect = new KeyframeEffect(t, [ {
            height: i + "px",
            transform: "translateY(0)"
        }, {
            height: i / 2 + "px",
            transform: "translateY(-20px)"
        } ], this.timingFromConfig(e)), this._effect;
    }
});

var config = {
    ANIMATION_CUBIC_BEZIER: "cubic-bezier(.3,.95,.5,1)",
    MAX_ANIMATION_TIME_MS: 400
};

const PaperMenuButton = Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        position: relative;
        padding: 8px;
        outline: none;

        @apply --paper-menu-button;
      }

      :host([disabled]) {
        cursor: auto;
        color: var(--disabled-text-color);

        @apply --paper-menu-button-disabled;
      }

      iron-dropdown {
        @apply --paper-menu-button-dropdown;
      }

      .dropdown-content {
        @apply --shadow-elevation-2dp;

        position: relative;
        border-radius: 2px;
        background-color: var(--paper-menu-button-dropdown-background, var(--primary-background-color));

        @apply --paper-menu-button-content;
      }

      :host([vertical-align="top"]) .dropdown-content {
        margin-bottom: 20px;
        margin-top: -10px;
        top: 10px;
      }

      :host([vertical-align="bottom"]) .dropdown-content {
        bottom: 10px;
        margin-bottom: -10px;
        margin-top: 20px;
      }

      #trigger {
        cursor: pointer;
      }
    </style>

    <div id="trigger" on-tap="toggle">
      <slot name="dropdown-trigger"></slot>
    </div>

    <iron-dropdown id="dropdown" opened="{{opened}}" horizontal-align="[[horizontalAlign]]" vertical-align="[[verticalAlign]]" dynamic-align="[[dynamicAlign]]" horizontal-offset="[[horizontalOffset]]" vertical-offset="[[verticalOffset]]" no-overlap="[[noOverlap]]" open-animation-config="[[openAnimationConfig]]" close-animation-config="[[closeAnimationConfig]]" no-animations="[[noAnimations]]" focus-target="[[_dropdownContent]]" allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]" on-iron-overlay-canceled="__onIronOverlayCanceled">
      <div slot="dropdown-content" class="dropdown-content">
        <slot id="content" name="dropdown-content"></slot>
      </div>
    </iron-dropdown>
`,
    is: "paper-menu-button",
    behaviors: [ IronA11yKeysBehavior, IronControlState ],
    properties: {
        opened: {
            type: Boolean,
            value: !1,
            notify: !0,
            observer: "_openedChanged"
        },
        horizontalAlign: {
            type: String,
            value: "left",
            reflectToAttribute: !0
        },
        verticalAlign: {
            type: String,
            value: "top",
            reflectToAttribute: !0
        },
        dynamicAlign: {
            type: Boolean
        },
        horizontalOffset: {
            type: Number,
            value: 0,
            notify: !0
        },
        verticalOffset: {
            type: Number,
            value: 0,
            notify: !0
        },
        noOverlap: {
            type: Boolean
        },
        noAnimations: {
            type: Boolean,
            value: !1
        },
        ignoreSelect: {
            type: Boolean,
            value: !1
        },
        closeOnActivate: {
            type: Boolean,
            value: !1
        },
        openAnimationConfig: {
            type: Object,
            value: function() {
                return [ {
                    name: "fade-in-animation",
                    timing: {
                        delay: 100,
                        duration: 200
                    }
                }, {
                    name: "paper-menu-grow-width-animation",
                    timing: {
                        delay: 100,
                        duration: 150,
                        easing: config.ANIMATION_CUBIC_BEZIER
                    }
                }, {
                    name: "paper-menu-grow-height-animation",
                    timing: {
                        delay: 100,
                        duration: 275,
                        easing: config.ANIMATION_CUBIC_BEZIER
                    }
                } ];
            }
        },
        closeAnimationConfig: {
            type: Object,
            value: function() {
                return [ {
                    name: "fade-out-animation",
                    timing: {
                        duration: 150
                    }
                }, {
                    name: "paper-menu-shrink-width-animation",
                    timing: {
                        delay: 100,
                        duration: 50,
                        easing: config.ANIMATION_CUBIC_BEZIER
                    }
                }, {
                    name: "paper-menu-shrink-height-animation",
                    timing: {
                        duration: 200,
                        easing: "ease-in"
                    }
                } ];
            }
        },
        allowOutsideScroll: {
            type: Boolean,
            value: !1
        },
        restoreFocusOnClose: {
            type: Boolean,
            value: !0
        },
        _dropdownContent: {
            type: Object
        }
    },
    hostAttributes: {
        role: "group",
        "aria-haspopup": "true"
    },
    listeners: {
        "iron-activate": "_onIronActivate",
        "iron-select": "_onIronSelect"
    },
    get contentElement() {
        for (var e = dom(this.$.content).getDistributedNodes(), t = 0, i = e.length; t < i; t++) if (e[t].nodeType === Node.ELEMENT_NODE) return e[t];
    },
    toggle: function() {
        this.opened ? this.close() : this.open();
    },
    open: function() {
        this.disabled || this.$.dropdown.open();
    },
    close: function() {
        this.$.dropdown.close();
    },
    _onIronSelect: function(e) {
        this.ignoreSelect || this.close();
    },
    _onIronActivate: function(e) {
        this.closeOnActivate && this.close();
    },
    _openedChanged: function(e, t) {
        e ? (this._dropdownContent = this.contentElement, this.fire("paper-dropdown-open")) : null != t && this.fire("paper-dropdown-close");
    },
    _disabledChanged: function(e) {
        IronControlState._disabledChanged.apply(this, arguments), e && this.opened && this.close();
    },
    __onIronOverlayCanceled: function(e) {
        var t = e.detail, i = this.$.trigger;
        dom(t).path.indexOf(i) > -1 && e.preventDefault();
    }
});

Object.keys(config).forEach(function(e) {
    PaperMenuButton[e] = config[e];
});

var paperMenuButton = {
    PaperMenuButton: PaperMenuButton
};

const $_documentContainer$3 = document.createElement("template");

$_documentContainer$3.setAttribute("style", "display: none;"), $_documentContainer$3.innerHTML = '<iron-iconset-svg name="paper-dropdown-menu" size="24">\n<svg><defs>\n<g id="arrow-drop-down"><path d="M7 10l5 5 5-5z"></path></g>\n</defs></svg>\n</iron-iconset-svg>', 
document.head.appendChild($_documentContainer$3.content);

const $_documentContainer$4 = document.createElement("template");

$_documentContainer$4.setAttribute("style", "display: none;"), $_documentContainer$4.innerHTML = '<dom-module id="paper-dropdown-menu-shared-styles">\n  <template>\n    <style>\n      :host {\n        display: inline-block;\n        position: relative;\n        text-align: left;\n\n        /* NOTE(cdata): Both values are needed, since some phones require the\n         * value to be `transparent`.\n         */\n        -webkit-tap-highlight-color: rgba(0,0,0,0);\n        -webkit-tap-highlight-color: transparent;\n\n        --paper-input-container-input: {\n          overflow: hidden;\n          white-space: nowrap;\n          text-overflow: ellipsis;\n          max-width: 100%;\n          box-sizing: border-box;\n          cursor: pointer;\n        };\n\n        @apply --paper-dropdown-menu;\n      }\n\n      :host([disabled]) {\n        @apply --paper-dropdown-menu-disabled;\n      }\n\n      :host([noink]) paper-ripple {\n        display: none;\n      }\n\n      :host([no-label-float]) paper-ripple {\n        top: 8px;\n      }\n\n      paper-ripple {\n        top: 12px;\n        left: 0px;\n        bottom: 8px;\n        right: 0px;\n\n        @apply --paper-dropdown-menu-ripple;\n      }\n\n      paper-menu-button {\n        display: block;\n        padding: 0;\n\n        @apply --paper-dropdown-menu-button;\n      }\n\n      paper-input {\n        @apply --paper-dropdown-menu-input;\n      }\n\n      iron-icon {\n        color: var(--disabled-text-color);\n\n        @apply --paper-dropdown-menu-icon;\n      }\n    </style>\n  </template>\n</dom-module>', 
document.head.appendChild($_documentContainer$4.content), Polymer({
    _template: html`
    <style include="paper-dropdown-menu-shared-styles"></style>

    <!-- this div fulfills an a11y requirement for combobox, do not remove -->
    <span role="button"></span>
    <paper-menu-button id="menuButton" vertical-align="[[verticalAlign]]" horizontal-align="[[horizontalAlign]]" dynamic-align="[[dynamicAlign]]" vertical-offset="[[_computeMenuVerticalOffset(noLabelFloat, verticalOffset)]]" disabled="[[disabled]]" no-animations="[[noAnimations]]" on-iron-select="_onIronSelect" on-iron-deselect="_onIronDeselect" opened="{{opened}}" close-on-activate allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]">
      <!-- support hybrid mode: user might be using paper-menu-button 1.x which distributes via <content> -->
      <div class="dropdown-trigger" slot="dropdown-trigger">
        <paper-ripple></paper-ripple>
        <!-- paper-input has type="text" for a11y, do not remove -->
        <paper-input type="text" invalid="[[invalid]]" readonly disabled="[[disabled]]" value="[[value]]" placeholder="[[placeholder]]" error-message="[[errorMessage]]" always-float-label="[[alwaysFloatLabel]]" no-label-float="[[noLabelFloat]]" label="[[label]]">
          <!-- support hybrid mode: user might be using paper-input 1.x which distributes via <content> -->
          <iron-icon icon="paper-dropdown-menu:arrow-drop-down" suffix slot="suffix"></iron-icon>
        </paper-input>
      </div>
      <slot id="content" name="dropdown-content" slot="dropdown-content"></slot>
    </paper-menu-button>
`,
    is: "paper-dropdown-menu",
    behaviors: [ IronButtonState, IronControlState, IronFormElementBehavior, IronValidatableBehavior ],
    properties: {
        selectedItemLabel: {
            type: String,
            notify: !0,
            readOnly: !0
        },
        selectedItem: {
            type: Object,
            notify: !0,
            readOnly: !0
        },
        value: {
            type: String,
            notify: !0
        },
        label: {
            type: String
        },
        placeholder: {
            type: String
        },
        errorMessage: {
            type: String
        },
        opened: {
            type: Boolean,
            notify: !0,
            value: !1,
            observer: "_openedChanged"
        },
        allowOutsideScroll: {
            type: Boolean,
            value: !1
        },
        noLabelFloat: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        },
        alwaysFloatLabel: {
            type: Boolean,
            value: !1
        },
        noAnimations: {
            type: Boolean,
            value: !1
        },
        horizontalAlign: {
            type: String,
            value: "right"
        },
        verticalAlign: {
            type: String,
            value: "top"
        },
        verticalOffset: Number,
        dynamicAlign: {
            type: Boolean
        },
        restoreFocusOnClose: {
            type: Boolean,
            value: !0
        }
    },
    listeners: {
        tap: "_onTap"
    },
    keyBindings: {
        "up down": "open",
        esc: "close"
    },
    hostAttributes: {
        role: "combobox",
        "aria-autocomplete": "none",
        "aria-haspopup": "true"
    },
    observers: [ "_selectedItemChanged(selectedItem)" ],
    attached: function() {
        var e = this.contentElement;
        e && e.selectedItem && this._setSelectedItem(e.selectedItem);
    },
    get contentElement() {
        for (var e = dom(this.$.content).getDistributedNodes(), t = 0, i = e.length; t < i; t++) if (e[t].nodeType === Node.ELEMENT_NODE) return e[t];
    },
    open: function() {
        this.$.menuButton.open();
    },
    close: function() {
        this.$.menuButton.close();
    },
    _onIronSelect: function(e) {
        this._setSelectedItem(e.detail.item);
    },
    _onIronDeselect: function(e) {
        this._setSelectedItem(null);
    },
    _onTap: function(e) {
        findOriginalTarget(e) === this && this.open();
    },
    _selectedItemChanged: function(e) {
        var t = "";
        t = e ? e.label || e.getAttribute("label") || e.textContent.trim() : "", this.value = t, 
        this._setSelectedItemLabel(t);
    },
    _computeMenuVerticalOffset: function(e, t) {
        return t || (e ? -4 : 8);
    },
    _getValidity: function(e) {
        return this.disabled || !this.required || this.required && !!this.value;
    },
    _openedChanged: function() {
        var e = this.opened ? "true" : "false", t = this.contentElement;
        t && t.setAttribute("aria-expanded", e);
    }
});

var __decorate$b = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let SettingDropdownElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.value = 0, this.label = "", this.items = [];
    }
    onItemSelected(e) {
        const t = this.template.modelForElement(e.target);
        t && event(EVENT.MENU, `${this.name}: ${t.get("index")}`);
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
  }

  :host([disabled]) {
    pointer-events: none;
  }


  :host([indent]) .setting-label {
    padding-left: 8px;
  }

  :host .top {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  :host paper-dropdown-menu {
    width: 175px;

    --paper-input-container-input: {
      text-align: right;
    };
  }

</style>

<paper-item class="top center horizontal layout" tabindex="-1">
  <div class="setting-label flex">[[label]]</div>
  <paper-dropdown-menu disabled$="[[disabled]]" noink="" no-label-float="">
    <paper-listbox id="list" slot="dropdown-content" selected="{{value}}">
      <template id="t" is="dom-repeat" items="[[items]]">
        <paper-item>[[item]]</paper-item>
      </template>
    </paper-listbox>
  </paper-dropdown-menu>
</paper-item>

<app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
</app-localstorage-document>
`;
    }
};

__decorate$b([ property({
    type: Number,
    notify: !0
}) ], SettingDropdownElement.prototype, "value", void 0), __decorate$b([ property({
    type: String
}) ], SettingDropdownElement.prototype, "label", void 0), __decorate$b([ property({
    type: Array
}) ], SettingDropdownElement.prototype, "items", void 0), __decorate$b([ query("#t") ], SettingDropdownElement.prototype, "template", void 0), 
__decorate$b([ listen("tap", "list") ], SettingDropdownElement.prototype, "onItemSelected", null), 
SettingDropdownElement = __decorate$b([ customElement("setting-dropdown") ], SettingDropdownElement);

var settingDropdown = {
    get SettingDropdownElement() {
        return SettingDropdownElement;
    }
};

const IronRangeBehavior = {
    properties: {
        value: {
            type: Number,
            value: 0,
            notify: !0,
            reflectToAttribute: !0
        },
        min: {
            type: Number,
            value: 0,
            notify: !0
        },
        max: {
            type: Number,
            value: 100,
            notify: !0
        },
        step: {
            type: Number,
            value: 1,
            notify: !0
        },
        ratio: {
            type: Number,
            value: 0,
            readOnly: !0,
            notify: !0
        }
    },
    observers: [ "_update(value, min, max, step)" ],
    _calcRatio: function(e) {
        return (this._clampValue(e) - this.min) / (this.max - this.min);
    },
    _clampValue: function(e) {
        return Math.min(this.max, Math.max(this.min, this._calcStep(e)));
    },
    _calcStep: function(e) {
        if (e = parseFloat(e), !this.step) return e;
        var t = Math.round((e - this.min) / this.step);
        return this.step < 1 ? t / (1 / this.step) + this.min : t * this.step + this.min;
    },
    _validateValue: function() {
        var e = this._clampValue(this.value);
        return this.value = this.oldValue = isNaN(e) ? this.oldValue : e, this.value !== e;
    },
    _update: function() {
        this._validateValue(), this._setRatio(100 * this._calcRatio(this.value));
    }
};

var ironRangeBehavior = {
    IronRangeBehavior: IronRangeBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        width: 200px;
        position: relative;
        overflow: hidden;
      }

      :host([hidden]), [hidden] {
        display: none !important;
      }

      #progressContainer {
        @apply --paper-progress-container;
        position: relative;
      }

      #progressContainer,
      /* the stripe for the indeterminate animation*/
      .indeterminate::after {
        height: var(--paper-progress-height, 4px);
      }

      #primaryProgress,
      #secondaryProgress,
      .indeterminate::after {
        @apply --layout-fit;
      }

      #progressContainer,
      .indeterminate::after {
        background: var(--paper-progress-container-color, var(--google-grey-300));
      }

      :host(.transiting) #primaryProgress,
      :host(.transiting) #secondaryProgress {
        -webkit-transition-property: -webkit-transform;
        transition-property: transform;

        /* Duration */
        -webkit-transition-duration: var(--paper-progress-transition-duration, 0.08s);
        transition-duration: var(--paper-progress-transition-duration, 0.08s);

        /* Timing function */
        -webkit-transition-timing-function: var(--paper-progress-transition-timing-function, ease);
        transition-timing-function: var(--paper-progress-transition-timing-function, ease);

        /* Delay */
        -webkit-transition-delay: var(--paper-progress-transition-delay, 0s);
        transition-delay: var(--paper-progress-transition-delay, 0s);
      }

      #primaryProgress,
      #secondaryProgress {
        @apply --layout-fit;
        -webkit-transform-origin: left center;
        transform-origin: left center;
        -webkit-transform: scaleX(0);
        transform: scaleX(0);
        will-change: transform;
      }

      #primaryProgress {
        background: var(--paper-progress-active-color, var(--google-green-500));
      }

      #secondaryProgress {
        background: var(--paper-progress-secondary-color, var(--google-green-100));
      }

      :host([disabled]) #primaryProgress {
        background: var(--paper-progress-disabled-active-color, var(--google-grey-500));
      }

      :host([disabled]) #secondaryProgress {
        background: var(--paper-progress-disabled-secondary-color, var(--google-grey-300));
      }

      :host(:not([disabled])) #primaryProgress.indeterminate {
        -webkit-transform-origin: right center;
        transform-origin: right center;
        -webkit-animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      :host(:not([disabled])) #primaryProgress.indeterminate::after {
        content: "";
        -webkit-transform-origin: center center;
        transform-origin: center center;

        -webkit-animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      @-webkit-keyframes indeterminate-bar {
        0% {
          -webkit-transform: scaleX(1) translateX(-100%);
        }
        50% {
          -webkit-transform: scaleX(1) translateX(0%);
        }
        75% {
          -webkit-transform: scaleX(1) translateX(0%);
          -webkit-animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          -webkit-transform: scaleX(0) translateX(0%);
        }
      }

      @-webkit-keyframes indeterminate-splitter {
        0% {
          -webkit-transform: scaleX(.75) translateX(-125%);
        }
        30% {
          -webkit-transform: scaleX(.75) translateX(-125%);
          -webkit-animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
        100% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
      }

      @keyframes indeterminate-bar {
        0% {
          transform: scaleX(1) translateX(-100%);
        }
        50% {
          transform: scaleX(1) translateX(0%);
        }
        75% {
          transform: scaleX(1) translateX(0%);
          animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          transform: scaleX(0) translateX(0%);
        }
      }

      @keyframes indeterminate-splitter {
        0% {
          transform: scaleX(.75) translateX(-125%);
        }
        30% {
          transform: scaleX(.75) translateX(-125%);
          animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          transform: scaleX(.75) translateX(125%);
        }
        100% {
          transform: scaleX(.75) translateX(125%);
        }
      }
    </style>

    <div id="progressContainer">
      <div id="secondaryProgress" hidden\$="[[_hideSecondaryProgress(secondaryRatio)]]"></div>
      <div id="primaryProgress"></div>
    </div>
`,
    is: "paper-progress",
    behaviors: [ IronRangeBehavior ],
    properties: {
        secondaryProgress: {
            type: Number,
            value: 0
        },
        secondaryRatio: {
            type: Number,
            value: 0,
            readOnly: !0
        },
        indeterminate: {
            type: Boolean,
            value: !1,
            observer: "_toggleIndeterminate"
        },
        disabled: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0,
            observer: "_disabledChanged"
        }
    },
    observers: [ "_progressChanged(secondaryProgress, value, min, max, indeterminate)" ],
    hostAttributes: {
        role: "progressbar"
    },
    _toggleIndeterminate: function(e) {
        this.toggleClass("indeterminate", e, this.$.primaryProgress);
    },
    _transformProgress: function(e, t) {
        var i = "scaleX(" + t / 100 + ")";
        e.style.transform = e.style.webkitTransform = i;
    },
    _mainRatioChanged: function(e) {
        this._transformProgress(this.$.primaryProgress, e);
    },
    _progressChanged: function(e, t, i, o, n) {
        e = this._clampValue(e), t = this._clampValue(t);
        var a = 100 * this._calcRatio(e), r = 100 * this._calcRatio(t);
        this._setSecondaryRatio(a), this._transformProgress(this.$.secondaryProgress, a), 
        this._transformProgress(this.$.primaryProgress, r), this.secondaryProgress = e, 
        n ? this.removeAttribute("aria-valuenow") : this.setAttribute("aria-valuenow", t), 
        this.setAttribute("aria-valuemin", i), this.setAttribute("aria-valuemax", o);
    },
    _disabledChanged: function(e) {
        this.setAttribute("aria-disabled", e ? "true" : "false");
    },
    _hideSecondaryProgress: function(e) {
        return 0 === e;
    }
});

const template$9 = html$1`
  <style>
    :host {
      @apply --layout;
      @apply --layout-justified;
      @apply --layout-center;
      width: 200px;
      cursor: default;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      --paper-progress-active-color: var(--paper-slider-active-color, var(--google-blue-700));
      --paper-progress-secondary-color: var(--paper-slider-secondary-color, var(--google-blue-300));
      --paper-progress-disabled-active-color: var(--paper-slider-disabled-active-color, var(--paper-grey-400));
      --paper-progress-disabled-secondary-color: var(--paper-slider-disabled-secondary-color, var(--paper-grey-400));
      --calculated-paper-slider-height: var(--paper-slider-height, 2px);
    }

    /* focus shows the ripple */
    :host(:focus) {
      outline: none;
    }

    /**
      * NOTE(keanulee): Though :host-context is not universally supported, some pages
      * still rely on paper-slider being flipped when dir="rtl" is set on body. For full
      * compatibility, dir="rtl" must be explicitly set on paper-slider.
      */
    :dir(rtl) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): This is separate from the rule above because :host-context may
      * not be recognized.
      */
    :host([dir="rtl"]) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): Needed to override the :host-context rule (where supported)
      * to support LTR sliders in RTL pages.
      */
    :host([dir="ltr"]) #sliderContainer {
      -webkit-transform: scaleX(1);
      transform: scaleX(1);
    }

    #sliderContainer {
      position: relative;
      width: 100%;
      height: calc(30px + var(--calculated-paper-slider-height));
      margin-left: calc(15px + var(--calculated-paper-slider-height)/2);
      margin-right: calc(15px + var(--calculated-paper-slider-height)/2);
    }

    #sliderContainer:focus {
      outline: 0;
    }

    #sliderContainer.editable {
      margin-top: 12px;
      margin-bottom: 12px;
    }

    .bar-container {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      overflow: hidden;
    }

    .ring > .bar-container {
      left: calc(5px + var(--calculated-paper-slider-height)/2);
      transition: left 0.18s ease;
    }

    .ring.expand.dragging > .bar-container {
      transition: none;
    }

    .ring.expand:not(.pin) > .bar-container {
      left: calc(8px + var(--calculated-paper-slider-height)/2);
    }

    #sliderBar {
      padding: 15px 0;
      width: 100%;
      background-color: var(--paper-slider-bar-color, transparent);
      --paper-progress-container-color: var(--paper-slider-container-color, var(--paper-grey-400));
      --paper-progress-height: var(--calculated-paper-slider-height);
    }

    .slider-markers {
      position: absolute;
      /* slider-knob is 30px + the slider-height so that the markers should start at a offset of 15px*/
      top: 15px;
      height: var(--calculated-paper-slider-height);
      left: 0;
      right: -1px;
      box-sizing: border-box;
      pointer-events: none;
      @apply --layout-horizontal;
    }

    .slider-marker {
      @apply --layout-flex;
    }
    .slider-markers::after,
    .slider-marker::after {
      content: "";
      display: block;
      margin-left: -1px;
      width: 2px;
      height: var(--calculated-paper-slider-height);
      border-radius: 50%;
      background-color: var(--paper-slider-markers-color, #000);
    }

    .slider-knob {
      position: absolute;
      left: 0;
      top: 0;
      margin-left: calc(-15px - var(--calculated-paper-slider-height)/2);
      width: calc(30px + var(--calculated-paper-slider-height));
      height: calc(30px + var(--calculated-paper-slider-height));
    }

    .transiting > .slider-knob {
      transition: left 0.08s ease;
    }

    .slider-knob:focus {
      outline: none;
    }

    .slider-knob.dragging {
      transition: none;
    }

    .snaps > .slider-knob.dragging {
      transition: -webkit-transform 0.08s ease;
      transition: transform 0.08s ease;
    }

    .slider-knob-inner {
      margin: 10px;
      width: calc(100% - 20px);
      height: calc(100% - 20px);
      background-color: var(--paper-slider-knob-color, var(--google-blue-700));
      border: 2px solid var(--paper-slider-knob-color, var(--google-blue-700));
      border-radius: 50%;

      -moz-box-sizing: border-box;
      box-sizing: border-box;

      transition-property: -webkit-transform, background-color, border;
      transition-property: transform, background-color, border;
      transition-duration: 0.18s;
      transition-timing-function: ease;
    }

    .expand:not(.pin) > .slider-knob > .slider-knob-inner {
      -webkit-transform: scale(1.5);
      transform: scale(1.5);
    }

    .ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-color, var(--google-blue-700));
    }

    .pin > .slider-knob > .slider-knob-inner::before {
      content: "";
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -13px;
      width: 26px;
      height: 26px;
      border-radius: 50% 50% 50% 0;

      -webkit-transform: rotate(-45deg) scale(0) translate(0);
      transform: rotate(-45deg) scale(0) translate(0);
    }

    .slider-knob-inner::before,
    .slider-knob-inner::after {
      transition: -webkit-transform .18s ease, background-color .18s ease;
      transition: transform .18s ease, background-color .18s ease;
    }

    .pin.ring > .slider-knob > .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-start-color, var(--paper-grey-400));
    }

    .pin.expand > .slider-knob > .slider-knob-inner::before {
      -webkit-transform: rotate(-45deg) scale(1) translate(17px, -17px);
      transform: rotate(-45deg) scale(1) translate(17px, -17px);
    }

    .pin > .slider-knob > .slider-knob-inner::after {
      content: attr(value);
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -16px;
      width: 32px;
      height: 26px;
      text-align: center;
      color: var(--paper-slider-font-color, #fff);
      font-size: 10px;

      -webkit-transform: scale(0) translate(0);
      transform: scale(0) translate(0);
    }

    .pin.expand > .slider-knob > .slider-knob-inner::after {
      -webkit-transform: scale(1) translate(0, -17px);
      transform: scale(1) translate(0, -17px);
    }

    /* paper-input */
    .slider-input {
      width: 50px;
      overflow: hidden;
      --paper-input-container-input: {
        text-align: center;
        @apply --paper-slider-input-container-input;
      };
      @apply --paper-slider-input;
    }

    /* disabled state */
    #sliderContainer.disabled {
      pointer-events: none;
    }

    .disabled > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      border: 2px solid var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      -webkit-transform: scale3d(0.75, 0.75, 1);
      transform: scale3d(0.75, 0.75, 1);
    }

    .disabled.ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    paper-ripple {
      color: var(--paper-slider-knob-color, var(--google-blue-700));
    }
  </style>

  <div id="sliderContainer" class\$="[[_getClassNames(disabled, pin, snaps, immediateValue, min, expand, dragging, transiting, editable)]]">
    <div class="bar-container">
      <paper-progress disabled\$="[[disabled]]" id="sliderBar" aria-hidden="true" min="[[min]]" max="[[max]]" step="[[step]]" value="[[immediateValue]]" secondary-progress="[[secondaryProgress]]" on-down="_bardown" on-up="_resetKnob" on-track="_bartrack" on-tap="_barclick">
      </paper-progress>
    </div>

    <template is="dom-if" if="[[snaps]]">
      <div class="slider-markers">
        <template is="dom-repeat" items="[[markers]]">
          <div class="slider-marker"></div>
        </template>
      </div>
    </template>

    <div id="sliderKnob" class="slider-knob" on-down="_knobdown" on-up="_resetKnob" on-track="_onTrack" on-transitionend="_knobTransitionEnd">
        <div class="slider-knob-inner" value\$="[[immediateValue]]"></div>
    </div>
  </div>

  <template is="dom-if" if="[[editable]]">
    <paper-input id="input" type="number" step="[[step]]" min="[[min]]" max="[[max]]" class="slider-input" disabled\$="[[disabled]]" value="[[immediateValue]]" on-change="_changeValue" on-keydown="_inputKeyDown" no-label-float>
    </paper-input>
  </template>
`;

template$9.setAttribute("strip-whitespace", ""), Polymer({
    _template: template$9,
    is: "paper-slider",
    behaviors: [ IronA11yKeysBehavior, IronFormElementBehavior, PaperInkyFocusBehavior, IronRangeBehavior ],
    properties: {
        value: {
            type: Number,
            value: 0
        },
        snaps: {
            type: Boolean,
            value: !1,
            notify: !0
        },
        pin: {
            type: Boolean,
            value: !1,
            notify: !0
        },
        secondaryProgress: {
            type: Number,
            value: 0,
            notify: !0,
            observer: "_secondaryProgressChanged"
        },
        editable: {
            type: Boolean,
            value: !1
        },
        immediateValue: {
            type: Number,
            value: 0,
            readOnly: !0,
            notify: !0
        },
        maxMarkers: {
            type: Number,
            value: 0,
            notify: !0
        },
        expand: {
            type: Boolean,
            value: !1,
            readOnly: !0
        },
        ignoreBarTouch: {
            type: Boolean,
            value: !1
        },
        dragging: {
            type: Boolean,
            value: !1,
            readOnly: !0,
            notify: !0
        },
        transiting: {
            type: Boolean,
            value: !1,
            readOnly: !0
        },
        markers: {
            type: Array,
            readOnly: !0,
            value: function() {
                return [];
            }
        }
    },
    observers: [ "_updateKnob(value, min, max, snaps, step)", "_valueChanged(value)", "_immediateValueChanged(immediateValue)", "_updateMarkers(maxMarkers, min, max, snaps)" ],
    hostAttributes: {
        role: "slider",
        tabindex: 0
    },
    keyBindings: {
        left: "_leftKey",
        right: "_rightKey",
        "down pagedown home": "_decrementKey",
        "up pageup end": "_incrementKey"
    },
    ready: function() {
        this.ignoreBarTouch && setTouchAction(this.$.sliderBar, "auto");
    },
    increment: function() {
        this.value = this._clampValue(this.value + this.step);
    },
    decrement: function() {
        this.value = this._clampValue(this.value - this.step);
    },
    _updateKnob: function(e, t, i, o, n) {
        this.setAttribute("aria-valuemin", t), this.setAttribute("aria-valuemax", i), this.setAttribute("aria-valuenow", e), 
        this._positionKnob(100 * this._calcRatio(e));
    },
    _valueChanged: function() {
        this.fire("value-change", {
            composed: !0
        });
    },
    _immediateValueChanged: function() {
        this.dragging ? this.fire("immediate-value-change", {
            composed: !0
        }) : this.value = this.immediateValue;
    },
    _secondaryProgressChanged: function() {
        this.secondaryProgress = this._clampValue(this.secondaryProgress);
    },
    _expandKnob: function() {
        this._setExpand(!0);
    },
    _resetKnob: function() {
        this.cancelDebouncer("expandKnob"), this._setExpand(!1);
    },
    _positionKnob: function(e) {
        this._setImmediateValue(this._calcStep(this._calcKnobPosition(e))), this._setRatio(100 * this._calcRatio(this.immediateValue)), 
        this.$.sliderKnob.style.left = this.ratio + "%", this.dragging && (this._knobstartx = this.ratio * this._w / 100, 
        this.translate3d(0, 0, 0, this.$.sliderKnob));
    },
    _calcKnobPosition: function(e) {
        return (this.max - this.min) * e / 100 + this.min;
    },
    _onTrack: function(e) {
        switch (e.stopPropagation(), e.detail.state) {
          case "start":
            this._trackStart(e);
            break;

          case "track":
            this._trackX(e);
            break;

          case "end":
            this._trackEnd();
        }
    },
    _trackStart: function(e) {
        this._setTransiting(!1), this._w = this.$.sliderBar.offsetWidth, this._x = this.ratio * this._w / 100, 
        this._startx = this._x, this._knobstartx = this._startx, this._minx = -this._startx, 
        this._maxx = this._w - this._startx, this.$.sliderKnob.classList.add("dragging"), 
        this._setDragging(!0);
    },
    _trackX: function(e) {
        this.dragging || this._trackStart(e);
        var t = this._isRTL ? -1 : 1, i = Math.min(this._maxx, Math.max(this._minx, e.detail.dx * t));
        this._x = this._startx + i;
        var o = this._calcStep(this._calcKnobPosition(this._x / this._w * 100));
        this._setImmediateValue(o);
        var n = this._calcRatio(this.immediateValue) * this._w - this._knobstartx;
        this.translate3d(n + "px", 0, 0, this.$.sliderKnob);
    },
    _trackEnd: function() {
        var e = this.$.sliderKnob.style;
        this.$.sliderKnob.classList.remove("dragging"), this._setDragging(!1), this._resetKnob(), 
        this.value = this.immediateValue, e.transform = e.webkitTransform = "", this.fire("change", {
            composed: !0
        });
    },
    _knobdown: function(e) {
        this._expandKnob(), e.preventDefault(), this.focus();
    },
    _bartrack: function(e) {
        this._allowBarEvent(e) && this._onTrack(e);
    },
    _barclick: function(e) {
        this._w = this.$.sliderBar.offsetWidth;
        var t = this.$.sliderBar.getBoundingClientRect(), i = (e.detail.x - t.left) / this._w * 100;
        this._isRTL && (i = 100 - i);
        var o = this.ratio;
        this._setTransiting(!0), this._positionKnob(i), o === this.ratio && this._setTransiting(!1), 
        this.async(function() {
            this.fire("change", {
                composed: !0
            });
        }), e.preventDefault(), this.focus();
    },
    _bardown: function(e) {
        this._allowBarEvent(e) && (this.debounce("expandKnob", this._expandKnob, 60), this._barclick(e));
    },
    _knobTransitionEnd: function(e) {
        e.target === this.$.sliderKnob && this._setTransiting(!1);
    },
    _updateMarkers: function(e, t, i, o) {
        o || this._setMarkers([]);
        var n = Math.round((i - t) / this.step);
        n > e && (n = e), (n < 0 || !isFinite(n)) && (n = 0), this._setMarkers(new Array(n));
    },
    _mergeClasses: function(e) {
        return Object.keys(e).filter(function(t) {
            return e[t];
        }).join(" ");
    },
    _getClassNames: function() {
        return this._mergeClasses({
            disabled: this.disabled,
            pin: this.pin,
            snaps: this.snaps,
            ring: this.immediateValue <= this.min,
            expand: this.expand,
            dragging: this.dragging,
            transiting: this.transiting,
            editable: this.editable
        });
    },
    _allowBarEvent: function(e) {
        return !this.ignoreBarTouch || e.detail.sourceEvent instanceof MouseEvent;
    },
    get _isRTL() {
        return void 0 === this.__isRTL && (this.__isRTL = "rtl" === window.getComputedStyle(this).direction), 
        this.__isRTL;
    },
    _leftKey: function(e) {
        this._isRTL ? this._incrementKey(e) : this._decrementKey(e);
    },
    _rightKey: function(e) {
        this._isRTL ? this._decrementKey(e) : this._incrementKey(e);
    },
    _incrementKey: function(e) {
        this.disabled || ("end" === e.detail.key ? this.value = this.max : this.increment(), 
        this.fire("change"), e.preventDefault());
    },
    _decrementKey: function(e) {
        this.disabled || ("home" === e.detail.key ? this.value = this.min : this.decrement(), 
        this.fire("change"), e.preventDefault());
    },
    _changeValue: function(e) {
        this.value = e.target.value, this.fire("change", {
            composed: !0
        });
    },
    _inputKeyDown: function(e) {
        e.stopPropagation();
    },
    _createRipple: function() {
        return this._rippleContainer = this.$.sliderKnob, PaperInkyFocusBehaviorImpl._createRipple.call(this);
    },
    _focusedChanged: function(e) {
        e && this.ensureRipple(), this.hasRipple() && (this._ripple.style.display = e ? "" : "none", 
        this._ripple.holdDown = e);
    }
});

var __decorate$c = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let SettingSliderElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.value = {
            base: 10,
            display: 10,
            unit: 0
        }, this.label = "", this.unit = {
            name: "unknown",
            min: 0,
            max: 1e3,
            step: 1,
            mult: 1
        }, this.unitIdx = 1, this.units = [];
    }
    ready() {
        super.ready(), setTimeout(() => {
            this.list.selected = this.value.unit;
        }, 0);
    }
    onUnitMenuSelected(e) {
        const t = this.template.modelForElement(e.target);
        if (t) {
            const e = t.get("unit"), i = `${this.name}: ${JSON.stringify(e)}`;
            event(EVENT.SLIDER_UNITS, i);
        }
    }
    onSliderValueChanged() {
        this._setBase();
        const e = `${this.name}: ${JSON.stringify(this.value)}`;
        event(EVENT.SLIDER_VALUE, e);
    }
    unitIdxChanged(e) {
        void 0 !== e && (this.set("value.unit", e), this._setBase(), void 0 !== this.units && this.set("unit", this.units[e]));
    }
    _valueChanged(e, t) {
        void 0 !== e && void 0 !== t && e.unit !== t.unit && (this.list.selected = e.unit);
    }
    _setBase() {
        const e = this.units[this.unitIdx], t = e.mult;
        let i = this.value.display;
        i = Math.max(i, e.min), i = Math.min(i, e.max), this.set("value.base", t * i);
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  #label {
    margin: 20px 0 0 0;
    --paper-item-min-height: {
      min-height: 0;
    };
  }

  :host paper-slider {
    position: relative;
    margin: 0;
    padding-right: 16px;
    padding-left: 5px;
    cursor: pointer;
  }

  :host > paper-item {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  :host paper-dropdown-menu {
    width: 175px;
    padding-right: 16px;
    --paper-input-container-input: {
      text-align: right;
    };
  }

</style>

<paper-item id="label" class="setting-label" tabindex="-1">
  [[label]]
</paper-item>
<div class="horizontal layout">
  <paper-slider class="flex" id="slider" editable="" value="{{value.display}}"
                min="{{unit.min}}" max="{{unit.max}}" step="{{unit.step}}" disabled$="[[disabled]]"></paper-slider>
  <paper-dropdown-menu disabled$="[[disabled]]" noink="" no-label-float="">
    <paper-listbox id="list" slot="dropdown-content" selected="{{unitIdx}}">
      <template id="t" is="dom-repeat" as="unit" items="[[units]]">
        <paper-item>[[unit.name]]</paper-item>
      </template>
    </paper-listbox>
  </paper-dropdown-menu>
</div>

<app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
</app-localstorage-document>
`;
    }
};

__decorate$c([ property({
    type: Object,
    notify: !0,
    observer: "_valueChanged"
}) ], SettingSliderElement.prototype, "value", void 0), __decorate$c([ property({
    type: String
}) ], SettingSliderElement.prototype, "label", void 0), __decorate$c([ property({
    type: Object,
    notify: !0
}) ], SettingSliderElement.prototype, "unit", void 0), __decorate$c([ property({
    type: Number,
    notify: !0
}) ], SettingSliderElement.prototype, "unitIdx", void 0), __decorate$c([ property({
    type: Array
}) ], SettingSliderElement.prototype, "units", void 0), __decorate$c([ query("#list") ], SettingSliderElement.prototype, "list", void 0), 
__decorate$c([ query("#t") ], SettingSliderElement.prototype, "template", void 0), 
__decorate$c([ listen("tap", "list") ], SettingSliderElement.prototype, "onUnitMenuSelected", null), 
__decorate$c([ listen("change", "slider") ], SettingSliderElement.prototype, "onSliderValueChanged", null), 
__decorate$c([ observe("unitIdx") ], SettingSliderElement.prototype, "unitIdxChanged", null), 
SettingSliderElement = __decorate$c([ customElement("setting-slider") ], SettingSliderElement);

var settingSlider = {
    get SettingSliderElement() {
        return SettingSliderElement;
    }
}, __decorate$d = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SettingTimeElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.value = "00:00", this.mainLabel = "", this.secondaryLabel = "";
    }
    static get mainContent() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host iron-label {
    display: block;
    position: relative;
    cursor: pointer;
  }

  :host([indent]) paper-item {
    padding-left: 24px;
  }
</style>

<paper-item class="center horizontal layout" tabindex="-1">
  <paper-item-body class="flex" two-line="">
    <div class="setting-label" hidden$="[[!mainLabel]]">
      [[mainLabel]]
    </div>
    <div class="setting-label" secondary="" hidden$="[[!secondaryLabel]]">
      [[secondaryLabel]]
    </div>
  </paper-item-body>
  <paper-input type="time" min="0:00" max="24:00" required
               class="setting-label" tabindex="-1" value={{value}} disabled$="[[disabled]]"></paper-input>
</paper-item>
<hr hidden$="[[noseparator]]">

<app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$d([ property({
    type: String,
    notify: !0
}) ], SettingTimeElement.prototype, "value", void 0), __decorate$d([ property({
    type: String
}) ], SettingTimeElement.prototype, "mainLabel", void 0), __decorate$d([ property({
    type: String
}) ], SettingTimeElement.prototype, "secondaryLabel", void 0), SettingTimeElement = __decorate$d([ customElement("setting-time") ], SettingTimeElement);

var SettingsPageElement_1, settingTime = {
    get SettingTimeElement() {
        return SettingTimeElement;
    }
}, __decorate$e = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let SettingsPageElement = SettingsPageElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.selectedTab = 0, this.enabled = !0, this.showTimeValue = 1, 
        this.showWeatherValue = !1, this.panAndScanValue = !1, this.weatherTempUnitValue = 0, 
        this.waitTimeUnits = [ SettingsPageElement_1.getUnit("minutes", 1, 60, 1, 1), SettingsPageElement_1.getUnit("hours", 1, 24, 1, 60), SettingsPageElement_1.getUnit("days", 1, 365, 1, 1440) ], 
        this.transitionTimeUnits = [ SettingsPageElement_1.getUnit("seconds", 10, 60, 1, 1), SettingsPageElement_1.getUnit("minutes", 1, 60, 1, 60), SettingsPageElement_1.getUnit("hours", 1, 24, 1, 3600), SettingsPageElement_1.getUnit("days", 1, 365, 1, 86400) ], 
        this.photoSizingMenu = [ localize("menu_letterbox"), localize("menu_zoom"), localize("menu_frame"), localize("menu_full"), localize("menu_random") ], 
        this.photoTransmissionMenu = [ localize("menu_scale_up"), localize("menu_fade"), localize("menu_slide_from_right"), localize("menu_slide_down"), localize("menu_spin_up"), localize("menu_slide_up"), localize("menu_slide_from_bottom"), localize("menu_slide_right"), localize("menu_random") ], 
        this.timeFormatMenu = [ localize("no"), localize("menu_12_hour"), localize("menu_24_hour") ], 
        this.tempUnitMenu = [ "°C", "°F" ];
    }
    static getUnit(e, t, i, o, n) {
        return {
            name: localize(e),
            min: t,
            max: i,
            step: o,
            mult: n
        };
    }
    get menuHidden() {
        return 2 !== this.selectedTab;
    }
    get largeTimeDisabled() {
        let e = !1;
        return this.enabled && 0 !== this.showTimeValue || (e = !0), e;
    }
    get detectFacesDisabled() {
        let e = !1;
        return this.enabled && this.panAndScanValue || (e = !0), e;
    }
    get weatherTempDisabled() {
        let e = !1;
        return this.enabled && this.showWeatherValue || (e = !0), e;
    }
    deselectPhotoSource(e) {
        this.setPhotoSourceChecked(e, !1);
    }
    onEnabledChanged() {
        const e = this.settingsToggle.checked;
        event(EVENT.TOGGLE, `screensaverEnabled: ${e}`);
    }
    onHelpTapped() {
        event(EVENT.ICON, "settingsHelp");
        let e = "ss_controls";
        switch (this.selectedTab) {
          case 0:
            e = "ss_controls";
            break;

          case 1:
            e = "display_controls";
            break;

          case 2:
            e = "photo_sources";
        }
        const t = `${getGithubPagesPath()}help/settings.html#${e}`;
        chrome.tabs.create({
            url: t
        });
    }
    onSelectAllTapped() {
        this.setPhotoSourcesChecked(!0);
    }
    onDeselectAllTapped() {
        this.setPhotoSourcesChecked(!1);
    }
    onRestoreDefaultsTapped() {
        send(TYPE$1.RESTORE_DEFAULTS).catch(() => {});
    }
    onChromeBackgroundTapped() {
        const e = localize("err_optional_permissions"), t = getBool("allowBackground"), i = BACKGROUND, o = isAllowed(i);
        t && !o ? request(i).catch(t => {
            error$1(t.message, "SettingsPage.onChromeBackgroundTapped", e);
        }) : !t && o && remove(i).catch(() => {});
    }
    async onShowWeatherTapped() {
        const e = localize("err_optional_permissions"), t = localize("err_weather_perm"), i = WEATHER, o = "showCurrentWeather", n = TYPE.UPDATE_WEATHER_ALARM, a = getBool(o, !1);
        try {
            if (a) {
                const e = await navigator.permissions.query({
                    name: "geolocation"
                });
                if ("denied" === e.state) throw new Error(localize("err_geolocation_perm"));
                if ("prompt" === e.state) {
                    const e = shallowCopy(DEF_LOC_OPTIONS);
                    e.timeout = 6e4, await getLocation(e);
                }
                if (!await request(i)) throw new Error(t);
                await update(!0);
            } else await remove(i);
            const r = await send(n);
            if (r.errorMessage) throw new Error(r.errorMessage);
        } catch (t) {
            try {
                const e = shallowCopy(TYPE$1.STORE);
                e.key = o, e.value = !1, await send(e), await send(n), await remove(i);
            } catch (e) {}
            Options.showErrorDialog(e, t.message, "SettingsPage.onShowWeatherTapped");
        }
    }
    async onDetectFacesTapped() {
        const e = localize("err_optional_permissions"), t = localize("err_detect_faces_perm"), i = DETECT_FACES, o = "detectFaces", n = getBool(o, !1);
        try {
            if (n) {
                if (!await request(i)) throw new Error(t);
            } else await remove(i);
        } catch (t) {
            try {
                const e = shallowCopy(TYPE$1.STORE);
                e.key = o, e.value = !1, await send(e), await remove(i);
            } catch (e) {}
            Options.showErrorDialog(e, t.message, "SettingsPage.onDetectFacesTapped");
        }
    }
    setPhotoSourceChecked(e, t) {
        const i = `[name=${e}]`, o = this.shadowRoot.querySelector(i);
        o && !e.includes("useGoogle") && o.setChecked(t);
    }
    setPhotoSourcesChecked(e) {
        const t = getUseKeyValues();
        for (const i of t) this.setPhotoSourceChecked(i, e);
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  #topToolbar {
    padding: 10px 10px 10px 24px;
  }

  #onOffLabel {
    cursor: pointer;
  }

  :host app-toolbar {
    height: 100px;
  }

</style>

<paper-material elevation="1" class="page-container">
  <paper-material elevation="1">
    <app-toolbar class="page-toolbar">
      <div id="topToolbar" top-item="" class="horizontal layout flex">
        <iron-label for="settingsToggle" class="center horizontal layout flex">
          <div id="onOffLabel" class="flex">[[localize('screensaver')]]
            <span hidden$="[[!enabled]]">[[localize('on')]]</span>
            <span hidden$="[[enabled]]">[[localize('off')]]</span>
          </div>
        </iron-label>
        <paper-icon-button id="select" icon="myicons:check-box" hidden$="[[menuHidden]]"
                           disabled$="[[!enabled]]"></paper-icon-button>
        <paper-tooltip for="select" position="left" offset="0">
          [[localize('tooltip_select')]]
        </paper-tooltip>
        <paper-icon-button id="deselect" icon="myicons:check-box-outline-blank"
                           hidden$="[[menuHidden]]" disabled$="[[!enabled]]"></paper-icon-button>
        <paper-tooltip for="deselect" position="left" offset="0">
          [[localize('tooltip_deselect')]]
        </paper-tooltip>
        <paper-icon-button id="restore" icon="myicons:settings-backup-restore"
                           disabled$="[[!enabled]]"></paper-icon-button>
        <paper-tooltip for="restore" position="left" offset="0">
          [[localize('tooltip_restore')]]
        </paper-tooltip>
        <paper-icon-button id="help" icon="myicons:help"></paper-icon-button>
        <paper-tooltip for="help" position="left" offset="0">
          [[localize('help')]]
        </paper-tooltip>
        <paper-toggle-button id="settingsToggle"
                             checked="{{enabled}}"></paper-toggle-button>
        <paper-tooltip for="settingsToggle" position="left" offset="0">
          [[localize('tooltip_settings_toggle')]]
        </paper-tooltip>
      </div>

      <paper-tabs selected="{{selectedTab}}" bottom-item="" class="fit">
        <paper-tab>[[localize('tab_slideshow')]]</paper-tab>
        <paper-tab>[[localize('tab_display')]]</paper-tab>
        <paper-tab>[[localize('tab_sources')]]</paper-tab>
      </paper-tabs>

    </app-toolbar>
    <app-localstorage-document key="enabled" data="{{enabled}}" storage="window.localStorage">
    </app-localstorage-document>

  </paper-material>

  <div class="page-content">
    <iron-pages selected="{{selectedTab}}">
      <div>
        <setting-slider section-title="[[localize('settings_appearance')]]" name="idleTime"
                        label="[[localize('setting_idle_time')]]" units="[[waitTimeUnits]]"
                        disabled$="[[!enabled]]"></setting-slider>
        <setting-slider name="transitionTime"
                        label="[[localize('setting_transition_time')]]"
                        units="[[transitionTimeUnits]]" disabled$="[[!enabled]]"></setting-slider>
        <setting-dropdown name="photoTransition" label="[[localize('setting_photo_transition')]]"
                          items="[[photoTransmissionMenu]]" disabled$="[[!enabled]]"></setting-dropdown>
        <setting-dropdown name="photoSizing" label="[[localize('setting_photo_sizing')]]"
                          items="[[photoSizingMenu]]" disabled$="[[!enabled]]"></setting-dropdown>
        <setting-toggle name="panAndScan" main-label="[[localize('setting_pan_and_scan')]]"
                        secondary-label="[[localize('setting_pan_and_scan_desc')]]"
                        checked="{{panAndScanValue}}"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle id="detectFaces" name="detectFaces" main-label="[[localize('setting_detect_faces')]]"
                        secondary-label="[[localize('setting_detect_faces_desc')]]"
                        disabled$="[[detectFacesDisabled]]" indent></setting-toggle>
        <setting-background name="background" main-label="[[localize('setting_bg')]]"
                            secondary-label="[[localize('setting_bg_desc')]]"
                            disabled$="[[!enabled]]"></setting-background>
        <setting-toggle name="fullResGoogle" main-label="[[localize('setting_full_res')]]"
                        secondary-label="[[localize('setting_full_res_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle section-title="[[localize('settings_behavior')]]" id="allowBackground" name="allowBackground"
                        main-label="[[localize('setting_background')]]"
                        secondary-label="[[localize('setting_background_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="interactive" main-label="[[localize('setting_interactive')]]"
                        secondary-label="[[localize('setting_interactive_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="shuffle" main-label="[[localize('setting_shuffle')]]"
                        secondary-label="[[localize('setting_shuffle_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="skip" main-label="[[localize('setting_skip')]]"
                        secondary-label="[[localize('setting_skip_desc')]]" disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="allowPhotoClicks" main-label="[[localize('setting_photo_clicks')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle section-title="[[localize('settings_extras')]]" name="showPhotog"
                        main-label="[[localize('setting_photog')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
<!--        <setting-toggle name="showLocation" main-label="[[localize('setting_location')]]"-->
<!--                        secondary-label="[[localize('setting_location_desc')]]"-->
<!--                        disabled$="[[!enabled]]"></setting-toggle>-->
        <setting-toggle id="showWeather" name="showCurrentWeather" main-label="[[localize('setting_weather')]]"
                        secondary-label="[[localize('setting_weather_desc')]]"
                        checked="{{showWeatherValue}}"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-dropdown name="weatherTempUnit" label="[[localize('setting_temp_unit')]]"
                          items="[[tempUnitMenu]]" value="[[weatherTempUnitValue]]"
                          disabled$="[[weatherTempDisabled]]"
                          indent=""></setting-dropdown>
        <setting-dropdown name="showTime" label="[[localize('setting_show_time')]]" items="[[timeFormatMenu]]"
                          value="{{showTimeValue}}" disabled$="[[!enabled]]"></setting-dropdown>
        <setting-toggle name="largeTime" main-label="[[localize('setting_large_time')]]" indent=""
                        disabled$="[[largeTimeDisabled]]" noseparator="">
        </setting-toggle>
      </div>
      <div>
        <setting-toggle name="allDisplays" main-label="[[localize('setting_all_displays')]]"
                        secondary-label="[[localize('setting_all_displays_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="chromeFullscreen" main-label="[[localize('setting_full_screen')]]"
                        secondary-label="[[localize('setting_full_screen_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle id="keepAwake" name="keepAwake" main-label="[[localize('setting_keep_awake')]]"
                        secondary-label="[[localize('setting_keep_awake_desc')]]"
                        checked="{{keepEnabled}}"></setting-toggle>
        <paper-tooltip for="keepAwake" position="top" offset="0">
          [[localize('tooltip_keep_awake')]]
        </paper-tooltip>
        <setting-time name="activeStart" main-label="[[localize('setting_start_time')]]"
                      secondary-label="[[localize('setting_start_time_desc')]]" format="[[showTimeValue]]" indent=""
                      disabled$="[[!keepEnabled]]"></setting-time>
        <setting-time name="activeStop" main-label="[[localize('setting_stop_time')]]"
                      secondary-label="[[localize('setting_stop_time_desc')]]" format="[[showTimeValue]]" indent=""
                      disabled$="[[!keepEnabled]]"></setting-time>
        <setting-toggle id="allowSuspend" name="allowSuspend" main-label="[[localize('setting_suspend')]]"
                        secondary-label="[[localize('setting_suspend_desc')]]" indent="" noseparator=""
                        disabled$="[[!keepEnabled]]"></setting-toggle>
      </div>
      <div>
        <setting-toggle name="useChromecast" main-label="[[localize('setting_chromecast')]]"
                        secondary-label="[[localize('setting_chromecast_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="useInterestingFlickr" main-label="[[localize('setting_flickr_int')]]"
                        secondary-label="[[localize('setting_flickr_int_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="useSpaceReddit" main-label="[[localize('setting_reddit_space')]]"
                        secondary-label="[[localize('setting_reddit_space_desc')]]" noseparator=""
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="useEarthReddit" main-label="[[localize('setting_reddit_earth')]]"
                        secondary-label="[[localize('setting_reddit_earth_desc')]]" noseparator=""
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="useAnimalReddit" main-label="[[localize('setting_reddit_animal')]]"
                        secondary-label="[[localize('setting_reddit_animal_desc')]]"
                        disabled$="[[!enabled]]"></setting-toggle>
        <setting-toggle name="useAuthors" main-label="[[localize('setting_mine')]]"
                        secondary-label="[[localize('setting_mine_desc')]]" disabled$="[[!enabled]]"></setting-toggle>
        <paper-item tabindex="-1">
          [[localize('setting_flickr_api')]]
        </paper-item>
      </div>
    </iron-pages>
  </div>
</paper-material>
`;
    }
};

__decorate$e([ property({
    type: Number,
    notify: !0
}) ], SettingsPageElement.prototype, "selectedTab", void 0), __decorate$e([ property({
    type: Boolean,
    notify: !0
}) ], SettingsPageElement.prototype, "enabled", void 0), __decorate$e([ property({
    type: Number,
    notify: !0
}) ], SettingsPageElement.prototype, "showTimeValue", void 0), __decorate$e([ property({
    type: Boolean,
    notify: !0
}) ], SettingsPageElement.prototype, "showWeatherValue", void 0), __decorate$e([ property({
    type: Boolean,
    notify: !0
}) ], SettingsPageElement.prototype, "panAndScanValue", void 0), __decorate$e([ property({
    type: Number,
    notify: !0
}) ], SettingsPageElement.prototype, "weatherTempUnitValue", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "waitTimeUnits", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "transitionTimeUnits", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "photoSizingMenu", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "photoTransmissionMenu", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "timeFormatMenu", void 0), __decorate$e([ property({
    type: Array
}) ], SettingsPageElement.prototype, "tempUnitMenu", void 0), __decorate$e([ computed("selectedTab") ], SettingsPageElement.prototype, "menuHidden", null), 
__decorate$e([ computed("enabled", "showTimeValue") ], SettingsPageElement.prototype, "largeTimeDisabled", null), 
__decorate$e([ computed("enabled", "panAndScanValue") ], SettingsPageElement.prototype, "detectFacesDisabled", null), 
__decorate$e([ computed("enabled", "showWeatherValue") ], SettingsPageElement.prototype, "weatherTempDisabled", null), 
__decorate$e([ query("#settingsToggle") ], SettingsPageElement.prototype, "settingsToggle", void 0), 
__decorate$e([ listen("change", "settingsToggle") ], SettingsPageElement.prototype, "onEnabledChanged", null), 
__decorate$e([ listen("tap", "help") ], SettingsPageElement.prototype, "onHelpTapped", null), 
__decorate$e([ listen("tap", "select") ], SettingsPageElement.prototype, "onSelectAllTapped", null), 
__decorate$e([ listen("tap", "deselect") ], SettingsPageElement.prototype, "onDeselectAllTapped", null), 
__decorate$e([ listen("tap", "restore") ], SettingsPageElement.prototype, "onRestoreDefaultsTapped", null), 
__decorate$e([ listen("tap", "allowBackground") ], SettingsPageElement.prototype, "onChromeBackgroundTapped", null), 
__decorate$e([ listen("tap", "showWeather") ], SettingsPageElement.prototype, "onShowWeatherTapped", null), 
__decorate$e([ listen("tap", "detectFaces") ], SettingsPageElement.prototype, "onDetectFacesTapped", null), 
SettingsPageElement = SettingsPageElement_1 = __decorate$e([ customElement("settings-page") ], SettingsPageElement);

var settingsPage = {
    get SettingsPageElement() {
        return SettingsPageElement;
    }
}, __decorate$f = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let ConfirmDialogElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.confirmLabel = localize("ok", "OK");
    }
    onConfirmTapped() {
        event(EVENT.BUTTON, "ConfirmDialog.onConfirmTapped");
        const e = new CustomEvent("confirm-tap", {
            bubbles: !0,
            composed: !0
        });
        this.dispatchEvent(e);
    }
    open(e = "Continue?", t = "This operation cannot be undone", i = "") {
        isWhiteSpace(i) || this.set("confirmLabel", i), e = e.replace(/\n/g, "<br/>"), this.$.dialogTitle.innerHTML = t, 
        this.$.dialogText.innerHTML = e, this.dialog.open();
    }
    close() {
        this.dialog.close();
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  .dialog {
    min-width: 25vw;
    max-width: 75vw;
  }
</style>

<paper-dialog id="dialog" class="dialog" modal entry-animation="scale-up-animation" exit-animation="fade-out-animation">
  <h2 id="dialogTitle" class="vertical layout center"></h2>
  <paper-dialog-scrollable>
    <paper-item id="dialogText" class="text"></paper-item>
  </paper-dialog-scrollable>
  <div class="buttons">
    <paper-button dialog-dismiss="" autofocus="">[[localize('cancel', 'CANCEL')]]</paper-button>
    <paper-button id="confirmButton" dialog-confirm="">[[confirmLabel]]</paper-button>
  </div>
</paper-dialog>
`;
    }
};

__decorate$f([ property({
    type: String
}) ], ConfirmDialogElement.prototype, "confirmLabel", void 0), __decorate$f([ query("#dialog") ], ConfirmDialogElement.prototype, "dialog", void 0), 
__decorate$f([ listen("click", "confirmButton") ], ConfirmDialogElement.prototype, "onConfirmTapped", null), 
ConfirmDialogElement = __decorate$f([ customElement("confirm-dialog") ], ConfirmDialogElement);

var confirmDialog = {
    get ConfirmDialogElement() {
        return ConfirmDialogElement;
    }
}, __decorate$g = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let ErrorDialogElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.showConfirmButton = !1;
    }
    onConfirmTapped() {
        const e = new CustomEvent("confirm-tap", {
            bubbles: !0,
            composed: !0
        });
        this.dispatchEvent(e);
    }
    open(e, t) {
        e = e || "Unknown", t = (t = t || "Unknown").replace(/\n/g, "<br/>"), this.$.dialogTitle.innerHTML = e, 
        this.$.dialogText.innerHTML = t, this.dialog.open();
    }
    close() {
        this.dialog.close();
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  .dialog {
    min-width: 25vw;
    max-width: 75vw;
  }
</style>

<paper-dialog id="dialog" class="dialog" modal entry-animation="scale-up-animation" exit-animation="fade-out-animation">
  <h2 id="dialogTitle" class="vertical layout center"></h2>
  <paper-dialog-scrollable>
    <paper-item id="dialogText" class="text"></paper-item>
  </paper-dialog-scrollable>
  <div class="buttons">
    <paper-button dialog-dismiss="" autofocus="">[[localize('close', 'CLOSE')]]</paper-button>
    <paper-button id="confirmButton" dialog-confirm="" hidden$="[[!showConfirmButton]]">
      [[localize('ok', 'OK')]]
    </paper-button>
  </div>
</paper-dialog>
`;
    }
};

__decorate$g([ property({
    type: Boolean,
    notify: !0
}) ], ErrorDialogElement.prototype, "showConfirmButton", void 0), __decorate$g([ query("#dialog") ], ErrorDialogElement.prototype, "dialog", void 0), 
__decorate$g([ listen("click", "confirmButton") ], ErrorDialogElement.prototype, "onConfirmTapped", null), 
ErrorDialogElement = __decorate$g([ customElement("error-dialog") ], ErrorDialogElement);

var AppMainElement_1, errorDialog = {
    get ErrorDialogElement() {
        return ErrorDialogElement;
    }
}, __decorate$h = function(e, t, i, o) {
    var n, a = arguments.length, r = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (r = (a < 3 ? n(r) : a > 3 ? n(t, i, r) : n(t, i)) || r);
    return a > 3 && r && Object.defineProperty(t, i, r), r;
};

let AppMainElement = AppMainElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.pages = [ {
            label: localize("menu_settings"),
            route: "page-settings",
            icon: "myicons:settings",
            fn: null,
            url: null,
            ready: !0,
            disabled: !1,
            divider: !1
        }, {
            label: localize("menu_preview"),
            route: "page-preview",
            icon: "myicons:pageview",
            fn: this.showScreensaverPreview.bind(this),
            url: null,
            ready: !0,
            disabled: !1,
            divider: !1
        }, {
            label: localize("menu_google"),
            route: "page-google-photos",
            icon: "myicons:cloud",
            fn: this.showGooglePhotosPage.bind(this),
            url: null,
            ready: !1,
            divider: !0,
            disabled: !1
        }, {
            label: localize("menu_permission"),
            route: "page-permission",
            icon: "myicons:perm-data-setting",
            fn: this.showPermissionsDialog.bind(this),
            url: null,
            ready: !0,
            divider: !1,
            disabled: !1
        }, {
            label: localize("menu_error"),
            route: "page-error",
            icon: "myicons:error",
            fn: this.showErrorPage.bind(this),
            url: null,
            ready: !1,
            disabled: !1,
            divider: !0
        }, {
            label: localize("menu_help"),
            route: "page-help",
            icon: "myicons:help",
            fn: this.showHelpPage.bind(this),
            url: null,
            ready: !1,
            divider: !1,
            disabled: !1
        }, {
            label: localize("help_faq"),
            route: "page-faq",
            icon: "myicons:help",
            fn: null,
            url: "https://opus1269.github.io/screensaver/faq.html",
            ready: !0,
            divider: !1,
            disabled: !1
        }, {
            label: localize("menu_support"),
            route: "page-support",
            icon: "myicons:help",
            fn: null,
            url: `${AppMainElement_1.EXT_URI}support`,
            ready: !0,
            divider: !1,
            disabled: !1
        }, {
            label: localize("menu_rate"),
            route: "page-rate",
            icon: "myicons:grade",
            fn: null,
            url: `${AppMainElement_1.EXT_URI}reviews`,
            ready: !0,
            divider: !1,
            disabled: !1
        }, {
            label: localize("menu_pushy"),
            route: "page-pushy",
            icon: "myicons:extension",
            fn: null,
            url: AppMainElement_1.PUSHY_URI,
            ready: !0,
            divider: !0,
            disabled: !1
        } ], this.route = "page-settings", this.permission = "notSet";
    }
    get permissionStatus() {
        return `${localize("permission_status")} ${localize(this.permission)}`;
    }
    connectedCallback() {
        super.connectedCallback(), addListener(this.onChromeMessage.bind(this)), chrome.storage.onChanged.addListener(this.chromeStorageChanged.bind(this)), 
        window.addEventListener("storage", this.localStorageChanged.bind(this));
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListener(this.onChromeMessage.bind(this)), chrome.storage.onChanged.removeListener(this.chromeStorageChanged.bind(this)), 
        window.removeEventListener("storage", this.localStorageChanged.bind(this));
    }
    ready() {
        super.ready(), initialize(), page("/options.html"), setTimeout(async () => {
            await this.setErrorMenuState(), this.setGooglePhotosMenuState();
        }, 0);
    }
    showErrorDialog(e, t, i) {
        i && error$1(t, i, e), this.errorDialog.open(e, t);
    }
    showStorageErrorDialog(e) {
        const t = localize("err_storage_title"), i = localize("err_storage_desc");
        error$1(i, e, t), this.errorDialog.open(t, i);
    }
    showConfirmDialog(e, t, i, o) {
        this.confirmFn = o, this.confirmDialog.open(e, t, i);
    }
    onConfirmDialogTapped() {
        this.confirmFn && this.confirmFn();
    }
    async onAcceptPermissionsClicked() {
        event(EVENT.BUTTON, "Permission.Allow");
        try {
            await request(GOOGLE_PHOTOS) || await removeGooglePhotos();
        } catch (e) {
            error$1(e.message, "AppMain._onAcceptPermissionsClicked");
        }
    }
    async onDenyPermissionsClicked() {
        event(EVENT.BUTTON, "Permission.Deny");
        try {
            await removeGooglePhotos();
        } catch (e) {
            error$1(e.message, "AppMain._onDenyPermissionsClicked");
        }
    }
    localStorageChanged(e) {
        "permPicasa" === e.key && this.setGooglePhotosMenuState();
    }
    chromeStorageChanged(e) {
        for (const t of Object.keys(e)) if ("lastError" === t) {
            this.setErrorMenuState().catch(() => {});
            break;
        }
    }
    onNavMenuItemTapped(e) {
        const t = this.appDrawerLayout, i = this.appDrawer;
        i && t && t.narrow && i.close();
        const o = this.route, n = this.getPageIdx(e.currentTarget.id), a = this.pages[n];
        event(EVENT.MENU, a.route), a.url ? (this.mainMenu.select(o), chrome.tabs.create({
            url: a.url
        })) : a.fn ? a.fn(n, o) : this.set("route", a.route);
    }
    showGooglePhotosPage(e, t) {
        if (getBool("signedInToChrome", !0)) this.pages[e].ready ? getBool("isAlbumMode", !0) && this.gPhotosPage && this.gPhotosPage.loadAlbumList().catch(() => {}) : (this.pages[e].ready = !0, 
        this.gPhotosPage = new GooglePhotosPageElement(), this.googlePhotosInsertion.appendChild(this.gPhotosPage)), 
        this.set("route", this.pages[e].route); else {
            const e = localize("err_chrome_signin_title"), t = localize("err_chrome_signin");
            this.errorDialog.open(e, t);
        }
    }
    showErrorPage(e, t) {
        if (!this.pages[e].ready) {
            this.pages[e].ready = !0;
            const t = new ErrorPageElement();
            this.errorInsertion.appendChild(t);
        }
        this.set("route", this.pages[e].route);
    }
    showHelpPage(e, t) {
        if (!this.pages[e].ready) {
            this.pages[e].ready = !0;
            const t = new HelpPageElement();
            this.helpInsertion.appendChild(t);
        }
        this.set("route", this.pages[e].route);
    }
    showScreensaverPreview(e, t) {
        setTimeout(() => this.mainMenu.select(t), 500), send(TYPE.SS_SHOW).catch(() => {});
    }
    showPermissionsDialog() {
        this.permissionsDialog.open();
    }
    setGooglePhotosMenuState() {
        const e = this.getPageIdx("page-google-photos"), t = this.shadowRoot.querySelector(`#${this.pages[e].route}`);
        t ? "allowed" !== this.permission ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled") : error("no element found", "AppMain.setGooglePhotosMenuState");
    }
    async setErrorMenuState() {
        try {
            const e = await ChromeLastError.load(), t = this.getPageIdx("page-error"), i = this.pages[t].route, o = this.shadowRoot.querySelector(`#${i}`);
            o && !isWhiteSpace(e.message) ? o.removeAttribute("disabled") : o && o.setAttribute("disabled", "true");
        } catch (e) {
            error(e.message, "AppMain.setErrorMenuState");
        }
    }
    onChromeMessage(e, t, i) {
        let o = !1;
        if (e.message === TYPE$1.HIGHLIGHT.message) {
            o = !0, new ChromePromise().tabs.getCurrent().then(e => {
                e && e.id && chrome.tabs.update(e.id, {
                    highlighted: !0
                }), i({
                    message: "OK"
                });
            }).catch(e => {
                error$1(e.message, "chromep.tabs.getCurrent");
            });
        } else if (e.message === TYPE$1.STORAGE_EXCEEDED.message) {
            const e = localize("err_storage_title"), t = localize("err_storage_desc");
            this.errorDialog.open(e, t);
        } else if (e.message === TYPE.PHOTO_SOURCE_FAILED.message) {
            e.key && this.settingsPage.deselectPhotoSource(e.key);
            const t = localize("err_photo_source_title"), i = e.error || "";
            this.errorDialog.open(t, i);
        }
        return o;
    }
    getPageIdx(e) {
        return this.pages.map(e => e.route).indexOf(e);
    }
    static get template() {
        return html$2`<style include="shared-styles iron-flex iron-flex-alignment">

  :host {
    display: block;
    position: relative;
  }

  .main-toolbar {
    color: var(--text-primary-color);
    background-color: var(--dark-primary-color);
    /*noinspection CssUnresolvedCustomPropertySet*/
    @apply --paper-font-headline;
  }

  .menu-name {
    /*noinspection CssUnresolvedCustomPropertySet*/
    @apply --paper-font-title;
    color: var(--dark-primary-color);
    background-color: var(--drawer-menu-color);
    border-bottom: var(--drawer-toolbar-border-color);
  }

  #mainPages neon-animatable {
    padding: 0 0;
  }

  /* Height of the main scroll area */
  #mainContainer {
    height: 100%;
    padding: 0 0;
  }

  .permText {
    padding-bottom: 16px;
  }

  .status {
    padding-top: 8px;
    /*noinspection CssUnresolvedCustomPropertySet*/
    @apply --paper-font-title;
  }


</style>

<!-- Error dialog keep above app-drawer-layout because of overlay bug -->
<error-dialog id="errorDialog"></error-dialog>

<!-- Confirm dialog keep above app-drawer-layout because of overlay bug -->
<confirm-dialog id="confirmDialog" confirm-label="[[localize('ok')]]"></confirm-dialog>

<!-- permissions dialog keep above app-drawer-layout because of overlay bug -->
<paper-dialog id="permissionsDialog" modal entry-animation="scale-up-animation"
              exit-animation="fade-out-animation">
  <h2>[[localize('menu_permission')]]</h2>
  <paper-dialog-scrollable>
    <div>

      <paper-item class="permText">
        [[localize('permission_message')]]
      </paper-item>


      <paper-item class="permText">
        [[localize('permission_message1')]]
      </paper-item>

      <paper-item class="permText">
        [[localize('permission_message2')]]
      </paper-item>

      <paper-item class="status">
        [[permissionStatus]]
      </paper-item>

    </div>
  </paper-dialog-scrollable>
  <div class="buttons">
    <paper-button dialog-dismiss>[[localize('cancel')]]</paper-button>
    <paper-button id="permissionsDialogDenyButton" dialog-dismiss>[[localize('deny')]]</paper-button>
    <paper-button id="permissionsDialogConfirmButton" dialog-confirm autofocus>[[localize('allow')]]</paper-button>
  </div>
</paper-dialog>

<app-drawer-layout id="appDrawerLayout" responsive-width="800px">

  <!-- Drawer Content -->
  <app-drawer id="appDrawer" slot="drawer">
    <!-- For scrolling -->
    <div style="height: 100%; overflow: auto;">
      <!-- Menu Title -->
      <app-toolbar class="menu-name">
        <div>[[localize('menu')]]</div>
      </app-toolbar>

      <!-- Menu Items -->
      <paper-listbox id="mainMenu" attr-for-selected="id"
                     selected="[[route]]">
        <template is="dom-repeat" id="menuTemplate" items="[[pages]]">
          <hr hidden$="[[!item.divider]]"/>
          <paper-item id="[[item.route]]"
                      class="center horizontal layout"
                      on-click="onNavMenuItemTapped" disabled$="[[item.disabled]]">
            <iron-icon icon="[[item.icon]]"></iron-icon>
            <span class="flex">[[item.label]]</span>
          </paper-item>
        </template>
      </paper-listbox>
    </div>
  </app-drawer>

  <app-header-layout fullbleed]>

    <app-header fixed slot="header">

      <!-- App Toolbar -->
      <app-toolbar class="main-toolbar">
        <paper-icon-button icon="myicons:menu" drawer-toggle></paper-icon-button>
        <div class="app-name center horizontal layout">
          <div>[[localize('chrome_extension_name')]]</div>
        </div>
      </app-toolbar>

    </app-header>

    <!--Main Contents-->
    <div id="mainContainer">

      <!-- Options Tabbed Pages -->
      <neon-animated-pages id="mainPages"
                           attr-for-selected="data-route"
                           selected="{{route}}"
                           entry-animation="fade-in-animation"
                           exit-animation="fade-out-animation">
        <neon-animatable data-route="page-settings">
          <section>
            <settings-page id="settingsPage"></settings-page>
          </section>
        </neon-animatable>
        <neon-animatable data-route="page-google-photos">
          <section id="googlePhotosInsertion"></section>
        </neon-animatable>
        <neon-animatable data-route="page-error">
          <section id="errorInsertion"></section>
        </neon-animatable>
        <neon-animatable data-route="page-help">
          <section id="helpInsertion"></section>
        </neon-animatable>
      </neon-animated-pages>

    </div>

  </app-header-layout>

  <app-localstorage-document key="permPicasa" data="{{permission}}" storage="window.localStorage">
  </app-localstorage-document>

</app-drawer-layout>
`;
    }
};

AppMainElement.EXT_URI = `https://chrome.google.com/webstore/detail/screensaver/${chrome.runtime.id}/`, 
AppMainElement.PUSHY_URI = "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd", 
__decorate$h([ property({
    type: Array
}) ], AppMainElement.prototype, "pages", void 0), __decorate$h([ property({
    type: String,
    notify: !0
}) ], AppMainElement.prototype, "route", void 0), __decorate$h([ property({
    type: String,
    notify: !0
}) ], AppMainElement.prototype, "permission", void 0), __decorate$h([ computed("permission") ], AppMainElement.prototype, "permissionStatus", null), 
__decorate$h([ query("#mainMenu") ], AppMainElement.prototype, "mainMenu", void 0), 
__decorate$h([ query("#appDrawer") ], AppMainElement.prototype, "appDrawer", void 0), 
__decorate$h([ query("#appDrawerLayout") ], AppMainElement.prototype, "appDrawerLayout", void 0), 
__decorate$h([ query("#errorDialog") ], AppMainElement.prototype, "errorDialog", void 0), 
__decorate$h([ query("#confirmDialog") ], AppMainElement.prototype, "confirmDialog", void 0), 
__decorate$h([ query("#permissionsDialog") ], AppMainElement.prototype, "permissionsDialog", void 0), 
__decorate$h([ query("#settingsPage") ], AppMainElement.prototype, "settingsPage", void 0), 
__decorate$h([ query("#googlePhotosInsertion") ], AppMainElement.prototype, "googlePhotosInsertion", void 0), 
__decorate$h([ query("#errorInsertion") ], AppMainElement.prototype, "errorInsertion", void 0), 
__decorate$h([ query("#helpInsertion") ], AppMainElement.prototype, "helpInsertion", void 0), 
__decorate$h([ listen("confirm-tap", "confirmDialog") ], AppMainElement.prototype, "onConfirmDialogTapped", null), 
__decorate$h([ listen("click", "permissionsDialogConfirmButton") ], AppMainElement.prototype, "onAcceptPermissionsClicked", null), 
__decorate$h([ listen("click", "permissionsDialogDenyButton") ], AppMainElement.prototype, "onDenyPermissionsClicked", null), 
AppMainElement = AppMainElement_1 = __decorate$h([ customElement("app-main") ], AppMainElement);

var appMain = {
    get AppMainElement() {
        return AppMainElement;
    }
};

export { albumsView as $albumsView, appLayoutBehavior as $appLayoutBehavior, appMain as $appMain, appScrollEffectsBehavior as $appScrollEffectsBehavior, confirmDialog as $confirmDialog, errorDialog as $errorDialog, errorPage as $errorPage, googlePhotosPage as $googlePhotosPage, helpPage as $helpPage, helpers as $helpers, ironA11yAnnouncer as $ironA11yAnnouncer, ironCheckedElementBehavior as $ironCheckedElementBehavior, ironFitBehavior as $ironFitBehavior, ironFocusablesHelper as $ironFocusablesHelper, ironFormElementBehavior as $ironFormElementBehavior, ironLabel as $ironLabel, ironMenuBehavior as $ironMenuBehavior, ironMenubarBehavior as $ironMenubarBehavior, ironMeta as $ironMeta, ironMultiSelectable as $ironMultiSelectable, ironOverlayBehavior as $ironOverlayBehavior, ironOverlayManager as $ironOverlayManager, ironRangeBehavior as $ironRangeBehavior, ironScrollManager as $ironScrollManager, ironScrollTargetBehavior as $ironScrollTargetBehavior, ironValidatableBehavior as $ironValidatableBehavior, my_utils as $myUtils, options as $options, paperButtonBehavior as $paperButtonBehavior, paperCheckedElementBehavior as $paperCheckedElementBehavior, paperDialogBehavior as $paperDialogBehavior, paperInkyFocusBehavior as $paperInkyFocusBehavior, paperInputAddonBehavior as $paperInputAddonBehavior, paperInputBehavior as $paperInputBehavior, paperMenuButton as $paperMenuButton, paperRippleBehavior as $paperRippleBehavior, paperSpinnerBehavior as $paperSpinnerBehavior, photo_cat as $photoCat, photosView as $photosView, settingBackground as $settingBackground, settingBase as $settingBase, settingDropdown as $settingDropdown, settingLink as $settingLink, settingSlider as $settingSlider, settingTime as $settingTime, settingToggle as $settingToggle, settingsPage as $settingsPage, waiterElement as $waiterElement, AlbumsViewElement, AppLayoutBehavior, AppMainElement, AppScrollEffectsBehavior, ConfirmDialogElement, ErrorDialogElement, ErrorPageElement, GooglePhotosPageElement, HelpPageElement, IronA11yAnnouncer, IronCheckedElementBehavior, IronCheckedElementBehaviorImpl, IronFitBehavior, IronFocusablesHelper, IronFormElementBehavior, IronLabel, IronMenuBehavior, IronMenuBehaviorImpl, IronMenubarBehavior, IronMenubarBehaviorImpl, IronMeta, IronMultiSelectableBehavior, IronMultiSelectableBehaviorImpl, IronOverlayBehavior, IronOverlayBehaviorImpl, IronOverlayManager, IronOverlayManagerClass, IronRangeBehavior, IronScrollTargetBehavior, IronValidatableBehavior, IronValidatableBehaviorMeta, Options, PaperButtonBehavior, PaperButtonBehaviorImpl, PaperCheckedElementBehavior, PaperCheckedElementBehaviorImpl, PaperDialogBehavior, PaperDialogBehaviorImpl, PaperInkyFocusBehavior, PaperInkyFocusBehaviorImpl, PaperInputAddonBehavior, PaperInputBehavior, PaperInputBehaviorImpl, PaperInputHelper, PaperMenuButton, PaperRippleBehavior, PaperSpinnerBehavior, PhotoCatElement, PhotosViewElement, SettingBackgroundElement, SettingBase, SettingDropdownElement, SettingLinkElement, SettingSliderElement, SettingTimeElement, SettingToggleElement, SettingsPageElement, WaiterElement, _boundScrollHandler, _composedTreeContains, _getScrollInfo, _getScrollableNodes, _getScrollingNode, _hasCachedLockedElement, _hasCachedUnlockedElement, _lockScrollInteractions, _lockedElementCache, _lockingElements, _scrollEffects, _scrollInteractionHandler, _scrollTimer, _shouldPreventScrolling, _unlockScrollInteractions, _unlockedElementCache, currentLockingElement, elementIsScrollLocked, getEmail, getEmailBody, getEmailUrl, getGithubPagesPath, getGithubPath, pushScrollLock, queryAllRoot, registerEffect, removeScrollLock, scroll, scrollTimingFunction };