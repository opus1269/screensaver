import { LOAD_FILTERED_PHOTOS, LOAD_ALBUM, PHOTO_SOURCE_FAILED, SS_CLOSE, SS_IS_SHOWING, SS_SHOW, $photoSourceGoogleDefault as GoogleSource, processDaily, getSelectedSources, processAll, isUseKey, process, isSignedIn, removeCachedToken, event, EVENT, page, error, $lastErrorDefault as ChromeLastError, localize, error$1, send, HIGHLIGHT, RESTORE_DEFAULTS, STORE, listen, getBool, get, set, asyncSet, getInt, $timeDefault as ChromeTime, getVersion, getChromeVersion, isWindows, initialize, EVENT$1, DEBUG } from "./shared_bundle_3.js";

const chromep = new ChromePromise(), _DATA_VERSION = 22, _DEF_VALUES = {
    version: _DATA_VERSION,
    enabled: !0,
    permPicasa: "notSet",
    permBackground: "notSet",
    allowBackground: !1,
    idleTime: {
        base: 5,
        display: 5,
        unit: 0
    },
    transitionTime: {
        base: 30,
        display: 30,
        unit: 0
    },
    skip: !0,
    shuffle: !0,
    photoSizing: 0,
    photoTransition: 1,
    interactive: !1,
    showTime: 2,
    largeTime: !1,
    showPhotog: !0,
    showLocation: !0,
    background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
    keepAwake: !1,
    chromeFullscreen: !0,
    allDisplays: !1,
    activeStart: "00:00",
    activeStop: "00:00",
    allowSuspend: !1,
    allowPhotoClicks: !0,
    useSpaceReddit: !1,
    useEarthReddit: !1,
    useAnimalReddit: !1,
    useInterestingFlickr: !1,
    useChromecast: !0,
    useAuthors: !1,
    fullResGoogle: !1,
    isAlbumMode: !0,
    useGoogle: !0,
    useGoogleAlbums: !0,
    useGooglePhotos: !1,
    googleImages: [],
    signedInToChrome: !0,
    googlePhotosNoFilter: !0,
    googlePhotosFilter: GoogleSource.DEF_FILTER
};

async function _updateToChromeLocaleStorage() {
    const e = getSelectedSources();
    for (const t of e) {
        const e = t.getPhotosKey(), o = get(e);
        if (o) {
            if (!await asyncSet(e, o)) {
                const e = t.getDesc();
                error$1(`Failed to move source: ${e} to chrome.storage`, "AppData._updateToChromeLocaleStorage");
            }
            set(e, null);
        }
    }
}

function _processEnabled() {
    const e = getBool("enabled") ? localize("disable") : localize("enable");
    updateBadgeText(), chromep.contextMenus.update("ENABLE_MENU", {
        title: e
    }).catch(() => {});
}

function _processKeepAwake() {
    getBool("keepAwake", !0) ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
    updateRepeatingAlarms(), updateBadgeText();
}

function _processIdleTime() {
    const e = getIdleSeconds();
    e ? chrome.idle.setDetectionInterval(e) : error$1("idleTime is null", "Data._processIdleTime");
}

function _getTimeFormat() {
    let e = 2;
    const t = localize("time_format");
    return t && "12" === t && (e = 1), e;
}

function _setOS() {
    return chromep.runtime.getPlatformInfo().then(e => (set("os", e.os), null)).catch(() => (set("os", "unknown"), 
    null));
}

function _addDefaults() {
    Object.keys(_DEF_VALUES).forEach(function(e) {
        null === get(e) && set(e, _DEF_VALUES[e]);
    });
}

function _convertSliderValue(e) {
    const t = get(e);
    if (t) {
        set(e, {
            base: t,
            display: t,
            unit: 0
        });
    }
}

function initialize$1() {
    _addDefaults(), _setOS().catch(() => {}), isSignedIn().then(e => (set("signedInToChrome", e), 
    null)).catch(() => {}), ChromeLastError.reset().catch(e => {
        error(e.message, "Data.initialize");
    }), set("showTime", _getTimeFormat()), processState().catch(() => {});
}

function update() {
    let e = getInt("version");
    if ((Number.isNaN(e) || _DATA_VERSION > e) && set("version", _DATA_VERSION), !Number.isNaN(e)) {
        if (e < 8 && (_convertSliderValue("transitionTime"), _convertSliderValue("idleTime")), 
        e < 10) {
            const e = localStorage.getItem("os");
            e && set("os", e);
        }
        e < 12 && set("permPicasa", "allowed"), e < 14 && (set("permBackground", "allowed"), 
        set("allowBackground", !0)), e < 18 && (set("permPicasa", "notSet"), removeCachedToken(!1, null, null).catch(() => null), 
        set("albumSelections", []));
    }
    if (e < 19 && (set("useEditors500px", null), set("usePopular500px", null), set("useYesterday500px", null), 
    set("editors500pxImages", null), set("popular500pxImages", null), set("yesterday500pxImages", null)), 
    e < 20) {
        isSignedIn().then(e => (set("signedInToChrome", e), null)).catch(() => {});
        const e = get("transitionTime", {
            base: 30,
            display: 30,
            unit: 0
        });
        0 === e.unit && (e.base = Math.max(10, e.base), e.display = e.base, set("transitionTime", e));
    }
    e < 21 && _updateToChromeLocaleStorage().catch(() => {}), e < 22 && (set("gPhotosNeedsUpdate", null), 
    set("gPhotosMaxAlbums", null), set("isAwake", null), set("isShowing", null), set("albumSelections", null)), 
    _addDefaults(), processState().catch(() => {});
}

function restoreDefaults() {
    Object.keys(_DEF_VALUES).forEach(function(e) {
        e.includes("useGoogle") || "signedInToChrome" === e || "isAlbumMode" === e || "googlePhotosFilter" === e || "permPicasa" === e || "googleImages" === e || "albumSelections" === e || set(e, _DEF_VALUES[e]);
    }), set("showTime", _getTimeFormat()), processState().catch(() => {});
}

async function processState(e = "all", t = !1) {
    const o = {
        enabled: _processEnabled,
        keepAwake: _processKeepAwake,
        activeStart: _processKeepAwake,
        activeStop: _processKeepAwake,
        allowSuspend: _processKeepAwake,
        idleTime: _processIdleTime
    };
    if ("all" === e) Object.keys(o).forEach(function(e) {
        (0, o[e])();
    }), processAll(t), get("os") || _setOS().catch(() => {}); else if (isUseKey(e) || "fullResGoogle" === e) {
        let t = e;
        if ("fullResGoogle" === e) {
            if (getBool("useGoogleAlbums")) {
                t = "useGoogleAlbums";
                try {
                    await process(t);
                } catch (e) {
                    const o = PHOTO_SOURCE_FAILED;
                    o.key = t, o.error = e.message, send(o).catch(() => {});
                }
            }
            if (getBool("useGooglePhotos")) {
                t = "useGooglePhotos";
                try {
                    await process(t);
                } catch (e) {
                    const o = PHOTO_SOURCE_FAILED;
                    o.key = t, o.error = e.message, send(o).catch(() => {});
                }
            }
        } else if ("useGoogleAlbums" !== e && "useGooglePhotos" !== e) try {
            await process(t);
        } catch (e) {
            const o = PHOTO_SOURCE_FAILED;
            o.key = t, o.error = e.message, send(o).catch(() => {});
        }
    } else {
        const t = o[e];
        void 0 !== t && t();
    }
}

function getIdleSeconds() {
    return 60 * get("idleTime", {
        base: 5,
        display: 5,
        unit: 0
    }).base;
}

var data = {
    initialize: initialize$1,
    update: update,
    restoreDefaults: restoreDefaults,
    processState: processState,
    getIdleSeconds: getIdleSeconds
};

const chromep$1 = new ChromePromise(), _SS_URL = "/html/screensaver.html", _ERR_SHOW = localize("err_show_ss");

function isActive() {
    const e = getBool("enabled"), t = getBool("keepAwake"), o = get("activeStart"), s = get("activeStop"), n = ChromeTime.isInRange(o, s);
    return !(!e || t && !n);
}

function display(e) {
    !e && getBool("allDisplays") ? _openOnAllDisplays() : _open(null);
}

function close() {
    send(SS_CLOSE).catch(() => {});
}

function _hasFullscreen(e) {
    return getBool("chromeFullscreen") ? chromep$1.windows.getAll({
        populate: !1
    }).then(t => {
        let o = !1;
        const s = e ? e.bounds.left : 0, n = e ? e.bounds.top : 0;
        for (let a = 0; a < t.length; a++) {
            const l = t[a];
            if ("fullscreen" === l.state && (!e || l.top === n && l.left === s)) {
                o = !0;
                break;
            }
        }
        return Promise.resolve(o);
    }) : Promise.resolve(!1);
}

function _isShowing() {
    return send(SS_IS_SHOWING).then(() => Promise.resolve(!0)).catch(() => Promise.resolve(!1));
}

function _open(e) {
    const t = {
        url: _SS_URL,
        type: "popup"
    };
    _hasFullscreen(e).then(o => {
        if (o) return null;
        if (getChromeVersion() >= 44 && !e) t.state = "fullscreen"; else {
            const o = e ? e.bounds.left : 0, s = e ? e.bounds.top : 0;
            t.left = o, t.top = s, t.width = 1, t.height = 1;
        }
        return chromep$1.windows.create(t);
    }).then(e => (e && "fullscreen" !== t.state && chrome.windows.update(e.id, {
        state: "fullscreen"
    }), e)).then(e => (e && chrome.windows.update(e.id, {
        focused: !0
    }), null)).catch(e => {
        error$1(e.message, "SSControl._open", _ERR_SHOW);
    });
}

function _openOnAllDisplays() {
    chromep$1.system.display.getInfo().then(e => {
        if (1 === e.length) _open(null); else for (const t of e) _open(t);
        return null;
    }).catch(e => {
        error$1(e.message, "SSControl._openOnAllDisplays", _ERR_SHOW);
    });
}

function _onIdleStateChanged(e) {
    _isShowing().then(t => {
        if ("idle" === e) isActive() && !t && display(!1); else {
            if ("locked" !== e) return isWindows().then(e => (e || close(), null));
            close();
        }
        return null;
    }).catch(e => {
        error$1(e.message, "SSControl._isShowing", _ERR_SHOW);
    });
}

function _onChromeMessage(e, t, o) {
    return e.message === SS_SHOW.message && display(!0), !1;
}

function _onLoad() {
    chrome.idle.onStateChanged.addListener(_onIdleStateChanged), listen(_onChromeMessage);
}

window.addEventListener("load", _onLoad);

var ss_controller = {
    isActive: isActive,
    display: display,
    close: close
};

const chromep$2 = new ChromePromise(), _ALARMS = {
    ACTIVATE: "ACTIVATE",
    DEACTIVATE: "DEACTIVATE",
    UPDATE_PHOTOS: "UPDATE_PHOTOS",
    BADGE_TEXT: "BADGE_TEXT"
};

function updateRepeatingAlarms() {
    const e = getBool("keepAwake"), t = get("activeStart", "00:00"), o = get("activeStop", "00:00");
    if (e && t !== o) {
        const e = ChromeTime.getTimeDelta(t), s = ChromeTime.getTimeDelta(o);
        chrome.alarms.create(_ALARMS.ACTIVATE, {
            delayInMinutes: e,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), chrome.alarms.create(_ALARMS.DEACTIVATE, {
            delayInMinutes: s,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), ChromeTime.isInRange(t, o) || _setInactiveState();
    } else chrome.alarms.clear(_ALARMS.ACTIVATE), chrome.alarms.clear(_ALARMS.DEACTIVATE);
    chromep$2.alarms.get(_ALARMS.UPDATE_PHOTOS).then(e => (e || chrome.alarms.create(_ALARMS.UPDATE_PHOTOS, {
        when: Date.now() + ChromeTime.MSEC_IN_DAY,
        periodInMinutes: ChromeTime.MIN_IN_DAY
    }), null)).catch(e => {
        error$1(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
    });
}

function updateBadgeText() {
    chrome.alarms.create(_ALARMS.BADGE_TEXT, {
        when: Date.now() + 1e3
    });
}

function _setActiveState() {
    getBool("keepAwake") && chrome.power.requestKeepAwake("display");
    const e = getIdleSeconds();
    chromep$2.idle.queryState(e).then(e => (getBool("enabled") && "idle" === e && display(!1), 
    null)).catch(e => {
        error$1(e.message, "Alarm._setActiveState");
    }), updateBadgeText();
}

function _setInactiveState() {
    getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
    close(), updateBadgeText();
}

function _setBadgeText() {
    let e = "";
    e = getBool("enabled") ? isActive() ? "" : localize("sleep_abbrev") : getBool("keepAwake") ? localize("power_abbrev") : localize("off_abbrev"), 
    chrome.browserAction.setBadgeText({
        text: e
    });
}

function _onAlarm(e) {
    switch (e.name) {
      case _ALARMS.ACTIVATE:
        _setActiveState();
        break;

      case _ALARMS.DEACTIVATE:
        _setInactiveState();
        break;

      case _ALARMS.UPDATE_PHOTOS:
        processDaily();
        break;

      case _ALARMS.BADGE_TEXT:
        _setBadgeText();
    }
}

function _onLoad$1() {
    chrome.alarms.onAlarm.addListener(_onAlarm);
}

window.addEventListener("load", _onLoad$1);

var alarm = {
    updateRepeatingAlarms: updateRepeatingAlarms,
    updateBadgeText: updateBadgeText
};

const _DISPLAY_MENU = "DISPLAY_MENU", _ENABLE_MENU = "ENABLE_MENU";

function _toggleEnabled() {
    const e = getBool("enabled", !0);
    set("enabled", !e), processState("enabled").catch(() => {});
}

function _onInstalled(e) {
    const t = new ChromePromise();
    t.contextMenus.create({
        type: "normal",
        id: _DISPLAY_MENU,
        title: localize("display_now"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error$1(e.message, "chromep.contextMenus.create");
    }), t.contextMenus.create({
        type: "normal",
        id: _ENABLE_MENU,
        title: localize("disable"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error$1(e.message, "chromep.contextMenus.create");
    }), t.contextMenus.create({
        type: "separator",
        id: "SEP_MENU",
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || error$1(e.message, "chromep.contextMenus.create");
    });
}

function _onMenuClicked(e) {
    if (e.menuItemId === _DISPLAY_MENU) event(EVENT.MENU, `${e.menuItemId}`), display(!1); else if (e.menuItemId === _ENABLE_MENU) {
        const t = getBool("enabled");
        event(EVENT.MENU, `${e.menuItemId}: ${t}`), _toggleEnabled();
    }
}

function _onKeyCommand(e) {
    "toggle-enabled" === e ? (event(EVENT.KEY_COMMAND, `${e}`), _toggleEnabled()) : "show-screensaver" === e && (event(EVENT.KEY_COMMAND, `${e}`), 
    display(!1));
}

function _onLoad$2() {
    chrome.runtime.onInstalled.addListener(_onInstalled), chrome.contextMenus.onClicked.addListener(_onMenuClicked), 
    chrome.commands.onCommand.addListener(_onKeyCommand);
}

function _onSignInChanged(e, t) {
    if (set("signedInToChrome", t), !t) {
        event(EVENT$1.CHROME_SIGN_OUT), asyncSet("albumSelections", []).catch(() => {}), 
        asyncSet("googleImages", []).catch(() => {}), "allowed" === get("permPicasa") && error$1(localize("err_chrome_signout"), "User._onSignInChanged");
    }
}

function _onLoad$3() {
    chrome.identity.onSignInChanged.addListener(_onSignInChanged);
}

function _showOptionsTab() {
    send(HIGHLIGHT).catch(() => {
        chrome.tabs.create({
            url: "/html/options.html"
        });
    });
}

function _onInstalled$1(e) {
    if ("install" === e.reason) event(EVENT.INSTALLED, getVersion()), initialize$1(), 
    _showOptionsTab(); else if ("update" === e.reason) {
        if (!DEBUG) {
            const t = e.previousVersion;
            if (getVersion() === t) return;
            let o = !1;
            t && !t.startsWith("3") && (o = !0), o && chrome.tabs.create({
                url: "/html/update3.html"
            });
        }
        update();
    }
}

function _onStartup() {
    page("/background.html"), processState().catch(() => {});
}

function _onIconClicked() {
    _showOptionsTab();
}

function _onStorageChanged(e) {
    processState(e.key).catch(() => {});
}

function _onChromeMessage$1(e, t, o) {
    let s = !1;
    return e.message === RESTORE_DEFAULTS.message ? restoreDefaults() : e.message === STORE.message ? set(e.key, e.value) : e.message === LOAD_FILTERED_PHOTOS.message ? (s = !0, 
    GoogleSource.loadFilteredPhotos(!0, !0).then(e => (o(e), null)).catch(e => {
        o({
            message: e.message
        });
    })) : e.message === LOAD_ALBUM.message && (s = !0, GoogleSource.loadAlbum(e.id, e.name, !0, !0).then(e => (o(e), 
    null)).catch(e => {
        o({
            message: e.message
        });
    })), s;
}

function _onLoad$4() {
    initialize(), chrome.runtime.onInstalled.addListener(_onInstalled$1), chrome.runtime.onStartup.addListener(_onStartup), 
    chrome.browserAction.onClicked.addListener(_onIconClicked), addEventListener("storage", _onStorageChanged, !1), 
    listen(_onChromeMessage$1);
}

window.addEventListener("load", _onLoad$2), window.addEventListener("load", _onLoad$3), 
window.addEventListener("load", _onLoad$4);

export { alarm as $alarm, data as $data, ss_controller as $ssController, updateRepeatingAlarms, updateBadgeText, initialize$1 as initialize, update, restoreDefaults, processState, getIdleSeconds, isActive, display, close };