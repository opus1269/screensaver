import { PaperDialogBehaviorImpl, Polymer, html } from "./shared_bundle_12.js";

Polymer({
    _template: html`
    <style>

      :host {
        display: block;
        @apply --layout-relative;
      }

      :host(.is-scrolled:not(:first-child))::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      :host(.can-scroll:not(.scrolled-to-bottom):not(:last-child))::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      .scrollable {
        padding: 0 24px;

        @apply --layout-scroll;
        @apply --paper-dialog-scrollable;
      }

      .fit {
        @apply --layout-fit;
      }
    </style>

    <div id="scrollable" class="scrollable" on-scroll="updateScrollState">
      <slot></slot>
    </div>
`,
    is: "paper-dialog-scrollable",
    properties: {
        dialogElement: {
            type: Object
        }
    },
    get scrollTarget() {
        return this.$.scrollable;
    },
    ready: function() {
        this._ensureTarget(), this.classList.add("no-padding");
    },
    attached: function() {
        this._ensureTarget(), requestAnimationFrame(this.updateScrollState.bind(this));
    },
    updateScrollState: function() {
        this.toggleClass("is-scrolled", this.scrollTarget.scrollTop > 0), this.toggleClass("can-scroll", this.scrollTarget.offsetHeight < this.scrollTarget.scrollHeight), 
        this.toggleClass("scrolled-to-bottom", this.scrollTarget.scrollTop + this.scrollTarget.offsetHeight >= this.scrollTarget.scrollHeight);
    },
    _ensureTarget: function() {
        this.dialogElement = this.dialogElement || this.parentElement, this.dialogElement && this.dialogElement.behaviors && this.dialogElement.behaviors.indexOf(PaperDialogBehaviorImpl) >= 0 ? (this.dialogElement.sizingTarget = this.scrollTarget, 
        this.scrollTarget.classList.remove("fit")) : this.dialogElement && this.scrollTarget.classList.add("fit");
    }
});