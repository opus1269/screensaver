import "./shared_bundle_12.js";

function _onSignInChanged(e, o) {
    if (Chrome.Storage.set("signedInToChrome", o), !o) {
        Chrome.GA.event(app.GA.EVENT.CHROME_SIGN_OUT), Chrome.Storage.set("albumSelections", []), 
        "allowed" === Chrome.Storage.getBool("permPicasa") && Chrome.Log.error(Chrome.Locale.localize("err_chrome_signout"));
    }
}

function _onLoad() {
    chrome.identity.onSignInChanged.addListener(_onSignInChanged);
}

window.addEventListener("load", _onLoad);