/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
import "../../../node_modules/@polymer/polymer/polymer-legacy.js";

import { Polymer } from "../../../node_modules/@polymer/polymer/lib/legacy/polymer-fn.js";

import { NeonAnimationBehavior } from "../../../node_modules/@polymer/neon-animation/neon-animation-behavior.js";

import "../../../scripts/chrome-extension-utils/scripts/ex_handler.js";

const PanAndZoomAnimation = Polymer({
    is: "pan-and-zoom-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(o) {
        const n = o.node;
        return o.transformOrigin && this.setPrefixedProperty(n, "transformOrigin", o.transformOrigin), 
        this._effect = new KeyframeEffect(n, [ {
            transform: "scale(.8) translateY()"
        }, {
            transform: "scale(1.0) translate(0)"
        } ], this.timingFromConfig(o)), this._effect;
    }
});

export default PanAndZoomAnimation;