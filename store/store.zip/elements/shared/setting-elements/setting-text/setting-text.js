var __decorate = this && this.__decorate || function(e, t, o, r) {
    var n, i = arguments.length, p = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) p = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (n = e[a]) && (p = (i < 3 ? n(p) : i > 3 ? n(t, o, p) : n(t, o)) || p);
    return i > 3 && p && Object.defineProperty(t, o, p), p;
};

/*
 * Copyright (c) 2016-2019, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://goo.gl/wFvBM1
 */ import { customElement, listen, property } from "../../../../node_modules/@polymer/decorators/lib/decorators.js";

import { html } from "../../../../node_modules/@polymer/polymer/polymer-element.js";

import "../../../../node_modules/@polymer/paper-input/paper-input.js";

import "../../../../node_modules/@polymer/paper-item/paper-item-body.js";

import "../../../../node_modules/@polymer/paper-item/paper-item.js";

import "../../../../node_modules/@polymer/app-storage/app-localstorage/app-localstorage-document.js";

import { SettingBase } from "../setting-base/setting-base.js";

import * as ChromeGA from "../../../../scripts/chrome-extension-utils/scripts/analytics.js";

let SettingTextElement = class extends SettingBase {
    constructor() {
        super(...arguments), this.value = "", this.placeholder = "e.g. Text", this.maxLength = 16;
    }
    onBlur() {
        ChromeGA.event(ChromeGA.EVENT.TEXT, this.name), this.fireEvent("setting-text-changed", this.value);
    }
    onKeyUp(e) {
        "Enter" === e.code && (ChromeGA.event(ChromeGA.EVENT.TEXT, this.name), this.fireEvent("setting-text-changed", this.value));
    }
    static get mainContent() {
        return html`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host([indent]) paper-item {
    padding-left: 24px;
  }

  :host paper-input {
    width: 175px;

    --paper-input-container-input: {
      text-align: right;
    };
  }

</style>

<paper-item class="center horizontal layout" tabindex="-1">
  <paper-item-body class="flex" two-line="">
    <div class="setting-label" hidden$="[[!mainLabel]]">
      [[mainLabel]]
    </div>
    <div class="setting-label" secondary="" hidden$="[[!secondaryLabel]]">
      [[secondaryLabel]]
    </div>
  </paper-item-body>
  <paper-input id="text" value="{{value}}" minlength="1" maxlength="[[maxLength]]" placeholder="[[placeholder]]"
               tabindex="0" disabled$="[[disabled]]"></paper-input>
</paper-item>

<app-localstorage-document key="[[name]]" data="{{value}}" storage="window.localStorage">
</app-localstorage-document>
`;
    }
};

__decorate([ property({
    type: String,
    notify: !0
}) ], SettingTextElement.prototype, "value", void 0), __decorate([ property({
    type: String
}) ], SettingTextElement.prototype, "placeholder", void 0), __decorate([ property({
    type: Number
}) ], SettingTextElement.prototype, "maxLength", void 0), __decorate([ property({
    type: String
}) ], SettingTextElement.prototype, "mainLabel", void 0), __decorate([ property({
    type: String
}) ], SettingTextElement.prototype, "secondaryLabel", void 0), __decorate([ listen("blur", "text") ], SettingTextElement.prototype, "onBlur", null), 
__decorate([ listen("keyup", "text") ], SettingTextElement.prototype, "onKeyUp", null), 
SettingTextElement = __decorate([ customElement("setting-text") ], SettingTextElement);

export { SettingTextElement };