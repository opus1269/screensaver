import { NeonAnimationBehavior, Polymer, NeonAnimatableBehavior, html$1 as html, EVENT$1 as EVENT, page, event, EVENT as EVENT$1, localize, getInt, get, getBool, set, getRandomInt, getChromeVersion, shuffleArray, isWhiteSpace, $timeDefault as ChromeTime, error$1 as error, SS_CLOSE, SS_IS_SHOWING, send, listen, getSelectedPhotos, $photoSourceGoogleDefault as GoogleSource } from "./shared_bundle_4.js";

Polymer({
    is: "spin-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)"
        }, {
            transform: "scale(0) rotate(0)"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "spin-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)"
        }, {
            transform: "scale(1) rotate(1.0turn)"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }
    </style>
    <slot></slot>
`,
    is: "slide-animatable",
    behaviors: [ NeonAnimatableBehavior ],
    properties: {
        animationConfig: {
            type: Object,
            value: function() {
                return {
                    entry: {
                        name: "fade-in-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    },
                    exit: {
                        name: "fade-out-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    }
                };
            }
        },
        aniType: {
            type: Number,
            observer: "_aniChanged"
        }
    },
    _aniChanged: function(e) {
        let t, i, s = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", i = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", i = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", i = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", i = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", i = "spin-down-animation", s = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", i = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", i = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", i = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", i = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = s, 
        this.animationConfig.exit.name = i, this.animationConfig.exit.timing.duration = s;
    }
});

class SSPhoto {
    constructor(e, t, i) {
        this._id = e, this._url = t.url, this._photographer = t.author ? t.author : "", 
        this._type = i, this._aspectRatio = t.asp, this._ex = t.ex, this._point = t.point, 
        this._isBad = !1;
    }
    getId() {
        return this._id;
    }
    setId(e) {
        this._id = e;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e, t, i = null;
        switch (this._type) {
          case "flickr":
            this._ex && (e = /(\/[^/]*){4}(_.*_)/, t = this._url.match(e), i = `https://www.flickr.com/photos/${this._ex}${t[1]}`);
            break;

          case "reddit":
            this._ex && (i = this._ex);
            break;

          case "Google User":
            this._ex && this._ex.url && (i = this._ex.url);
            break;

          default:
            i = this._url;
        }
        null !== i && (event(EVENT.VIEW_PHOTO, this._type), chrome.tabs.create({
            url: i
        }));
    }
}

var ss_photo = {
    default: SSPhoto
};

/*
    *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
    *  Licensed under the BSD-3-Clause
    *  https://opensource.org/licenses/BSD-3-Clause
    *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
    */ const _SCREEN_AR = screen.width / screen.height;

class SSView {
    constructor(e) {
        this.photo = e, this.image = null, this.author = null, this.time = null, this.location = null, 
        this.model = null, this.url = e.getUrl(), this.authorLabel = "", this.locationLabel = "";
    }
    static _dirtySet(e, t, i) {
        e.set(t, i), e.notifyPath(t);
    }
    static _isBadAspect(e) {
        return e < _SCREEN_AR - .5 || e > _SCREEN_AR + .5;
    }
    static ignore(e, t) {
        let i = !1;
        const s = getBool("skip");
        return (!e || isNaN(e) || s && (1 === t || 3 === t) && SSView._isBadAspect(e)) && (i = !0), 
        i;
    }
    static _showLocation() {
        return getBool("showLocation");
    }
    static showTime() {
        return getBool("showTime");
    }
    _hasAuthor() {
        const e = this.photo.getPhotographer();
        return !isWhiteSpace(e);
    }
    _hasAuthorLabel() {
        return !isWhiteSpace(this.authorLabel);
    }
    _hasLocation() {
        return !!this.photo.getPoint();
    }
    _hasLocationLabel() {
        return !isWhiteSpace(this.locationLabel);
    }
    _setTimeStyle() {
        getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
    }
    setUrl(e = null) {
        this.url = e || this.photo.getUrl(), SSView._dirtySet(this.model, "view.url", this.url);
    }
    markPhotoBad() {
        this.photo && this.photo.markBad();
    }
    _setAuthorLabel() {
        this.authorLabel = "", SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel);
        const e = this.photo.getType(), t = this.photo.getPhotographer();
        let i = e;
        const s = e.search("User");
        (getBool("showPhotog") || -1 === s) && (-1 !== s && (i = e.substring(0, s - 1)), 
        this._hasAuthor() ? this.authorLabel = `${t} / ${i}` : this.authorLabel = `${localize("photo_from")} ${i}`, 
        SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel));
    }
    _setLocationLabel() {
        this.locationLabel = "", SSView._dirtySet(this.model, "view.locationLabel", this.locationLabel);
    }
    setElements(e, t, i, s, o) {
        this.image = e, this.author = t, this.time = i, this.location = s, this.model = o, 
        this._setTimeStyle(), this.setPhoto(this.photo);
    }
    setPhoto(e) {
        this.photo = e, this.setUrl(), this._setAuthorLabel(!1), this._setLocationLabel();
    }
    render() {}
    isError() {
        return !this.image || this.image.error;
    }
    isLoaded() {
        return !!this.image && this.image.loaded;
    }
}

var ss_view = {
    default: SSView
};

const _photos = [];

let _curIdx = 0;

function addFromSource(e) {
    const t = e.type, i = getType();
    let s = 0;
    for (const o of e.photos) if (!SSView.ignore(o.asp, i)) {
        const e = new SSPhoto(s, o, t);
        _photos.push(e), s++;
    }
}

function getCount() {
    return _photos.length;
}

function hasUsable() {
    return !_photos.every(e => e.isBad());
}

function get$1(e) {
    return _photos[e];
}

function getNextUsable() {
    for (let e = 0; e < _photos.length; e++) {
        const t = (e + _curIdx) % _photos.length, i = _photos[t];
        if (!i.isBad() && !hasPhoto(i)) return _curIdx = t, incCurrentIndex(), i;
    }
    return null;
}

function getCurrentIndex() {
    return _curIdx;
}

function getNextGooglePhotos(e, t) {
    const i = [];
    let s = 0;
    for (let o = 0; o < _photos.length; o++) {
        const n = (o + t) % _photos.length, a = _photos[n];
        if (s >= e) break;
        "Google User" === a.getType() && (i.push(a), s++);
    }
    return i;
}

function updateGooglePhotoUrls(e) {
    for (let t = _photos.length - 1; t >= 0; t--) {
        if ("Google User" !== _photos[t].getType()) continue;
        const i = e.findIndex(e => e.ex.id === _photos[t].getEx().id);
        i >= 0 && _photos[t].setUrl(e[i].url);
    }
}

function setCurrentIndex(e) {
    _curIdx = e;
}

function incCurrentIndex() {
    return _curIdx = _curIdx === _photos.length - 1 ? 0 : _curIdx + 1;
}

function shuffle() {
    shuffleArray(_photos), _photos.forEach((e, t) => {
        e.setId(t);
    });
}

var ss_photos = {
    addFromSource: addFromSource,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get$1,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex,
    shuffle: shuffle
};

let _transTime = 3e4;

function initialize() {
    const e = get("transitionTime");
    e && (_transTime = 1e3 * e.base);
}

function getNext(e) {
    let t = findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : _transTime), t;
}

function replacePhoto(e) {
    e >= 0 && function(e) {
        if (isSelectedIndex(e)) return;
        const t = getCount$1();
        if (getCount() <= t) return;
        const i = getNextUsable();
        if (i) {
            const t = get$2(e);
            t.setPhoto(i);
        }
    }(e);
}

var ss_photo_finder = {
    initialize: initialize,
    getNext: getNext,
    replacePhoto: replacePhoto
};

const _history = {
    arr: [],
    idx: -1,
    max: 20
};

function initialize$1() {
    _history.max = Math.min(getCount(), _history.max);
}

function add(e, t, i) {
    if (null === e) {
        const e = get$2(t), s = _history.idx, o = _history.arr.length, n = {
            viewsIdx: t,
            replaceIdx: i,
            photoId: e.photo.getId(),
            photosPos: getCurrentIndex()
        };
        s === o - 1 && (_history.arr.length > _history.max && (_history.arr.shift(), _history.idx--, 
        _history.idx = Math.max(_history.idx, -1)), _history.arr.push(n));
    }
    _history.idx++;
}

function clear() {
    _history.arr = [], _history.idx = -1;
}

function back() {
    if (_history.idx <= 0) return null;
    let e = null, t = 2, i = _history.idx - t;
    if (_history.idx = i, i < 0) {
        if (_history.arr.length > _history.max) return _history.idx += t, null;
        _history.idx = -1, t = 1, e = -1, i = 0;
    }
    const s = _history.arr[i].photosPos, o = _history.arr[i + t].replaceIdx;
    setCurrentIndex(s), setReplaceIdx(o);
    const n = _history.arr[i].viewsIdx, a = _history.arr[i].photoId;
    e = null === e ? n : e;
    const r = get$2(n), l = get$1(a);
    return r.setPhoto(l), r.render(), e;
}

var ss_history = {
    initialize: initialize$1,
    add: add,
    clear: clear,
    back: back
};

function initialize$2() {
    getInt("showTime", 0) > 0 && setInterval(setTime, 61e3);
}

function setTime() {
    let e = "";
    0 !== getInt("showTime", 0) && isStarted() && (e = ChromeTime.getStringShort()), 
    setTimeLabel(e);
}

var ss_time = {
    initialize: initialize$2,
    setTime: setTime
};

const _VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    const t = get("transitionTime");
    t && setWaitTime(1e3 * t.base), _VARS.interactive = getBool("interactive"), initialize$1(), 
    window.setTimeout(_runShow, e);
}

function getWaitTime() {
    return _VARS.waitTime;
}

function setWaitTime(e) {
    _VARS.waitTime = e, _VARS.waitTime = Math.min(2147483647, e);
}

function setLastSelected(e) {
    _VARS.lastSelected = e;
}

function setReplaceIdx(e) {
    _VARS.replaceIdx = e;
}

function isStarted() {
    return _VARS.started;
}

function isInteractive() {
    return _VARS.interactive;
}

function isPaused() {
    return _VARS.paused;
}

function isCurrentPair(e) {
    return e === getSelectedIndex() || e === _VARS.lastSelected;
}

function togglePaused(e = null) {
    _VARS.started && (_VARS.paused = !_VARS.paused, setPaused(_VARS.paused), _VARS.paused ? _stop() : _restart(e));
}

function forward() {
    _VARS.started && _step();
}

function back$1() {
    if (_VARS.started) {
        const e = back();
        null !== e && _step(e);
    }
}

function _stop() {
    window.clearTimeout(_VARS.timeOutId);
}

function _restart(e = null) {
    const t = get("transitionTime");
    t && setWaitTime(1e3 * t.base), _runShow(e);
}

function _step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (_stop(), _restart(e));
}

function _runShow(e = null) {
    if (noPhotos()) return;
    const t = getSelectedIndex(), i = getCount$1();
    let s = null === e ? t : e, o = (s = isStarted() ? s : 0) === i - 1 ? 0 : s + 1;
    if (isStarted() || (o = 0), -1 !== (o = getNext(o))) {
        isStarted() || (_VARS.started = !0, setTime()), get$2(o).render(), add(e, o, _VARS.replaceIdx), 
        _VARS.lastSelected = t, setSelectedIndex(o), null === e && (replacePhoto(_VARS.replaceIdx), 
        _VARS.replaceIdx = _VARS.lastSelected);
    }
    _VARS.timeOutId = window.setTimeout(() => {
        _runShow();
    }, _VARS.waitTime);
}

var ss_runner = {
    start: start,
    getWaitTime: getWaitTime,
    setWaitTime: setWaitTime,
    setLastSelected: setLastSelected,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isPaused: isPaused,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

class SSViewZoom extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
    }
}

var ss_view_zoom = {
    default: SSViewZoom
};

class SSViewFrame extends SSView {
    constructor(e) {
        super(e);
    }
    static _setLabelStyle(e, t, i, s) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = 1, 
        e.fontSize = "2.5vh", e.fontWeight = 400;
        let o = t / screen.width * 100, n = (100 - o) / 2;
        s ? (e.left = n + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = n + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = o - 1 + "vw";
        let a = (100 - i / screen.height * 100) / 2;
        e.bottom = a + 1.1 + "vh";
    }
    render() {
        super.render();
        const e = this.author.style, t = this.location.style, i = this.time.style, s = this.image, o = s.style, n = s.$.img.style, a = this.photo.getAspectRatio(), r = .005 * screen.height, l = .05 * screen.height, h = .025 * screen.height, c = Math.min((screen.width - 2 * h - 2 * r) / a, screen.height - 2 * h - r - l), u = c * a, d = u + 2 * r, _ = c + l + r;
        n.height = c + "px", n.width = u + "px", s.height = c, s.width = u, o.top = (screen.height - _) / 2 + "px", 
        o.left = (screen.width - d) / 2 + "px", o.border = "0.5vh ridge WhiteSmoke", o.borderBottom = "5vh solid WhiteSmoke", 
        o.borderRadius = "1.5vh", o.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", SSViewFrame._setLabelStyle(e, d, _, !1), 
        SSViewFrame._setLabelStyle(t, d, _, !0);
        let g = (100 - _ / screen.height * 100) / 2, m = d / screen.width * 100, f = (100 - m) / 2;
        i.right = f + 1 + "vw", i.textAlign = "right", i.bottom = g + 5 + "vh";
        let p = m / 2;
        this._hasLocationLabel() && (e.maxWidth = p - 1 + "vw"), this._hasAuthorLabel() && (t.maxWidth = p - 1 + "vw");
    }
}

var ss_view_frame = {
    default: SSViewFrame
};

class SSViewFull extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.image.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
}

var ss_view_full = {
    default: SSViewFull
};

const _SCREEN_AR$1 = screen.width / screen.height;

class SSViewLetterbox extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.photo.getAspectRatio(), t = this.author.style, i = this.location.style, s = this.time.style;
        let o = e / _SCREEN_AR$1 * 100, n = (100 - (o = Math.min(o, 100))) / 2, a = _SCREEN_AR$1 / e * 100, r = (100 - (a = Math.min(a, 100))) / 2;
        t.textAlign = "right", i.textAlign = "left", t.right = n + 1 + "vw", t.bottom = r + 1 + "vh", 
        t.width = o - .5 + "vw", i.left = n + 1 + "vw", i.bottom = r + 1 + "vh", i.width = o - .5 + "vw", 
        s.right = n + 1 + "vw", s.bottom = r + 3.5 + "vh", SSView.showTime() && (t.textOverflow = "ellipsis", 
        t.whiteSpace = "nowrap");
        let l = o / 2;
        this._hasLocationLabel() && (t.maxWidth = l - 1.1 + "vw"), this._hasAuthorLabel() && (i.maxWidth = l - 1.1 + "vw");
    }
}

var ss_view_letterbox = {
    default: SSViewLetterbox
};

function create(e, t) {
    switch (t) {
      case Type.LETTERBOX:
        return new SSViewLetterbox(e);

      case Type.ZOOM:
        return new SSViewZoom(e);

      case Type.FRAME:
        return new SSViewFrame(e);

      case Type.FULL:
        return new SSViewFull(e);

      default:
        return error(`Bad SSView type: ${t}`, "SSView.createView"), new SSViewLetterbox(e);
    }
}

var ss_view_factory = {
    create: create
};

const Type = {
    UNDEFINED: -1,
    LETTERBOX: 0,
    ZOOM: 1,
    FRAME: 2,
    FULL: 3,
    RANDOM: 4
}, _MAX_VIEWS = 20, _views = [];

let _pages = null, _type = Type.UNDEFINED;

function _setViewType() {
    (_type = getInt("photoSizing", 0)) === Type.RANDOM && (_type = getRandomInt(0, 3));
    let e = "contain";
    switch (_type) {
      case Type.LETTERBOX:
        e = "contain";
        break;

      case Type.ZOOM:
        e = "cover";
        break;

      case Type.FRAME:
      case Type.FULL:
        e = null;
    }
    setSizingType(e);
}

function create$1(e) {
    _pages = e.$.pages, _setViewType();
    const t = Math.min(getCount(), _MAX_VIEWS);
    for (let e = 0; e < t; e++) {
        const t = create(get$1(e), _type);
        _views.push(t);
    }
    setCurrentIndex(t), e.set("_views", _views), e.$.repeatTemplate.render(), _views.forEach((t, i) => {
        const s = _pages.querySelector("#view" + i), o = s.querySelector(".image"), n = s.querySelector(".author"), a = s.querySelector(".time"), r = s.querySelector(".location"), l = e.$.repeatTemplate.modelForElement(s);
        t.setElements(o, n, a, r, l);
    });
}

function getType() {
    return _type === Type.UNDEFINED && _setViewType(), _type;
}

function getCount$1() {
    return _views.length;
}

function get$2(e) {
    return _views[e];
}

function getSelectedIndex() {
    if (_pages) return _pages.selected;
}

function setSelectedIndex(e) {
    _pages.selected = e;
}

function isSelectedIndex(e) {
    let t = !1;
    return _pages && e === _pages.selected && (t = !0), t;
}

function hasPhoto(e) {
    let t = !1;
    for (const i of _views) if (i.photo.getId() === e.getId()) {
        t = !0;
        break;
    }
    return t;
}

function hasUsable$1() {
    let e = !1;
    for (let t = 0; t < _views.length; t++) {
        const i = _views[t];
        if (!isCurrentPair(t) && !i.photo.isBad()) {
            e = !0;
            break;
        }
    }
    return e;
}

function replaceAll() {
    for (let e = 0; e < _views.length; e++) {
        if (isCurrentPair(e)) continue;
        const t = _views[e], i = getNextUsable();
        if (!i) break;
        t.setPhoto(i);
    }
    clear();
}

function findLoadedPhoto(e) {
    if (hasUsable$1() || replaceAll(), _views[e].isLoaded()) return e;
    for (let t = 0; t < _views.length; t++) {
        const i = (t + e) % _views.length, s = _views[i];
        if (!isCurrentPair(i)) {
            if (s.isLoaded()) return i;
            if (s.isError() && !s.photo.isBad() && (s.photo.markBad(), !hasUsable())) return setNoPhotos(), 
            -1;
        }
    }
    return -1;
}

var ss_views = {
    Type: Type,
    create: create$1,
    getType: getType,
    getCount: getCount$1,
    get: get$2,
    getSelectedIndex: getSelectedIndex,
    setSelectedIndex: setSelectedIndex,
    isSelectedIndex: isSelectedIndex,
    hasPhoto: hasPhoto,
    hasUsable: hasUsable$1,
    replaceAll: replaceAll,
    findLoadedPhoto: findLoadedPhoto
};

const _MOUSE_START = {
    x: null,
    y: null
};

function _close() {
    set("isShowing", !1), send(SS_CLOSE).catch(() => {}), setTimeout(() => {
        window.close();
    }, 750);
}

function _onKeyCommand(e) {
    isInteractive() && ("ss-toggle-paused" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), forward()) : "ss-back" === e && (event(EVENT$1.KEY_COMMAND, `${e}`), 
    back$1()));
}

function _onMessage(e, t, i) {
    return e.message === SS_CLOSE.message ? _close() : e.message === SS_IS_SHOWING.message && i({
        message: "OK"
    }), !1;
}

function _onKey(e) {
    const t = e.key;
    if (isStarted()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || _close();
        break;

      default:
        _close();
    } else _close();
}

function _onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), i = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, i) > 10 && _close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function _onMouseClick() {
    if (isStarted()) {
        const e = getSelectedIndex();
        if (getBool("allowPhotoClicks") && void 0 !== e) {
            get$2(e).photo.showSource();
        }
    }
    _close();
}

function _onLoad() {
    listen(_onMessage), window.addEventListener("keydown", _onKey, !1), window.addEventListener("mousemove", _onMouseMove, !1), 
    window.addEventListener("click", _onMouseClick, !1), chrome.commands.onCommand.addListener(_onKeyCommand);
}

async function build() {
    const e = await _loadPhotos();
    return e && (createPages(), initialize()), e;
}

async function _loadPhotos() {
    try {
        let e = await getSelectedPhotos();
        e = e || [];
        for (const t of e) addFromSource(t);
        if (!getCount()) return setNoPhotos(), Promise.resolve(!1);
    } catch (e) {
        return Promise.resolve(!1);
    }
    return getBool("shuffle") && shuffle(), Promise.resolve(!0);
}

window.addEventListener("load", _onLoad);

var ss_builder = {
    build: build
};

const t = document.querySelector("#t");

t.sizingType = null, t.screenWidth = screen.width, t.screenHeight = screen.height, 
t.aniType = 0, t.paused = !1, t.noPhotos = !1, t.noPhotosLabel = "", t.timeLabel = "";

const _MAX_GPHOTO_UPDATES = 168;

let _gPhotoCt = 0, _isUpdating = !1;

function createPages() {
    create$1(t);
}

function setSizingType(e) {
    t.set("sizingType", e);
}

function noPhotos() {
    return t.noPhotos;
}

function setNoPhotos() {
    t.set("noPhotos", !0), t.noPhotosLabel = localize("no_photos");
}

function setTimeLabel(e) {
    t.timeLabel = e;
}

function setPaused(e) {
    t.paused = e, e ? (t.$.pauseImage.classList.add("fadeOut"), t.$.playImage.classList.remove("fadeOut")) : (t.$.playImage.classList.add("fadeOut"), 
    t.$.pauseImage.classList.remove("fadeOut"));
}

function _setupPhotoTransitions() {
    let e = getInt("photoTransition", 0);
    8 === e && (e = getRandomInt(0, 7)), t.set("aniType", e), initialize$2();
}

function _setZoom() {
    if (getChromeVersion() >= 42) {
        new ChromePromise().tabs.getZoom().then(e => ((e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1), 
        null)).catch(e => {
            error(e.message, "chromep.tabs.getZoom");
        });
    }
}

async function _launch(e = 2e3) {
    await build() && start(1e3);
}

function _onLoad$1() {
    document.body.style.background = get("background", "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)").substring(11), 
    page("/screensaver.html"), _setZoom(), _setupPhotoTransitions(), _launch().catch(e => {
        error(e.message, "Screensaver._launch"), setTimeout(() => {
            window.close();
        }, 750);
    });
}

t._onErrorChanged = async function(e) {
    const i = e.detail.value;
    if (!_isUpdating && i) {
        _isUpdating = !0;
        const i = e.model.index, s = t._views[i].photo;
        if ("Google User" === s.getType()) {
            if (++_gPhotoCt >= 168) return void (_isUpdating = !1);
            const e = getWaitTime();
            let i = Math.round(ChromeTime.MSEC_IN_HOUR / e);
            i = Math.max(i, 50);
            const o = getNextGooglePhotos(i = 1 === _gPhotoCt ? Math.min(i, 50) : Math.min(i, 300), s.getId()), n = [];
            for (const e of o) {
                const t = e.getEx().id;
                -1 === n.indexOf(t) && n.push(t);
            }
            let a = [];
            try {
                a = await GoogleSource.loadPhotos(n);
            } catch (e) {
                return _gPhotoCt = 169, void (_isUpdating = !0);
            }
            updateGooglePhotoUrls(a);
            for (let e = 0; e < t._views.length; e++) {
                const i = t._views[e], s = i.photo;
                if ("Google User" === s.getType()) {
                    const e = a.findIndex(e => e.ex.id === s.getEx().id);
                    e >= 0 && i.setUrl(a[e].url);
                }
            }
            if (!GoogleSource.updateBaseUrls(a)) return _gPhotoCt = 169, void (_isUpdating = !0);
            _isUpdating = !1;
        }
    }
}, window.addEventListener("load", _onLoad$1);

var screensaver = {
    createPages: createPages,
    setSizingType: setSizingType,
    noPhotos: noPhotos,
    setNoPhotos: setNoPhotos,
    setTimeLabel: setTimeLabel,
    setPaused: setPaused
};

export { screensaver as $screensaver, ss_builder as $ssBuilder, ss_history as $ssHistory, ss_photo as $ssPhoto, ss_photo_finder as $ssPhotoFinder, ss_photos as $ssPhotos, ss_runner as $ssRunner, ss_time as $ssTime, ss_views as $ssViews, ss_view as $ssView, ss_view_factory as $ssViewFactory, ss_view_frame as $ssViewFrame, ss_view_full as $ssViewFull, ss_view_letterbox as $ssViewLetterbox, ss_view_zoom as $ssViewZoom, createPages, setSizingType, noPhotos, setNoPhotos, setTimeLabel, setPaused, build, initialize$1 as initialize, add, clear, back, SSPhoto as $ssPhotoDefault, initialize as initialize$1, getNext, replacePhoto, addFromSource, getCount, hasUsable, get$1 as get, getNextUsable, getCurrentIndex, getNextGooglePhotos, updateGooglePhotoUrls, setCurrentIndex, incCurrentIndex, shuffle, start, getWaitTime, setWaitTime, setLastSelected, setReplaceIdx, isStarted, isInteractive, isPaused, isCurrentPair, togglePaused, forward, back$1, initialize$2, setTime, Type, create$1 as create, getType, getCount$1, get$2 as get$1, getSelectedIndex, setSelectedIndex, isSelectedIndex, hasPhoto, hasUsable$1, replaceAll, findLoadedPhoto, SSView as $ssViewDefault, create as create$1, SSViewFrame as $ssViewFrameDefault, SSViewFull as $ssViewFullDefault, SSViewLetterbox as $ssViewLetterboxDefault, SSViewZoom as $ssViewZoomDefault };