import { customElement, property, computed, query, listen, observe, mixinBehaviors, NeonAnimationBehavior, BaseElement, html, NeonAnimatableBehavior, DEF_WEATHER, error, event, EVENT as EVENT$1, page, localize, getBool, get as get$1, getInt, isWhiteSpace, getRandomInt, getRandomFloat, shuffleArray, isInOrigins, DETECT_FACES, isGoogleSourceOrigin, error$1, send, addListener, removeListener, ChromeTime, EVENT$1 as EVENT, initialize as initialize$2, TYPE$1 as TYPE, GoogleSource, getSelectedSources } from "./shared_bundle_4.js";

var __decorate = function(e, t, i, o) {
    var n, r = arguments.length, a = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (a = (r < 3 ? n(a) : r > 3 ? n(t, i, a) : n(t, i)) || a);
    return r > 3 && a && Object.defineProperty(t, i, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */ let SpinDownAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        }, {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinDownAnimationElement = __decorate([ customElement("spin-down-animation") ], SpinDownAnimationElement);

var spinDownAnimation = {
    get SpinDownAnimationElement() {
        return SpinDownAnimationElement;
    }
}, __decorate$1 = function(e, t, i, o) {
    var n, r = arguments.length, a = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (a = (r < 3 ? n(a) : r > 3 ? n(t, i, a) : n(t, i)) || a);
    return r > 3 && a && Object.defineProperty(t, i, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SpinUpAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        }, {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinUpAnimationElement = __decorate$1([ customElement("spin-up-animation") ], SpinUpAnimationElement);

var spinUpAnimation = {
    get SpinUpAnimationElement() {
        return SpinUpAnimationElement;
    }
}, __decorate$2 = function(e, t, i, o) {
    var n, r = arguments.length, a = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (a = (r < 3 ? n(a) : r > 3 ? n(t, i, a) : n(t, i)) || a);
    return r > 3 && a && Object.defineProperty(t, i, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let WeatherElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.show = !1, this.weather = DEF_WEATHER;
    }
    _weatherChanged(e, t) {
        let i = null;
        if (void 0 !== t && (i = "wi-owm-" + t.dayNight + t.id), void 0 !== e) {
            const t = "wi-owm-" + e.dayNight + e.id;
            i ? this.$.weatherIcon.classList.replace(i, t) : this.$.weatherIcon.classList.add(t);
        }
    }
    static get template() {
        return html`<!--
  Need to include globally too
  see: https://bugs.chromium.org/p/chromium/issues/detail?id=336876
  -->
<link rel="stylesheet" href="../../css/weather-icons.min.css">

<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .temp {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0 0 0 16px;
  }

  :host .icon {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0;
  }

</style>

<div class="horizontal layout center" hidden$="[[!show]]">
  <i id="weatherIcon" class="icon wi"></i>
  <paper-item class="temp">[[weather.temp]]</paper-item>
</div>

<app-localstorage-document key="currentWeather" data="{{weather}}" storage="window.localStorage">
</app-localstorage-document>
<app-localstorage-document key="showCurrentWeather" data="{{show}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$2([ property({
    type: Boolean,
    notify: !0
}) ], WeatherElement.prototype, "show", void 0), __decorate$2([ property({
    type: Object,
    observer: "_weatherChanged"
}) ], WeatherElement.prototype, "weather", void 0), WeatherElement = __decorate$2([ customElement("weather-element") ], WeatherElement);

var weatherElement = {
    get WeatherElement() {
        return WeatherElement;
    }
};

function initialize() {
    return faceapi.loadTinyFaceDetectorModel("/assets/models").catch(e => {
        throw e;
    });
}

function detectAll(e) {
    return faceapi.detectAllFaces(e, new faceapi.TinyFaceDetectorOptions()).then(e => e).catch(() => []);
}

var ScreensaverSlideElement_1, face_detect = {
    initialize: initialize,
    detectAll: detectAll
}, __decorate$3 = function(e, t, i, o) {
    var n, r = arguments.length, a = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (a = (r < 3 ? n(a) : r > 3 ? n(t, i, a) : n(t, i)) || a);
    return r > 3 && a && Object.defineProperty(t, i, a), a;
};

let ScreensaverSlideElement = ScreensaverSlideElement_1 = class extends(mixinBehaviors([ NeonAnimatableBehavior ], BaseElement)){
    constructor() {
        super(...arguments), this.photo = null, this.viewType = 0, this.index = 0, this.url = "", 
        this.aniType = 1, this.screenWidth = screen.width, this.screenHeight = screen.height, 
        this.timeLabel = "", this.isAnimate = !1, this.animation = null, this.detectFaces = getBool("detectFaces", !1), 
        this.animationTarget = null, this.animationConfig = {
            entry: {
                name: "fade-in-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            },
            exit: {
                name: "fade-out-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            }
        };
    }
    static setFrameLabelStyle(e, t, i, o) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = "1.0", 
        e.fontSize = "2.5vh", e.fontWeight = "400";
        const n = t / screen.width * 100, r = (100 - n) / 2;
        o ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = n - 1 + "vw";
        const a = (100 - i / screen.height * 100) / 2;
        e.bottom = a + 1.1 + "vh";
    }
    get authorLabel() {
        let e = "";
        if (this.photo) {
            const t = this.photo.getType(), i = this.photo.getPhotographer();
            let o = t;
            const n = t.search("User");
            if (!getBool("showPhotog", !0) && -1 !== n) return "";
            -1 !== n && (o = t.substring(0, n - 1)), e = isWhiteSpace(i) ? `${localize("photo_from")} ${o}` : `${i} / ${o}`;
        }
        return e;
    }
    get locationLabel() {
        return "";
    }
    getPhoto() {
        return this.photo;
    }
    setUrl(e) {
        this.set("url", e);
    }
    isPhotoLoaded() {
        return !!this.ironImage && this.ironImage.loaded;
    }
    isPhotoError() {
        return !this.ironImage || this.ironImage.error;
    }
    async prep() {
        getBool("largeTime", !1) && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = "300"), 
        this.render(), this.isAnimate && await this.startAnimation();
    }
    onErrorChanged(e) {
        if (e.detail.value) {
            const e = new CustomEvent("image-error", {
                bubbles: !0,
                composed: !0,
                detail: {
                    index: this.index
                }
            });
            this.dispatchEvent(e);
        }
    }
    photoChanged(e) {
        e && this.set("url", e.getUrl());
    }
    aniChanged(e) {
        let t, i, o = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", i = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", i = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", i = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", i = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", i = "spin-down-animation", o = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", i = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", i = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", i = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", i = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = o, 
        this.animationConfig.exit.name = i, this.animationConfig.exit.timing.duration = o;
    }
    isAnimateChanged(e) {
        void 0 !== e && (e || this.animation && (this.animation.cancel(), this.set("animation", null)));
    }
    render() {
        switch (this.viewType) {
          case 1:
            this.renderZoom();
            break;

          case 3:
            this.renderFull();
            break;

          case 0:
            this.renderLetterbox();
            break;

          case 2:
            this.renderFrame();
        }
    }
    renderFull() {
        const e = this.ironImage.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
    renderZoom() {
        const e = this.ironImage.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "cover";
    }
    renderLetterbox() {
        if (!this.photo) return;
        const e = screen.width / screen.height, t = this.photo.getAspectRatio(), i = this.ironImage, o = i.style, n = i.$.img.style, r = this.author.style, a = this.location.style, s = this.time.style, l = this.weather.style;
        let c = t / e * 100;
        const d = (100 - (c = Math.min(c, 100))) / 2;
        let h = e / t * 100;
        const p = (100 - (h = Math.min(h, 100))) / 2, m = Math.round(h / 100 * screen.height), u = Math.round(c / 100 * screen.width);
        i.height = m, i.width = u, n.height = m + "px", n.width = u + "px", o.top = (screen.height - m) / 2 + "px", 
        o.left = (screen.width - u) / 2 + "px", r.textAlign = "right", a.textAlign = "left", 
        l.textAlign = "left", r.right = d + 1 + "vw", r.bottom = p + 1 + "vh", r.width = c - .5 + "vw", 
        a.left = d + 1 + "vw", a.bottom = p + 1 + "vh", a.width = c - .5 + "vw", l.left = d + 1 + "vw", 
        l.bottom = p + 3.5 + "vh", l.width = c - .5 + "vw", s.right = d + 1 + "vw", s.bottom = p + 3.5 + "vh", 
        getBool("showTime", !1) && (r.textOverflow = "ellipsis", r.whiteSpace = "nowrap");
        const g = c / 2;
        isWhiteSpace(this.locationLabel) || (r.maxWidth = g - 1.1 + "vw"), isWhiteSpace(this.authorLabel) || (a.maxWidth = g - 1.1 + "vw");
    }
    renderFrame() {
        if (!this.photo) return;
        const e = this.photo.getAspectRatio(), t = this.ironImage, i = t.style, o = t.$.img.style, n = this.author.style, r = this.location.style, a = this.weather.style, s = this.time.style, l = .005 * screen.height, c = .05 * screen.height, d = .025 * screen.height, h = Math.min((screen.width - 2 * d - 2 * l) / e, screen.height - 2 * d - l - c), p = h * e, m = p + 2 * l, u = h + c + l;
        t.height = h, t.width = p, i.top = (screen.height - u) / 2 + "px", i.left = (screen.width - m) / 2 + "px", 
        i.border = "0.5vh ridge WhiteSmoke", i.borderBottom = "5vh solid WhiteSmoke", i.borderRadius = "1.5vh", 
        i.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", o.height = h + "px", o.width = p + "px", 
        o.top = screen.height / 2 + "px", o.left = screen.width / 2 + "px", ScreensaverSlideElement_1.setFrameLabelStyle(n, m, u, !1), 
        ScreensaverSlideElement_1.setFrameLabelStyle(r, m, u, !0);
        const g = (100 - u / screen.height * 100) / 2, S = m / screen.width * 100, f = (100 - S) / 2;
        s.right = f + 1 + "vw", s.textAlign = "right", s.bottom = g + 5 + "vh", a.left = f + 1 + "vw", 
        a.textAlign = "left", a.bottom = g + 6.5 + "vh";
        const v = S / 2;
        isWhiteSpace(this.locationLabel) || (n.maxWidth = v - 1 + "vw"), isWhiteSpace(this.authorLabel) || (r.maxWidth = v - 1 + "vw");
    }
    async setAnimationTarget() {
        const e = this.ironImage;
        if (!e) return;
        const t = e.width, i = e.height;
        if (t && i) try {
            const e = this.ironImage.$.img;
            let o = [];
            try {
                o = await detectAll(e);
            } catch (e) {}
            if (o.length) {
                const n = {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                };
                let r = e.naturalWidth, a = 0, s = e.naturalHeight, l = 0;
                for (const e of o) {
                    const t = e.box;
                    r = Math.min(t.left, r), a = Math.max(t.right, a), s = Math.min(t.top, s), l = Math.max(t.bottom, l);
                }
                n.x = Math.round(r + (a - r) / 2 - e.naturalWidth / 2), n.y = Math.round(s + (l - s) / 2 - e.naturalHeight / 2), 
                n.width = Math.round(a - r), n.height = Math.round(l - s);
                const c = t / e.naturalWidth, d = i / e.naturalHeight;
                if (n.x = Math.round(n.x * c), n.y = Math.round(n.y * d), n.width = Math.round(n.width * c), 
                n.height = Math.round(n.height * d), 1 === o.length) {
                    const e = n.height;
                    n.height = Math.round(1.2 * e), n.y = Math.round(n.y - .2 * n.height), n.y = Math.max(n.y, -i / 2);
                }
                this.animationTarget = n;
            } else this.animationTarget = null;
        } catch (e) {
            this.animationTarget = null, error(e.message, "SSSlide.setAnimationTarget");
        }
    }
    async startAnimation() {
        if (this.animation && (this.animation.cancel(), this.set("animation", null)), !this.isAnimate) return;
        const e = this.ironImage;
        if (!e) return;
        const t = e.width, i = e.height;
        if (t && i) try {
            this.detectFaces && isInOrigins(this.url, DETECT_FACES) && await this.setAnimationTarget();
            const o = 1e3 * get$1("transitionTime", {
                base: 30,
                display: 30,
                unit: 0
            }).base;
            let n = 1e3;
            let r, a, s;
            if (4 === getInt("photoTransition", 1) && (n = 2e3), this.animationTarget) {
                const e = t / this.animationTarget.width, o = i / this.animationTarget.height, n = Math.min(e, o), l = .25 * ((s = Math.min(1.6, n)) - 1) * t, c = .25 * (s - 1) * i, d = Math.min(l, Math.abs(this.animationTarget.x)) * Math.sign(this.animationTarget.x), h = Math.min(c, Math.abs(this.animationTarget.y)) * Math.sign(this.animationTarget.y);
                r = -d + "px", a = -h + "px";
            } else {
                const e = getRandomInt(0, 1) ? -1 : 1, o = getRandomInt(0, 1) ? -1 : 1, n = .2 * ((s = 1 + getRandomFloat(.2, .6)) - 1), l = e * t * getRandomFloat(0, n), c = o * i * getRandomFloat(0, n);
                r = Math.round(l) + "px", a = Math.round(c) + "px";
            }
            const l = [ {
                transform: "scale(1.0) translateX(0vw) translateY(0vh)"
            }, {
                transform: `scale(${s}) translateX(${r}) translateY(${a})`
            } ], c = {
                delay: n,
                duration: o - n,
                iterations: 1,
                easing: "ease-in-out",
                fill: "forwards"
            }, d = e.$.img;
            this.set("animation", d.animate(l, c));
        } catch (e) {
            this.animation && (this.animation.cancel(), this.set("animation", null)), error(e.message, "SSSlide.startAnimation");
        }
    }
    static get template() {
        return html`
<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  .time {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    right: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .weather {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    left: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .author {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    right: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .location {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    left: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }
  
</style>
<section id="slide[[index]]">
  <iron-image
      crossorign="Anonymous"
      id="ironImage"
      class="image"
      src="[[url]]"
      width="[[screenWidth]]"
      height="[[screenHeight]]"
      preload>
  </iron-image>
  <div class="time">[[timeLabel]]</div>
  <div class="author">[[authorLabel]]</div>
  <div class="location">[[locationLabel]]</div>
  <weather-element class="weather"></weather-element>
</section>


<app-localstorage-document key="panAndScan" data="{{isAnimate}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "photo", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "viewType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "index", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "url", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "aniType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenWidth", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenHeight", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "timeLabel", void 0), __decorate$3([ property({
    type: Boolean,
    notify: !0
}) ], ScreensaverSlideElement.prototype, "isAnimate", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animation", void 0), __decorate$3([ property({
    type: Boolean
}) ], ScreensaverSlideElement.prototype, "detectFaces", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animationTarget", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animationConfig", void 0), __decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "authorLabel", null), 
__decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "locationLabel", null), 
__decorate$3([ query("#ironImage") ], ScreensaverSlideElement.prototype, "ironImage", void 0), 
__decorate$3([ query(".time") ], ScreensaverSlideElement.prototype, "time", void 0), 
__decorate$3([ query(".author") ], ScreensaverSlideElement.prototype, "author", void 0), 
__decorate$3([ query(".location") ], ScreensaverSlideElement.prototype, "location", void 0), 
__decorate$3([ query(".weather") ], ScreensaverSlideElement.prototype, "weather", void 0), 
__decorate$3([ listen("error-changed", "ironImage") ], ScreensaverSlideElement.prototype, "onErrorChanged", null), 
__decorate$3([ observe("photo") ], ScreensaverSlideElement.prototype, "photoChanged", null), 
__decorate$3([ observe("aniType") ], ScreensaverSlideElement.prototype, "aniChanged", null), 
__decorate$3([ observe("isAnimate") ], ScreensaverSlideElement.prototype, "isAnimateChanged", null), 
ScreensaverSlideElement = ScreensaverSlideElement_1 = __decorate$3([ customElement("screensaver-slide") ], ScreensaverSlideElement);

var screensaverSlide = {
    get ScreensaverSlideElement() {
        return ScreensaverSlideElement;
    }
};

let Screensaver;

window.addEventListener("load", () => {
    (Screensaver = document.querySelector("screensaver-element")) ? Screensaver.launch().catch(() => {}) : (error$1("Failed to get screensaver reference", "Screensaver.onLoad"), 
    send(TYPE.SS_CLOSE).catch(() => {}));
});

var screensaver = {
    get Screensaver() {
        return Screensaver;
    }
};

class SSPhoto {
    static ignore(e) {
        let t = !1;
        const i = getBool("skip", !1), o = getInt("photoSizing", 0);
        return i && (1 === o || 3 === o) && SSPhoto._isBadAspect(e) && (t = !0), t;
    }
    static _isBadAspect(e) {
        const t = screen.width / screen.height;
        return e < t - .5 || e > t + .5;
    }
    constructor(e, t, i) {
        this._url = t.url, this._photographer = t.author ? t.author : "", this._aspectRatio = parseFloat(t.asp), 
        this._ex = t.ex, this._point = t.point, this._type = i, this._isBad = !1;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e = null;
        switch (this._type) {
          case "flickr":
            if (this._ex) {
                const t = /(\/[^/]*){4}(_.*_)/, i = this._url.match(t);
                i && (e = `https://www.flickr.com/photos/${this._ex}${i[1]}`);
            }
            break;

          case "reddit":
            this._ex && (e = this._ex);
            break;

          case "Google User":
            this._ex && this._ex.url && (e = this._ex.url);
            break;

          default:
            e = this._url;
        }
        null !== e && (event(EVENT.VIEW_PHOTO, this._type), chrome.tabs.create({
            url: e
        }));
    }
}

var ss_photo = {
    SSPhoto: SSPhoto
};

const _photos = [];

let _curIdx = 0;

async function addFromSource(e) {
    const t = await e.getPhotos(), i = t.type;
    let o = 0;
    for (const e of t.photos) {
        const t = parseFloat(e.asp);
        if (!SSPhoto.ignore(t)) {
            const t = new SSPhoto(o, e, i);
            _photos.push(t), o++;
        }
    }
}

function getCount() {
    return _photos.length;
}

function hasUsable() {
    return !_photos.every(e => e.isBad());
}

function get(e) {
    return _photos[e];
}

function getIndex(e) {
    return _photos.indexOf(e);
}

function getNextUsable(e = []) {
    for (let t = 0; t < _photos.length; t++) {
        const i = (t + _curIdx) % _photos.length, o = _photos[i];
        if (!o.isBad() && !e.includes(o)) return _curIdx = i, incCurrentIndex(), o;
    }
    return null;
}

function getCurrentIndex() {
    return _curIdx;
}

function getNextGooglePhotos(e, t) {
    t = t < 0 ? 0 : t;
    const i = [];
    for (let o = 0, n = 0; o < _photos.length; o++) {
        const r = (o + t) % _photos.length, a = _photos[r];
        if (n >= e) break;
        "Google User" === a.getType() && (i.push(a), n++);
    }
    return i;
}

function updateGooglePhotoUrls(e) {
    for (let t = _photos.length - 1; t >= 0; t--) {
        if ("Google User" !== _photos[t].getType()) continue;
        const i = e.findIndex(e => e.ex.id === _photos[t].getEx().id);
        i >= 0 && _photos[t].setUrl(e[i].url);
    }
}

function setCurrentIndex(e) {
    _curIdx = e;
}

function incCurrentIndex() {
    return _curIdx = _curIdx === _photos.length - 1 ? 0 : _curIdx + 1;
}

function shuffle() {
    shuffleArray(_photos);
}

var ss_photos = {
    addFromSource: addFromSource,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get,
    getIndex: getIndex,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex,
    shuffle: shuffle
};

const HIST = {
    arr: [],
    idx: -1,
    max: 10
};

function initialize$1() {
    HIST.max = Math.min(getCount(), Screensaver.getMaxSlideCount());
}

function add(e, t, i) {
    const o = Screensaver.getSlide(t).getPhoto();
    if (null === e && o) {
        const e = HIST.idx, n = HIST.arr.length, r = {
            currentIdx: t,
            replaceIdx: i,
            photoId: getIndex(o),
            photosPos: getCurrentIndex()
        };
        e === n - 1 && (HIST.arr.length > HIST.max && (HIST.arr.shift(), HIST.idx--, HIST.idx = Math.max(HIST.idx, -1)), 
        HIST.arr.push(r));
    }
    HIST.idx++;
}

function clear() {
    HIST.arr = [], HIST.idx = -1;
}

function back() {
    if (HIST.idx <= 0) return null;
    let e = null, t = 2, i = HIST.idx - t;
    if (HIST.idx = i, i < 0) {
        if (HIST.arr.length > HIST.max) return HIST.idx += t, null;
        HIST.idx = -1, t = 1, e = -1, i = 0;
    }
    const o = HIST.arr[i].photosPos, n = HIST.arr[i + t].replaceIdx;
    setCurrentIndex(o), setReplaceIdx(n);
    const r = HIST.arr[i].currentIdx;
    e = null === e ? r : e;
    const a = get(HIST.arr[i].photoId);
    return Screensaver.replacePhoto(a, r), e;
}

var ss_history = {
    initialize: initialize$1,
    add: add,
    clear: clear,
    back: back
};

const VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    transTime: 3e4,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    const t = get$1("transitionTime", {
        base: 30,
        display: 30,
        unit: 0
    });
    VARS.transTime = 1e3 * t.base, setWaitTime(1e3 * t.base), VARS.interactive = getBool("interactive", !1), 
    initialize$1(), window.setTimeout(runShow, e);
}

function setReplaceIdx(e) {
    VARS.replaceIdx = e;
}

function isStarted() {
    return VARS.started;
}

function isInteractive() {
    return VARS.interactive;
}

function isCurrentPair(e) {
    return e === Screensaver.getSelectedSlideIndex() || e === VARS.lastSelected;
}

function togglePaused(e = null) {
    VARS.started && (VARS.paused = !VARS.paused, Screensaver.setPaused(VARS.paused), 
    VARS.paused ? stop() : restart(e));
}

function forward() {
    VARS.started && step();
}

function back$1() {
    if (VARS.started) {
        const e = back();
        null !== e && step(e);
    }
}

function isPaused() {
    return VARS.paused;
}

function stop() {
    window.clearTimeout(VARS.timeOutId);
}

function restart(e = null) {
    const t = get$1("transitionTime");
    t && setWaitTime(1e3 * t.base), runShow(e).catch(() => {});
}

function step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (stop(), restart(e));
}

async function runShow(e = null) {
    if (Screensaver.isNoPhotos()) return;
    const t = Screensaver.getSelectedSlideIndex(), i = Screensaver.getSlideCount();
    let o = null === e ? t : e, n = (o = isStarted() ? o : 0) === i - 1 ? 0 : o + 1;
    if (isStarted() || (n = 0), -1 !== (n = getNextSlideIdx(n))) {
        isStarted() || (VARS.started = !0);
        const i = Screensaver.getSlide(n);
        i && await i.prep(), VARS.interactive && add(e, n, VARS.replaceIdx), VARS.lastSelected = t, 
        Screensaver.setSelectedSlideIndex(n), null === e && (replacePhoto(VARS.replaceIdx), 
        VARS.replaceIdx = VARS.lastSelected);
    }
    VARS.timeOutId = setTimeout(async () => {
        await runShow();
    }, VARS.waitTime);
}

function setWaitTime(e) {
    VARS.waitTime = e, VARS.waitTime = Math.min(2147483647, e);
}

function getNextSlideIdx(e) {
    const t = Screensaver.findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : VARS.transTime), t;
}

function replacePhoto(e) {
    if (e >= 0) {
        if (Screensaver.isSelectedSlideIndex(e)) return;
        const t = Screensaver.getSlideCount();
        if (getCount() <= t) return;
        const i = getNextUsable(Screensaver.getPhotos());
        i && Screensaver.replacePhoto(i, e);
    }
}

var ss_runner = {
    start: start,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

const _MOUSE_START = {
    x: null,
    y: null
};

function addListeners() {
    addListener(onChromeMessage), window.addEventListener("keydown", onKey, !1), window.addEventListener("mousemove", onMouseMove, !1), 
    window.addEventListener("click", onMouseClick, !1), chrome.commands.onCommand.addListener(onKeyCommand);
}

function removeListeners() {
    removeListener(onChromeMessage), window.removeEventListener("keydown", onKey, !1), 
    window.removeEventListener("mousemove", onMouseMove, !1), window.removeEventListener("click", onMouseClick, !1), 
    chrome.commands.onCommand.removeListener(onKeyCommand);
}

function close() {
    send(TYPE.SS_CLOSE).catch(() => {}), setTimeout(() => {
        window.close();
    }, 750);
}

function onKeyCommand(e) {
    isStarted() && isInteractive() && ("ss-toggle-paused" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), forward()) : "ss-back" === e && (event(EVENT$1.KEY_COMMAND, `${e}`), 
    back$1()));
}

function onChromeMessage(e, t, i) {
    return e.message === TYPE.SS_CLOSE.message ? close() : e.message === TYPE.SS_IS_SHOWING.message && i({
        message: "OK"
    }), !1;
}

function onKey(e) {
    const t = e.key;
    if (isStarted() || isInteractive()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || close();
        break;

      default:
        close();
    } else close();
}

function onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), i = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, i) > 10 && close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function onMouseClick() {
    if (isStarted()) {
        const e = Screensaver.getSelectedPhoto();
        getBool("allowPhotoClicks", !0) && e && e.showSource();
    }
    close();
}

var ScreensaverElement_1, ss_events = {
    addListeners: addListeners,
    removeListeners: removeListeners
}, __decorate$4 = function(e, t, i, o) {
    var n, r = arguments.length, a = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, o); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (a = (r < 3 ? n(a) : r > 3 ? n(t, i, a) : n(t, i)) || a);
    return r > 3 && a && Object.defineProperty(t, i, a), a;
};

const errHandler = {
    MAX_COUNT: 168,
    count: 0,
    isUpdating: !1,
    TIME_LIMIT: 3e5,
    lastTime: 0
};

let ScreensaverElement = ScreensaverElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.MAX_SLIDES = 10, this.photos = [], this.aniType = 0, this.paused = !1, 
        this.noPhotos = !1, this.timeLabel = "", this.delayTime = 1500;
    }
    static async setZoom() {
        const e = new ChromePromise();
        try {
            const t = await e.tabs.getZoom();
            (t <= .99 || t >= 1.01) && chrome.tabs.setZoom(1);
        } catch (e) {
            error(e.message, "SS.setZoom");
        }
    }
    static async setupFaceDetect() {
        getBool("panAndScan", !1) && await initialize();
    }
    connectedCallback() {
        super.connectedCallback(), addListeners();
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListeners();
    }
    ready() {
        super.ready(), document.body.style.background = get$1("background", "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)").substring(11), 
        setTimeout(async () => {
            initialize$2(), page("/screensaver.html"), await ScreensaverElement_1.setZoom(), 
            this.setupPhotoTransitions(), this.setupViewType();
        }, 0);
    }
    async launch() {
        try {
            if (await this.loadPhotos()) {
                try {
                    await ScreensaverElement_1.setupFaceDetect();
                } catch (e) {
                    error(e.message, "SS.launch");
                }
                const e = [], t = Math.min(getCount(), this.MAX_SLIDES);
                for (let i = 0; i < t; i++) {
                    const t = getNextUsable();
                    t && e.push(t);
                }
                if (this.set("photos", e), this.repeatTemplate.render(), 0 === e.length) return void this.setNoPhotos();
                send(TYPE.UPDATE_WEATHER).catch(() => {}), this.setupTime(), start(this.delayTime);
            }
        } catch (e) {
            error$1(e.message, "SS.launch"), this.setNoPhotos();
        }
    }
    getMaxSlideCount() {
        return this.MAX_SLIDES;
    }
    getPhotos() {
        return this.photos;
    }
    getSelectedPhoto() {
        let e;
        const t = this.getSelectedSlideIndex();
        return -1 !== t && (e = this.photos[t]), e;
    }
    replacePhoto(e, t) {
        if (e && t >= 0) {
            this.splice("photos", t, 1, e);
            const i = this.getSlide(t);
            i.setUrl(e.getUrl()), i.notifyPath("url");
        }
    }
    findLoadedPhoto(e) {
        this.hasUsablePhoto() || this.replaceAllPhotos();
        const t = this.getSlide(e);
        if (t && t.isPhotoLoaded()) return e;
        for (let t = 0; t < this.photos.length; t++) {
            const i = (t + e) % this.photos.length, o = this.getSlide(i), n = this.photos[i];
            if (!isCurrentPair(i)) {
                if (o.isPhotoLoaded()) return i;
                if (o.isPhotoError() && !n.isBad() && (n.markBad(), !hasUsable())) return this.setNoPhotos(), 
                -1;
            }
        }
        return -1;
    }
    isSelectedSlideIndex(e) {
        let t = !1;
        return this.pages && e === this.pages.selected && (t = !0), t;
    }
    getSelectedSlideIndex() {
        if (this.pages) {
            let e;
            return e = "string" == typeof this.pages.selected ? parseInt(this.pages.selected, 10) : this.pages.selected;
        }
        return -1;
    }
    setSelectedSlideIndex(e) {
        this.pages && (this.pages.selected = e);
    }
    getSlideCount() {
        return this.photos ? this.photos.length : 0;
    }
    getSlide(e) {
        const t = `#slide${e}`;
        return this.shadowRoot.querySelector(t);
    }
    isNoPhotos() {
        return this.noPhotos;
    }
    setNoPhotos() {
        this.set("noPhotos", !0);
    }
    setPaused(e) {
        this.set("paused", e);
    }
    async loadPhotos() {
        let e = getSelectedSources();
        e = e || [];
        for (const t of e) await addFromSource(t);
        return getCount() ? (getBool("shuffle") && shuffle(), !0) : (this.setNoPhotos(), 
        !1);
    }
    setupViewType() {
        let e = getInt("photoSizing", 0);
        4 === e && (e = getRandomInt(0, 3)), this.set("viewType", e);
    }
    setupPhotoTransitions() {
        let e = getInt("photoTransition", 1);
        8 === e && (e = getRandomInt(0, 7)), this.set("aniType", e);
    }
    setupTime() {
        getInt("showTime", 0) > 0 && (this.setTimeLabel(), setInterval(this.setTimeLabel.bind(this), 61e3));
    }
    setTimeLabel() {
        let e = "";
        0 !== getInt("showTime", 0) && (e = ChromeTime.getStringShort(), this.set("timeLabel", e));
    }
    pausedChanged(e, t) {
        void 0 !== t && (e ? (this.$.pauseImage.classList.add("fadeOut"), this.$.playImage.classList.remove("fadeOut")) : (this.$.playImage.classList.add("fadeOut"), 
        this.$.pauseImage.classList.remove("fadeOut")));
    }
    hasUsablePhoto() {
        let e = !1;
        for (let t = 0; t < this.photos.length; t++) {
            const i = this.photos[t];
            if (!isCurrentPair(t) && !i.isBad()) {
                e = !0;
                break;
            }
        }
        return e;
    }
    replaceAllPhotos() {
        for (let e = 0; e < this.photos.length; e++) {
            if (isCurrentPair(e)) continue;
            const t = getNextUsable(this.photos);
            if (!t) break;
            this.replacePhoto(t, e);
        }
        clear();
    }
    updateAllUrls(e) {
        for (let t = 0; t < this.photos.length; t++) {
            const i = this.photos[t];
            if ("Google User" === i.getType()) {
                const o = this.getSlide(t), n = e.findIndex(e => e.ex.id === i.getEx().id);
                n >= 0 && o.setUrl(e[n].url);
            }
        }
    }
    async onImageError(e) {
        if (errHandler.isUpdating) return;
        errHandler.isUpdating = !0;
        const t = e.detail.index, i = this.photos[t];
        if ("Google User" === i.getType()) try {
            if (!navigator.onLine) return void (errHandler.isUpdating = !1);
            if (Date.now() - errHandler.lastTime < errHandler.TIME_LIMIT) return void (errHandler.isUpdating = !1);
            if (errHandler.count++, errHandler.count >= errHandler.MAX_COUNT) return void (errHandler.isUpdating = !1);
            errHandler.lastTime = Date.now();
            const e = i.getUrl();
            if (await isGoogleSourceOrigin(e)) try {
                if (403 !== (await fetch(e, {
                    method: "get"
                })).status) return void (errHandler.isUpdating = !1);
            } catch (e) {
                return void (errHandler.isUpdating = !1);
            }
            let t = get$1("transitionTime", {
                base: 30,
                display: 30,
                unit: 0
            });
            t = 1e3 * t.base;
            let o = Math.round(ChromeTime.MSEC_IN_HOUR / t);
            o = Math.max(o, 50);
            const n = getNextGooglePhotos(o = 1 === errHandler.count ? Math.min(o, 50) : Math.min(o, 300), getIndex(i)), r = [];
            for (const e of n) {
                const t = e.getEx();
                if (t) {
                    const e = t.id;
                    -1 === r.indexOf(e) && r.push(e);
                }
            }
            const a = await GoogleSource.loadPhotos(r);
            if (updateGooglePhotoUrls(a), this.updateAllUrls(a), !await GoogleSource.updateBaseUrls(a)) return error("Failed to save new urls", "SS.onImageError"), 
            errHandler.count = errHandler.MAX_COUNT + 1, void (errHandler.isUpdating = !0);
            errHandler.isUpdating = !1;
        } catch (e) {
            return error(e.message, "SS.onImageError"), errHandler.count = errHandler.MAX_COUNT + 1, 
            void (errHandler.isUpdating = !0);
        }
    }
    static get template() {
        return html`<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  /* Added programmatically */
  .fadeOut {
    animation: fadeOut 1s 2s;
    animation-fill-mode: both;
  }

  @keyframes fadeOut {
    from {
      opacity: 1.0;
    }
    to {
      opacity: 0.0;
    }
  }

  .vcr {
    position: fixed;
    width: 15vh;
    height: 15vh;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.0;
  }

  .noPhotos {
    font-size: 5vh;
    font-weight: 600;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    color: rgba(48, 63, 159, 1);
    opacity: .8;
  }

</style>

<div id="mainContainer" class="flex" hidden$="[[noPhotos]]">
  <neon-animated-pages id="pages" class="fit" animate-initial-selection>
    <template is="dom-repeat" id="repeatTemplate" as="photo" items="[[photos]]">
      <screensaver-slide class="fit" id="slide[[index]]" view-type="[[viewType]]" ani-type="[[aniType]]"
                         photo="[[photo]]" index="[[index]]" time-label="[[timeLabel]]" on-image-error="onImageError">
      </screensaver-slide>
    </template>
  </neon-animated-pages>
</div>

<div class="noPhotos" hidden$="[[!noPhotos]]">[[localize('no_photos')]]</div>

<iron-image id="pauseImage" class="vcr" src="../images/pause.png" sizing="contain" preload
            hidden$="[[!paused]]"></iron-image>
<iron-image id="playImage" class="vcr" src="../images/play.png" sizing="contain" preload
            hidden$="[[paused]]"></iron-image>
`;
    }
};

__decorate$4([ property({
    type: Array
}) ], ScreensaverElement.prototype, "photos", void 0), __decorate$4([ property({
    type: Number
}) ], ScreensaverElement.prototype, "aniType", void 0), __decorate$4([ property({
    type: Boolean,
    observer: "pausedChanged"
}) ], ScreensaverElement.prototype, "paused", void 0), __decorate$4([ property({
    type: Boolean
}) ], ScreensaverElement.prototype, "noPhotos", void 0), __decorate$4([ property({
    type: String
}) ], ScreensaverElement.prototype, "timeLabel", void 0), __decorate$4([ query("#repeatTemplate") ], ScreensaverElement.prototype, "repeatTemplate", void 0), 
__decorate$4([ query("#pages") ], ScreensaverElement.prototype, "pages", void 0), 
ScreensaverElement = ScreensaverElement_1 = __decorate$4([ customElement("screensaver-element") ], ScreensaverElement);

var screensaverElement = {
    get ScreensaverElement() {
        return ScreensaverElement;
    }
};

export { face_detect as $faceDetect, screensaver as $screensaver, screensaverElement as $screensaverElement, screensaverSlide as $screensaverSlide, spinDownAnimation as $spinDownAnimation, spinUpAnimation as $spinUpAnimation, ss_events as $ssEvents, ss_history as $ssHistory, ss_photo as $ssPhoto, ss_photos as $ssPhotos, ss_runner as $ssRunner, weatherElement as $weatherElement, SSPhoto, Screensaver, ScreensaverElement, ScreensaverSlideElement, SpinDownAnimationElement, SpinUpAnimationElement, WeatherElement, add, addFromSource, addListeners, back, back$1, clear, detectAll, forward, get, getCount, getCurrentIndex, getIndex, getNextGooglePhotos, getNextUsable, hasUsable, incCurrentIndex, initialize, initialize$1, isCurrentPair, isInteractive, isStarted, removeListeners, setCurrentIndex, setReplaceIdx, shuffle, start, togglePaused, updateGooglePhotoUrls };