import { Polymer, NeonAnimationBehavior, html$1 as html, resolveUrl, get as get$2, getInt, getBool, getRandomInt, getRandomFloat, shuffleArray, isWhiteSpace, NeonAnimatableBehavior, DEF_WEATHER, LocalizeBehavior, EVENT$1 as EVENT, initialize as initialize$3, SS_CLOSE, SS_IS_SHOWING, UPDATE_WEATHER, event, error, EVENT as EVENT$1, page, $timeDefault as ChromeTime, localize, send, listen, getSelectedSources, GoogleSource, error$1 } from "./shared_bundle_4.js";

const SpinDownAnimation = Polymer({
    is: "spin-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)"
        }, {
            transform: "scale(0) rotate(0)"
        } ], this.timingFromConfig(e)), this._effect;
    }
});

var spinDownAnimation = {
    default: SpinDownAnimation
};

const SpinUpAnimation = Polymer({
    is: "spin-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)"
        }, {
            transform: "scale(1) rotate(1.0turn)"
        } ], this.timingFromConfig(e)), this._effect;
    }
});

var spinUpAnimation = {
    default: SpinUpAnimation
};

Polymer({
    _template: html`<!--suppress RequiredAttributes -->
<style>
  :host {
    display: inline-block;
    overflow: hidden;
    position: relative;
  }

  #baseURIAnchor {
    display: none;
  }

  #sizedImgDiv {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    overflow: hidden;
    display: none;
  }

  #img {
    display: block;
    width: var(--iron-image-width, auto);
    height: var(--iron-image-height, auto);
  }

  :host([sizing]) #sizedImgDiv {
    display: block;
  }

  :host([sizing]) #img {
    display: none;
  }

  #placeholder {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;

    background-color: inherit;
    opacity: 1;

    @apply --iron-image-placeholder;
  }

  #placeholder.faded-out {
    transition: opacity 0.5s linear;
    opacity: 0;
  }
</style>

<a id="baseURIAnchor" href="#"></a>
<div id="sizedImgDiv" role="img" hidden$="[[_computeImgDivHidden(sizing)]]"
     aria-hidden$="[[_computeImgDivARIAHidden(alt)]]" aria-label$="[[_computeImgDivARIALabel(alt, src)]]"></div>
<!--suppress HtmlRequiredAltAttribute -->
<img id="img" alt$="[[alt]]" hidden$="[[_computeImgHidden(sizing)]]" crossorigin$="[[crossorigin]]" on-load="_imgOnLoad"
     on-error="_imgOnError">
<div id="placeholder" hidden$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]"
     class$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>

<app-localstorage-document key="panAndScan" data="{{isAnimate}}" storage="window.localStorage">
</app-localstorage-document>

`,
    is: "iron-image-ken-burns",
    properties: {
        isAnimate: {
            type: Boolean,
            value: !1,
            notify: !0,
            observer: "_isAnimateChanged"
        },
        animation: {
            type: Object,
            value: null
        },
        src: {
            type: String,
            value: ""
        },
        alt: {
            type: String,
            value: null
        },
        crossorigin: {
            type: String,
            value: null
        },
        preventLoad: {
            type: Boolean,
            value: !1
        },
        sizing: {
            type: String,
            value: null,
            reflectToAttribute: !0
        },
        position: {
            type: String,
            value: "center"
        },
        preload: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: String,
            value: null,
            observer: "_placeholderChanged"
        },
        fade: {
            type: Boolean,
            value: !1
        },
        loaded: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        loading: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        error: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        width: {
            observer: "_widthChanged",
            type: Number,
            value: null
        },
        height: {
            observer: "_heightChanged",
            type: Number,
            value: null
        }
    },
    observers: [ "_transformChanged(sizing, position)", "_loadStateObserver(src, preventLoad)" ],
    created: function() {
        this._resolvedSrc = "";
    },
    _imgOnLoad: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this._setLoading(!1), this._setLoaded(!0), 
        this._setError(!1));
    },
    _imgOnError: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", this._setLoading(!1), this._setLoaded(!1), 
        this._setError(!0));
    },
    _computePlaceholderHidden: function() {
        return !this.preload || !this.fade && !this.loading && this.loaded;
    },
    _computePlaceholderClassName: function() {
        return this.preload && this.fade && !this.loading && this.loaded ? "faded-out" : "";
    },
    _computeImgDivHidden: function() {
        return !this.sizing;
    },
    _computeImgDivARIAHidden: function() {
        return "" === this.alt ? "true" : void 0;
    },
    _computeImgDivARIALabel: function() {
        if (null !== this.alt) return this.alt;
        if ("" === this.src) return "";
        return this._resolveSrc(this.src).replace(/[?|#].*/g, "").split("/").pop();
    },
    _computeImgHidden: function() {
        return !!this.sizing;
    },
    _widthChanged: function() {
        this.style.width = isNaN(this.width) ? this.width : this.width + "px";
    },
    _heightChanged: function() {
        this.style.height = isNaN(this.height) ? this.height : this.height + "px";
    },
    _loadStateObserver: function(e, t) {
        const i = this._resolveSrc(e);
        i !== this._resolvedSrc && (this._resolvedSrc = "", this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", "" === e || t ? (this._setLoading(!1), 
        this._setLoaded(!1), this._setError(!1)) : (this._resolvedSrc = i, this.$.img.src = this._resolvedSrc, 
        this.$.sizedImgDiv.style.backgroundImage = 'url("' + this._resolvedSrc + '")', this._setLoading(!0), 
        this._setLoaded(!1), this._setError(!1)));
    },
    _placeholderChanged: function() {
        this.$.placeholder.style.backgroundImage = this.placeholder ? 'url("' + this.placeholder + '")' : "";
    },
    _transformChanged: function() {
        const e = this.$.sizedImgDiv.style, t = this.$.placeholder.style;
        e.backgroundSize = t.backgroundSize = this.sizing, e.backgroundPosition = t.backgroundPosition = this.sizing ? this.position : "", 
        e.backgroundRepeat = t.backgroundRepeat = this.sizing ? "no-repeat" : "";
    },
    _resolveSrc: function(e) {
        let t = resolveUrl(e, this.$.baseURIAnchor.href);
        return "/" === t[0] && (t = (location.origin || location.protocol + "//" + location.host) + t), 
        t;
    },
    _isAnimateChanged: function(e) {
        void 0 !== e && (e || this.animation && (this.animation.cancel(), this.set("animation", null)));
    },
    startAnimation: function() {
        if (!this.isAnimate) return;
        this.animation && this.animation.cancel();
        const e = 1e3 * get$2("transitionTime", {
            base: 30,
            display: 30,
            unit: 0
        }).base;
        let t = 1e3;
        4 === getInt("photoTransition", 0) && (t = 2e3);
        const i = this.width, s = this.height, o = getRandomInt(0, 1) ? -1 : 1, a = getRandomInt(0, 1) ? -1 : 1, n = 1 + getRandomFloat(.5, .9), r = .2 * (n - 1), l = o * i * getRandomFloat(0, r), h = a * s * getRandomFloat(0, r), d = [ {
            transform: "scale(1.0) translateX(0vw) translateY(0vh)"
        }, {
            transform: `scale(${n}) translateX(${Math.round(l) + "px"}) translateY(${Math.round(h) + "px"})`
        } ], c = {
            delay: t,
            duration: e - t,
            iterations: 1,
            easing: "ease-in-out",
            fill: "forwards"
        };
        let u = this.$.img;
        this.sizing && (u = this.$.sizedImgDiv), this.set("animation", u.animate(d, c));
    }
});

const SlideAnimatable = Polymer({
    _template: html`<style>
  :host {
    display: block;
  }
</style>
<slot></slot>
`,
    is: "slide-animatable",
    behaviors: [ NeonAnimatableBehavior ],
    properties: {
        animationConfig: {
            type: Object,
            value: function() {
                return {
                    entry: {
                        name: "fade-in-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    },
                    exit: {
                        name: "fade-out-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    }
                };
            }
        },
        aniType: {
            type: Number,
            observer: "_aniChanged"
        }
    },
    _aniChanged: function(e) {
        let t, i, s = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", i = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", i = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", i = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", i = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", i = "spin-down-animation", s = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", i = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", i = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", i = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", i = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = s, 
        this.animationConfig.exit.name = i, this.animationConfig.exit.timing.duration = s;
    }
});

var slideAnimatable = {
    default: SlideAnimatable
};

const WeatherElement = Polymer({
    _template: html`<!--
  Need to include globally too
  see: https://bugs.chromium.org/p/chromium/issues/detail?id=336876
  -->
<link rel="stylesheet" href="../../css/weather-icons.min.css">

<style include="iron-flex iron-flex-alignment"></style>
<style include="shared-styles"></style>
<style>
  :host {
    display: block;
    position: relative;
  }

  :host .temp {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0 0 0 16px;
  }

  :host .icon {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0;
  }

</style>

<div class="horizontal layout center" hidden$="[[!show]]">
  <!--suppress HtmlUnknownTarget -->
  <!--suppress HtmlRequiredAltAttribute -->
  <!--<img class="image" src="[[weather.iconUrl]]">-->
  <i id="weatherIcon" class="icon wi"></i>
  <paper-item class="temp">[[weather.temp]]</paper-item>
</div>

<app-localstorage-document key="currentWeather" data="{{weather}}" storage="window.localStorage">
</app-localstorage-document>
<app-localstorage-document key="showCurrentWeather" data="{{show}}" storage="window.localStorage">
</app-localstorage-document>

`,
    is: "weather-element",
    properties: {
        show: {
            type: Boolean,
            value: !1,
            notify: !0
        },
        weather: {
            type: Object,
            value: DEF_WEATHER,
            observer: "_weatherChanged"
        }
    },
    _weatherChanged: function(e, t) {
        let i = null;
        if (void 0 !== t && (i = "wi-owm-" + t.dayNight + t.id), void 0 !== e) {
            const t = "wi-owm-" + e.dayNight + e.id;
            i ? this.$.weatherIcon.classList.replace(i, t) : this.$.weatherIcon.classList.add(t);
        }
    }
});

var weatherElement = {
    default: WeatherElement
};

class SSPhoto {
    static ignore(e) {
        let t = !1;
        const i = getBool("skip", !1), s = getInt("photoSizing", 0);
        return i && (1 === s || 3 === s) && SSPhoto._isBadAspect(e) && (t = !0), t;
    }
    static _isBadAspect(e) {
        const t = screen.width / screen.height;
        return e < t - .5 || e > t + .5;
    }
    constructor(e, t, i) {
        this._id = e, this._url = t.url, this._photographer = t.author ? t.author : "", 
        this._type = i, this._aspectRatio = parseFloat(t.asp), this._ex = t.ex, this._point = t.point, 
        this._isBad = !1;
    }
    getId() {
        return this._id;
    }
    setId(e) {
        this._id = e;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e, t, i = null;
        switch (this._type) {
          case "flickr":
            this._ex && (e = /(\/[^/]*){4}(_.*_)/, t = this._url.match(e), i = `https://www.flickr.com/photos/${this._ex}${t[1]}`);
            break;

          case "reddit":
            this._ex && (i = this._ex);
            break;

          case "Google User":
            this._ex && this._ex.url && (i = this._ex.url);
            break;

          default:
            i = this._url;
        }
        null !== i && (event(EVENT.VIEW_PHOTO, this._type), chrome.tabs.create({
            url: i
        }));
    }
}

var ss_photo = {
    default: SSPhoto
};

const _photos = [];

let _curIdx = 0;

async function addFromSource(e) {
    const t = await e.getPhotos(), i = t.type;
    let s = 0;
    for (const e of t.photos) {
        const t = parseFloat(e.asp);
        if (!SSPhoto.ignore(t)) {
            const t = new SSPhoto(s, e, i);
            _photos.push(t), s++;
        }
    }
}

function getCount() {
    return _photos.length;
}

function hasUsable() {
    return !_photos.every(e => e.isBad());
}

function get(e) {
    return _photos[e];
}

function getNextUsable(e) {
    for (let t = 0; t < _photos.length; t++) {
        const i = (t + _curIdx) % _photos.length, s = _photos[i];
        if (!s.isBad() && !e.includes(s)) return _curIdx = i, incCurrentIndex(), s;
    }
    return null;
}

function getCurrentIndex() {
    return _curIdx;
}

function getNextGooglePhotos(e, t) {
    const i = [];
    let s = 0;
    for (let o = 0; o < _photos.length; o++) {
        const a = (o + t) % _photos.length, n = _photos[a];
        if (s >= e) break;
        "Google User" === n.getType() && (i.push(n), s++);
    }
    return i;
}

function updateGooglePhotoUrls(e) {
    for (let t = _photos.length - 1; t >= 0; t--) {
        if ("Google User" !== _photos[t].getType()) continue;
        const i = e.findIndex(e => e.ex.id === _photos[t].getEx().id);
        i >= 0 && _photos[t].setUrl(e[i].url);
    }
}

function setCurrentIndex(e) {
    _curIdx = e;
}

function incCurrentIndex() {
    return _curIdx = _curIdx === _photos.length - 1 ? 0 : _curIdx + 1;
}

function shuffle() {
    shuffleArray(_photos), _photos.forEach((e, t) => {
        e.setId(t);
    });
}

var ss_photos = {
    addFromSource: addFromSource,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex,
    shuffle: shuffle
};

let _transTime = 3e4;

function initialize() {
    const e = get$2("transitionTime", {
        base: 30,
        display: 30,
        unit: 0
    });
    _transTime = 1e3 * e.base;
}

function getNext(e) {
    const t = findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : _transTime), t;
}

function replacePhoto(e) {
    if (e >= 0) {
        if (isSelectedIndex(e)) return;
        const t = getCount$1();
        if (getCount() <= t) return;
        const i = getNextUsable(getPhotos());
        if (i) {
            get$1(e).setPhoto(i);
        }
    }
}

var ss_photo_finder = {
    initialize: initialize,
    getNext: getNext,
    replacePhoto: replacePhoto
};

const _history = {
    arr: [],
    idx: -1,
    max: 10
};

function initialize$1() {
    _history.max = Math.min(getCount(), _history.max);
}

function add(e, t, i) {
    if (null === e) {
        const e = get$1(t), s = _history.idx, o = _history.arr.length, a = {
            viewsIdx: t,
            replaceIdx: i,
            photoId: e.photo.getId(),
            photosPos: getCurrentIndex()
        };
        s === o - 1 && (_history.arr.length > _history.max && (_history.arr.shift(), _history.idx--, 
        _history.idx = Math.max(_history.idx, -1)), _history.arr.push(a));
    }
    _history.idx++;
}

function clear() {
    _history.arr = [], _history.idx = -1;
}

function back() {
    if (_history.idx <= 0) return null;
    let e = null, t = 2, i = _history.idx - t;
    if (_history.idx = i, i < 0) {
        if (_history.arr.length > _history.max) return _history.idx += t, null;
        _history.idx = -1, t = 1, e = -1, i = 0;
    }
    const s = _history.arr[i].photosPos, o = _history.arr[i + t].replaceIdx;
    setCurrentIndex(s), setReplaceIdx(o);
    const a = _history.arr[i].viewsIdx, n = _history.arr[i].photoId;
    e = null === e ? a : e;
    const r = get$1(a), l = get(n);
    return r.setPhoto(l), r.render(), e;
}

var ss_history = {
    initialize: initialize$1,
    add: add,
    clear: clear,
    back: back
};

function initialize$2() {
    getInt("showTime", 0) > 0 && setInterval(setTime, 61e3);
}

function setTime() {
    let e = "";
    0 !== getInt("showTime", 0) && isStarted() && (e = ChromeTime.getStringShort()), 
    setTimeLabel(e);
}

var ss_time = {
    initialize: initialize$2,
    setTime: setTime
};

const _VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    setWaitTime(1e3 * get$2("transitionTime", {
        base: 30,
        display: 30,
        unit: 0
    }).base), _VARS.interactive = getBool("interactive", !1), initialize$1(), window.setTimeout(_runShow, e);
}

function getWaitTime() {
    return _VARS.waitTime;
}

function setWaitTime(e) {
    _VARS.waitTime = e, _VARS.waitTime = Math.min(2147483647, e);
}

function setLastSelected(e) {
    _VARS.lastSelected = e;
}

function setReplaceIdx(e) {
    _VARS.replaceIdx = e;
}

function isStarted() {
    return _VARS.started;
}

function isInteractive() {
    return _VARS.interactive;
}

function isPaused() {
    return _VARS.paused;
}

function isCurrentPair(e) {
    return e === getSelectedIndex() || e === _VARS.lastSelected;
}

function togglePaused(e = null) {
    _VARS.started && (_VARS.paused = !_VARS.paused, setPaused(_VARS.paused), _VARS.paused ? _stop() : _restart(e));
}

function forward() {
    _VARS.started && _step();
}

function back$1() {
    if (_VARS.started) {
        const e = back();
        null !== e && _step(e);
    }
}

function _stop() {
    window.clearTimeout(_VARS.timeOutId);
}

function _restart(e = null) {
    const t = get$2("transitionTime");
    t && setWaitTime(1e3 * t.base), _runShow(e);
}

function _step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (_stop(), _restart(e));
}

function _runShow(e = null) {
    if (isNoPhotos()) return;
    const t = getSelectedIndex(), i = getCount$1();
    let s = null === e ? t : e, o = (s = isStarted() ? s : 0) === i - 1 ? 0 : s + 1;
    if (isStarted() || (o = 0), -1 !== (o = getNext(o))) {
        isStarted() || (_VARS.started = !0, setTime());
        const i = get$1(o);
        i.render(), i.image.startAnimation(), add(e, o, _VARS.replaceIdx), _VARS.lastSelected = t, 
        setSelectedIndex(o), null === e && (replacePhoto(_VARS.replaceIdx), _VARS.replaceIdx = _VARS.lastSelected);
    }
    _VARS.timeOutId = window.setTimeout(() => {
        _runShow();
    }, _VARS.waitTime);
}

var ss_runner = {
    start: start,
    getWaitTime: getWaitTime,
    setWaitTime: setWaitTime,
    setLastSelected: setLastSelected,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isPaused: isPaused,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

class SSView {
    static showTime() {
        return getBool("showTime");
    }
    static _dirtySet(e, t, i) {
        e.set(t, i), e.notifyPath(t);
    }
    constructor(e) {
        this.photo = e, this.image = null, this.author = null, this.time = null, this.location = null, 
        this.weather = null, this.model = null, this.url = e.getUrl(), this.authorLabel = "", 
        this.locationLabel = "";
    }
    setUrl(e = null) {
        this.url = e || this.photo.getUrl(), SSView._dirtySet(this.model, "view.url", this.url);
    }
    markPhotoBad() {
        this.photo && this.photo.markBad();
    }
    setElements(e, t, i, s, o, a) {
        this.image = e, this.author = t, this.time = i, this.location = s, this.weather = o, 
        this.model = a, this._setTimeStyle(), this.setPhoto(this.photo);
    }
    setPhoto(e) {
        this.photo = e, this.setUrl(), this._setAuthorLabel(), this._setLocationLabel();
    }
    render() {}
    isError() {
        return !this.image || this.image.error;
    }
    isLoaded() {
        return !!this.image && this.image.loaded;
    }
    _hasAuthor() {
        const e = this.photo.getPhotographer();
        return !isWhiteSpace(e);
    }
    _hasAuthorLabel() {
        return !isWhiteSpace(this.authorLabel);
    }
    _hasLocation() {
        return !!this.photo.getPoint();
    }
    _hasLocationLabel() {
        return !isWhiteSpace(this.locationLabel);
    }
    _setTimeStyle() {
        getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = "300");
    }
    _setAuthorLabel() {
        this.authorLabel = "", SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel);
        const e = this.photo.getType(), t = this.photo.getPhotographer();
        let i = e;
        const s = e.search("User");
        (getBool("showPhotog") || -1 === s) && (-1 !== s && (i = e.substring(0, s - 1)), 
        this._hasAuthor() ? this.authorLabel = `${t} / ${i}` : this.authorLabel = `${localize("photo_from")} ${i}`, 
        SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel));
    }
    _setLocationLabel() {
        this.locationLabel = "", SSView._dirtySet(this.model, "view.locationLabel", this.locationLabel);
    }
}

var ss_view = {
    default: SSView
};

class SSViewZoom extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
    }
}

var ss_view_zoom = {
    default: SSViewZoom
};

class SSViewFrame extends SSView {
    static _setLabelStyle(e, t, i, s) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = "1.0", 
        e.fontSize = "2.5vh", e.fontWeight = "400";
        const o = t / screen.width * 100, a = (100 - o) / 2;
        s ? (e.left = a + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = a + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = o - 1 + "vw";
        const n = (100 - i / screen.height * 100) / 2;
        e.bottom = n + 1.1 + "vh";
    }
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.author.style, t = this.location.style, i = this.weather.style, s = this.time.style, o = this.image, a = o.style, n = o.$.img.style, r = this.photo.getAspectRatio(), l = .005 * screen.height, h = .05 * screen.height, d = .025 * screen.height, c = Math.min((screen.width - 2 * d - 2 * l) / r, screen.height - 2 * d - l - h), u = c * r, g = u + 2 * l, m = c + h + l;
        n.height = c + "px", n.width = u + "px", n.top = screen.height / 2 + "px", n.left = screen.width / 2 + "px", 
        o.height = c, o.width = u, a.top = (screen.height - m) / 2 + "px", a.left = (screen.width - g) / 2 + "px", 
        a.border = "0.5vh ridge WhiteSmoke", a.borderBottom = "5vh solid WhiteSmoke", a.borderRadius = "1.5vh", 
        a.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", SSViewFrame._setLabelStyle(e, g, m, !1), 
        SSViewFrame._setLabelStyle(t, g, m, !0);
        const p = (100 - m / screen.height * 100) / 2, _ = g / screen.width * 100, f = (100 - _) / 2;
        s.right = f + 1 + "vw", s.textAlign = "right", s.bottom = p + 5 + "vh", i.left = f + 1 + "vw", 
        i.textAlign = "left", i.bottom = p + 6.5 + "vh";
        const w = _ / 2;
        this._hasLocationLabel() && (e.maxWidth = w - 1 + "vw"), this._hasAuthorLabel() && (t.maxWidth = w - 1 + "vw");
    }
}

var ss_view_frame = {
    default: SSViewFrame
};

class SSViewFull extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.image.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
}

var ss_view_full = {
    default: SSViewFull
};

const _SCREEN_AR = screen.width / screen.height;

class SSViewLetterbox extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.photo.getAspectRatio(), t = this.image, i = t.style, s = t.$.img.style, o = this.author.style, a = this.location.style, n = this.weather.style, r = this.time.style;
        let l = e / _SCREEN_AR * 100;
        const h = (100 - (l = Math.min(l, 100))) / 2;
        let d = _SCREEN_AR / e * 100;
        const c = (100 - (d = Math.min(d, 100))) / 2, u = Math.round(d / 100 * screen.height), g = Math.round(l / 100 * screen.width);
        t.height = u, t.width = g, s.height = u + "px", s.width = g + "px", i.top = (screen.height - u) / 2 + "px", 
        i.left = (screen.width - g) / 2 + "px", o.textAlign = "right", a.textAlign = "left", 
        n.textAlign = "left", o.right = h + 1 + "vw", o.bottom = c + 1 + "vh", o.width = l - .5 + "vw", 
        a.left = h + 1 + "vw", a.bottom = c + 1 + "vh", a.width = l - .5 + "vw", n.left = h + 1 + "vw", 
        n.bottom = c + 3.5 + "vh", n.width = l - .5 + "vw", r.right = h + 1 + "vw", r.bottom = c + 3.5 + "vh", 
        SSView.showTime() && (o.textOverflow = "ellipsis", o.whiteSpace = "nowrap");
        const m = l / 2;
        this._hasLocationLabel() && (o.maxWidth = m - 1.1 + "vw"), this._hasAuthorLabel() && (a.maxWidth = m - 1.1 + "vw");
    }
}

var ss_view_letterbox = {
    default: SSViewLetterbox
};

function create(e, t) {
    switch (t) {
      case Type.LETTERBOX:
        return new SSViewLetterbox(e);

      case Type.ZOOM:
        return new SSViewZoom(e);

      case Type.FRAME:
        return new SSViewFrame(e);

      case Type.FULL:
        return new SSViewFull(e);

      default:
        return error(`Bad SSView type: ${t}`, "SSView.createView"), new SSViewLetterbox(e);
    }
}

var ss_view_factory = {
    create: create
};

const Type = {
    UNDEFINED: -1,
    LETTERBOX: 0,
    ZOOM: 1,
    FRAME: 2,
    FULL: 3,
    RANDOM: 4
}, _MAX_VIEWS = 10, _views = [];

let _pages = null, _type = Type.UNDEFINED;

function _setViewType() {
    (_type = getInt("photoSizing", 0)) === Type.RANDOM && (_type = getRandomInt(0, 3));
    let e = "contain";
    switch (_type) {
      case Type.ZOOM:
        e = "cover";
        break;

      case Type.LETTERBOX:
      case Type.FRAME:
      case Type.FULL:
        e = null;
    }
    setSizingType(e);
}

function create$1(e) {
    _pages = e.$.pages, _setViewType();
    const t = Math.min(getCount(), _MAX_VIEWS);
    for (let e = 0; e < t; e++) {
        const t = create(get(e), _type);
        _views.push(t);
    }
    setCurrentIndex(t), e.set("_views", _views), e.$.repeatTemplate.render(), _views.forEach((t, i) => {
        const s = _pages.querySelector("#view" + i), o = s.querySelector(".image"), a = s.querySelector(".author"), n = s.querySelector(".time"), r = s.querySelector(".location"), l = s.querySelector(".weather"), h = e.$.repeatTemplate.modelForElement(s);
        t.setElements(o, a, n, r, l, h);
    });
}

function getType() {
    return _type === Type.UNDEFINED && _setViewType(), _type;
}

function getCount$1() {
    return _views.length;
}

function get$1(e) {
    return _views[e];
}

function getSelectedIndex() {
    if (_pages) {
        let e;
        return e = "string" == typeof _pages.selected ? parseInt(_pages.selected, 10) : _pages.selected;
    }
}

function setSelectedIndex(e) {
    _pages.selected = e;
}

function getPhotos() {
    const e = [];
    for (const t of _views) e.push(t.photo);
    return e;
}

function isSelectedIndex(e) {
    let t = !1;
    return _pages && e === _pages.selected && (t = !0), t;
}

function hasPhoto(e) {
    let t = !1;
    for (const i of _views) if (i.photo.getId() === e.getId()) {
        t = !0;
        break;
    }
    return t;
}

function hasUsable$1() {
    let e = !1;
    for (let t = 0; t < _views.length; t++) {
        const i = _views[t];
        if (!isCurrentPair(t) && !i.photo.isBad()) {
            e = !0;
            break;
        }
    }
    return e;
}

function replaceAll() {
    for (let e = 0; e < _views.length; e++) {
        if (isCurrentPair(e)) continue;
        const t = _views[e], i = getNextUsable(getPhotos());
        if (!i) break;
        t.setPhoto(i);
    }
    clear();
}

function findLoadedPhoto(e) {
    if (hasUsable$1() || replaceAll(), void 0 !== _views[e] && _views[e].isLoaded()) return e;
    for (let t = 0; t < _views.length; t++) {
        const i = (t + e) % _views.length, s = _views[i];
        if (!isCurrentPair(i)) {
            if (s.isLoaded()) return i;
            if (s.isError() && !s.photo.isBad() && (s.photo.markBad(), !hasUsable())) return setNoPhotos(), 
            -1;
        }
    }
    return -1;
}

var ss_views = {
    Type: Type,
    create: create$1,
    getType: getType,
    getCount: getCount$1,
    get: get$1,
    getSelectedIndex: getSelectedIndex,
    setSelectedIndex: setSelectedIndex,
    getPhotos: getPhotos,
    isSelectedIndex: isSelectedIndex,
    hasPhoto: hasPhoto,
    hasUsable: hasUsable$1,
    replaceAll: replaceAll,
    findLoadedPhoto: findLoadedPhoto
};

const _MOUSE_START = {
    x: null,
    y: null
};

function _close() {
    send(SS_CLOSE).catch(() => {}), setTimeout(() => {
        window.close();
    }, 750);
}

function _onKeyCommand(e) {
    isInteractive() && ("ss-toggle-paused" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), forward()) : "ss-back" === e && (event(EVENT$1.KEY_COMMAND, `${e}`), 
    back$1()));
}

function _onChromeMessage(e, t, i) {
    return e.message === SS_CLOSE.message ? _close() : e.message === SS_IS_SHOWING.message && i({
        message: "OK"
    }), !1;
}

function _onKey(e) {
    const t = e.key;
    if (isStarted()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || _close();
        break;

      default:
        _close();
    } else _close();
}

function _onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), i = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, i) > 10 && _close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function _onMouseClick() {
    if (isStarted()) {
        const e = getSelectedIndex();
        if (getBool("allowPhotoClicks") && void 0 !== e) {
            get$1(e).photo.showSource();
        }
    }
    _close();
}

async function build() {
    const e = await _loadPhotos();
    return e && (createPages(), initialize()), Promise.resolve(e);
}

async function _loadPhotos() {
    let e = getSelectedSources();
    e = e || [];
    for (const t of e) await addFromSource(t);
    return getCount() ? (getBool("shuffle") && shuffle(), Promise.resolve(!0)) : (setNoPhotos(), 
    Promise.resolve(!1));
}

listen(_onChromeMessage), window.addEventListener("keydown", _onKey, !1), window.addEventListener("mousemove", _onMouseMove, !1), 
window.addEventListener("click", _onMouseClick, !1), chrome.commands.onCommand.addListener(_onKeyCommand);

var ss_builder = {
    build: build
};

const _errHandler = {
    MAX_COUNT: 168,
    count: 0,
    isUpdating: !1,
    TIME_LIMIT: 3e5,
    lastTime: 0
};

let createPages = null, setSizingType = null, isNoPhotos = null, setNoPhotos = null, setTimeLabel = null, setPaused = null;

const Screensaver = Polymer({
    _template: html`<!--suppress CssUnresolvedCustomProperty -->
<style include="iron-flex iron-flex-alignment iron-positioning"></style>
<style include="shared-styles"></style>
<style>

  /* Added programmatically */
  .fadeOut {
    animation: fadeOut 1s 2s;
    animation-fill-mode: both;
  }

  @keyframes fadeOut {
    from {
      opacity: 1.0;
    }
    to {
      opacity: 0.0;
    }
  }

  .vcr {
    position: fixed;
    width: 15vh;
    height: 15vh;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.0;
  }

  .time {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    right: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .weather {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    left: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .author {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    right: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .location {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    left: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .noPhotos {
    font-size: 5vh;
    font-weight: 600;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    color: rgba(48, 63, 159, 1);
    opacity: .8;
  }

</style>

<div id="mainContainer" class="flex" hidden$="[[noPhotos]]">
  <neon-animated-pages id="pages" class="fit" animate-initial-selection>
    <template is="dom-repeat" id="repeatTemplate" as="view" items="[[_views]]">
      <slide-animatable ani-type="[[aniType]]" class="fit">
        <section id="view[[index]]">
          <iron-image-ken-burns
              class="image"
              src="[[view.url]]"
              width="[[screenWidth]]"
              height="[[screenHeight]]"
              sizing="[[sizingType]]"
              on-error-changed="_onErrorChanged"
              preload>
          </iron-image-ken-burns>
          <div class="time">[[timeLabel]]</div>
          <div class="author">[[view.authorLabel]]</div>
          <div class="location">[[view.locationLabel]]</div>
          <weather-element class="weather"></weather-element>
        </section>
      </slide-animatable>
    </template>
  </neon-animated-pages>
</div>

<div class="noPhotos" hidden$="[[!noPhotos]]">[[localize('no_photos')]]</div>

<iron-image id="pauseImage" class="vcr" src="../images/pause.png" sizing="contain" preload
            hidden$="[[!paused]]"></iron-image>
<iron-image id="playImage" class="vcr" src="../images/play.png" sizing="contain" preload
            hidden$="[[paused]]"></iron-image>
`,
    is: "screensaver-element",
    behaviors: [ LocalizeBehavior ],
    properties: {
        _views: {
            type: Array,
            value: []
        },
        sizingType: {
            type: String,
            value: null
        },
        aniType: {
            type: Number,
            value: 0
        },
        screenWidth: {
            type: Number,
            value: screen.width,
            readOnly: !0
        },
        screenHeight: {
            type: Number,
            value: screen.height,
            readOnly: !0
        },
        paused: {
            type: Boolean,
            value: !1,
            observer: "_pausedChanged"
        },
        noPhotos: {
            type: Boolean,
            value: !1
        },
        timeLabel: {
            type: String,
            value: ""
        }
    },
    ready: function() {
        document.body.style.background = get$2("background", "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)").substring(11), 
        createPages = this.createPages.bind(this), setSizingType = this.setSizingType.bind(this), 
        isNoPhotos = this.isNoPhotos.bind(this), setNoPhotos = this.setNoPhotos.bind(this), 
        setTimeLabel = this.setTimeLabel.bind(this), setPaused = this.setPaused.bind(this), 
        setTimeout(async () => {
            initialize$3(), page("/screensaver.html"), await this._setZoom(), this._setupPhotoTransitions(), 
            this._launch().catch(() => {});
        }, 0);
    },
    createPages: function() {
        create$1(this);
    },
    setSizingType: function(e) {
        this.set("sizingType", e);
    },
    isNoPhotos: function() {
        return this.noPhotos;
    },
    setNoPhotos: function() {
        this.set("noPhotos", !0);
    },
    setTimeLabel: function(e) {
        this.set("timeLabel", e);
    },
    setPaused: function(e) {
        this.set("paused", e);
    },
    _setupPhotoTransitions: function() {
        let e = getInt("photoTransition", 0);
        8 === e && (e = getRandomInt(0, 7)), this.set("aniType", e), initialize$2();
    },
    _setZoom: async function() {
        const e = new ChromePromise();
        try {
            const t = await e.tabs.getZoom();
            (t <= .99 || t >= 1.01) && chrome.tabs.setZoom(1);
        } catch (e) {
            error(e.message, "SS._setZoom");
        }
        return Promise.resolve();
    },
    _launch: async function(e = 2e3) {
        try {
            await build() && (send(UPDATE_WEATHER).catch(() => {}), start(e));
        } catch (e) {
            error$1(e.message, "SS._launch"), setNoPhotos();
        }
        return Promise.resolve();
    },
    _onErrorChanged: async function(e) {
        const t = e.detail.value;
        if (!_errHandler.isUpdating && t) {
            _errHandler.isUpdating = !0;
            const t = e.model.index, i = this._views[t].photo;
            if ("Google User" === i.getType()) {
                if (Date.now() - _errHandler.lastTime < _errHandler.TIME_LIMIT) return void (_errHandler.isUpdating = !1);
                if (_errHandler.count++, _errHandler.count >= _errHandler.MAX_COUNT) return void (_errHandler.isUpdating = !1);
                _errHandler.lastTime = Date.now();
                const e = getWaitTime();
                let t = Math.round(ChromeTime.MSEC_IN_HOUR / e);
                t = Math.max(t, 50);
                const s = getNextGooglePhotos(t = 1 === _errHandler.count ? Math.min(t, 50) : Math.min(t, 300), i.getId()), o = [];
                for (const e of s) {
                    const t = e.getEx().id;
                    -1 === o.indexOf(t) && o.push(t);
                }
                let a = [];
                try {
                    a = await GoogleSource.loadPhotos(o);
                } catch (e) {
                    return _errHandler.count = _errHandler.MAX_COUNT + 1, void (_errHandler.isUpdating = !0);
                }
                updateGooglePhotoUrls(a);
                for (const e of this._views) {
                    const t = e.photo;
                    if ("Google User" === t.getType()) {
                        const i = a.findIndex(e => e.ex.id === t.getEx().id);
                        i >= 0 && e.setUrl(a[i].url);
                    }
                }
                if (!await GoogleSource.updateBaseUrls(a)) return _errHandler.count = _errHandler.MAX_COUNT + 1, 
                void (_errHandler.isUpdating = !0);
                _errHandler.isUpdating = !1;
            }
        }
    },
    _pausedChanged: function(e, t) {
        void 0 !== t && (e ? (this.$.pauseImage.classList.add("fadeOut"), this.$.playImage.classList.remove("fadeOut")) : (this.$.playImage.classList.add("fadeOut"), 
        this.$.pauseImage.classList.remove("fadeOut")));
    }
});

var screensaverElement = {
    get createPages() {
        return createPages;
    },
    get setSizingType() {
        return setSizingType;
    },
    get isNoPhotos() {
        return isNoPhotos;
    },
    get setNoPhotos() {
        return setNoPhotos;
    },
    get setTimeLabel() {
        return setTimeLabel;
    },
    get setPaused() {
        return setPaused;
    },
    default: Screensaver
};

export { screensaverElement as $screensaverElement, Screensaver as $screensaverElementDefault, slideAnimatable as $slideAnimatable, SlideAnimatable as $slideAnimatableDefault, spinDownAnimation as $spinDownAnimation, SpinDownAnimation as $spinDownAnimationDefault, spinUpAnimation as $spinUpAnimation, SpinUpAnimation as $spinUpAnimationDefault, ss_builder as $ssBuilder, ss_history as $ssHistory, ss_photo as $ssPhoto, SSPhoto as $ssPhotoDefault, ss_photo_finder as $ssPhotoFinder, ss_photos as $ssPhotos, ss_runner as $ssRunner, ss_time as $ssTime, ss_view as $ssView, SSView as $ssViewDefault, ss_view_factory as $ssViewFactory, ss_view_frame as $ssViewFrame, SSViewFrame as $ssViewFrameDefault, ss_view_full as $ssViewFull, SSViewFull as $ssViewFullDefault, ss_view_letterbox as $ssViewLetterbox, SSViewLetterbox as $ssViewLetterboxDefault, ss_view_zoom as $ssViewZoom, SSViewZoom as $ssViewZoomDefault, ss_views as $ssViews, weatherElement as $weatherElement, WeatherElement as $weatherElementDefault, Type, add, addFromSource, back, back$1, build, clear, create$1 as create, create as create$1, createPages, findLoadedPhoto, forward, get, get$1, getCount, getCount$1, getCurrentIndex, getNext, getNextGooglePhotos, getNextUsable, getPhotos, getSelectedIndex, getType, getWaitTime, hasPhoto, hasUsable, hasUsable$1, incCurrentIndex, initialize$1 as initialize, initialize as initialize$1, initialize$2, isCurrentPair, isInteractive, isNoPhotos, isPaused, isSelectedIndex, isStarted, replaceAll, replacePhoto, setCurrentIndex, setLastSelected, setNoPhotos, setPaused, setReplaceIdx, setSelectedIndex, setSizingType, setTime, setTimeLabel, setWaitTime, shuffle, start, togglePaused, updateGooglePhotoUrls };