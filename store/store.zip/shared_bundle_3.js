import { customElement, property, computed, query, listen, observe, mixinBehaviors, NeonAnimationBehavior, BaseElement, html, DEF_WEATHER, NeonAnimatableBehavior, localize, getBool, get as get$1, getInt, isWhiteSpace, getRandomInt, getRandomFloat, shuffleArray, event, EVENT as EVENT$1, error, page, error$1, addListener, removeListener, send, ChromeTime, EVENT$1 as EVENT, initialize as initialize$1, TYPE$1 as TYPE, GoogleSource, getSelectedSources } from "./shared_bundle_4.js";

var __decorate = function(e, t, o, n) {
    var i, r = arguments.length, s = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, o, s) : i(t, o)) || s);
    return r > 3 && s && Object.defineProperty(t, o, s), s;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */ let SpinDownAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        }, {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinDownAnimationElement = __decorate([ customElement("spin-down-animation") ], SpinDownAnimationElement);

var spinDownAnimation = {
    get SpinDownAnimationElement() {
        return SpinDownAnimationElement;
    }
}, __decorate$1 = function(e, t, o, n) {
    var i, r = arguments.length, s = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, o, s) : i(t, o)) || s);
    return r > 3 && s && Object.defineProperty(t, o, s), s;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SpinUpAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        }, {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinUpAnimationElement = __decorate$1([ customElement("spin-up-animation") ], SpinUpAnimationElement);

var spinUpAnimation = {
    get SpinUpAnimationElement() {
        return SpinUpAnimationElement;
    }
}, __decorate$2 = function(e, t, o, n) {
    var i, r = arguments.length, s = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, o, s) : i(t, o)) || s);
    return r > 3 && s && Object.defineProperty(t, o, s), s;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let WeatherElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.show = !1, this.weather = DEF_WEATHER;
    }
    _weatherChanged(e, t) {
        let o = null;
        if (void 0 !== t && (o = "wi-owm-" + t.dayNight + t.id), void 0 !== e) {
            const t = "wi-owm-" + e.dayNight + e.id;
            o ? this.$.weatherIcon.classList.replace(o, t) : this.$.weatherIcon.classList.add(t);
        }
    }
    static get template() {
        return html`<!--
  Need to include globally too
  see: https://bugs.chromium.org/p/chromium/issues/detail?id=336876
  -->
<link rel="stylesheet" href="../../css/weather-icons.min.css">

<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .temp {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0 0 0 16px;
  }

  :host .icon {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0;
  }

</style>

<div class="horizontal layout center" hidden$="[[!show]]">
  <i id="weatherIcon" class="icon wi"></i>
  <paper-item class="temp">[[weather.temp]]</paper-item>
</div>

<app-localstorage-document key="currentWeather" data="{{weather}}" storage="window.localStorage">
</app-localstorage-document>
<app-localstorage-document key="showCurrentWeather" data="{{show}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$2([ property({
    type: Boolean,
    notify: !0
}) ], WeatherElement.prototype, "show", void 0), __decorate$2([ property({
    type: Object,
    observer: "_weatherChanged"
}) ], WeatherElement.prototype, "weather", void 0), WeatherElement = __decorate$2([ customElement("weather-element") ], WeatherElement);

var ScreensaverSlideElement_1, weatherElement = {
    get WeatherElement() {
        return WeatherElement;
    }
}, __decorate$3 = function(e, t, o, n) {
    var i, r = arguments.length, s = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, o, s) : i(t, o)) || s);
    return r > 3 && s && Object.defineProperty(t, o, s), s;
};

let ScreensaverSlideElement = ScreensaverSlideElement_1 = class extends(mixinBehaviors([ NeonAnimatableBehavior ], BaseElement)){
    constructor() {
        super(...arguments), this.photo = null, this.viewType = 0, this.index = 0, this.url = "", 
        this.aniType = 1, this.screenWidth = screen.width, this.screenHeight = screen.height, 
        this.timeLabel = "", this.isAnimate = !1, this.animation = null, this.animationConfig = {
            entry: {
                name: "fade-in-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            },
            exit: {
                name: "fade-out-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            }
        };
    }
    static setFrameLabelStyle(e, t, o, n) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = "1.0", 
        e.fontSize = "2.5vh", e.fontWeight = "400";
        const i = t / screen.width * 100, r = (100 - i) / 2;
        n ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = i - 1 + "vw";
        const s = (100 - o / screen.height * 100) / 2;
        e.bottom = s + 1.1 + "vh";
    }
    get sizing() {
        let e = null;
        switch (this.viewType) {
          case 1:
            e = "cover";
            break;

          case 0:
          case 2:
          case 3:
            e = null;
        }
        return e;
    }
    get authorLabel() {
        const e = this.photo.getType(), t = this.photo.getPhotographer();
        let o = e;
        const n = e.search("User");
        return getBool("showPhotog", !0) || -1 === n ? (-1 !== n && (o = e.substring(0, n - 1)), 
        isWhiteSpace(t) ? `${localize("photo_from")} ${o}` : `${t} / ${o}`) : "";
    }
    get locationLabel() {
        return "";
    }
    setUrl(e) {
        this.set("url", e);
    }
    isPhotoLoaded() {
        return !!this.ironImage && this.ironImage.loaded;
    }
    isPhotoError() {
        return !this.ironImage || this.ironImage.error;
    }
    startAnimation() {
        if (!this.isAnimate) return;
        this.animation && this.animation.cancel();
        const e = this.ironImage, t = 1e3 * get$1("transitionTime", {
            base: 30,
            display: 30,
            unit: 0
        }).base;
        let o = 1e3;
        4 === getInt("photoTransition", 1) && (o = 2e3);
        const n = e.width, i = e.height, r = getRandomInt(0, 1) ? -1 : 1, s = getRandomInt(0, 1) ? -1 : 1, a = 1 + getRandomFloat(.2, .6), l = .2 * (a - 1), d = r * n * getRandomFloat(0, l), c = s * i * getRandomFloat(0, l), h = [ {
            transform: "scale(1.0) translateX(0vw) translateY(0vh)"
        }, {
            transform: `scale(${a}) translateX(${Math.round(d) + "px"}) translateY(${Math.round(c) + "px"})`
        } ], p = {
            delay: o,
            duration: t - o,
            iterations: 1,
            easing: "ease-in-out",
            fill: "forwards"
        };
        let m = e.$.img;
        e.sizing && (m = e.$.sizedImgDiv), this.set("animation", m.animate(h, p));
    }
    onLoadedChanged(e) {
        e.detail.value && this.render();
    }
    onErrorChanged(e) {
        if (e.detail.value) {
            const e = new CustomEvent("image-error", {
                bubbles: !0,
                composed: !0,
                detail: {
                    index: this.index
                }
            });
            this.dispatchEvent(e);
        }
    }
    photoChanged(e) {
        e && this.set("url", e.getUrl());
    }
    aniChanged(e) {
        let t, o, n = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", o = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", o = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", o = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", o = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", o = "spin-down-animation", n = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", o = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", o = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", o = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", o = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = n, 
        this.animationConfig.exit.name = o, this.animationConfig.exit.timing.duration = n;
    }
    isAnimateChanged(e) {
        void 0 !== e && (e || this.animation && (this.animation.cancel(), this.set("animation", null)));
    }
    render() {
        switch (this.viewType) {
          case 1:
            break;

          case 3:
            this.renderFull();
            break;

          case 0:
            this.renderLetterbox();
            break;

          case 2:
            this.renderFrame();
        }
    }
    renderFull() {
        const e = this.ironImage.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
    renderLetterbox() {
        const e = screen.width / screen.height, t = this.photo.getAspectRatio(), o = this.ironImage, n = o.style, i = o.$.img.style, r = this.author.style, s = this.location.style, a = this.time.style, l = this.weather.style;
        let d = t / e * 100;
        const c = (100 - (d = Math.min(d, 100))) / 2;
        let h = e / t * 100;
        const p = (100 - (h = Math.min(h, 100))) / 2, m = Math.round(h / 100 * screen.height), u = Math.round(d / 100 * screen.width);
        o.height = m, o.width = u, i.height = m + "px", i.width = u + "px", n.top = (screen.height - m) / 2 + "px", 
        n.left = (screen.width - u) / 2 + "px", r.textAlign = "right", s.textAlign = "left", 
        l.textAlign = "left", r.right = c + 1 + "vw", r.bottom = p + 1 + "vh", r.width = d - .5 + "vw", 
        s.left = c + 1 + "vw", s.bottom = p + 1 + "vh", s.width = d - .5 + "vw", l.left = c + 1 + "vw", 
        l.bottom = p + 3.5 + "vh", l.width = d - .5 + "vw", a.right = c + 1 + "vw", a.bottom = p + 3.5 + "vh", 
        getBool("showTime", !1) && (r.textOverflow = "ellipsis", r.whiteSpace = "nowrap");
        const g = d / 2;
        isWhiteSpace(this.locationLabel) || (r.maxWidth = g - 1.1 + "vw"), isWhiteSpace(this.authorLabel) || (s.maxWidth = g - 1.1 + "vw");
    }
    renderFrame() {
        const e = this.photo.getAspectRatio(), t = this.ironImage, o = t.style, n = t.$.img.style, i = this.author.style, r = this.location.style, s = this.weather.style, a = this.time.style, l = .005 * screen.height, d = .05 * screen.height, c = .025 * screen.height, h = Math.min((screen.width - 2 * c - 2 * l) / e, screen.height - 2 * c - l - d), p = h * e, m = p + 2 * l, u = h + d + l;
        t.height = h, t.width = p, o.top = (screen.height - u) / 2 + "px", o.left = (screen.width - m) / 2 + "px", 
        o.border = "0.5vh ridge WhiteSmoke", o.borderBottom = "5vh solid WhiteSmoke", o.borderRadius = "1.5vh", 
        o.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", n.height = h + "px", n.width = p + "px", 
        n.top = screen.height / 2 + "px", n.left = screen.width / 2 + "px", ScreensaverSlideElement_1.setFrameLabelStyle(i, m, u, !1), 
        ScreensaverSlideElement_1.setFrameLabelStyle(r, m, u, !0);
        const g = (100 - u / screen.height * 100) / 2, S = m / screen.width * 100, f = (100 - S) / 2;
        a.right = f + 1 + "vw", a.textAlign = "right", a.bottom = g + 5 + "vh", s.left = f + 1 + "vw", 
        s.textAlign = "left", s.bottom = g + 6.5 + "vh";
        const v = S / 2;
        isWhiteSpace(this.locationLabel) || (i.maxWidth = v - 1 + "vw"), isWhiteSpace(this.authorLabel) || (r.maxWidth = v - 1 + "vw");
    }
    static get template() {
        return html`
<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  .time {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    right: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .weather {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    left: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .author {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    right: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .location {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    left: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }
  
</style>
<section id="slide[[index]]">
  <iron-image
      id="ironImage"
      class="image"
      src="[[url]]"
      width="[[screenWidth]]"
      height="[[screenHeight]]"
      sizing="[[sizing]]"
      preload>
  </iron-image>
  <div class="time">[[timeLabel]]</div>
  <div class="author">[[authorLabel]]</div>
  <div class="location">[[locationLabel]]</div>
  <weather-element class="weather"></weather-element>
</section>


<app-localstorage-document key="panAndScan" data="{{isAnimate}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "photo", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "viewType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "index", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "url", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "aniType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenWidth", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenHeight", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "timeLabel", void 0), __decorate$3([ property({
    type: Boolean,
    notify: !0
}) ], ScreensaverSlideElement.prototype, "isAnimate", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animation", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animationConfig", void 0), __decorate$3([ computed("viewType") ], ScreensaverSlideElement.prototype, "sizing", null), 
__decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "authorLabel", null), 
__decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "locationLabel", null), 
__decorate$3([ query("#ironImage") ], ScreensaverSlideElement.prototype, "ironImage", void 0), 
__decorate$3([ query(".time") ], ScreensaverSlideElement.prototype, "time", void 0), 
__decorate$3([ query(".author") ], ScreensaverSlideElement.prototype, "author", void 0), 
__decorate$3([ query(".location") ], ScreensaverSlideElement.prototype, "location", void 0), 
__decorate$3([ query(".weather") ], ScreensaverSlideElement.prototype, "weather", void 0), 
__decorate$3([ listen("loaded-changed", "ironImage") ], ScreensaverSlideElement.prototype, "onLoadedChanged", null), 
__decorate$3([ listen("error-changed", "ironImage") ], ScreensaverSlideElement.prototype, "onErrorChanged", null), 
__decorate$3([ observe("photo") ], ScreensaverSlideElement.prototype, "photoChanged", null), 
__decorate$3([ observe("aniType") ], ScreensaverSlideElement.prototype, "aniChanged", null), 
__decorate$3([ observe("isAnimate") ], ScreensaverSlideElement.prototype, "isAnimateChanged", null), 
ScreensaverSlideElement = ScreensaverSlideElement_1 = __decorate$3([ customElement("screensaver-slide") ], ScreensaverSlideElement);

var screensaverSlide = {
    get ScreensaverSlideElement() {
        return ScreensaverSlideElement;
    }
};

let Screensaver;

window.addEventListener("load", () => {
    (Screensaver = document.querySelector("screensaver-element")).launch().catch(() => {});
});

var screensaver = {
    get Screensaver() {
        return Screensaver;
    }
};

class SSPhoto {
    static ignore(e) {
        let t = !1;
        const o = getBool("skip", !1), n = getInt("photoSizing", 0);
        return o && (1 === n || 3 === n) && SSPhoto._isBadAspect(e) && (t = !0), t;
    }
    static _isBadAspect(e) {
        const t = screen.width / screen.height;
        return e < t - .5 || e > t + .5;
    }
    constructor(e, t, o) {
        this._id = e, this._url = t.url, this._photographer = t.author ? t.author : "", 
        this._type = o, this._aspectRatio = parseFloat(t.asp), this._ex = t.ex, this._point = t.point, 
        this._isBad = !1;
    }
    getId() {
        return this._id;
    }
    setId(e) {
        this._id = e;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e, t, o = null;
        switch (this._type) {
          case "flickr":
            this._ex && (e = /(\/[^/]*){4}(_.*_)/, t = this._url.match(e), o = `https://www.flickr.com/photos/${this._ex}${t[1]}`);
            break;

          case "reddit":
            this._ex && (o = this._ex);
            break;

          case "Google User":
            this._ex && this._ex.url && (o = this._ex.url);
            break;

          default:
            o = this._url;
        }
        null !== o && (event(EVENT.VIEW_PHOTO, this._type), chrome.tabs.create({
            url: o
        }));
    }
}

var ss_photo = {
    SSPhoto: SSPhoto
};

const _photos = [];

let _curIdx = 0;

async function addFromSource(e) {
    const t = await e.getPhotos(), o = t.type;
    let n = 0;
    for (const e of t.photos) {
        const t = parseFloat(e.asp);
        if (!SSPhoto.ignore(t)) {
            const t = new SSPhoto(n, e, o);
            _photos.push(t), n++;
        }
    }
}

function getCount() {
    return _photos.length;
}

function hasUsable() {
    return !_photos.every(e => e.isBad());
}

function get(e) {
    return _photos[e];
}

function getNextUsable(e = []) {
    for (let t = 0; t < _photos.length; t++) {
        const o = (t + _curIdx) % _photos.length, n = _photos[o];
        if (!n.isBad() && !e.includes(n)) return _curIdx = o, incCurrentIndex(), n;
    }
    return null;
}

function getCurrentIndex() {
    return _curIdx;
}

function getNextGooglePhotos(e, t) {
    const o = [];
    let n = 0;
    for (let i = 0; i < _photos.length; i++) {
        const r = (i + t) % _photos.length, s = _photos[r];
        if (n >= e) break;
        "Google User" === s.getType() && (o.push(s), n++);
    }
    return o;
}

function updateGooglePhotoUrls(e) {
    for (let t = _photos.length - 1; t >= 0; t--) {
        if ("Google User" !== _photos[t].getType()) continue;
        const o = e.findIndex(e => e.ex.id === _photos[t].getEx().id);
        o >= 0 && _photos[t].setUrl(e[o].url);
    }
}

function setCurrentIndex(e) {
    _curIdx = e;
}

function incCurrentIndex() {
    return _curIdx = _curIdx === _photos.length - 1 ? 0 : _curIdx + 1;
}

function shuffle() {
    shuffleArray(_photos), _photos.forEach((e, t) => {
        e.setId(t);
    });
}

var ss_photos = {
    addFromSource: addFromSource,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex,
    shuffle: shuffle
};

const HIST = {
    arr: [],
    idx: -1,
    max: 10
};

function initialize() {
    HIST.max = Math.min(getCount(), Screensaver.getMaxSlideCount());
}

function add(e, t, o) {
    if (null === e) {
        const e = Screensaver.getSlide(t), n = HIST.idx, i = HIST.arr.length, r = {
            currentIdx: t,
            replaceIdx: o,
            photoId: e.photo.getId(),
            photosPos: getCurrentIndex()
        };
        n === i - 1 && (HIST.arr.length > HIST.max && (HIST.arr.shift(), HIST.idx--, HIST.idx = Math.max(HIST.idx, -1)), 
        HIST.arr.push(r));
    }
    HIST.idx++;
}

function clear() {
    HIST.arr = [], HIST.idx = -1;
}

function back() {
    if (HIST.idx <= 0) return null;
    let e = null, t = 2, o = HIST.idx - t;
    if (HIST.idx = o, o < 0) {
        if (HIST.arr.length > HIST.max) return HIST.idx += t, null;
        HIST.idx = -1, t = 1, e = -1, o = 0;
    }
    const n = HIST.arr[o].photosPos, i = HIST.arr[o + t].replaceIdx;
    setCurrentIndex(n), setReplaceIdx(i);
    const r = HIST.arr[o].currentIdx;
    e = null === e ? r : e;
    const s = get(HIST.arr[o].photoId);
    return Screensaver.replacePhoto(s, r), e;
}

var ss_history = {
    initialize: initialize,
    add: add,
    clear: clear,
    back: back
};

const VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    transTime: 3e4,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    const t = get$1("transitionTime", {
        base: 30,
        display: 30,
        unit: 0
    });
    VARS.transTime = 1e3 * t.base, setWaitTime(1e3 * t.base), VARS.interactive = getBool("interactive", !1), 
    initialize(), window.setTimeout(runShow, e);
}

function getWaitTime() {
    return VARS.waitTime;
}

function setReplaceIdx(e) {
    VARS.replaceIdx = e;
}

function isStarted() {
    return VARS.started;
}

function isInteractive() {
    return VARS.interactive;
}

function isPaused() {
    return VARS.paused;
}

function isCurrentPair(e) {
    return e === Screensaver.getSelectedSlideIndex() || e === VARS.lastSelected;
}

function togglePaused(e = null) {
    VARS.started && (VARS.paused = !VARS.paused, Screensaver.setPaused(VARS.paused), 
    VARS.paused ? stop() : restart(e));
}

function forward() {
    VARS.started && step();
}

function back$1() {
    if (VARS.started) {
        const e = back();
        null !== e && step(e);
    }
}

function stop() {
    window.clearTimeout(VARS.timeOutId);
}

function restart(e = null) {
    const t = get$1("transitionTime");
    t && setWaitTime(1e3 * t.base), runShow(e);
}

function step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (stop(), restart(e));
}

function runShow(e = null) {
    if (Screensaver.isNoPhotos()) return;
    const t = Screensaver.getSelectedSlideIndex(), o = Screensaver.getSlideCount();
    let n = null === e ? t : e, i = (n = isStarted() ? n : 0) === o - 1 ? 0 : n + 1;
    if (isStarted() || (i = 0), -1 !== (i = getNextSlideIdx(i))) {
        isStarted() || (VARS.started = !0), Screensaver.getSlide(i).startAnimation(), VARS.interactive && add(e, i, VARS.replaceIdx), 
        VARS.lastSelected = t, Screensaver.setSelectedSlideIndex(i), null === e && (VARS.interactive ? replacePhoto(VARS.replaceIdx) : setTimeout(() => {
            replacePhoto(VARS.replaceIdx);
        }, 2e3), VARS.replaceIdx = VARS.lastSelected);
    }
    VARS.timeOutId = setTimeout(() => {
        runShow();
    }, VARS.waitTime);
}

function setWaitTime(e) {
    VARS.waitTime = e, VARS.waitTime = Math.min(2147483647, e);
}

function getNextSlideIdx(e) {
    const t = Screensaver.findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : VARS.transTime), t;
}

function replacePhoto(e) {
    if (e >= 0) {
        if (Screensaver.isSelectedSlideIndex(e)) return;
        const t = Screensaver.getSlideCount();
        if (getCount() <= t) return;
        const o = getNextUsable(Screensaver.getPhotos());
        o && Screensaver.replacePhoto(o, e);
    }
}

var ss_runner = {
    start: start,
    getWaitTime: getWaitTime,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isPaused: isPaused,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

const _MOUSE_START = {
    x: null,
    y: null
};

function addListeners() {
    addListener(onChromeMessage), window.addEventListener("keydown", onKey, !1), window.addEventListener("mousemove", onMouseMove, !1), 
    window.addEventListener("click", onMouseClick, !1), chrome.commands.onCommand.addListener(onKeyCommand);
}

function removeListeners() {
    removeListener(onChromeMessage), window.removeEventListener("keydown", onKey, !1), 
    window.removeEventListener("mousemove", onMouseMove, !1), window.removeEventListener("click", onMouseClick, !1), 
    chrome.commands.onCommand.removeListener(onKeyCommand);
}

function close() {
    send(TYPE.SS_CLOSE).catch(() => {}), setTimeout(() => {
        window.close();
    }, 750);
}

function onKeyCommand(e) {
    isStarted() && isInteractive() && ("ss-toggle-paused" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), forward()) : "ss-back" === e && (event(EVENT$1.KEY_COMMAND, `${e}`), 
    back$1()));
}

function onChromeMessage(e, t, o) {
    return e.message === TYPE.SS_CLOSE.message ? close() : e.message === TYPE.SS_IS_SHOWING.message && o({
        message: "OK"
    }), !1;
}

function onKey(e) {
    const t = e.key;
    if (isStarted() || isInteractive()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || close();
        break;

      default:
        close();
    } else close();
}

function onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), o = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, o) > 10 && close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function onMouseClick() {
    if (isStarted()) {
        const e = Screensaver.getSelectedPhoto();
        getBool("allowPhotoClicks", !0) && e && e.showSource();
    }
    close();
}

var ScreensaverElement_1, ss_events = {
    addListeners: addListeners,
    removeListeners: removeListeners
}, __decorate$4 = function(e, t, o, n) {
    var i, r = arguments.length, s = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, o, s) : i(t, o)) || s);
    return r > 3 && s && Object.defineProperty(t, o, s), s;
};

const errHandler = {
    MAX_COUNT: 168,
    count: 0,
    isUpdating: !1,
    TIME_LIMIT: 3e5,
    lastTime: 0
};

let ScreensaverElement = ScreensaverElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.MAX_SLIDES = 10, this.photos = [], this.aniType = 0, this.paused = !1, 
        this.noPhotos = !1, this.timeLabel = "";
    }
    static async setZoom() {
        const e = new ChromePromise();
        try {
            const t = await e.tabs.getZoom();
            (t <= .99 || t >= 1.01) && chrome.tabs.setZoom(1);
        } catch (e) {
            error(e.message, "SS.setZoom");
        }
    }
    connectedCallback() {
        super.connectedCallback(), addListeners();
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListeners();
    }
    ready() {
        super.ready(), document.body.style.background = get$1("background", "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)").substring(11), 
        setTimeout(async () => {
            initialize$1(), page("/screensaver.html"), await ScreensaverElement_1.setZoom(), 
            this.setupPhotoTransitions(), this.setupViewType();
        }, 0);
    }
    async launch(e = 1500) {
        try {
            if (await this.loadPhotos()) {
                const t = Math.min(getCount(), this.MAX_SLIDES), o = [];
                for (let e = 0; e < t; e++) o.push(getNextUsable());
                this.set("photos", o), this.repeatTemplate.render(), send(TYPE.UPDATE_WEATHER).catch(() => {}), 
                this.setupTime(), start(e);
            }
        } catch (e) {
            error$1(e.message, "SS._launch"), this.setNoPhotos();
        }
    }
    getMaxSlideCount() {
        return this.MAX_SLIDES;
    }
    getPhotos() {
        return this.photos;
    }
    getSelectedPhoto() {
        let e;
        const t = this.getSelectedSlideIndex();
        return -1 !== t && (e = this.photos[t]), e;
    }
    replacePhoto(e, t) {
        if (e && t >= 0) {
            this.splice("photos", t, 1, e);
            const o = this.getSlide(t);
            o.setUrl(e.getUrl()), o.notifyPath("url");
        }
    }
    findLoadedPhoto(e) {
        this.hasUsablePhoto() || this.replaceAll();
        const t = this.getSlide(e);
        if (t && t.isPhotoLoaded()) return e;
        for (let t = 0; t < this.photos.length; t++) {
            const o = (t + e) % this.photos.length, n = this.getSlide(o), i = this.photos[o];
            if (!isCurrentPair(o)) {
                if (n.isPhotoLoaded()) return o;
                if (n.isPhotoError() && !i.isBad() && (i.markBad(), !hasUsable())) return this.setNoPhotos(), 
                -1;
            }
        }
        return -1;
    }
    isSelectedSlideIndex(e) {
        let t = !1;
        return this.pages && e === this.pages.selected && (t = !0), t;
    }
    getSelectedSlideIndex() {
        if (this.pages) {
            let e;
            return e = "string" == typeof this.pages.selected ? parseInt(this.pages.selected, 10) : this.pages.selected;
        }
        return -1;
    }
    setSelectedSlideIndex(e) {
        this.pages && (this.pages.selected = e);
    }
    getSlideCount() {
        return this.photos ? this.photos.length : 0;
    }
    getSlide(e) {
        const t = `#slide${e}`;
        return this.shadowRoot.querySelector(t);
    }
    isNoPhotos() {
        return this.noPhotos;
    }
    setNoPhotos() {
        this.set("noPhotos", !0);
    }
    setPaused(e) {
        this.set("paused", e);
    }
    async loadPhotos() {
        let e = getSelectedSources();
        e = e || [];
        for (const t of e) await addFromSource(t);
        return getCount() ? (getBool("shuffle") && shuffle(), !0) : (this.setNoPhotos(), 
        !1);
    }
    setupViewType() {
        let e = getInt("photoSizing", 0);
        4 === e && (e = getRandomInt(0, 3)), this.set("viewType", e);
    }
    setupPhotoTransitions() {
        let e = getInt("photoTransition", 1);
        8 === e && (e = getRandomInt(0, 7)), this.set("aniType", e);
    }
    setupTime() {
        getInt("showTime", 0) > 0 && (this.setTimeLabel(), setInterval(this.setTimeLabel.bind(this), 61e3));
    }
    setTimeLabel() {
        let e = "";
        0 !== getInt("showTime", 0) && (e = ChromeTime.getStringShort(), this.set("timeLabel", e));
    }
    pausedChanged(e, t) {
        void 0 !== t && (e ? (this.$.pauseImage.classList.add("fadeOut"), this.$.playImage.classList.remove("fadeOut")) : (this.$.playImage.classList.add("fadeOut"), 
        this.$.pauseImage.classList.remove("fadeOut")));
    }
    hasUsablePhoto() {
        let e = !1;
        for (let t = 0; t < this.photos.length; t++) {
            const o = this.photos[t];
            if (!isCurrentPair(t) && !o.isBad()) {
                e = !0;
                break;
            }
        }
        return e;
    }
    replaceAll() {
        for (let e = 0; e < this.photos.length; e++) {
            if (isCurrentPair(e)) continue;
            const t = getNextUsable(this.photos);
            if (!t) break;
            this.replacePhoto(t, e);
        }
        clear();
    }
    updateAllUrls(e) {
        for (let t = 0; t < this.photos.length; t++) {
            const o = this.photos[t];
            if ("Google User" === o.getType()) {
                const n = this.getSlide(t), i = e.findIndex(e => e.ex.id === o.getEx().id);
                i >= 0 && n.setUrl(e[i].url);
            }
        }
    }
    async onImageError(e) {
        if (errHandler.isUpdating) return;
        errHandler.isUpdating = !0;
        const t = e.detail.index, o = this.photos[t];
        if ("Google User" === o.getType()) try {
            if (Date.now() - errHandler.lastTime < errHandler.TIME_LIMIT) return void (errHandler.isUpdating = !1);
            if (errHandler.count++, errHandler.count >= errHandler.MAX_COUNT) return void (errHandler.isUpdating = !1);
            errHandler.lastTime = Date.now();
            let e = get$1("transitionTime", {
                base: 30,
                display: 30,
                unit: 0
            });
            e = 1e3 * e.base;
            let t = Math.round(ChromeTime.MSEC_IN_HOUR / e);
            t = Math.max(t, 50);
            const n = getNextGooglePhotos(t = 1 === errHandler.count ? Math.min(t, 50) : Math.min(t, 300), o.getId()), i = [];
            for (const e of n) {
                const t = e.getEx();
                if (t) {
                    const e = t.id;
                    -1 === i.indexOf(e) && i.push(e);
                }
            }
            const r = await GoogleSource.loadPhotos(i);
            if (updateGooglePhotoUrls(r), this.updateAllUrls(r), !await GoogleSource.updateBaseUrls(r)) return error("Failed to save new urls", "SS.onImageError"), 
            errHandler.count = errHandler.MAX_COUNT + 1, void (errHandler.isUpdating = !0);
            errHandler.isUpdating = !1;
        } catch (e) {
            return error(e.message, "SS.onImageError"), errHandler.count = errHandler.MAX_COUNT + 1, 
            void (errHandler.isUpdating = !0);
        }
    }
    static get template() {
        return html`<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  /* Added programmatically */
  .fadeOut {
    animation: fadeOut 1s 2s;
    animation-fill-mode: both;
  }

  @keyframes fadeOut {
    from {
      opacity: 1.0;
    }
    to {
      opacity: 0.0;
    }
  }

  .vcr {
    position: fixed;
    width: 15vh;
    height: 15vh;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.0;
  }

  .noPhotos {
    font-size: 5vh;
    font-weight: 600;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    color: rgba(48, 63, 159, 1);
    opacity: .8;
  }

</style>

<div id="mainContainer" class="flex" hidden$="[[noPhotos]]">
  <neon-animated-pages id="pages" class="fit" animate-initial-selection>
    <template is="dom-repeat" id="repeatTemplate" as="photo" items="[[photos]]">
      <screensaver-slide class="fit" id="slide[[index]]" view-type="[[viewType]]" ani-type="[[aniType]]"
                         photo="[[photo]]" index="[[index]]" time-label="[[timeLabel]]" on-image-error="onImageError">
      </screensaver-slide>
    </template>
  </neon-animated-pages>
</div>

<div class="noPhotos" hidden$="[[!noPhotos]]">[[localize('no_photos')]]</div>

<iron-image id="pauseImage" class="vcr" src="../images/pause.png" sizing="contain" preload
            hidden$="[[!paused]]"></iron-image>
<iron-image id="playImage" class="vcr" src="../images/play.png" sizing="contain" preload
            hidden$="[[paused]]"></iron-image>
`;
    }
};

__decorate$4([ property({
    type: Array
}) ], ScreensaverElement.prototype, "photos", void 0), __decorate$4([ property({
    type: Number
}) ], ScreensaverElement.prototype, "aniType", void 0), __decorate$4([ property({
    type: Boolean,
    observer: "pausedChanged"
}) ], ScreensaverElement.prototype, "paused", void 0), __decorate$4([ property({
    type: Boolean
}) ], ScreensaverElement.prototype, "noPhotos", void 0), __decorate$4([ property({
    type: String
}) ], ScreensaverElement.prototype, "timeLabel", void 0), __decorate$4([ query("#repeatTemplate") ], ScreensaverElement.prototype, "repeatTemplate", void 0), 
__decorate$4([ query("#pages") ], ScreensaverElement.prototype, "pages", void 0), 
ScreensaverElement = ScreensaverElement_1 = __decorate$4([ customElement("screensaver-element") ], ScreensaverElement);

var screensaverElement = {
    get ScreensaverElement() {
        return ScreensaverElement;
    }
};

export { screensaver as $screensaver, screensaverElement as $screensaverElement, screensaverSlide as $screensaverSlide, spinDownAnimation as $spinDownAnimation, spinUpAnimation as $spinUpAnimation, ss_events as $ssEvents, ss_history as $ssHistory, ss_photo as $ssPhoto, ss_photos as $ssPhotos, ss_runner as $ssRunner, weatherElement as $weatherElement, SSPhoto, Screensaver, ScreensaverElement, ScreensaverSlideElement, SpinDownAnimationElement, SpinUpAnimationElement, WeatherElement, add, addFromSource, addListeners, back, back$1, clear, forward, get, getCount, getCurrentIndex, getNextGooglePhotos, getNextUsable, getWaitTime, hasUsable, incCurrentIndex, initialize, isCurrentPair, isInteractive, isPaused, isStarted, removeListeners, setCurrentIndex, setReplaceIdx, shuffle, start, togglePaused, updateGooglePhotoUrls };