import { NeonAnimationBehavior, Polymer, NeonAnimatableBehavior, html$1 as html, SS_CLOSE, SS_IS_SHOWING, getSelectedPhotos, $photoSourceGoogleDefault as GoogleSource } from "./shared_bundle_4.js";

Polymer({
    is: "spin-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)"
        }, {
            transform: "scale(0) rotate(0)"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "spin-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)"
        }, {
            transform: "scale(1) rotate(1.0turn)"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }
    </style>
    <slot></slot>
`,
    is: "slide-animatable",
    behaviors: [ NeonAnimatableBehavior ],
    properties: {
        animationConfig: {
            type: Object,
            value: function() {
                return {
                    entry: {
                        name: "fade-in-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    },
                    exit: {
                        name: "fade-out-animation",
                        node: this,
                        timing: {
                            duration: 2e3,
                            easing: "cubic-bezier(0.455, 0.03, 0.515, 0.955)"
                        }
                    }
                };
            }
        },
        aniType: {
            type: Number,
            observer: "_aniChanged"
        }
    },
    _aniChanged: function(e) {
        let t, o, i = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", o = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", o = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", o = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", o = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", o = "spin-down-animation", i = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", o = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", o = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", o = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", o = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = i, 
        this.animationConfig.exit.name = o, this.animationConfig.exit.timing.duration = i;
    }
});

class SSPhoto {
    constructor(e, t, o) {
        this._id = e, this._url = t.url, this._photographer = t.author ? t.author : "", 
        this._type = o, this._aspectRatio = t.asp, this._ex = t.ex, this._point = t.point, 
        this._isBad = !1;
    }
    getId() {
        return this._id;
    }
    setId(e) {
        this._id = e;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e, t, o = null;
        switch (this._type) {
          case "flickr":
            this._ex && (e = /(\/[^/]*){4}(_.*_)/, t = this._url.match(e), o = `https://www.flickr.com/photos/${this._ex}${t[1]}`);
            break;

          case "reddit":
            this._ex && (o = this._ex);
            break;

          case "Google User":
            this._ex && this._ex.url && (o = this._ex.url);
            break;

          default:
            o = this._url;
        }
        null !== o && chrome.tabs.create({
            url: o
        });
    }
}

var ss_photo = {
    default: SSPhoto
};

const _SCREEN_AR = screen.width / screen.height;

class SSView {
    constructor(e) {
        this.photo = e, this.image = null, this.author = null, this.time = null, this.location = null, 
        this.model = null, this.url = e.getUrl(), this.authorLabel = "", this.locationLabel = "";
    }
    static _dirtySet(e, t, o) {
        e.set(t, o), e.notifyPath(t);
    }
    static _isBadAspect(e) {
        return e < _SCREEN_AR - .5 || e > _SCREEN_AR + .5;
    }
    static ignore(e, t) {
        let o = !1;
        const i = Chrome.Storage.getBool("skip");
        return (!e || isNaN(e) || i && (1 === t || 3 === t) && SSView._isBadAspect(e)) && (o = !0), 
        o;
    }
    static _showLocation() {
        return Chrome.Storage.getBool("showLocation");
    }
    static showTime() {
        return Chrome.Storage.getBool("showTime");
    }
    _hasAuthor() {
        const e = this.photo.getPhotographer();
        return !Chrome.Utils.isWhiteSpace(e);
    }
    _hasAuthorLabel() {
        return !Chrome.Utils.isWhiteSpace(this.authorLabel);
    }
    _hasLocation() {
        return !!this.photo.getPoint();
    }
    _hasLocationLabel() {
        return !Chrome.Utils.isWhiteSpace(this.locationLabel);
    }
    _setTimeStyle() {
        Chrome.Storage.getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
    }
    setUrl(e = null) {
        this.url = e || this.photo.getUrl(), SSView._dirtySet(this.model, "view.url", this.url);
    }
    markPhotoBad() {
        this.photo && this.photo.markBad();
    }
    _setAuthorLabel() {
        this.authorLabel = "", SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel);
        const e = this.photo.getType(), t = this.photo.getPhotographer();
        let o = e;
        const i = e.search("User");
        (Chrome.Storage.getBool("showPhotog") || -1 === i) && (-1 !== i && (o = e.substring(0, i - 1)), 
        this._hasAuthor() ? this.authorLabel = `${t} / ${o}` : this.authorLabel = `${Chrome.Locale.localize("photo_from")} ${o}`, 
        SSView._dirtySet(this.model, "view.authorLabel", this.authorLabel));
    }
    _setLocationLabel() {
        this.locationLabel = "", SSView._dirtySet(this.model, "view.locationLabel", this.locationLabel);
    }
    setElements(e, t, o, i, s) {
        this.image = e, this.author = t, this.time = o, this.location = i, this.model = s, 
        this._setTimeStyle(), this.setPhoto(this.photo);
    }
    setPhoto(e) {
        this.photo = e, this.setUrl(), this._setAuthorLabel(!1), this._setLocationLabel();
    }
    render() {}
    isError() {
        return !this.image || this.image.error;
    }
    isLoaded() {
        return !!this.image && this.image.loaded;
    }
}

var ss_view = {
    default: SSView
};

const _photos = [];

let _curIdx = 0;

function addFromSource(e) {
    const t = e.type, o = getType();
    let i = 0;
    for (const s of e.photos) if (!SSView.ignore(s.asp, o)) {
        const e = new SSPhoto(i, s, t);
        _photos.push(e), i++;
    }
}

function getCount() {
    return _photos.length;
}

function hasUsable() {
    return !_photos.every(e => e.isBad());
}

function get(e) {
    return _photos[e];
}

function getNextUsable() {
    for (let e = 0; e < _photos.length; e++) {
        const t = (e + _curIdx) % _photos.length, o = _photos[t];
        if (!o.isBad() && !hasPhoto(o)) return _curIdx = t, incCurrentIndex(), o;
    }
    return null;
}

function getCurrentIndex() {
    return _curIdx;
}

function getNextGooglePhotos(e, t) {
    const o = [];
    let i = 0;
    for (let s = 0; s < _photos.length; s++) {
        const r = (s + t) % _photos.length, n = _photos[r];
        if (i >= e) break;
        "Google User" === n.getType() && (o.push(n), i++);
    }
    return o;
}

function updateGooglePhotoUrls(e) {
    for (let t = _photos.length - 1; t >= 0; t--) {
        if ("Google User" !== _photos[t].getType()) continue;
        const o = e.findIndex(e => e.ex.id === _photos[t].getEx().id);
        o >= 0 && _photos[t].setUrl(e[o].url);
    }
}

function setCurrentIndex(e) {
    _curIdx = e;
}

function incCurrentIndex() {
    return _curIdx = _curIdx === _photos.length - 1 ? 0 : _curIdx + 1;
}

function shuffle() {
    Chrome.Utils.shuffleArray(_photos), _photos.forEach((e, t) => {
        e.setId(t);
    });
}

var ss_photos = {
    addFromSource: addFromSource,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex,
    shuffle: shuffle
};

let _transTime = 3e4;

function initialize() {
    const e = Chrome.Storage.get("transitionTime");
    e && (_transTime = 1e3 * e.base);
}

function getNext(e) {
    let t = findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : _transTime), t;
}

function replacePhoto(e) {
    e >= 0 && function(e) {
        if (isSelectedIndex(e)) return;
        const t = getCount$1();
        if (getCount() <= t) return;
        const o = getNextUsable();
        if (o) {
            const t = get$1(e);
            t.setPhoto(o);
        }
    }(e);
}

var ss_photo_finder = {
    initialize: initialize,
    getNext: getNext,
    replacePhoto: replacePhoto
};

const _history = {
    arr: [],
    idx: -1,
    max: 20
};

function initialize$1() {
    _history.max = Math.min(getCount(), _history.max);
}

function add(e, t, o) {
    if (null === e) {
        const e = get$1(t), i = _history.idx, s = _history.arr.length, r = {
            viewsIdx: t,
            replaceIdx: o,
            photoId: e.photo.getId(),
            photosPos: getCurrentIndex()
        };
        i === s - 1 && (_history.arr.length > _history.max && (_history.arr.shift(), _history.idx--, 
        _history.idx = Math.max(_history.idx, -1)), _history.arr.push(r));
    }
    _history.idx++;
}

function clear() {
    _history.arr = [], _history.idx = -1;
}

function back() {
    if (_history.idx <= 0) return null;
    let e = null, t = 2, o = _history.idx - t;
    if (_history.idx = o, o < 0) {
        if (_history.arr.length > _history.max) return _history.idx += t, null;
        _history.idx = -1, t = 1, e = -1, o = 0;
    }
    const i = _history.arr[o].photosPos, s = _history.arr[o + t].replaceIdx;
    setCurrentIndex(i), setReplaceIdx(s);
    const r = _history.arr[o].viewsIdx, n = _history.arr[o].photoId;
    e = null === e ? r : e;
    const a = get$1(r), h = get(n);
    return a.setPhoto(h), a.render(), e;
}

var ss_history = {
    initialize: initialize$1,
    add: add,
    clear: clear,
    back: back
};

function initialize$2() {
    Chrome.Storage.getInt("showTime", 0) > 0 && setInterval(setTime, 61e3);
}

function setTime() {
    let e = "";
    0 !== Chrome.Storage.getInt("showTime", 0) && isStarted() && (e = Chrome.Time.getStringShort()), 
    setTimeLabel(e);
}

var ss_time = {
    initialize: initialize$2,
    setTime: setTime
};

const _VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    const t = Chrome.Storage.get("transitionTime");
    t && setWaitTime(1e3 * t.base), _VARS.interactive = Chrome.Storage.getBool("interactive"), 
    initialize$1(), window.setTimeout(_runShow, e);
}

function getWaitTime() {
    return _VARS.waitTime;
}

function setWaitTime(e) {
    _VARS.waitTime = e, _VARS.waitTime = Math.min(2147483647, e);
}

function setLastSelected(e) {
    _VARS.lastSelected = e;
}

function setReplaceIdx(e) {
    _VARS.replaceIdx = e;
}

function isStarted() {
    return _VARS.started;
}

function isInteractive() {
    return _VARS.interactive;
}

function isPaused() {
    return _VARS.paused;
}

function isCurrentPair(e) {
    return e === getSelectedIndex() || e === _VARS.lastSelected;
}

function togglePaused(e = null) {
    _VARS.started && (_VARS.paused = !_VARS.paused, setPaused(_VARS.paused), _VARS.paused ? _stop() : _restart(e));
}

function forward() {
    _VARS.started && _step();
}

function back$1() {
    if (_VARS.started) {
        const e = back();
        null !== e && _step(e);
    }
}

function _stop() {
    window.clearTimeout(_VARS.timeOutId);
}

function _restart(e = null) {
    const t = Chrome.Storage.get("transitionTime");
    t && setWaitTime(1e3 * t.base), _runShow(e);
}

function _step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (_stop(), _restart(e));
}

function _runShow(e = null) {
    if (noPhotos()) return;
    const t = getSelectedIndex(), o = getCount$1();
    let i = null === e ? t : e, s = (i = isStarted() ? i : 0) === o - 1 ? 0 : i + 1;
    if (isStarted() || (s = 0), -1 !== (s = getNext(s))) {
        isStarted() || (_VARS.started = !0, setTime()), get$1(s).render(), add(e, s, _VARS.replaceIdx), 
        _VARS.lastSelected = t, setSelectedIndex(s), null === e && (replacePhoto(_VARS.replaceIdx), 
        _VARS.replaceIdx = _VARS.lastSelected);
    }
    _VARS.timeOutId = window.setTimeout(() => {
        _runShow();
    }, _VARS.waitTime);
}

var ss_runner = {
    start: start,
    getWaitTime: getWaitTime,
    setWaitTime: setWaitTime,
    setLastSelected: setLastSelected,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isPaused: isPaused,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

class SSViewZoom extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
    }
}

var ss_view_zoom = {
    default: SSViewZoom
};

class SSViewFrame extends SSView {
    constructor(e) {
        super(e);
    }
    static _setLabelStyle(e, t, o, i) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = 1, 
        e.fontSize = "2.5vh", e.fontWeight = 400;
        let s = t / screen.width * 100, r = (100 - s) / 2;
        i ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = s - 1 + "vw";
        let n = (100 - o / screen.height * 100) / 2;
        e.bottom = n + 1.1 + "vh";
    }
    render() {
        super.render();
        const e = this.author.style, t = this.location.style, o = this.time.style, i = this.image, s = i.style, r = i.$.img.style, n = this.photo.getAspectRatio(), a = .005 * screen.height, h = .05 * screen.height, l = .025 * screen.height, c = Math.min((screen.width - 2 * l - 2 * a) / n, screen.height - 2 * l - a - h), u = c * n, d = u + 2 * a, _ = c + h + a;
        r.height = c + "px", r.width = u + "px", i.height = c, i.width = u, s.top = (screen.height - _) / 2 + "px", 
        s.left = (screen.width - d) / 2 + "px", s.border = "0.5vh ridge WhiteSmoke", s.borderBottom = "5vh solid WhiteSmoke", 
        s.borderRadius = "1.5vh", s.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", SSViewFrame._setLabelStyle(e, d, _, !1), 
        SSViewFrame._setLabelStyle(t, d, _, !0);
        let g = (100 - _ / screen.height * 100) / 2, m = d / screen.width * 100, f = (100 - m) / 2;
        o.right = f + 1 + "vw", o.textAlign = "right", o.bottom = g + 5 + "vh";
        let S = m / 2;
        this._hasLocationLabel() && (e.maxWidth = S - 1 + "vw"), this._hasAuthorLabel() && (t.maxWidth = S - 1 + "vw");
    }
}

var ss_view_frame = {
    default: SSViewFrame
};

class SSViewFull extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.image.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
}

var ss_view_full = {
    default: SSViewFull
};

const _SCREEN_AR$1 = screen.width / screen.height;

class SSViewLetterbox extends SSView {
    constructor(e) {
        super(e);
    }
    render() {
        super.render();
        const e = this.photo.getAspectRatio(), t = this.author.style, o = this.location.style, i = this.time.style;
        let s = e / _SCREEN_AR$1 * 100, r = (100 - (s = Math.min(s, 100))) / 2, n = _SCREEN_AR$1 / e * 100, a = (100 - (n = Math.min(n, 100))) / 2;
        t.textAlign = "right", o.textAlign = "left", t.right = r + 1 + "vw", t.bottom = a + 1 + "vh", 
        t.width = s - .5 + "vw", o.left = r + 1 + "vw", o.bottom = a + 1 + "vh", o.width = s - .5 + "vw", 
        i.right = r + 1 + "vw", i.bottom = a + 3.5 + "vh", SSView.showTime() && (t.textOverflow = "ellipsis", 
        t.whiteSpace = "nowrap");
        let h = s / 2;
        this._hasLocationLabel() && (t.maxWidth = h - 1.1 + "vw"), this._hasAuthorLabel() && (o.maxWidth = h - 1.1 + "vw");
    }
}

var ss_view_letterbox = {
    default: SSViewLetterbox
};

function create(e, t) {
    switch (t) {
      case Type.LETTERBOX:
        return new SSViewLetterbox(e);

      case Type.ZOOM:
        return new SSViewZoom(e);

      case Type.FRAME:
        return new SSViewFrame(e);

      case Type.FULL:
        return new SSViewFull(e);

      default:
        return Chrome.Log.error(`Bad SSView type: ${t}`, "SSView.createView"), new SSViewLetterbox(e);
    }
}

var ss_view_factory = {
    create: create
};

const Type = {
    UNDEFINED: -1,
    LETTERBOX: 0,
    ZOOM: 1,
    FRAME: 2,
    FULL: 3,
    RANDOM: 4
}, _MAX_VIEWS = 20, _views = [];

let _pages = null, _type = Type.UNDEFINED;

function _setViewType() {
    (_type = Chrome.Storage.getInt("photoSizing", 0)) === Type.RANDOM && (_type = Chrome.Utils.getRandomInt(0, 3));
    let e = "contain";
    switch (_type) {
      case Type.LETTERBOX:
        e = "contain";
        break;

      case Type.ZOOM:
        e = "cover";
        break;

      case Type.FRAME:
      case Type.FULL:
        e = null;
    }
    setSizingType(e);
}

function create$1(e) {
    _pages = e.$.pages, _setViewType();
    const t = Math.min(getCount(), _MAX_VIEWS);
    for (let e = 0; e < t; e++) {
        const t = create(get(e), _type);
        _views.push(t);
    }
    setCurrentIndex(t), e.set("_views", _views), e.$.repeatTemplate.render(), _views.forEach((t, o) => {
        const i = _pages.querySelector("#view" + o), s = i.querySelector(".image"), r = i.querySelector(".author"), n = i.querySelector(".time"), a = i.querySelector(".location"), h = e.$.repeatTemplate.modelForElement(i);
        t.setElements(s, r, n, a, h);
    });
}

function getType() {
    return _type === Type.UNDEFINED && _setViewType(), _type;
}

function getCount$1() {
    return _views.length;
}

function get$1(e) {
    return _views[e];
}

function getSelectedIndex() {
    if (_pages) return _pages.selected;
}

function setSelectedIndex(e) {
    _pages.selected = e;
}

function isSelectedIndex(e) {
    let t = !1;
    return _pages && e === _pages.selected && (t = !0), t;
}

function hasPhoto(e) {
    let t = !1;
    for (const o of _views) if (o.photo.getId() === e.getId()) {
        t = !0;
        break;
    }
    return t;
}

function hasUsable$1() {
    let e = !1;
    for (let t = 0; t < _views.length; t++) {
        const o = _views[t];
        if (!isCurrentPair(t) && !o.photo.isBad()) {
            e = !0;
            break;
        }
    }
    return e;
}

function replaceAll() {
    for (let e = 0; e < _views.length; e++) {
        if (isCurrentPair(e)) continue;
        const t = _views[e], o = getNextUsable();
        if (!o) break;
        t.setPhoto(o);
    }
    clear();
}

function findLoadedPhoto(e) {
    if (hasUsable$1() || replaceAll(), _views[e].isLoaded()) return e;
    for (let t = 0; t < _views.length; t++) {
        const o = (t + e) % _views.length, i = _views[o];
        if (!isCurrentPair(o)) {
            if (i.isLoaded()) return o;
            if (i.isError() && !i.photo.isBad() && (i.photo.markBad(), !hasUsable())) return setNoPhotos(), 
            -1;
        }
    }
    return -1;
}

var ss_views = {
    Type: Type,
    create: create$1,
    getType: getType,
    getCount: getCount$1,
    get: get$1,
    getSelectedIndex: getSelectedIndex,
    setSelectedIndex: setSelectedIndex,
    isSelectedIndex: isSelectedIndex,
    hasPhoto: hasPhoto,
    hasUsable: hasUsable$1,
    replaceAll: replaceAll,
    findLoadedPhoto: findLoadedPhoto
};

const _MOUSE_START = {
    x: null,
    y: null
};

function _close() {
    Chrome.Storage.set("isShowing", !1), Chrome.Msg.send(SS_CLOSE).catch(() => {}), 
    setTimeout(() => {
        window.close();
    }, 750);
}

function _onKeyCommand(e) {
    isInteractive() && ("ss-toggle-paused" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    forward()) : "ss-back" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    back$1()));
}

function _onMessage(e, t, o) {
    return e.message === SS_CLOSE.message ? _close() : e.message === SS_IS_SHOWING.message && o({
        message: "OK"
    }), !1;
}

function _onKey(e) {
    const t = e.key;
    if (isStarted()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || _close();
        break;

      default:
        _close();
    } else _close();
}

function _onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), o = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, o) > 10 && _close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function _onMouseClick() {
    if (isStarted()) {
        const e = getSelectedIndex();
        if (Chrome.Storage.getBool("allowPhotoClicks") && void 0 !== e) {
            get$1(e).photo.showSource();
        }
    }
    _close();
}

function _onLoad() {
    Chrome.Msg.listen(_onMessage), window.addEventListener("keydown", _onKey, !1), window.addEventListener("mousemove", _onMouseMove, !1), 
    window.addEventListener("click", _onMouseClick, !1), chrome.commands.onCommand.addListener(_onKeyCommand);
}

function build() {
    const e = _loadPhotos();
    return e && (createPages(), initialize()), e;
}

function _loadPhotos() {
    let e = getSelectedPhotos();
    e = e || [];
    for (const t of e) addFromSource(t);
    return getCount() ? (Chrome.Storage.getBool("shuffle") && shuffle(), !0) : (setNoPhotos(), 
    !1);
}

window.addEventListener("load", _onLoad);

var ss_builder = {
    build: build
};

const t = document.querySelector("#t");

t.sizingType = null, t.screenWidth = screen.width, t.screenHeight = screen.height, 
t.aniType = 0, t.paused = !1, t.noPhotos = !1, t.noPhotosLabel = "", t.timeLabel = "";

const _MAX_GPHOTO_UPDATES = 168;

let _gPhotoCt = 0, _isUpdating = !1;

function createPages() {
    create$1(t);
}

function setSizingType(e) {
    t.set("sizingType", e);
}

function noPhotos() {
    return t.noPhotos;
}

function setNoPhotos() {
    t.set("noPhotos", !0), t.noPhotosLabel = Chrome.Locale.localize("no_photos");
}

function setTimeLabel(e) {
    t.timeLabel = e;
}

function setPaused(e) {
    t.paused = e, e ? (t.$.pauseImage.classList.add("fadeOut"), t.$.playImage.classList.remove("fadeOut")) : (t.$.playImage.classList.add("fadeOut"), 
    t.$.pauseImage.classList.remove("fadeOut"));
}

function _setupPhotoTransitions() {
    let e = Chrome.Storage.getInt("photoTransition", 0);
    8 === e && (e = Chrome.Utils.getRandomInt(0, 7)), t.set("aniType", e), initialize$2();
}

function _setZoom() {
    if (Chrome.Utils.getChromeVersion() >= 42) {
        new ChromePromise().tabs.getZoom().then(e => ((e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1), 
        null)).catch(e => {
            Chrome.Log.error(e.message, "chromep.tabs.getZoom");
        });
    }
}

function _launch(e = 2e3) {
    build() && start(1e3);
}

function _onLoad$1() {
    document.body.style.background = Chrome.Storage.get("background").substring(11), 
    Chrome.GA.page("/screensaver.html"), _setZoom(), _setupPhotoTransitions(), _launch();
}

t._onErrorChanged = async function(e) {
    const o = e.detail.value;
    if (!_isUpdating && o) {
        _isUpdating = !0;
        const o = e.model.index, i = t._views[o].photo;
        if ("Google User" === i.getType()) {
            if (++_gPhotoCt >= 168) return void (_isUpdating = !1);
            const e = getWaitTime();
            let o = Math.round(Chrome.Time.MSEC_IN_HOUR / e);
            o = Math.max(o, 50);
            const s = getNextGooglePhotos(o = 1 === _gPhotoCt ? Math.min(o, 50) : Math.min(o, 300), i.getId()), r = [];
            for (const e of s) {
                const t = e.getEx().id;
                -1 === r.indexOf(t) && r.push(t);
            }
            let n = [];
            try {
                n = await GoogleSource.loadPhotos(r);
            } catch (e) {
                return _gPhotoCt = 169, void (_isUpdating = !0);
            }
            updateGooglePhotoUrls(n);
            for (let e = 0; e < t._views.length; e++) {
                const o = t._views[e], i = o.photo;
                if ("Google User" === i.getType()) {
                    const e = n.findIndex(e => e.ex.id === i.getEx().id);
                    e >= 0 && o.setUrl(n[e].url);
                }
            }
            if (!GoogleSource.updateBaseUrls(n)) return _gPhotoCt = 169, void (_isUpdating = !0);
            _isUpdating = !1;
        }
    }
}, window.addEventListener("load", _onLoad$1);

var screensaver = {
    createPages: createPages,
    setSizingType: setSizingType,
    noPhotos: noPhotos,
    setNoPhotos: setNoPhotos,
    setTimeLabel: setTimeLabel,
    setPaused: setPaused
};

export { screensaver as $screensaver, ss_builder as $ssBuilder, ss_history as $ssHistory, ss_photo as $ssPhoto, ss_photo_finder as $ssPhotoFinder, ss_photos as $ssPhotos, ss_runner as $ssRunner, ss_time as $ssTime, ss_views as $ssViews, ss_view as $ssView, ss_view_factory as $ssViewFactory, ss_view_frame as $ssViewFrame, ss_view_full as $ssViewFull, ss_view_letterbox as $ssViewLetterbox, ss_view_zoom as $ssViewZoom, createPages, setSizingType, noPhotos, setNoPhotos, setTimeLabel, setPaused, build, initialize$1 as initialize, add, clear, back, SSPhoto as $ssPhotoDefault, initialize as initialize$1, getNext, replacePhoto, addFromSource, getCount, hasUsable, get, getNextUsable, getCurrentIndex, getNextGooglePhotos, updateGooglePhotoUrls, setCurrentIndex, incCurrentIndex, shuffle, start, getWaitTime, setWaitTime, setLastSelected, setReplaceIdx, isStarted, isInteractive, isPaused, isCurrentPair, togglePaused, forward, back$1, initialize$2, setTime, Type, create$1 as create, getType, getCount$1, get$1, getSelectedIndex, setSelectedIndex, isSelectedIndex, hasPhoto, hasUsable$1, replaceAll, findLoadedPhoto, SSView as $ssViewDefault, create as create$1, SSViewFrame as $ssViewFrameDefault, SSViewFull as $ssViewFullDefault, SSViewLetterbox as $ssViewLetterboxDefault, SSViewZoom as $ssViewZoomDefault };