import { customElement, property, computed, query, listen, observe, mixinBehaviors, NeonAnimationBehavior, BaseElement, html, NeonAnimatableBehavior, DEF_WEATHER, error, event, EVENT as EVENT$1, page, localize, getBool, getInt, get as get$1, isWhiteSpace, getRandomInt, getRandomFloat, shuffleArray, isInOrigins, DETECT_FACES, isGoogleSourceOrigin, error$1, send, addListener, removeListener, ChromeTime, EVENT$1 as EVENT, initialize as initialize$2, TYPE$1 as TYPE, getSelectedSources, GoogleSource } from "./shared_bundle_4.js";

var __decorate = function(e, t, n, i) {
    var o, r = arguments.length, a = r < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, i); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (r < 3 ? o(a) : r > 3 ? o(t, n, a) : o(t, n)) || a);
    return r > 3 && a && Object.defineProperty(t, n, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */ let SpinDownAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        }, {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinDownAnimationElement = __decorate([ customElement("spin-down-animation") ], SpinDownAnimationElement);

var spinDownAnimation = {
    get SpinDownAnimationElement() {
        return SpinDownAnimationElement;
    }
}, __decorate$1 = function(e, t, n, i) {
    var o, r = arguments.length, a = r < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, i); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (r < 3 ? o(a) : r > 3 ? o(t, n, a) : o(t, n)) || a);
    return r > 3 && a && Object.defineProperty(t, n, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let SpinUpAnimationElement = class extends(mixinBehaviors([ NeonAnimationBehavior ], BaseElement)){
    configure(e) {
        const t = e.node;
        return e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        new KeyframeEffect(t, [ {
            transform: "scale(0) rotate(0)",
            easing: "ease-in-out"
        }, {
            transform: "scale(1) rotate(1.0turn)",
            easing: "ease-in-out"
        } ], this.timingFromConfig(e));
    }
};

SpinUpAnimationElement = __decorate$1([ customElement("spin-up-animation") ], SpinUpAnimationElement);

var spinUpAnimation = {
    get SpinUpAnimationElement() {
        return SpinUpAnimationElement;
    }
}, __decorate$2 = function(e, t, n, i) {
    var o, r = arguments.length, a = r < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, i); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (r < 3 ? o(a) : r > 3 ? o(t, n, a) : o(t, n)) || a);
    return r > 3 && a && Object.defineProperty(t, n, a), a;
};

/*
           *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
           *  Licensed under the BSD-3-Clause
           *  https://opensource.org/licenses/BSD-3-Clause
           *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
           */
let WeatherElement = class extends BaseElement {
    constructor() {
        super(...arguments), this.show = !1, this.weather = DEF_WEATHER;
    }
    _weatherChanged(e, t) {
        let n = null;
        if (void 0 !== t && (n = "wi-owm-" + t.dayNight + t.id), void 0 !== e) {
            const t = "wi-owm-" + e.dayNight + e.id;
            n ? this.$.weatherIcon.classList.replace(n, t) : this.$.weatherIcon.classList.add(t);
        }
    }
    static get template() {
        return html`<!--
  Need to include globally too
  see: https://bugs.chromium.org/p/chromium/issues/detail?id=336876
  -->
<link rel="stylesheet" href="../../css/weather-icons.min.css">

<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .temp {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0 0 0 16px;
  }

  :host .icon {
    font-size: 5.25vh;
    font-weight: 200;
    margin: 0;
    padding: 0;
  }

</style>

<div class="horizontal layout center" hidden$="[[!show]]">
  <i id="weatherIcon" class="icon wi"></i>
  <paper-item class="temp">[[weather.temp]]</paper-item>
</div>

<app-localstorage-document key="currentWeather" data="{{weather}}" storage="window.localStorage">
</app-localstorage-document>
<app-localstorage-document key="showCurrentWeather" data="{{show}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$2([ property({
    type: Boolean,
    notify: !0
}) ], WeatherElement.prototype, "show", void 0), __decorate$2([ property({
    type: Object,
    observer: "_weatherChanged"
}) ], WeatherElement.prototype, "weather", void 0), WeatherElement = __decorate$2([ customElement("weather-element") ], WeatherElement);

var weatherElement = {
    get WeatherElement() {
        return WeatherElement;
    }
};

function initialize() {
    return faceapi.loadTinyFaceDetectorModel("/assets/models").catch(e => {
        throw e;
    });
}

function detectAll(e) {
    return faceapi.detectAllFaces(e, new faceapi.TinyFaceDetectorOptions()).then(e => e).catch(() => []);
}

var ScreensaverSlideElement_1, face_detect = {
    initialize: initialize,
    detectAll: detectAll
}, __decorate$3 = function(e, t, n, i) {
    var o, r = arguments.length, a = r < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, i); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (r < 3 ? o(a) : r > 3 ? o(t, n, a) : o(t, n)) || a);
    return r > 3 && a && Object.defineProperty(t, n, a), a;
};

let ScreensaverSlideElement = ScreensaverSlideElement_1 = class extends(mixinBehaviors([ NeonAnimatableBehavior ], BaseElement)){
    constructor() {
        super(...arguments), this.photo = null, this.viewType = 0, this.index = 0, this.url = "", 
        this.aniType = 1, this.screenWidth = screen.width, this.screenHeight = screen.height, 
        this.timeLabel = "", this.isAnimate = !1, this.animation = null, this.detectFaces = getBool("detectFaces", !1), 
        this.animationTarget = null, this.animationConfig = {
            entry: {
                name: "fade-in-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            },
            exit: {
                name: "fade-out-animation",
                node: this,
                timing: {
                    duration: 2e3,
                    easing: "ease-in-out"
                }
            }
        };
    }
    static setFrameLabelStyle(e, t, n, i) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = "1.0", 
        e.fontSize = "2.5vh", e.fontWeight = "400";
        const o = t / screen.width * 100, r = (100 - o) / 2;
        i ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = o - 1 + "vw";
        const a = (100 - n / screen.height * 100) / 2;
        e.bottom = a + 1.1 + "vh";
    }
    get authorLabel() {
        let e = "";
        if (this.photo) {
            const t = this.photo.getType(), n = this.photo.getPhotographer();
            let i = t;
            const o = t.search("User");
            if (!getBool("showPhotog", !0) && -1 !== o) return "";
            -1 !== o && (i = t.substring(0, o - 1)), e = isWhiteSpace(n) ? `${localize("photo_from")} ${i}` : `${n} / ${i}`;
        }
        return e;
    }
    get locationLabel() {
        return "";
    }
    getPhoto() {
        return this.photo;
    }
    setUrl(e) {
        this.set("url", e);
    }
    isPhotoLoaded() {
        return !!this.ironImage && this.ironImage.loaded;
    }
    isPhotoError() {
        return !this.ironImage || this.ironImage.error;
    }
    async prep() {
        getBool("largeTime", !1) && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = "300"), 
        this.render(), this.isAnimate && await this.startAnimation();
    }
    onErrorChanged(e) {
        e.detail.value && this.fireEvent("image-error", this.index);
    }
    photoChanged(e) {
        e && this.set("url", e.getUrl());
    }
    aniChanged(e) {
        let t, n, i = 2e3;
        switch (e) {
          case 0:
            t = "scale-up-animation", n = "scale-down-animation";
            break;

          case 1:
            t = "fade-in-animation", n = "fade-out-animation";
            break;

          case 2:
            t = "slide-from-right-animation", n = "slide-left-animation";
            break;

          case 3:
            t = "slide-from-top-animation", n = "slide-up-animation";
            break;

          case 4:
            t = "spin-up-animation", n = "spin-down-animation", i = 3e3;
            break;

          case 5:
            t = "slide-from-bottom-animation", n = "slide-down-animation";
            break;

          case 6:
            t = "slide-from-bottom-animation", n = "slide-up-animation";
            break;

          case 7:
            t = "slide-from-left-animation", n = "slide-left-animation";
            break;

          default:
            t = "fade-in-animation", n = "fade-out-animation";
        }
        this.animationConfig.entry.name = t, this.animationConfig.entry.timing.duration = i, 
        this.animationConfig.exit.name = n, this.animationConfig.exit.timing.duration = i;
    }
    isAnimateChanged(e) {
        void 0 !== e && (e || this.animation && (this.animation.cancel(), this.set("animation", null)));
    }
    render() {
        switch (this.viewType) {
          case 1:
            this.renderZoom();
            break;

          case 3:
            this.renderFull();
            break;

          case 0:
            this.renderLetterbox();
            break;

          case 2:
            this.renderFrame();
        }
    }
    renderFull() {
        const e = this.ironImage.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
    renderZoom() {
        const e = this.ironImage.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "cover";
    }
    renderLetterbox() {
        if (!this.photo) return;
        const e = screen.width / screen.height, t = this.photo.getAspectRatio(), n = this.ironImage, i = n.style, o = n.$.img.style, r = this.author.style, a = this.location.style, s = this.time.style, l = this.weather.style;
        let c = t / e * 100;
        const d = (100 - (c = Math.min(c, 100))) / 2;
        let h = e / t * 100;
        const m = (100 - (h = Math.min(h, 100))) / 2, p = Math.round(h / 100 * screen.height), g = Math.round(c / 100 * screen.width);
        n.height = p, n.width = g, o.height = p + "px", o.width = g + "px", i.top = (screen.height - p) / 2 + "px", 
        i.left = (screen.width - g) / 2 + "px", r.textAlign = "right", a.textAlign = "left", 
        l.textAlign = "left", r.right = d + 1 + "vw", r.bottom = m + 1 + "vh", r.width = c - .5 + "vw", 
        a.left = d + 1 + "vw", a.bottom = m + 1 + "vh", a.width = c - .5 + "vw", l.left = d + 1 + "vw", 
        l.bottom = m + 3.5 + "vh", l.width = c - .5 + "vw", s.right = d + 1 + "vw", s.bottom = m + 3.5 + "vh", 
        0 !== getInt("showTime", 0) && (r.textOverflow = "ellipsis", r.whiteSpace = "nowrap");
        const u = c / 2;
        isWhiteSpace(this.locationLabel) || (r.maxWidth = u - 1.1 + "vw"), isWhiteSpace(this.authorLabel) || (a.maxWidth = u - 1.1 + "vw");
    }
    renderFrame() {
        if (!this.photo) return;
        const e = this.photo.getAspectRatio(), t = this.ironImage, n = t.style, i = t.$.img.style, o = this.author.style, r = this.location.style, a = this.weather.style, s = this.time.style, l = .005 * screen.height, c = .05 * screen.height, d = .025 * screen.height, h = Math.min((screen.width - 2 * d - 2 * l) / e, screen.height - 2 * d - l - c), m = h * e, p = m + 2 * l, g = h + c + l;
        t.height = h, t.width = m, n.top = (screen.height - g) / 2 + "px", n.left = (screen.width - p) / 2 + "px", 
        n.border = "0.5vh ridge WhiteSmoke", n.borderBottom = "5vh solid WhiteSmoke", n.borderRadius = "1.5vh", 
        n.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", i.height = h + "px", i.width = m + "px", 
        i.top = screen.height / 2 + "px", i.left = screen.width / 2 + "px", ScreensaverSlideElement_1.setFrameLabelStyle(o, p, g, !1), 
        ScreensaverSlideElement_1.setFrameLabelStyle(r, p, g, !0);
        const u = (100 - g / screen.height * 100) / 2, S = p / screen.width * 100, f = (100 - S) / 2;
        s.right = f + 1 + "vw", s.textAlign = "right", s.bottom = u + 5 + "vh", a.left = f + 1 + "vw", 
        a.textAlign = "left", a.bottom = u + 6.5 + "vh";
        const v = S / 2;
        isWhiteSpace(this.locationLabel) || (o.maxWidth = v - 1 + "vw"), isWhiteSpace(this.authorLabel) || (r.maxWidth = v - 1 + "vw");
    }
    async setAnimationTarget() {
        const e = this.ironImage;
        if (!e) return;
        const t = e.width, n = e.height;
        if (t && n) try {
            const e = this.ironImage.$.img;
            let i = [];
            try {
                i = await detectAll(e);
            } catch (e) {}
            if (i.length) {
                const o = {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                };
                let r = e.naturalWidth, a = 0, s = e.naturalHeight, l = 0;
                for (const e of i) {
                    const t = e.box;
                    r = Math.min(t.left, r), a = Math.max(t.right, a), s = Math.min(t.top, s), l = Math.max(t.bottom, l);
                }
                o.x = Math.round(r + (a - r) / 2 - e.naturalWidth / 2), o.y = Math.round(s + (l - s) / 2 - e.naturalHeight / 2), 
                o.width = Math.round(a - r), o.height = Math.round(l - s);
                const c = t / e.naturalWidth, d = n / e.naturalHeight;
                if (o.x = Math.round(o.x * c), o.y = Math.round(o.y * d), o.width = Math.round(o.width * c), 
                o.height = Math.round(o.height * d), 1 === i.length) {
                    const e = o.height;
                    o.height = Math.round(1.2 * e), o.y = Math.round(o.y - .2 * o.height), o.y = Math.max(o.y, -n / 2);
                }
                this.animationTarget = o;
            } else this.animationTarget = null;
        } catch (e) {
            this.animationTarget = null, error(e.message, "SSSlide.setAnimationTarget");
        }
    }
    async startAnimation() {
        if (this.animation && (this.animation.cancel(), this.set("animation", null)), !this.isAnimate) return;
        const e = this.ironImage;
        if (!e) return;
        const t = e.width, n = e.height;
        if (t && n) try {
            this.detectFaces && isInOrigins(this.url, DETECT_FACES) && await this.setAnimationTarget();
            const i = 1e3 * get$1("transitionTime", {
                base: 30,
                display: 30,
                unit: 0
            }).base;
            let o = 1e3;
            let r, a, s;
            if (4 === getInt("photoTransition", 1) && (o = 2e3), this.animationTarget) {
                const e = t / this.animationTarget.width, i = n / this.animationTarget.height, o = Math.min(e, i), l = .25 * ((s = Math.min(1.6, o)) - 1) * t, c = .25 * (s - 1) * n, d = Math.min(l, Math.abs(this.animationTarget.x)) * Math.sign(this.animationTarget.x), h = Math.min(c, Math.abs(this.animationTarget.y)) * Math.sign(this.animationTarget.y);
                r = -d + "px", a = -h + "px";
            } else {
                const e = getRandomInt(0, 1) ? -1 : 1, i = getRandomInt(0, 1) ? -1 : 1, o = .2 * ((s = 1 + getRandomFloat(.2, .6)) - 1), l = e * t * getRandomFloat(0, o), c = i * n * getRandomFloat(0, o);
                r = Math.round(l) + "px", a = Math.round(c) + "px";
            }
            const l = [ {
                transform: "scale(1.0) translateX(0vw) translateY(0vh)"
            }, {
                transform: `scale(${s}) translateX(${r}) translateY(${a})`
            } ], c = {
                delay: o,
                duration: i - o,
                iterations: 1,
                easing: "ease-in-out",
                fill: "forwards"
            }, d = e.$.img;
            this.set("animation", d.animate(l, c));
        } catch (e) {
            this.animation && (this.animation.cancel(), this.set("animation", null)), error(e.message, "SSSlide.startAnimation");
        }
    }
    static get template() {
        return html`
<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  .time {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    right: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .weather {
    font-size: 5.25vh;
    font-weight: 200;
    position: fixed;
    left: 1vw;
    bottom: 3.5vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .author {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    right: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }

  .location {
    font-size: 2.5vh;
    font-weight: 300;
    position: fixed;
    overflow: hidden;
    left: 1vw;
    bottom: 1vh;
    padding: 0;
    margin: 0;
    color: white;
    opacity: 1.0;
  }
  
</style>
<section id="slide[[index]]">
  <iron-image
      crossorign="Anonymous"
      id="ironImage"
      class="image"
      src="[[url]]"
      width="[[screenWidth]]"
      height="[[screenHeight]]"
      preload>
  </iron-image>
  <div class="time">[[timeLabel]]</div>
  <div class="author">[[authorLabel]]</div>
  <div class="location">[[locationLabel]]</div>
  <weather-element class="weather"></weather-element>
</section>


<app-localstorage-document key="panAndScan" data="{{isAnimate}}" storage="window.localStorage">
</app-localstorage-document>

`;
    }
};

__decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "photo", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "viewType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "index", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "url", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "aniType", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenWidth", void 0), __decorate$3([ property({
    type: Number
}) ], ScreensaverSlideElement.prototype, "screenHeight", void 0), __decorate$3([ property({
    type: String
}) ], ScreensaverSlideElement.prototype, "timeLabel", void 0), __decorate$3([ property({
    type: Boolean,
    notify: !0
}) ], ScreensaverSlideElement.prototype, "isAnimate", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animation", void 0), __decorate$3([ property({
    type: Boolean
}) ], ScreensaverSlideElement.prototype, "detectFaces", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animationTarget", void 0), __decorate$3([ property({
    type: Object
}) ], ScreensaverSlideElement.prototype, "animationConfig", void 0), __decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "authorLabel", null), 
__decorate$3([ computed("photo") ], ScreensaverSlideElement.prototype, "locationLabel", null), 
__decorate$3([ query("#ironImage") ], ScreensaverSlideElement.prototype, "ironImage", void 0), 
__decorate$3([ query(".time") ], ScreensaverSlideElement.prototype, "time", void 0), 
__decorate$3([ query(".author") ], ScreensaverSlideElement.prototype, "author", void 0), 
__decorate$3([ query(".location") ], ScreensaverSlideElement.prototype, "location", void 0), 
__decorate$3([ query(".weather") ], ScreensaverSlideElement.prototype, "weather", void 0), 
__decorate$3([ listen("error-changed", "ironImage") ], ScreensaverSlideElement.prototype, "onErrorChanged", null), 
__decorate$3([ observe("photo") ], ScreensaverSlideElement.prototype, "photoChanged", null), 
__decorate$3([ observe("aniType") ], ScreensaverSlideElement.prototype, "aniChanged", null), 
__decorate$3([ observe("isAnimate") ], ScreensaverSlideElement.prototype, "isAnimateChanged", null), 
ScreensaverSlideElement = ScreensaverSlideElement_1 = __decorate$3([ customElement("screensaver-slide") ], ScreensaverSlideElement);

var screensaverSlide = {
    get ScreensaverSlideElement() {
        return ScreensaverSlideElement;
    }
};

let Screensaver;

window.addEventListener("load", () => {
    (Screensaver = document.querySelector("screensaver-element")) ? Screensaver.launch().catch(() => {}) : (error$1("Failed to get screensaver reference", "Screensaver.onLoad"), 
    send(TYPE.SS_CLOSE).catch(() => {}));
});

var screensaver = {
    get Screensaver() {
        return Screensaver;
    }
};

class SSPhoto {
    static ignore(e) {
        let t = !1;
        const n = getBool("skip", !1), i = getInt("photoSizing", 0);
        return n && (1 === i || 3 === i) && SSPhoto._isBadAspect(e) && (t = !0), t;
    }
    static _isBadAspect(e) {
        const t = screen.width / screen.height;
        return e < t - .5 || e > t + .5;
    }
    constructor(e, t, n) {
        this._url = t.url, this._photographer = t.author ? t.author : "", this._aspectRatio = parseFloat(t.asp), 
        this._ex = t.ex, this._point = t.point, this._type = n, this._isBad = !1;
    }
    isBad() {
        return this._isBad;
    }
    markBad() {
        this._isBad = !0;
    }
    getUrl() {
        return this._url;
    }
    setUrl(e) {
        this._url = e, this._isBad = !1;
    }
    getType() {
        return this._type;
    }
    getPhotographer() {
        return this._photographer;
    }
    getAspectRatio() {
        return this._aspectRatio;
    }
    getPoint() {
        return this._point;
    }
    getEx() {
        return this._ex;
    }
    showSource() {
        let e = null;
        switch (this._type) {
          case "flickr":
            if (this._ex) {
                const t = /(\/[^/]*){4}(_.*_)/, n = this._url.match(t);
                n && (e = `https://www.flickr.com/photos/${this._ex}${n[1]}`);
            }
            break;

          case "reddit":
            this._ex && (e = this._ex);
            break;

          case "Google User":
          case "Unsplash":
            this._ex && this._ex.url && (e = this._ex.url);
            break;

          default:
            e = this._url;
        }
        null !== e && (event(EVENT.VIEW_PHOTO, this._type), chrome.tabs.create({
            url: e
        }));
    }
}

var ss_photo = {
    SSPhoto: SSPhoto
};

const PHOTOS = [];

let CUR_IDX = 0;

async function loadPhotos(e) {
    let t = !0;
    try {
        const n = getSelectedSources();
        for (const e of n) await addFromSource(e);
        getCount() ? e && shuffle() : t = !1;
    } catch (e) {
        error(e.message, "SSPhotos.loadPhotos"), t = !1;
    }
    return t;
}

function getCount() {
    return PHOTOS.length;
}

function hasUsable() {
    return !PHOTOS.every(e => e.isBad());
}

function get(e) {
    return PHOTOS[e];
}

function getIndex(e) {
    return PHOTOS.indexOf(e);
}

function getNextUsable(e = []) {
    for (let t = 0; t < PHOTOS.length; t++) {
        const n = (t + CUR_IDX) % PHOTOS.length, i = PHOTOS[n];
        if (!i.isBad() && !e.includes(i)) return CUR_IDX = n, incCurrentIndex(), i;
    }
    return null;
}

function getCurrentIndex() {
    return CUR_IDX;
}

function getNextGooglePhotos(e, t) {
    t = t < 0 ? 0 : t;
    const n = [];
    for (let i = 0, o = 0; i < PHOTOS.length; i++) {
        const r = (i + t) % PHOTOS.length, a = PHOTOS[r];
        if (o >= e) break;
        "Google User" === a.getType() && (n.push(a), o++);
    }
    return n;
}

function updateGooglePhotoUrls(e) {
    for (let t = PHOTOS.length - 1; t >= 0; t--) {
        if ("Google User" !== PHOTOS[t].getType()) continue;
        const n = e.findIndex(e => e.ex.id === PHOTOS[t].getEx().id);
        n >= 0 && PHOTOS[t].setUrl(e[n].url);
    }
}

function setCurrentIndex(e) {
    CUR_IDX = e;
}

function incCurrentIndex() {
    return CUR_IDX = CUR_IDX === PHOTOS.length - 1 ? 0 : CUR_IDX + 1;
}

async function addFromSource(e) {
    const t = await e.getPhotos(), n = t.type;
    let i = 0;
    for (const e of t.photos) {
        const t = parseFloat(e.asp);
        if (!SSPhoto.ignore(t)) {
            const t = new SSPhoto(i, e, n);
            PHOTOS.push(t), i++;
        }
    }
}

function shuffle() {
    shuffleArray(PHOTOS);
}

var ss_photos = {
    loadPhotos: loadPhotos,
    getCount: getCount,
    hasUsable: hasUsable,
    get: get,
    getIndex: getIndex,
    getNextUsable: getNextUsable,
    getCurrentIndex: getCurrentIndex,
    getNextGooglePhotos: getNextGooglePhotos,
    updateGooglePhotoUrls: updateGooglePhotoUrls,
    setCurrentIndex: setCurrentIndex,
    incCurrentIndex: incCurrentIndex
};

const HIST = {
    arr: [],
    idx: -1,
    max: 10
};

function initialize$1() {
    HIST.max = Math.min(getCount(), Screensaver.getMaxSlideCount());
}

function add(e, t, n) {
    const i = Screensaver.getSlide(t).getPhoto();
    if (null === e && i) {
        const e = HIST.idx, o = HIST.arr.length, r = {
            currentIdx: t,
            replaceIdx: n,
            photoId: getIndex(i),
            photosPos: getCurrentIndex()
        };
        e === o - 1 && (HIST.arr.length > HIST.max && (HIST.arr.shift(), HIST.idx--, HIST.idx = Math.max(HIST.idx, -1)), 
        HIST.arr.push(r));
    }
    HIST.idx++;
}

function clear() {
    HIST.arr = [], HIST.idx = -1;
}

function back() {
    if (HIST.idx <= 0) return null;
    let e = null, t = 2, n = HIST.idx - t;
    if (HIST.idx = n, n < 0) {
        if (HIST.arr.length > HIST.max) return HIST.idx += t, null;
        HIST.idx = -1, t = 1, e = -1, n = 0;
    }
    const i = HIST.arr[n].photosPos, o = HIST.arr[n + t].replaceIdx;
    setCurrentIndex(i), setReplaceIdx(o);
    const r = HIST.arr[n].currentIdx;
    e = null === e ? r : e;
    const a = get(HIST.arr[n].photoId);
    return Screensaver.replacePhoto(a, r), e;
}

var ss_history = {
    initialize: initialize$1,
    add: add,
    clear: clear,
    back: back
};

const VARS = {
    started: !1,
    replaceIdx: -1,
    lastSelected: -1,
    transTime: 3e4,
    waitTime: 3e4,
    interactive: !1,
    paused: !1,
    timeOutId: 0
};

function start(e = 2e3) {
    const t = get$1("transitionTime", {
        base: 30,
        display: 30,
        unit: 0
    });
    VARS.transTime = 1e3 * t.base, setWaitTime(1e3 * t.base), VARS.interactive = getBool("interactive", !1), 
    initialize$1(), window.setTimeout(runShow, e);
}

function setReplaceIdx(e) {
    VARS.replaceIdx = e;
}

function isStarted() {
    return VARS.started;
}

function isInteractive() {
    return VARS.interactive;
}

function isCurrentPair(e) {
    return e === Screensaver.getSelectedSlideIndex() || e === VARS.lastSelected;
}

function togglePaused(e = null) {
    VARS.started && (VARS.paused = !VARS.paused, Screensaver.setPaused(VARS.paused), 
    VARS.paused ? stop() : restart(e));
}

function forward() {
    VARS.started && step();
}

function back$1() {
    if (VARS.started) {
        const e = back();
        null !== e && step(e);
    }
}

function isPaused() {
    return VARS.paused;
}

function stop() {
    window.clearTimeout(VARS.timeOutId);
}

function restart(e = null) {
    const t = get$1("transitionTime");
    t && setWaitTime(1e3 * t.base), runShow(e).catch(() => {});
}

function step(e = null) {
    isPaused() ? (togglePaused(e), togglePaused()) : (stop(), restart(e));
}

async function runShow(e = null) {
    if (Screensaver.isNoPhotos()) return;
    const t = Screensaver.getSelectedSlideIndex(), n = Screensaver.getSlideCount();
    let i = null === e ? t : e, o = (i = isStarted() ? i : 0) === n - 1 ? 0 : i + 1;
    if (isStarted() || (o = 0), -1 !== (o = getNextSlideIdx(o))) {
        isStarted() || (VARS.started = !0);
        const n = Screensaver.getSlide(o);
        n && await n.prep(), VARS.interactive && add(e, o, VARS.replaceIdx), VARS.lastSelected = t, 
        Screensaver.setSelectedSlideIndex(o), null === e && (replacePhoto(VARS.replaceIdx), 
        VARS.replaceIdx = VARS.lastSelected);
    }
    VARS.timeOutId = setTimeout(async () => {
        await runShow();
    }, VARS.waitTime);
}

function setWaitTime(e) {
    VARS.waitTime = e, VARS.waitTime = Math.min(2147483647, e);
}

function getNextSlideIdx(e) {
    const t = Screensaver.findLoadedPhoto(e);
    return setWaitTime(-1 === t ? 500 : VARS.transTime), t;
}

function replacePhoto(e) {
    if (e >= 0) {
        if (Screensaver.isSelectedSlideIndex(e)) return;
        const t = Screensaver.getSlideCount();
        if (getCount() <= t) return;
        const n = getNextUsable(Screensaver.getPhotos());
        n && Screensaver.replacePhoto(n, e);
    }
}

var ss_runner = {
    start: start,
    setReplaceIdx: setReplaceIdx,
    isStarted: isStarted,
    isInteractive: isInteractive,
    isCurrentPair: isCurrentPair,
    togglePaused: togglePaused,
    forward: forward,
    back: back$1
};

const _MOUSE_START = {
    x: null,
    y: null
};

function addListeners() {
    addListener(onChromeMessage), window.addEventListener("keydown", onKey, !1), window.addEventListener("mousemove", onMouseMove, !1), 
    window.addEventListener("click", onMouseClick, !1), chrome.commands.onCommand.addListener(onKeyCommand);
}

function removeListeners() {
    removeListener(onChromeMessage), window.removeEventListener("keydown", onKey, !1), 
    window.removeEventListener("mousemove", onMouseMove, !1), window.removeEventListener("click", onMouseClick, !1), 
    chrome.commands.onCommand.removeListener(onKeyCommand);
}

function close() {
    send(TYPE.SS_CLOSE).catch(() => {}), setTimeout(() => {
        window.close();
    }, 750);
}

function onKeyCommand(e) {
    isStarted() && isInteractive() && ("ss-toggle-paused" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), 
    togglePaused()) : "ss-forward" === e ? (event(EVENT$1.KEY_COMMAND, `${e}`), forward()) : "ss-back" === e && (event(EVENT$1.KEY_COMMAND, `${e}`), 
    back$1()));
}

function onChromeMessage(e, t, n) {
    return e.message === TYPE.SS_CLOSE.message ? close() : e.message === TYPE.SS_IS_SHOWING.message && n({
        message: "OK"
    }), !1;
}

function onKey(e) {
    const t = e.key;
    if (isStarted() || isInteractive()) switch (t) {
      case "Alt":
      case "Shift":
      case " ":
      case "ArrowLeft":
      case "ArrowRight":
        isInteractive() || close();
        break;

      default:
        close();
    } else close();
}

function onMouseMove(e) {
    if (_MOUSE_START.x && _MOUSE_START.y) {
        const t = Math.abs(e.clientX - _MOUSE_START.x), n = Math.abs(e.clientY - _MOUSE_START.y);
        Math.max(t, n) > 10 && close();
    } else _MOUSE_START.x = e.clientX, _MOUSE_START.y = e.clientY;
}

function onMouseClick() {
    if (isStarted()) {
        const e = Screensaver.getSelectedPhoto();
        getBool("allowPhotoClicks", !0) && e && e.showSource();
    }
    close();
}

var ScreensaverElement_1, ss_events = {
    addListeners: addListeners,
    removeListeners: removeListeners
}, __decorate$4 = function(e, t, n, i) {
    var o, r = arguments.length, a = r < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, i); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (r < 3 ? o(a) : r > 3 ? o(t, n, a) : o(t, n)) || a);
    return r > 3 && a && Object.defineProperty(t, n, a), a;
};

const errHandler = {
    MAX_COUNT: 168,
    count: 0,
    isUpdating: !1,
    TIME_LIMIT: 3e5,
    lastTime: 0
};

let ScreensaverElement = ScreensaverElement_1 = class extends BaseElement {
    constructor() {
        super(...arguments), this.MAX_SLIDES = 10, this.photos = [], this.aniType = ScreensaverElement_1.getAniType(), 
        this.viewType = ScreensaverElement_1.getViewType(), this.paused = !1, this.noPhotos = !1, 
        this.timeLabel = "", this.delayTime = 1500;
    }
    static getViewType() {
        let e = getInt("photoSizing", 0);
        return 4 === e && (e = getRandomInt(0, 3)), e;
    }
    static getAniType() {
        let e = getInt("photoTransition", 1);
        return 8 === e && (e = getRandomInt(0, 7)), e;
    }
    static async setZoom() {
        const e = new ChromePromise();
        try {
            const t = await e.tabs.getZoom();
            (t <= .99 || t >= 1.01) && chrome.tabs.setZoom(1);
        } catch (e) {
            error(e.message, "SS.setZoom");
        }
    }
    static async setupFaceDetect() {
        getBool("panAndScan", !1) && await initialize();
    }
    connectedCallback() {
        super.connectedCallback(), addListeners();
    }
    disconnectedCallback() {
        super.disconnectedCallback(), removeListeners();
    }
    async ready() {
        super.ready(), document.body.style.background = get$1("background", "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)").substring(11), 
        initialize$2(), page("/screensaver.html"), await ScreensaverElement_1.setZoom();
    }
    async launch() {
        try {
            const e = getBool("shuffle", !1);
            if (!await loadPhotos(e)) return void this.setNoPhotos();
            try {
                await ScreensaverElement_1.setupFaceDetect();
            } catch (e) {
                error(e.message, "SS.launch");
            }
            const t = [], n = Math.min(getCount(), this.MAX_SLIDES);
            for (let e = 0; e < n; e++) {
                const e = getNextUsable();
                e && t.push(e);
            }
            if (this.set("photos", t), this.repeatTemplate.render(), 0 === t.length) return void this.setNoPhotos();
            send(TYPE.UPDATE_WEATHER).catch(() => {}), this.setupTime(), start(this.delayTime);
        } catch (e) {
            error$1(e.message, "SS.launch"), this.setNoPhotos();
        }
    }
    getMaxSlideCount() {
        return this.MAX_SLIDES;
    }
    getPhotos() {
        return this.photos;
    }
    getSelectedPhoto() {
        let e;
        const t = this.getSelectedSlideIndex();
        return -1 !== t && (e = this.photos[t]), e;
    }
    replacePhoto(e, t) {
        if (e && t >= 0) {
            this.splice("photos", t, 1, e);
            const n = this.getSlide(t);
            n.setUrl(e.getUrl()), n.notifyPath("url");
        }
    }
    findLoadedPhoto(e) {
        this.hasUsablePhoto() || this.replaceAllPhotos();
        const t = this.getSlide(e);
        if (t && t.isPhotoLoaded()) return e;
        for (let t = 0; t < this.photos.length; t++) {
            const n = (t + e) % this.photos.length, i = this.getSlide(n), o = this.photos[n];
            if (!isCurrentPair(n)) {
                if (i.isPhotoLoaded()) return n;
                if (i.isPhotoError() && !o.isBad() && (o.markBad(), !hasUsable())) return this.setNoPhotos(), 
                -1;
            }
        }
        return -1;
    }
    isSelectedSlideIndex(e) {
        let t = !1;
        return this.pages && e === this.pages.selected && (t = !0), t;
    }
    getSelectedSlideIndex() {
        if (this.pages) {
            let e;
            return e = "string" == typeof this.pages.selected ? parseInt(this.pages.selected, 10) : this.pages.selected;
        }
        return -1;
    }
    setSelectedSlideIndex(e) {
        this.pages && (this.pages.selected = e);
    }
    getSlideCount() {
        return this.photos ? this.photos.length : 0;
    }
    getSlide(e) {
        const t = `#slide${e}`;
        return this.shadowRoot.querySelector(t);
    }
    isNoPhotos() {
        return this.noPhotos;
    }
    setNoPhotos() {
        this.set("noPhotos", !0);
    }
    setPaused(e) {
        this.set("paused", e);
    }
    setupTime() {
        0 !== getInt("showTime", 0) && (this.setTimeLabel(), setInterval(this.setTimeLabel.bind(this), 61e3));
    }
    setTimeLabel() {
        let e = "";
        const t = getInt("showTime", 0);
        0 !== t && (e = ChromeTime.getStringShort(t), this.set("timeLabel", e));
    }
    pausedChanged(e, t) {
        void 0 !== t && (e ? (this.$.pauseImage.classList.add("fadeOut"), this.$.playImage.classList.remove("fadeOut")) : (this.$.playImage.classList.add("fadeOut"), 
        this.$.pauseImage.classList.remove("fadeOut")));
    }
    hasUsablePhoto() {
        let e = !1;
        for (let t = 0; t < this.photos.length; t++) {
            const n = this.photos[t];
            if (!isCurrentPair(t) && !n.isBad()) {
                e = !0;
                break;
            }
        }
        return e;
    }
    replaceAllPhotos() {
        for (let e = 0; e < this.photos.length; e++) {
            if (isCurrentPair(e)) continue;
            const t = getNextUsable(this.photos);
            if (!t) break;
            this.replacePhoto(t, e);
        }
        clear();
    }
    updateAllUrls(e) {
        for (let t = 0; t < this.photos.length; t++) {
            const n = this.photos[t];
            if ("Google User" === n.getType()) {
                const i = this.getSlide(t), o = e.findIndex(e => e.ex.id === n.getEx().id);
                o >= 0 && i.setUrl(e[o].url);
            }
        }
    }
    async onImageError(e) {
        if (errHandler.isUpdating) return;
        errHandler.isUpdating = !0;
        const t = e.detail.value, n = this.photos[t];
        if ("Google User" === n.getType()) try {
            if (!navigator.onLine) return void (errHandler.isUpdating = !1);
            if (Date.now() - errHandler.lastTime < errHandler.TIME_LIMIT) return void (errHandler.isUpdating = !1);
            if (errHandler.count++, errHandler.count >= errHandler.MAX_COUNT) return void (errHandler.isUpdating = !1);
            errHandler.lastTime = Date.now();
            const e = n.getUrl();
            if (await isGoogleSourceOrigin(e)) try {
                if (403 !== (await fetch(e, {
                    method: "get"
                })).status) return void (errHandler.isUpdating = !1);
            } catch (e) {
                return void (errHandler.isUpdating = !1);
            }
            let t = get$1("transitionTime", {
                base: 30,
                display: 30,
                unit: 0
            });
            t = 1e3 * t.base;
            let i = Math.round(ChromeTime.MSEC_IN_HOUR / t);
            i = Math.max(i, 50);
            const o = getNextGooglePhotos(i = 1 === errHandler.count ? Math.min(i, 50) : Math.min(i, 300), getIndex(n)), r = [];
            for (const e of o) {
                const t = e.getEx();
                if (t) {
                    const e = t.id;
                    -1 === r.indexOf(e) && r.push(e);
                }
            }
            const a = await GoogleSource.loadPhotos(r);
            if (updateGooglePhotoUrls(a), this.updateAllUrls(a), !await GoogleSource.updateBaseUrls(a)) return error("Failed to save new urls", "SS.onImageError"), 
            errHandler.count = errHandler.MAX_COUNT + 1, void (errHandler.isUpdating = !0);
            errHandler.isUpdating = !1;
        } catch (e) {
            return error(e.message, "SS.onImageError"), errHandler.count = errHandler.MAX_COUNT + 1, 
            void (errHandler.isUpdating = !0);
        }
    }
    static get template() {
        return html`<style include="shared-styles iron-flex iron-flex-alignment iron-positioning">
  :host {
    display: block;
  }

  /* Added programmatically */
  .fadeOut {
    animation: fadeOut 1s 2s;
    animation-fill-mode: both;
  }

  @keyframes fadeOut {
    from {
      opacity: 1.0;
    }
    to {
      opacity: 0.0;
    }
  }

  .vcr {
    position: fixed;
    width: 15vh;
    height: 15vh;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.0;
  }

  .noPhotos {
    font-size: 5vh;
    font-weight: 600;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    color: rgba(48, 63, 159, 1);
    opacity: .8;
  }

</style>

<div id="mainContainer" class="flex" hidden$="[[noPhotos]]">
  <neon-animated-pages id="pages" class="fit" animate-initial-selection>
    <template is="dom-repeat" id="repeatTemplate" as="photo" items="[[photos]]">
      <screensaver-slide class="fit" id="slide[[index]]" view-type="[[viewType]]" ani-type="[[aniType]]"
                         photo="[[photo]]" index="[[index]]" time-label="[[timeLabel]]" on-image-error="onImageError">
      </screensaver-slide>
    </template>
  </neon-animated-pages>
</div>

<div class="noPhotos" hidden$="[[!noPhotos]]">[[localize('no_photos')]]</div>

<iron-image id="pauseImage" class="vcr" src="../images/pause.png" sizing="contain" preload
            hidden$="[[!paused]]"></iron-image>
<iron-image id="playImage" class="vcr" src="../images/play.png" sizing="contain" preload
            hidden$="[[paused]]"></iron-image>
`;
    }
};

__decorate$4([ property({
    type: Array
}) ], ScreensaverElement.prototype, "photos", void 0), __decorate$4([ property({
    type: Number
}) ], ScreensaverElement.prototype, "aniType", void 0), __decorate$4([ property({
    type: Number
}) ], ScreensaverElement.prototype, "viewType", void 0), __decorate$4([ property({
    type: Boolean,
    observer: "pausedChanged"
}) ], ScreensaverElement.prototype, "paused", void 0), __decorate$4([ property({
    type: Boolean
}) ], ScreensaverElement.prototype, "noPhotos", void 0), __decorate$4([ property({
    type: String
}) ], ScreensaverElement.prototype, "timeLabel", void 0), __decorate$4([ query("#repeatTemplate") ], ScreensaverElement.prototype, "repeatTemplate", void 0), 
__decorate$4([ query("#pages") ], ScreensaverElement.prototype, "pages", void 0), 
ScreensaverElement = ScreensaverElement_1 = __decorate$4([ customElement("screensaver-element") ], ScreensaverElement);

var screensaverElement = {
    get ScreensaverElement() {
        return ScreensaverElement;
    }
};

export { face_detect as $faceDetect, screensaver as $screensaver, screensaverElement as $screensaverElement, screensaverSlide as $screensaverSlide, spinDownAnimation as $spinDownAnimation, spinUpAnimation as $spinUpAnimation, ss_events as $ssEvents, ss_history as $ssHistory, ss_photo as $ssPhoto, ss_photos as $ssPhotos, ss_runner as $ssRunner, weatherElement as $weatherElement, SSPhoto, Screensaver, ScreensaverElement, ScreensaverSlideElement, SpinDownAnimationElement, SpinUpAnimationElement, WeatherElement, add, addListeners, back, back$1, clear, detectAll, forward, get, getCount, getCurrentIndex, getIndex, getNextGooglePhotos, getNextUsable, hasUsable, incCurrentIndex, initialize, initialize$1, isCurrentPair, isInteractive, isStarted, loadPhotos, removeListeners, setCurrentIndex, setReplaceIdx, start, togglePaused, updateGooglePhotoUrls };