/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
"use strict";

const nativeShadow = !(window.ShadyDOM && window.ShadyDOM.inUse);

let nativeCssVariables_, cssBuild;

function calcCssVariables(e) {
    nativeCssVariables_ = (!e || !e.shimcssproperties) && (nativeShadow || Boolean(!navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/) && window.CSS && CSS.supports && CSS.supports("box-shadow", "0 0 0 var(--foo)")));
}

window.ShadyCSS && void 0 !== window.ShadyCSS.cssBuild && (cssBuild = window.ShadyCSS.cssBuild);

const disableRuntime = Boolean(window.ShadyCSS && window.ShadyCSS.disableRuntime);

window.ShadyCSS && void 0 !== window.ShadyCSS.nativeCss ? nativeCssVariables_ = window.ShadyCSS.nativeCss : window.ShadyCSS ? (calcCssVariables(window.ShadyCSS), 
window.ShadyCSS = void 0) : calcCssVariables(window.WebComponents && window.WebComponents.flags);

const nativeCssVariables = nativeCssVariables_;

var styleSettings = {
    nativeShadow: nativeShadow,
    get cssBuild() {
        return cssBuild;
    },
    disableRuntime: disableRuntime,
    nativeCssVariables: nativeCssVariables
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ class StyleNode {
    constructor() {
        this.start = 0, this.end = 0, this.previous = null, this.parent = null, this.rules = null, 
        this.parsedCssText = "", this.cssText = "", this.atRule = !1, this.type = 0, this.keyframesName = "", 
        this.selector = "", this.parsedSelector = "";
    }
}

function parse(e) {
    return parseCss(lex(e = clean(e)), e);
}

function clean(e) {
    return e.replace(RX.comments, "").replace(RX.port, "");
}

function lex(e) {
    let t = new StyleNode();
    t.start = 0, t.end = e.length;
    let n = t;
    for (let i = 0, r = e.length; i < r; i++) if (e[i] === OPEN_BRACE) {
        n.rules || (n.rules = []);
        let e = n, t = e.rules[e.rules.length - 1] || null;
        (n = new StyleNode()).start = i + 1, n.parent = e, n.previous = t, e.rules.push(n);
    } else e[i] === CLOSE_BRACE && (n.end = i + 1, n = n.parent || t);
    return t;
}

function parseCss(e, t) {
    let n = t.substring(e.start, e.end - 1);
    if (e.parsedCssText = e.cssText = n.trim(), e.parent) {
        let i = e.previous ? e.previous.end : e.parent.start;
        n = (n = (n = _expandUnicodeEscapes(n = t.substring(i, e.start - 1))).replace(RX.multipleSpaces, " ")).substring(n.lastIndexOf(";") + 1);
        let r = e.parsedSelector = e.selector = n.trim();
        e.atRule = 0 === r.indexOf(AT_START), e.atRule ? 0 === r.indexOf(MEDIA_START) ? e.type = types.MEDIA_RULE : r.match(RX.keyframesRule) && (e.type = types.KEYFRAMES_RULE, 
        e.keyframesName = e.selector.split(RX.multipleSpaces).pop()) : 0 === r.indexOf(VAR_START) ? e.type = types.MIXIN_RULE : e.type = types.STYLE_RULE;
    }
    let i = e.rules;
    if (i) for (let e, n = 0, r = i.length; n < r && (e = i[n]); n++) parseCss(e, t);
    return e;
}

function _expandUnicodeEscapes(e) {
    return e.replace(/\\([0-9a-f]{1,6})\s/gi, function() {
        let e = arguments[1], t = 6 - e.length;
        for (;t--; ) e = "0" + e;
        return "\\" + e;
    });
}

function stringify(e, t, n = "") {
    let i = "";
    if (e.cssText || e.rules) {
        let n = e.rules;
        if (n && !_hasMixinRules(n)) for (let e, r = 0, o = n.length; r < o && (e = n[r]); r++) i = stringify(e, t, i); else (i = (i = t ? e.cssText : removeCustomProps(e.cssText)).trim()) && (i = "  " + i + "\n");
    }
    return i && (e.selector && (n += e.selector + " " + OPEN_BRACE + "\n"), n += i, 
    e.selector && (n += CLOSE_BRACE + "\n\n")), n;
}

function _hasMixinRules(e) {
    let t = e[0];
    return Boolean(t) && Boolean(t.selector) && 0 === t.selector.indexOf(VAR_START);
}

function removeCustomProps(e) {
    return removeCustomPropApply(e = removeCustomPropAssignment(e));
}

function removeCustomPropAssignment(e) {
    return e.replace(RX.customProp, "").replace(RX.mixinProp, "");
}

function removeCustomPropApply(e) {
    return e.replace(RX.mixinApply, "").replace(RX.varApply, "");
}

const types = {
    STYLE_RULE: 1,
    KEYFRAMES_RULE: 7,
    MEDIA_RULE: 4,
    MIXIN_RULE: 1e3
}, OPEN_BRACE = "{", CLOSE_BRACE = "}", RX = {
    comments: /\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim,
    port: /@import[^;]*;/gim,
    customProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,
    mixinProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,
    mixinApply: /@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,
    varApply: /[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,
    keyframesRule: /^@[^\s]*keyframes/,
    multipleSpaces: /\s+/g
}, VAR_START = "--", MEDIA_START = "@media", AT_START = "@";

var cssParse = {
    StyleNode: StyleNode,
    parse: parse,
    stringify: stringify,
    removeCustomPropAssignment: removeCustomPropAssignment,
    types: types
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const VAR_ASSIGN = /(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi, MIXIN_MATCH = /(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi, VAR_CONSUMED = /(--[\w-]+)\s*([:,;)]|$)/gi, ANIMATION_MATCH = /(animation\s*:)|(animation-name\s*:)/, MEDIA_MATCH = /@media\s(.*)/, IS_VAR = /^--/, BRACKETED = /\{[^}]*\}/g, HOST_PREFIX = "(?:^|[^.#[:])", HOST_SUFFIX = "($|[.:[\\s>+~])";

var commonRegex = {
    VAR_ASSIGN: VAR_ASSIGN,
    MIXIN_MATCH: MIXIN_MATCH,
    VAR_CONSUMED: VAR_CONSUMED,
    ANIMATION_MATCH: ANIMATION_MATCH,
    MEDIA_MATCH: MEDIA_MATCH,
    IS_VAR: IS_VAR,
    BRACKETED: BRACKETED,
    HOST_PREFIX: HOST_PREFIX,
    HOST_SUFFIX: HOST_SUFFIX
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const styleTextSet = new Set(), scopingAttribute = "shady-unscoped";

function processUnscopedStyle(e) {
    const t = e.textContent;
    if (!styleTextSet.has(t)) {
        styleTextSet.add(t);
        const n = e.cloneNode(!0);
        document.head.appendChild(n);
    }
}

function isUnscopedStyle(e) {
    return e.hasAttribute(scopingAttribute);
}

var unscopedStyleHandler = {
    scopingAttribute: scopingAttribute,
    processUnscopedStyle: processUnscopedStyle,
    isUnscopedStyle: isUnscopedStyle
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function toCssText(e, t) {
    return e ? ("string" == typeof e && (e = parse(e)), t && forEachRule(e, t), stringify(e, nativeCssVariables)) : "";
}

function rulesForStyle(e) {
    return !e.__cssRules && e.textContent && (e.__cssRules = parse(e.textContent)), 
    e.__cssRules || null;
}

function isKeyframesSelector(e) {
    return Boolean(e.parent) && e.parent.type === types.KEYFRAMES_RULE;
}

function forEachRule(e, t, n, i) {
    if (!e) return;
    let r = !1, o = e.type;
    if (i && o === types.MEDIA_RULE) {
        let t = e.selector.match(MEDIA_MATCH);
        t && (window.matchMedia(t[1]).matches || (r = !0));
    }
    o === types.STYLE_RULE ? t(e) : n && o === types.KEYFRAMES_RULE ? n(e) : o === types.MIXIN_RULE && (r = !0);
    let s = e.rules;
    if (s && !r) for (let e, r = 0, o = s.length; r < o && (e = s[r]); r++) forEachRule(e, t, n, i);
}

function applyCss(e, t, n, i) {
    let r = createScopeStyle(e, t);
    return applyStyle(r, n, i), r;
}

function createScopeStyle(e, t) {
    let n = document.createElement("style");
    return t && n.setAttribute("scope", t), n.textContent = e, n;
}

let lastHeadApplyNode = null;

function applyStylePlaceHolder(e) {
    let t = document.createComment(" Shady DOM styles for " + e + " "), n = lastHeadApplyNode ? lastHeadApplyNode.nextSibling : null, i = document.head;
    return i.insertBefore(t, n || i.firstChild), lastHeadApplyNode = t, t;
}

function applyStyle(e, t, n) {
    t = t || document.head;
    let i = n && n.nextSibling || t.firstChild;
    if (t.insertBefore(e, i), lastHeadApplyNode) {
        e.compareDocumentPosition(lastHeadApplyNode) === Node.DOCUMENT_POSITION_PRECEDING && (lastHeadApplyNode = e);
    } else lastHeadApplyNode = e;
}

function isTargetedBuild(e) {
    return nativeShadow ? "shadow" === e : "shady" === e;
}

function findMatchingParen(e, t) {
    let n = 0;
    for (let i = t, r = e.length; i < r; i++) if ("(" === e[i]) n++; else if (")" === e[i] && 0 == --n) return i;
    return -1;
}

function processVariableAndFallback(e, t) {
    let n = e.indexOf("var(");
    if (-1 === n) return t(e, "", "", "");
    let i = findMatchingParen(e, n + 3), r = e.substring(n + 4, i), o = e.substring(0, n), s = processVariableAndFallback(e.substring(i + 1), t), a = r.indexOf(",");
    return -1 === a ? t(o, r.trim(), "", s) : t(o, r.substring(0, a).trim(), r.substring(a + 1).trim(), s);
}

function setElementClassRaw(e, t) {
    nativeShadow ? e.setAttribute("class", t) : window.ShadyDOM.nativeMethods.setAttribute.call(e, "class", t);
}

const wrap = window.ShadyDOM && window.ShadyDOM.wrap || (e => e);

function getIsExtends(e) {
    let t = e.localName, n = "", i = "";
    return t ? t.indexOf("-") > -1 ? n = t : (i = t, n = e.getAttribute && e.getAttribute("is") || "") : (n = e.is, 
    i = e.extends), {
        is: n,
        typeExtension: i
    };
}

function gatherStyleText(e) {
    const t = [], n = e.querySelectorAll("style");
    for (let e = 0; e < n.length; e++) {
        const i = n[e];
        isUnscopedStyle(i) ? nativeShadow || (processUnscopedStyle(i), i.parentNode.removeChild(i)) : (t.push(i.textContent), 
        i.parentNode.removeChild(i));
    }
    return t.join("").trim();
}

function splitSelectorList(e) {
    const t = [];
    let n = "";
    for (let i = 0; i >= 0 && i < e.length; i++) if ("(" === e[i]) {
        const t = findMatchingParen(e, i);
        n += e.slice(i, t + 1), i = t;
    } else "," === e[i] ? (t.push(n), n = "") : n += e[i];
    return n && t.push(n), t;
}

const CSS_BUILD_ATTR = "css-build";

function getCssBuild(e) {
    if (void 0 !== cssBuild) return cssBuild;
    if (void 0 === e.__cssBuild) {
        const t = e.getAttribute(CSS_BUILD_ATTR);
        if (t) e.__cssBuild = t; else {
            const t = getBuildComment(e);
            "" !== t && removeBuildComment(e), e.__cssBuild = t;
        }
    }
    return e.__cssBuild || "";
}

function elementHasBuiltCss(e) {
    return "" !== getCssBuild(e);
}

function getBuildComment(e) {
    const t = "template" === e.localName ? e.content.firstChild : e.firstChild;
    if (t instanceof Comment) {
        const e = t.textContent.trim().split(":");
        if (e[0] === CSS_BUILD_ATTR) return e[1];
    }
    return "";
}

function isOptimalCssBuild(e = "") {
    return !("" === e || !nativeCssVariables) && (nativeShadow ? "shadow" === e : "shady" === e);
}

function removeBuildComment(e) {
    const t = "template" === e.localName ? e.content.firstChild : e.firstChild;
    t.parentNode.removeChild(t);
}

var styleUtil = {
    toCssText: toCssText,
    rulesForStyle: rulesForStyle,
    isKeyframesSelector: isKeyframesSelector,
    forEachRule: forEachRule,
    applyCss: applyCss,
    createScopeStyle: createScopeStyle,
    applyStylePlaceHolder: applyStylePlaceHolder,
    applyStyle: applyStyle,
    isTargetedBuild: isTargetedBuild,
    findMatchingParen: findMatchingParen,
    processVariableAndFallback: processVariableAndFallback,
    setElementClassRaw: setElementClassRaw,
    wrap: wrap,
    getIsExtends: getIsExtends,
    gatherStyleText: gatherStyleText,
    splitSelectorList: splitSelectorList,
    getCssBuild: getCssBuild,
    elementHasBuiltCss: elementHasBuiltCss,
    getBuildComment: getBuildComment,
    isOptimalCssBuild: isOptimalCssBuild
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function updateNativeProperties(e, t) {
    for (let n in t) null === n ? e.style.removeProperty(n) : e.style.setProperty(n, t[n]);
}

function getComputedStyleValue(e, t) {
    const n = window.getComputedStyle(e).getPropertyValue(t);
    return n ? n.trim() : "";
}

function detectMixin(e) {
    const t = MIXIN_MATCH.test(e) || VAR_ASSIGN.test(e);
    return MIXIN_MATCH.lastIndex = 0, VAR_ASSIGN.lastIndex = 0, t;
}

var commonUtils = {
    updateNativeProperties: updateNativeProperties,
    getComputedStyleValue: getComputedStyleValue,
    detectMixin: detectMixin
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const APPLY_NAME_CLEAN = /;\s*/m, INITIAL_INHERIT = /^\s*(initial)|(inherit)\s*$/, IMPORTANT = /\s*!important/, MIXIN_VAR_SEP = "_-_";

let PropertyEntry, DependantsEntry, MixinMapEntry;

class MixinMap {
    constructor() {
        this._map = {};
    }
    set(e, t) {
        e = e.trim(), this._map[e] = {
            properties: t,
            dependants: {}
        };
    }
    get(e) {
        return e = e.trim(), this._map[e] || null;
    }
}

let invalidCallback = null;

class ApplyShim {
    constructor() {
        this._currentElement = null, this._measureElement = null, this._map = new MixinMap();
    }
    detectMixin(e) {
        return detectMixin(e);
    }
    gatherStyles(e) {
        const t = gatherStyleText(e.content);
        if (t) {
            const n = document.createElement("style");
            return n.textContent = t, e.content.insertBefore(n, e.content.firstChild), n;
        }
        return null;
    }
    transformTemplate(e, t) {
        void 0 === e._gatheredStyle && (e._gatheredStyle = this.gatherStyles(e));
        const n = e._gatheredStyle;
        return n ? this.transformStyle(n, t) : null;
    }
    transformStyle(e, t = "") {
        let n = rulesForStyle(e);
        return this.transformRules(n, t), e.textContent = toCssText(n), n;
    }
    transformCustomStyle(e) {
        let t = rulesForStyle(e);
        return forEachRule(t, e => {
            ":root" === e.selector && (e.selector = "html"), this.transformRule(e);
        }), e.textContent = toCssText(t), t;
    }
    transformRules(e, t) {
        this._currentElement = t, forEachRule(e, e => {
            this.transformRule(e);
        }), this._currentElement = null;
    }
    transformRule(e) {
        e.cssText = this.transformCssText(e.parsedCssText, e), ":root" === e.selector && (e.selector = ":host > *");
    }
    transformCssText(e, t) {
        return e = e.replace(VAR_ASSIGN, (e, n, i, r) => this._produceCssProperties(e, n, i, r, t)), 
        this._consumeCssProperties(e, t);
    }
    _getInitialValueForProperty(e) {
        return this._measureElement || (this._measureElement = document.createElement("meta"), 
        this._measureElement.setAttribute("apply-shim-measure", ""), this._measureElement.style.all = "initial", 
        document.head.appendChild(this._measureElement)), window.getComputedStyle(this._measureElement).getPropertyValue(e);
    }
    _fallbacksFromPreviousRules(e) {
        let t = e;
        for (;t.parent; ) t = t.parent;
        const n = {};
        let i = !1;
        return forEachRule(t, t => {
            (i = i || t === e) || t.selector === e.selector && Object.assign(n, this._cssTextToMap(t.parsedCssText));
        }), n;
    }
    _consumeCssProperties(e, t) {
        let n = null;
        for (;n = MIXIN_MATCH.exec(e); ) {
            let i = n[0], r = n[1], o = n.index, s = o + i.indexOf("@apply"), a = o + i.length, l = e.slice(0, s), c = e.slice(a), d = t ? this._fallbacksFromPreviousRules(t) : {};
            Object.assign(d, this._cssTextToMap(l));
            let p = this._atApplyToCssProperties(r, d);
            e = `${l}${p}${c}`, MIXIN_MATCH.lastIndex = o + p.length;
        }
        return e;
    }
    _atApplyToCssProperties(e, t) {
        e = e.replace(APPLY_NAME_CLEAN, "");
        let n = [], i = this._map.get(e);
        if (i || (this._map.set(e, {}), i = this._map.get(e)), i) {
            let r, o, s;
            this._currentElement && (i.dependants[this._currentElement] = !0);
            const a = i.properties;
            for (r in a) s = t && t[r], o = [ r, ": var(", e, MIXIN_VAR_SEP, r ], s && o.push(",", s.replace(IMPORTANT, "")), 
            o.push(")"), IMPORTANT.test(a[r]) && o.push(" !important"), n.push(o.join(""));
        }
        return n.join("; ");
    }
    _replaceInitialOrInherit(e, t) {
        let n = INITIAL_INHERIT.exec(t);
        return n && (t = n[1] ? this._getInitialValueForProperty(e) : "apply-shim-inherit"), 
        t;
    }
    _cssTextToMap(e, t = !1) {
        let n, i, r = e.split(";"), o = {};
        for (let e, s, a = 0; a < r.length; a++) (e = r[a]) && (s = e.split(":")).length > 1 && (n = s[0].trim(), 
        i = s.slice(1).join(":"), t && (i = this._replaceInitialOrInherit(n, i)), o[n] = i);
        return o;
    }
    _invalidateMixinEntry(e) {
        if (invalidCallback) for (let t in e.dependants) t !== this._currentElement && invalidCallback(t);
    }
    _produceCssProperties(e, t, n, i, r) {
        if (n && processVariableAndFallback(n, (e, t) => {
            t && this._map.get(t) && (i = `@apply ${t};`);
        }), !i) return e;
        let o = this._consumeCssProperties("" + i, r), s = e.slice(0, e.indexOf("--")), a = this._cssTextToMap(o, !0), l = a, c = this._map.get(t), d = c && c.properties;
        d ? l = Object.assign(Object.create(d), a) : this._map.set(t, l);
        let p, u, h = [], m = !1;
        for (p in l) void 0 === (u = a[p]) && (u = "initial"), !d || p in d || (m = !0), 
        h.push(`${t}${MIXIN_VAR_SEP}${p}: ${u}`);
        return m && this._invalidateMixinEntry(c), c && (c.properties = l), n && (s = `${e};${s}`), 
        `${s}${h.join("; ")};`;
    }
}

ApplyShim.prototype.detectMixin = ApplyShim.prototype.detectMixin, ApplyShim.prototype.transformStyle = ApplyShim.prototype.transformStyle, 
ApplyShim.prototype.transformCustomStyle = ApplyShim.prototype.transformCustomStyle, 
ApplyShim.prototype.transformRules = ApplyShim.prototype.transformRules, ApplyShim.prototype.transformRule = ApplyShim.prototype.transformRule, 
ApplyShim.prototype.transformTemplate = ApplyShim.prototype.transformTemplate, ApplyShim.prototype._separator = MIXIN_VAR_SEP, 
Object.defineProperty(ApplyShim.prototype, "invalidCallback", {
    get: () => invalidCallback,
    set(e) {
        invalidCallback = e;
    }
});

var applyShim = {
    default: ApplyShim
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const templateMap = {};

var templateMap$1 = {
    default: templateMap
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const CURRENT_VERSION = "_applyShimCurrentVersion", NEXT_VERSION = "_applyShimNextVersion", VALIDATING_VERSION = "_applyShimValidatingVersion", promise = Promise.resolve();

function invalidate(e) {
    let t = templateMap[e];
    t && invalidateTemplate(t);
}

function invalidateTemplate(e) {
    e[CURRENT_VERSION] = e[CURRENT_VERSION] || 0, e[VALIDATING_VERSION] = e[VALIDATING_VERSION] || 0, 
    e[NEXT_VERSION] = (e[NEXT_VERSION] || 0) + 1;
}

function isValid(e) {
    let t = templateMap[e];
    return !t || templateIsValid(t);
}

function templateIsValid(e) {
    return e[CURRENT_VERSION] === e[NEXT_VERSION];
}

function isValidating(e) {
    let t = templateMap[e];
    return !!t && templateIsValidating(t);
}

function templateIsValidating(e) {
    return !templateIsValid(e) && e[VALIDATING_VERSION] === e[NEXT_VERSION];
}

function startValidating(e) {
    startValidatingTemplate(templateMap[e]);
}

function startValidatingTemplate(e) {
    e[VALIDATING_VERSION] = e[NEXT_VERSION], e._validating || (e._validating = !0, promise.then(function() {
        e[CURRENT_VERSION] = e[NEXT_VERSION], e._validating = !1;
    }));
}

function elementsAreInvalid() {
    for (let e in templateMap) {
        if (!templateIsValid(templateMap[e])) return !0;
    }
    return !1;
}

var applyShimUtils = {
    invalidate: invalidate,
    invalidateTemplate: invalidateTemplate,
    isValid: isValid,
    templateIsValid: templateIsValid,
    isValidating: isValidating,
    templateIsValidating: templateIsValidating,
    startValidating: startValidating,
    startValidatingTemplate: startValidatingTemplate,
    elementsAreInvalid: elementsAreInvalid
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ let resolveFn, readyPromise = null, whenReady = window.HTMLImports && window.HTMLImports.whenReady || null;

function documentWait(e) {
    requestAnimationFrame(function() {
        whenReady ? whenReady(e) : (readyPromise || (readyPromise = new Promise(e => {
            resolveFn = e;
        }), "complete" === document.readyState ? resolveFn() : document.addEventListener("readystatechange", () => {
            "complete" === document.readyState && resolveFn();
        })), readyPromise.then(function() {
            e && e();
        }));
    });
}

var documentWait$1 = {
    default: documentWait
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ let CustomStyleProvider;

const SEEN_MARKER = "__seenByShadyCSS", CACHED_STYLE = "__shadyCSSCachedStyle";

let transformFn = null, validateFn = null;

class CustomStyleInterface {
    constructor() {
        this.customStyles = [], this.enqueued = !1, documentWait(() => {
            window.ShadyCSS.flushCustomStyles && window.ShadyCSS.flushCustomStyles();
        });
    }
    enqueueDocumentValidation() {
        !this.enqueued && validateFn && (this.enqueued = !0, documentWait(validateFn));
    }
    addCustomStyle(e) {
        e[SEEN_MARKER] || (e[SEEN_MARKER] = !0, this.customStyles.push(e), this.enqueueDocumentValidation());
    }
    getStyleForCustomStyle(e) {
        if (e[CACHED_STYLE]) return e[CACHED_STYLE];
        let t;
        return t = e.getStyle ? e.getStyle() : e;
    }
    processStyles() {
        const e = this.customStyles;
        for (let t = 0; t < e.length; t++) {
            const n = e[t];
            if (n[CACHED_STYLE]) continue;
            const i = this.getStyleForCustomStyle(n);
            if (i) {
                const e = i.__appliedElement || i;
                transformFn && transformFn(e), n[CACHED_STYLE] = e;
            }
        }
        return e;
    }
}

CustomStyleInterface.prototype.addCustomStyle = CustomStyleInterface.prototype.addCustomStyle, 
CustomStyleInterface.prototype.getStyleForCustomStyle = CustomStyleInterface.prototype.getStyleForCustomStyle, 
CustomStyleInterface.prototype.processStyles = CustomStyleInterface.prototype.processStyles, 
Object.defineProperties(CustomStyleInterface.prototype, {
    transformCallback: {
        get: () => transformFn,
        set(e) {
            transformFn = e;
        }
    },
    validateCallback: {
        get: () => validateFn,
        set(e) {
            let t = !1;
            validateFn || (t = !0), validateFn = e, t && this.enqueueDocumentValidation();
        }
    }
});

const CustomStyleInterfaceInterface = {};

var customStyleInterface = {
    CustomStyleProvider: CustomStyleProvider,
    default: CustomStyleInterface,
    CustomStyleInterfaceInterface: CustomStyleInterfaceInterface
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const applyShim$1 = new ApplyShim();

class ApplyShimInterface {
    constructor() {
        this.customStyleInterface = null, applyShim$1.invalidCallback = invalidate;
    }
    ensure() {
        this.customStyleInterface || window.ShadyCSS.CustomStyleInterface && (this.customStyleInterface = window.ShadyCSS.CustomStyleInterface, 
        this.customStyleInterface.transformCallback = (e => {
            applyShim$1.transformCustomStyle(e);
        }), this.customStyleInterface.validateCallback = (() => {
            requestAnimationFrame(() => {
                this.customStyleInterface.enqueued && this.flushCustomStyles();
            });
        }));
    }
    prepareTemplate(e, t) {
        if (this.ensure(), elementHasBuiltCss(e)) return;
        templateMap[t] = e;
        let n = applyShim$1.transformTemplate(e, t);
        e._styleAst = n;
    }
    flushCustomStyles() {
        if (this.ensure(), !this.customStyleInterface) return;
        let e = this.customStyleInterface.processStyles();
        if (this.customStyleInterface.enqueued) {
            for (let t = 0; t < e.length; t++) {
                let n = e[t], i = this.customStyleInterface.getStyleForCustomStyle(n);
                i && applyShim$1.transformCustomStyle(i);
            }
            this.customStyleInterface.enqueued = !1;
        }
    }
    styleSubtree(e, t) {
        if (this.ensure(), t && updateNativeProperties(e, t), e.shadowRoot) {
            this.styleElement(e);
            let t = e.shadowRoot.children || e.shadowRoot.childNodes;
            for (let e = 0; e < t.length; e++) this.styleSubtree(t[e]);
        } else {
            let t = e.children || e.childNodes;
            for (let e = 0; e < t.length; e++) this.styleSubtree(t[e]);
        }
    }
    styleElement(e) {
        this.ensure();
        let {is: t} = getIsExtends(e), n = templateMap[t];
        if ((!n || !elementHasBuiltCss(n)) && n && !templateIsValid(n)) {
            templateIsValidating(n) || (this.prepareTemplate(n, t), startValidatingTemplate(n));
            let i = e.shadowRoot;
            if (i) {
                let e = i.querySelector("style");
                e && (e.__cssRules = n._styleAst, e.textContent = toCssText(n._styleAst));
            }
        }
    }
    styleDocument(e) {
        this.ensure(), this.styleSubtree(document.body, e);
    }
}

if (!window.ShadyCSS || !window.ShadyCSS.ScopingShim) {
    const e = new ApplyShimInterface();
    let t = window.ShadyCSS && window.ShadyCSS.CustomStyleInterface;
    window.ShadyCSS = {
        prepareTemplate(t, n, i) {
            e.flushCustomStyles(), e.prepareTemplate(t, n);
        },
        prepareTemplateStyles(e, t, n) {
            window.ShadyCSS.prepareTemplate(e, t, n);
        },
        prepareTemplateDom(e, t) {},
        styleSubtree(t, n) {
            e.flushCustomStyles(), e.styleSubtree(t, n);
        },
        styleElement(t) {
            e.flushCustomStyles(), e.styleElement(t);
        },
        styleDocument(t) {
            e.flushCustomStyles(), e.styleDocument(t);
        },
        getComputedStyleValue: (e, t) => getComputedStyleValue(e, t),
        flushCustomStyles() {
            e.flushCustomStyles();
        },
        nativeCss: nativeCssVariables,
        nativeShadow: nativeShadow,
        cssBuild: cssBuild,
        disableRuntime: disableRuntime
    }, t && (window.ShadyCSS.CustomStyleInterface = t);
}

window.ShadyCSS.ApplyShim = applyShim$1, 
/**
                                         @license
                                         Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
                                         This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
                                         The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
                                         The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
                                         Code distributed by Google as part of the polymer project is also
                                         subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
                                         */
window.JSCompiler_renameProperty = function(e, t) {
    return e;
};

let workingURL, resolveDoc, CSS_URL_RX = /(url\()([^)]*)(\))/g, ABS_URL = /(^\/)|(^#)|(^[\w-\d]*:)/;

function resolveUrl(e, t) {
    if (e && ABS_URL.test(e)) return e;
    if (void 0 === workingURL) {
        workingURL = !1;
        try {
            const e = new URL("b", "http://a");
            e.pathname = "c%20d", workingURL = "http://a/c%20d" === e.href;
        } catch (e) {}
    }
    return t || (t = document.baseURI || window.location.href), workingURL ? new URL(e, t).href : (resolveDoc || ((resolveDoc = document.implementation.createHTMLDocument("temp")).base = resolveDoc.createElement("base"), 
    resolveDoc.head.appendChild(resolveDoc.base), resolveDoc.anchor = resolveDoc.createElement("a"), 
    resolveDoc.body.appendChild(resolveDoc.anchor)), resolveDoc.base.href = t, resolveDoc.anchor.href = e, 
    resolveDoc.anchor.href || e);
}

function resolveCss(e, t) {
    return e.replace(CSS_URL_RX, function(e, n, i, r) {
        return n + "'" + resolveUrl(i.replace(/["']/g, ""), t) + "'" + r;
    });
}

function pathFromUrl(e) {
    return e.substring(0, e.lastIndexOf("/") + 1);
}

var resolveUrl$1 = {
    resolveUrl: resolveUrl,
    resolveCss: resolveCss,
    pathFromUrl: pathFromUrl
};

const useShadow = !window.ShadyDOM, useNativeCSSProperties = Boolean(!window.ShadyCSS || window.ShadyCSS.nativeCss), useNativeCustomElements = !window.customElements.polyfillWrapFlushCallback;

let rootPath = pathFromUrl(document.baseURI || window.location.href);

const setRootPath = function(e) {
    rootPath = e;
};

let sanitizeDOMValue = window.Polymer && window.Polymer.sanitizeDOMValue || void 0;

const setSanitizeDOMValue = function(e) {
    sanitizeDOMValue = e;
};

let passiveTouchGestures = !1;

const setPassiveTouchGestures = function(e) {
    passiveTouchGestures = e;
};

let strictTemplatePolicy = !1;

const setStrictTemplatePolicy = function(e) {
    strictTemplatePolicy = e;
};

let allowTemplateFromDomModule = !1;

const setAllowTemplateFromDomModule = function(e) {
    allowTemplateFromDomModule = e;
};

let legacyOptimizations = !1;

const setLegacyOptimizations = function(e) {
    legacyOptimizations = e;
};

let syncInitialRender = !1;

const setSyncInitialRender = function(e) {
    syncInitialRender = e;
};

var settings = {
    useShadow: useShadow,
    useNativeCSSProperties: useNativeCSSProperties,
    useNativeCustomElements: useNativeCustomElements,
    get rootPath() {
        return rootPath;
    },
    setRootPath: setRootPath,
    get sanitizeDOMValue() {
        return sanitizeDOMValue;
    },
    setSanitizeDOMValue: setSanitizeDOMValue,
    get passiveTouchGestures() {
        return passiveTouchGestures;
    },
    setPassiveTouchGestures: setPassiveTouchGestures,
    get strictTemplatePolicy() {
        return strictTemplatePolicy;
    },
    setStrictTemplatePolicy: setStrictTemplatePolicy,
    get allowTemplateFromDomModule() {
        return allowTemplateFromDomModule;
    },
    setAllowTemplateFromDomModule: setAllowTemplateFromDomModule,
    get legacyOptimizations() {
        return legacyOptimizations;
    },
    setLegacyOptimizations: setLegacyOptimizations,
    get syncInitialRender() {
        return syncInitialRender;
    },
    setSyncInitialRender: setSyncInitialRender
};

let dedupeId = 0;

function MixinFunction() {}

MixinFunction.prototype.__mixinApplications, MixinFunction.prototype.__mixinSet;

const dedupingMixin = function(e) {
    let t = e.__mixinApplications;
    t || (t = new WeakMap(), e.__mixinApplications = t);
    let n = dedupeId++;
    return function(i) {
        let r = i.__mixinSet;
        if (r && r[n]) return i;
        let o = t, s = o.get(i);
        s || (s = e(i), o.set(i, s));
        let a = Object.create(s.__mixinSet || r || null);
        return a[n] = !0, s.__mixinSet = a, s;
    };
};

var mixin = {
    dedupingMixin: dedupingMixin
};

let modules = {}, lcModules = {};

function setModule(e, t) {
    modules[e] = lcModules[e.toLowerCase()] = t;
}

function findModule(e) {
    return modules[e] || lcModules[e.toLowerCase()];
}

function styleOutsideTemplateCheck(e) {
    e.querySelector("style") && console.warn("dom-module %s has style outside template", e.id);
}

class DomModule extends HTMLElement {
    static get observedAttributes() {
        return [ "id" ];
    }
    static import(e, t) {
        if (e) {
            let n = findModule(e);
            return n && t ? n.querySelector(t) : n;
        }
        return null;
    }
    attributeChangedCallback(e, t, n, i) {
        t !== n && this.register();
    }
    get assetpath() {
        if (!this.__assetpath) {
            const e = window.HTMLImports && HTMLImports.importForElement ? HTMLImports.importForElement(this) || document : this.ownerDocument, t = resolveUrl(this.getAttribute("assetpath") || "", e.baseURI);
            this.__assetpath = pathFromUrl(t);
        }
        return this.__assetpath;
    }
    register(e) {
        if (e = e || this.id) {
            if (strictTemplatePolicy && void 0 !== findModule(e)) throw setModule(e, null), 
            new Error(`strictTemplatePolicy: dom-module ${e} re-registered`);
            this.id = e, setModule(e, this), styleOutsideTemplateCheck(this);
        }
    }
}

DomModule.prototype.modules = modules, customElements.define("dom-module", DomModule);

var domModule = {
    DomModule: DomModule
};

const MODULE_STYLE_LINK_SELECTOR = "link[rel=import][type~=css]", INCLUDE_ATTR = "include", SHADY_UNSCOPED_ATTR = "shady-unscoped";

function importModule(e) {
    return DomModule.import(e);
}

function styleForImport(e) {
    const t = resolveCss((e.body ? e.body : e).textContent, e.baseURI), n = document.createElement("style");
    return n.textContent = t, n;
}

let templateWithAssetPath;

function stylesFromModules(e) {
    const t = e.trim().split(/\s+/), n = [];
    for (let e = 0; e < t.length; e++) n.push(...stylesFromModule(t[e]));
    return n;
}

function stylesFromModule(e) {
    const t = importModule(e);
    if (!t) return console.warn("Could not find style data in module named", e), [];
    if (void 0 === t._styles) {
        const e = [];
        e.push(..._stylesFromModuleImports(t));
        const n = t.querySelector("template");
        n && e.push(...stylesFromTemplate(n, t.assetpath)), t._styles = e;
    }
    return t._styles;
}

function stylesFromTemplate(e, t) {
    if (!e._styles) {
        const n = [], i = e.content.querySelectorAll("style");
        for (let e = 0; e < i.length; e++) {
            let r = i[e], o = r.getAttribute(INCLUDE_ATTR);
            o && n.push(...stylesFromModules(o).filter(function(e, t, n) {
                return n.indexOf(e) === t;
            })), t && (r.textContent = resolveCss(r.textContent, t)), n.push(r);
        }
        e._styles = n;
    }
    return e._styles;
}

function stylesFromModuleImports(e) {
    let t = importModule(e);
    return t ? _stylesFromModuleImports(t) : [];
}

function _stylesFromModuleImports(e) {
    const t = [], n = e.querySelectorAll(MODULE_STYLE_LINK_SELECTOR);
    for (let e = 0; e < n.length; e++) {
        let i = n[e];
        if (i.import) {
            const e = i.import, n = i.hasAttribute(SHADY_UNSCOPED_ATTR);
            if (n && !e._unscopedStyle) {
                const t = styleForImport(e);
                t.setAttribute(SHADY_UNSCOPED_ATTR, ""), e._unscopedStyle = t;
            } else e._style || (e._style = styleForImport(e));
            t.push(n ? e._unscopedStyle : e._style);
        }
    }
    return t;
}

function cssFromModules(e) {
    let t = e.trim().split(/\s+/), n = "";
    for (let e = 0; e < t.length; e++) n += cssFromModule(t[e]);
    return n;
}

function cssFromModule(e) {
    let t = importModule(e);
    if (t && void 0 === t._cssText) {
        let e = _cssFromModuleImports(t), n = t.querySelector("template");
        n && (e += cssFromTemplate(n, t.assetpath)), t._cssText = e || null;
    }
    return t || console.warn("Could not find style data in module named", e), t && t._cssText || "";
}

function cssFromTemplate(e, t) {
    let n = "";
    const i = stylesFromTemplate(e, t);
    for (let e = 0; e < i.length; e++) {
        let t = i[e];
        t.parentNode && t.parentNode.removeChild(t), n += t.textContent;
    }
    return n;
}

function cssFromModuleImports(e) {
    let t = importModule(e);
    return t ? _cssFromModuleImports(t) : "";
}

function _cssFromModuleImports(e) {
    let t = "", n = _stylesFromModuleImports(e);
    for (let e = 0; e < n.length; e++) t += n[e].textContent;
    return t;
}

var styleGather = {
    stylesFromModules: stylesFromModules,
    stylesFromModule: stylesFromModule,
    stylesFromTemplate: stylesFromTemplate,
    stylesFromModuleImports: stylesFromModuleImports,
    cssFromModules: cssFromModules,
    cssFromModule: cssFromModule,
    cssFromTemplate: cssFromTemplate,
    cssFromModuleImports: cssFromModuleImports
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const wrap$1 = window.ShadyDOM && window.ShadyDOM.noPatch && window.ShadyDOM.wrap ? window.ShadyDOM.wrap : e => e;

var wrap$2 = {
    wrap: wrap$1
};

function isPath(e) {
    return e.indexOf(".") >= 0;
}

function root(e) {
    let t = e.indexOf(".");
    return -1 === t ? e : e.slice(0, t);
}

function isAncestor(e, t) {
    return 0 === e.indexOf(t + ".");
}

function isDescendant(e, t) {
    return 0 === t.indexOf(e + ".");
}

function translate(e, t, n) {
    return t + n.slice(e.length);
}

function matches(e, t) {
    return e === t || isAncestor(e, t) || isDescendant(e, t);
}

function normalize(e) {
    if (Array.isArray(e)) {
        let t = [];
        for (let n = 0; n < e.length; n++) {
            let i = e[n].toString().split(".");
            for (let e = 0; e < i.length; e++) t.push(i[e]);
        }
        return t.join(".");
    }
    return e;
}

function split(e) {
    return Array.isArray(e) ? normalize(e).split(".") : e.toString().split(".");
}

function get(e, t, n) {
    let i = e, r = split(t);
    for (let e = 0; e < r.length; e++) {
        if (!i) return;
        i = i[r[e]];
    }
    return n && (n.path = r.join(".")), i;
}

function set(e, t, n) {
    let i = e, r = split(t), o = r[r.length - 1];
    if (r.length > 1) {
        for (let e = 0; e < r.length - 1; e++) {
            if (!(i = i[r[e]])) return;
        }
        i[o] = n;
    } else i[t] = n;
    return r.join(".");
}

const isDeep = isPath;

var path = {
    isPath: isPath,
    root: root,
    isAncestor: isAncestor,
    isDescendant: isDescendant,
    translate: translate,
    matches: matches,
    normalize: normalize,
    split: split,
    get: get,
    set: set,
    isDeep: isDeep
};

const caseMap = {}, DASH_TO_CAMEL = /-[a-z]/g, CAMEL_TO_DASH = /([A-Z])/g;

function dashToCamelCase(e) {
    return caseMap[e] || (caseMap[e] = e.indexOf("-") < 0 ? e : e.replace(DASH_TO_CAMEL, e => e[1].toUpperCase()));
}

function camelToDashCase(e) {
    return caseMap[e] || (caseMap[e] = e.replace(CAMEL_TO_DASH, "-$1").toLowerCase());
}

var caseMap$1 = {
    dashToCamelCase: dashToCamelCase,
    camelToDashCase: camelToDashCase
};

let microtaskCurrHandle = 0, microtaskLastHandle = 0, microtaskCallbacks = [], microtaskNodeContent = 0, microtaskNode = document.createTextNode("");

function microtaskFlush() {
    const e = microtaskCallbacks.length;
    for (let t = 0; t < e; t++) {
        let e = microtaskCallbacks[t];
        if (e) try {
            e();
        } catch (e) {
            setTimeout(() => {
                throw e;
            });
        }
    }
    microtaskCallbacks.splice(0, e), microtaskLastHandle += e;
}

new window.MutationObserver(microtaskFlush).observe(microtaskNode, {
    characterData: !0
});

const timeOut = {
    after: e => ({
        run: t => window.setTimeout(t, e),
        cancel(e) {
            window.clearTimeout(e);
        }
    }),
    run: (e, t) => window.setTimeout(e, t),
    cancel(e) {
        window.clearTimeout(e);
    }
}, animationFrame = {
    run: e => window.requestAnimationFrame(e),
    cancel(e) {
        window.cancelAnimationFrame(e);
    }
}, idlePeriod = {
    run: e => window.requestIdleCallback ? window.requestIdleCallback(e) : window.setTimeout(e, 16),
    cancel(e) {
        window.cancelIdleCallback ? window.cancelIdleCallback(e) : window.clearTimeout(e);
    }
}, microTask = {
    run: e => (microtaskNode.textContent = microtaskNodeContent++, microtaskCallbacks.push(e), 
    microtaskCurrHandle++),
    cancel(e) {
        const t = e - microtaskLastHandle;
        if (t >= 0) {
            if (!microtaskCallbacks[t]) throw new Error("invalid async handle: " + e);
            microtaskCallbacks[t] = null;
        }
    }
};

var async = {
    timeOut: timeOut,
    animationFrame: animationFrame,
    idlePeriod: idlePeriod,
    microTask: microTask
};

const microtask = microTask, PropertiesChanged = dedupingMixin(e => {
    return class extends e {
        static createProperties(e) {
            const t = this.prototype;
            for (let n in e) n in t || t._createPropertyAccessor(n);
        }
        static attributeNameForProperty(e) {
            return e.toLowerCase();
        }
        static typeForProperty(e) {}
        _createPropertyAccessor(e, t) {
            this._addPropertyToAttributeMap(e), this.hasOwnProperty("__dataHasAccessor") || (this.__dataHasAccessor = Object.assign({}, this.__dataHasAccessor)), 
            this.__dataHasAccessor[e] || (this.__dataHasAccessor[e] = !0, this._definePropertyAccessor(e, t));
        }
        _addPropertyToAttributeMap(e) {
            if (this.hasOwnProperty("__dataAttributes") || (this.__dataAttributes = Object.assign({}, this.__dataAttributes)), 
            !this.__dataAttributes[e]) {
                const t = this.constructor.attributeNameForProperty(e);
                this.__dataAttributes[t] = e;
            }
        }
        _definePropertyAccessor(e, t) {
            Object.defineProperty(this, e, {
                get() {
                    return this._getProperty(e);
                },
                set: t ? function() {} : function(t) {
                    this._setProperty(e, t);
                }
            });
        }
        constructor() {
            super(), this.__dataEnabled = !1, this.__dataReady = !1, this.__dataInvalid = !1, 
            this.__data = {}, this.__dataPending = null, this.__dataOld = null, this.__dataInstanceProps = null, 
            this.__serializing = !1, this._initializeProperties();
        }
        ready() {
            this.__dataReady = !0, this._flushProperties();
        }
        _initializeProperties() {
            for (let e in this.__dataHasAccessor) this.hasOwnProperty(e) && (this.__dataInstanceProps = this.__dataInstanceProps || {}, 
            this.__dataInstanceProps[e] = this[e], delete this[e]);
        }
        _initializeInstanceProperties(e) {
            Object.assign(this, e);
        }
        _setProperty(e, t) {
            this._setPendingProperty(e, t) && this._invalidateProperties();
        }
        _getProperty(e) {
            return this.__data[e];
        }
        _setPendingProperty(e, t, n) {
            let i = this.__data[e], r = this._shouldPropertyChange(e, t, i);
            return r && (this.__dataPending || (this.__dataPending = {}, this.__dataOld = {}), 
            !this.__dataOld || e in this.__dataOld || (this.__dataOld[e] = i), this.__data[e] = t, 
            this.__dataPending[e] = t), r;
        }
        _invalidateProperties() {
            !this.__dataInvalid && this.__dataReady && (this.__dataInvalid = !0, microtask.run(() => {
                this.__dataInvalid && (this.__dataInvalid = !1, this._flushProperties());
            }));
        }
        _enableProperties() {
            this.__dataEnabled || (this.__dataEnabled = !0, this.__dataInstanceProps && (this._initializeInstanceProperties(this.__dataInstanceProps), 
            this.__dataInstanceProps = null), this.ready());
        }
        _flushProperties() {
            const e = this.__data, t = this.__dataPending, n = this.__dataOld;
            this._shouldPropertiesChange(e, t, n) && (this.__dataPending = null, this.__dataOld = null, 
            this._propertiesChanged(e, t, n));
        }
        _shouldPropertiesChange(e, t, n) {
            return Boolean(t);
        }
        _propertiesChanged(e, t, n) {}
        _shouldPropertyChange(e, t, n) {
            return n !== t && (n == n || t == t);
        }
        attributeChangedCallback(e, t, n, i) {
            t !== n && this._attributeToProperty(e, n), super.attributeChangedCallback && super.attributeChangedCallback(e, t, n, i);
        }
        _attributeToProperty(e, t, n) {
            if (!this.__serializing) {
                const i = this.__dataAttributes, r = i && i[e] || e;
                this[r] = this._deserializeValue(t, n || this.constructor.typeForProperty(r));
            }
        }
        _propertyToAttribute(e, t, n) {
            this.__serializing = !0, n = arguments.length < 3 ? this[e] : n, this._valueToNodeAttribute(this, n, t || this.constructor.attributeNameForProperty(e)), 
            this.__serializing = !1;
        }
        _valueToNodeAttribute(e, t, n) {
            const i = this._serializeValue(t);
            void 0 === i ? e.removeAttribute(n) : ("class" !== n && "name" !== n && "slot" !== n || (e = wrap$1(e)), 
            e.setAttribute(n, i));
        }
        _serializeValue(e) {
            switch (typeof e) {
              case "boolean":
                return e ? "" : void 0;

              default:
                return null != e ? e.toString() : void 0;
            }
        }
        _deserializeValue(e, t) {
            switch (t) {
              case Boolean:
                return null !== e;

              case Number:
                return Number(e);

              default:
                return e;
            }
        }
    };
});

var propertiesChanged = {
    PropertiesChanged: PropertiesChanged
};

const nativeProperties = {};

let proto = HTMLElement.prototype;

for (;proto; ) {
    let e = Object.getOwnPropertyNames(proto);
    for (let t = 0; t < e.length; t++) nativeProperties[e[t]] = !0;
    proto = Object.getPrototypeOf(proto);
}

function saveAccessorValue(e, t) {
    if (!nativeProperties[t]) {
        let n = e[t];
        void 0 !== n && (e.__data ? e._setPendingProperty(t, n) : (e.__dataProto ? e.hasOwnProperty(JSCompiler_renameProperty("__dataProto", e)) || (e.__dataProto = Object.create(e.__dataProto)) : e.__dataProto = {}, 
        e.__dataProto[t] = n));
    }
}

const PropertyAccessors = dedupingMixin(e => {
    const t = PropertiesChanged(e);
    return class extends t {
        static createPropertiesForAttributes() {
            let e = this.observedAttributes;
            for (let t = 0; t < e.length; t++) this.prototype._createPropertyAccessor(dashToCamelCase(e[t]));
        }
        static attributeNameForProperty(e) {
            return camelToDashCase(e);
        }
        _initializeProperties() {
            this.__dataProto && (this._initializeProtoProperties(this.__dataProto), this.__dataProto = null), 
            super._initializeProperties();
        }
        _initializeProtoProperties(e) {
            for (let t in e) this._setProperty(t, e[t]);
        }
        _ensureAttribute(e, t) {
            const n = this;
            n.hasAttribute(e) || this._valueToNodeAttribute(n, t, e);
        }
        _serializeValue(e) {
            switch (typeof e) {
              case "object":
                if (e instanceof Date) return e.toString();
                if (e) try {
                    return JSON.stringify(e);
                } catch (e) {
                    return "";
                }

              default:
                return super._serializeValue(e);
            }
        }
        _deserializeValue(e, t) {
            let n;
            switch (t) {
              case Object:
                try {
                    n = JSON.parse(e);
                } catch (t) {
                    n = e;
                }
                break;

              case Array:
                try {
                    n = JSON.parse(e);
                } catch (t) {
                    n = null, console.warn(`Polymer::Attributes: couldn't decode Array as JSON: ${e}`);
                }
                break;

              case Date:
                n = isNaN(e) ? String(e) : Number(e), n = new Date(n);
                break;

              default:
                n = super._deserializeValue(e, t);
            }
            return n;
        }
        _definePropertyAccessor(e, t) {
            saveAccessorValue(this, e), super._definePropertyAccessor(e, t);
        }
        _hasAccessor(e) {
            return this.__dataHasAccessor && this.__dataHasAccessor[e];
        }
        _isPropertyPending(e) {
            return Boolean(this.__dataPending && e in this.__dataPending);
        }
    };
});

var propertyAccessors = {
    PropertyAccessors: PropertyAccessors
};

const walker = document.createTreeWalker(document, NodeFilter.SHOW_ALL, null, !1), templateExtensions = {
    "dom-if": !0,
    "dom-repeat": !0
};

function wrapTemplateExtension(e) {
    let t = e.getAttribute("is");
    if (t && templateExtensions[t]) {
        let n = e;
        for (n.removeAttribute("is"), e = n.ownerDocument.createElement(t), n.parentNode.replaceChild(e, n), 
        e.appendChild(n); n.attributes.length; ) e.setAttribute(n.attributes[0].name, n.attributes[0].value), 
        n.removeAttribute(n.attributes[0].name);
    }
    return e;
}

function findTemplateNode(e, t) {
    let n = t.parentInfo && findTemplateNode(e, t.parentInfo);
    if (!n) return e;
    walker.currentNode = n;
    for (let e = walker.firstChild(), n = 0; e; e = walker.nextSibling()) if (t.parentIndex === n++) return e;
}

function applyIdToMap(e, t, n, i) {
    i.id && (t[i.id] = n);
}

function applyEventListener(e, t, n) {
    if (n.events && n.events.length) for (let i, r = 0, o = n.events; r < o.length && (i = o[r]); r++) e._addMethodEventListenerToNode(t, i.name, i.value, e);
}

function applyTemplateContent(e, t, n) {
    n.templateInfo && (t._templateInfo = n.templateInfo);
}

function createNodeEventHandler(e, t, n) {
    e = e._methodHost || e;
    return function(t) {
        e[n] ? e[n](t, t.detail) : console.warn("listener method `" + n + "` not defined");
    };
}

const TemplateStamp = dedupingMixin(e => {
    return class extends e {
        static _parseTemplate(e, t) {
            if (!e._templateInfo) {
                let n = e._templateInfo = {};
                n.nodeInfoList = [], n.stripWhiteSpace = t && t.stripWhiteSpace || e.hasAttribute("strip-whitespace"), 
                this._parseTemplateContent(e, n, {
                    parent: null
                });
            }
            return e._templateInfo;
        }
        static _parseTemplateContent(e, t, n) {
            return this._parseTemplateNode(e.content, t, n);
        }
        static _parseTemplateNode(e, t, n) {
            let i, r = e;
            return "template" != r.localName || r.hasAttribute("preserve-content") ? "slot" === r.localName && (t.hasInsertionPoint = !0) : i = this._parseTemplateNestedTemplate(r, t, n) || i, 
            walker.currentNode = r, walker.firstChild() && (i = this._parseTemplateChildNodes(r, t, n) || i), 
            r.hasAttributes && r.hasAttributes() && (i = this._parseTemplateNodeAttributes(r, t, n) || i), 
            i;
        }
        static _parseTemplateChildNodes(e, t, n) {
            if ("script" !== e.localName && "style" !== e.localName) {
                walker.currentNode = e;
                for (let i, r = walker.firstChild(), o = 0; r; r = i) {
                    if ("template" == r.localName && (r = wrapTemplateExtension(r)), walker.currentNode = r, 
                    i = walker.nextSibling(), r.nodeType === Node.TEXT_NODE) {
                        let n = i;
                        for (;n && n.nodeType === Node.TEXT_NODE; ) r.textContent += n.textContent, i = walker.nextSibling(), 
                        e.removeChild(n), n = i;
                        if (t.stripWhiteSpace && !r.textContent.trim()) {
                            e.removeChild(r);
                            continue;
                        }
                    }
                    let s = {
                        parentIndex: o,
                        parentInfo: n
                    };
                    this._parseTemplateNode(r, t, s) && (s.infoIndex = t.nodeInfoList.push(s) - 1), 
                    walker.currentNode = r, walker.parentNode() && o++;
                }
            }
        }
        static _parseTemplateNestedTemplate(e, t, n) {
            let i = this._parseTemplate(e, t);
            return (i.content = e.content.ownerDocument.createDocumentFragment()).appendChild(e.content), 
            n.templateInfo = i, !0;
        }
        static _parseTemplateNodeAttributes(e, t, n) {
            let i = !1, r = Array.from(e.attributes);
            for (let o, s = r.length - 1; o = r[s]; s--) i = this._parseTemplateNodeAttribute(e, t, n, o.name, o.value) || i;
            return i;
        }
        static _parseTemplateNodeAttribute(e, t, n, i, r) {
            return "on-" === i.slice(0, 3) ? (e.removeAttribute(i), n.events = n.events || [], 
            n.events.push({
                name: i.slice(3),
                value: r
            }), !0) : "id" === i && (n.id = r, !0);
        }
        static _contentForTemplate(e) {
            let t = e._templateInfo;
            return t && t.content || e.content;
        }
        _stampTemplate(e) {
            e && !e.content && window.HTMLTemplateElement && HTMLTemplateElement.decorate && HTMLTemplateElement.decorate(e);
            let t = this.constructor._parseTemplate(e), n = t.nodeInfoList, i = t.content || e.content, r = document.importNode(i, !0);
            r.__noInsertionPoint = !t.hasInsertionPoint;
            let o = r.nodeList = new Array(n.length);
            r.$ = {};
            for (let e, t = 0, i = n.length; t < i && (e = n[t]); t++) {
                let n = o[t] = findTemplateNode(r, e);
                applyIdToMap(this, r.$, n, e), applyTemplateContent(this, n, e), applyEventListener(this, n, e);
            }
            return r = r;
        }
        _addMethodEventListenerToNode(e, t, n, i) {
            let r = createNodeEventHandler(i = i || e, t, n);
            return this._addEventListenerToNode(e, t, r), r;
        }
        _addEventListenerToNode(e, t, n) {
            e.addEventListener(t, n);
        }
        _removeEventListenerFromNode(e, t, n) {
            e.removeEventListener(t, n);
        }
    };
});

var templateStamp = {
    TemplateStamp: TemplateStamp
};

let dedupeId$1 = 0;

const TYPES = {
    COMPUTE: "__computeEffects",
    REFLECT: "__reflectEffects",
    NOTIFY: "__notifyEffects",
    PROPAGATE: "__propagateEffects",
    OBSERVE: "__observeEffects",
    READ_ONLY: "__readOnly"
}, capitalAttributeRegex = /[A-Z]/;

let DataTrigger, DataEffect;

function ensureOwnEffectMap(e, t) {
    let n = e[t];
    if (n) {
        if (!e.hasOwnProperty(t)) {
            n = e[t] = Object.create(e[t]);
            for (let e in n) {
                let t = n[e], i = n[e] = Array(t.length);
                for (let e = 0; e < t.length; e++) i[e] = t[e];
            }
        }
    } else n = e[t] = {};
    return n;
}

function runEffects(e, t, n, i, r, o) {
    if (t) {
        let s = !1, a = dedupeId$1++;
        for (let l in n) runEffectsForProperty(e, t, a, l, n, i, r, o) && (s = !0);
        return s;
    }
    return !1;
}

function runEffectsForProperty(e, t, n, i, r, o, s, a) {
    let l = !1, c = t[s ? root(i) : i];
    if (c) for (let t, d = 0, p = c.length; d < p && (t = c[d]); d++) t.info && t.info.lastRun === n || s && !pathMatchesTrigger(i, t.trigger) || (t.info && (t.info.lastRun = n), 
    t.fn(e, i, r, o, t.info, s, a), l = !0);
    return l;
}

function pathMatchesTrigger(e, t) {
    if (t) {
        let n = t.name;
        return n == e || !(!t.structured || !isAncestor(n, e)) || !(!t.wildcard || !isDescendant(n, e));
    }
    return !0;
}

function runObserverEffect(e, t, n, i, r) {
    let o = "string" == typeof r.method ? e[r.method] : r.method, s = r.property;
    o ? o.call(e, e.__data[s], i[s]) : r.dynamicFn || console.warn("observer method `" + r.method + "` not defined");
}

function runNotifyEffects(e, t, n, i, r) {
    let o, s, a = e[TYPES.NOTIFY], l = dedupeId$1++;
    for (let s in t) t[s] && (a && runEffectsForProperty(e, a, l, s, n, i, r) ? o = !0 : r && notifyPath(e, s, n) && (o = !0));
    o && (s = e.__dataHost) && s._invalidateProperties && s._invalidateProperties();
}

function notifyPath(e, t, n) {
    let i = root(t);
    if (i !== t) {
        return dispatchNotifyEvent(e, camelToDashCase(i) + "-changed", n[t], t), !0;
    }
    return !1;
}

function dispatchNotifyEvent(e, t, n, i) {
    let r = {
        value: n,
        queueProperty: !0
    };
    i && (r.path = i), wrap$1(e).dispatchEvent(new CustomEvent(t, {
        detail: r
    }));
}

function runNotifyEffect(e, t, n, i, r, o) {
    let s = (o ? root(t) : t) != t ? t : null, a = s ? get(e, s) : e.__data[t];
    s && void 0 === a && (a = n[t]), dispatchNotifyEvent(e, r.eventName, a, s);
}

function handleNotification(e, t, n, i, r) {
    let o, s = e.detail, a = s && s.path;
    a ? (i = translate(n, i, a), o = s && s.value) : o = e.currentTarget[n], o = r ? !o : o, 
    t[TYPES.READ_ONLY] && t[TYPES.READ_ONLY][i] || !t._setPendingPropertyOrPath(i, o, !0, Boolean(a)) || s && s.queueProperty || t._invalidateProperties();
}

function runReflectEffect(e, t, n, i, r) {
    let o = e.__data[t];
    sanitizeDOMValue && (o = sanitizeDOMValue(o, r.attrName, "attribute", e)), e._propertyToAttribute(t, r.attrName, o);
}

function runComputedEffects(e, t, n, i) {
    let r = e[TYPES.COMPUTE];
    if (r) {
        let o = t;
        for (;runEffects(e, r, o, n, i); ) Object.assign(n, e.__dataOld), Object.assign(t, e.__dataPending), 
        o = e.__dataPending, e.__dataPending = null;
    }
}

function runComputedEffect(e, t, n, i, r) {
    let o = runMethodEffect(e, t, n, i, r), s = r.methodInfo;
    e.__dataHasAccessor && e.__dataHasAccessor[s] ? e._setPendingProperty(s, o, !0) : e[s] = o;
}

function computeLinkedPaths(e, t, n) {
    let i = e.__dataLinkedPaths;
    if (i) {
        let r;
        for (let o in i) {
            let s = i[o];
            isDescendant(o, t) ? (r = translate(o, s, t), e._setPendingPropertyOrPath(r, n, !0, !0)) : isDescendant(s, t) && (r = translate(s, o, t), 
            e._setPendingPropertyOrPath(r, n, !0, !0));
        }
    }
}

function addBinding(e, t, n, i, r, o, s) {
    n.bindings = n.bindings || [];
    let a = {
        kind: i,
        target: r,
        parts: o,
        literal: s,
        isCompound: 1 !== o.length
    };
    if (n.bindings.push(a), shouldAddListener(a)) {
        let {event: e, negate: t} = a.parts[0];
        a.listenerEvent = e || camelToDashCase(r) + "-changed", a.listenerNegate = t;
    }
    let l = t.nodeInfoList.length;
    for (let n = 0; n < a.parts.length; n++) {
        let i = a.parts[n];
        i.compoundIndex = n, addEffectForBindingPart(e, t, a, i, l);
    }
}

function addEffectForBindingPart(e, t, n, i, r) {
    if (!i.literal) if ("attribute" === n.kind && "-" === n.target[0]) console.warn("Cannot set attribute " + n.target + ' because "-" is not a valid attribute starting character'); else {
        let o = i.dependencies, s = {
            index: r,
            binding: n,
            part: i,
            evaluator: e
        };
        for (let n = 0; n < o.length; n++) {
            let i = o[n];
            "string" == typeof i && ((i = parseArg(i)).wildcard = !0), e._addTemplatePropertyEffect(t, i.rootProperty, {
                fn: runBindingEffect,
                info: s,
                trigger: i
            });
        }
    }
}

function runBindingEffect(e, t, n, i, r, o, s) {
    let a = s[r.index], l = r.binding, c = r.part;
    if (o && c.source && t.length > c.source.length && "property" == l.kind && !l.isCompound && a.__isPropertyEffectsClient && a.__dataHasAccessor && a.__dataHasAccessor[l.target]) {
        let i = n[t];
        t = translate(c.source, l.target, t), a._setPendingPropertyOrPath(t, i, !1, !0) && e._enqueueClient(a);
    } else {
        applyBindingValue(e, a, l, c, r.evaluator._evaluateBinding(e, c, t, n, i, o));
    }
}

function applyBindingValue(e, t, n, i, r) {
    if (r = computeBindingValue(t, r, n, i), sanitizeDOMValue && (r = sanitizeDOMValue(r, n.target, n.kind, t)), 
    "attribute" == n.kind) e._valueToNodeAttribute(t, r, n.target); else {
        let i = n.target;
        t.__isPropertyEffectsClient && t.__dataHasAccessor && t.__dataHasAccessor[i] ? t[TYPES.READ_ONLY] && t[TYPES.READ_ONLY][i] || t._setPendingProperty(i, r) && e._enqueueClient(t) : e._setUnmanagedPropertyToNode(t, i, r);
    }
}

function computeBindingValue(e, t, n, i) {
    if (n.isCompound) {
        let r = e.__dataCompoundStorage[n.target];
        r[i.compoundIndex] = t, t = r.join("");
    }
    return "attribute" !== n.kind && ("textContent" !== n.target && ("value" !== n.target || "input" !== e.localName && "textarea" !== e.localName) || (t = null == t ? "" : t)), 
    t;
}

function shouldAddListener(e) {
    return Boolean(e.target) && "attribute" != e.kind && "text" != e.kind && !e.isCompound && "{" === e.parts[0].mode;
}

function setupBindings(e, t) {
    let {nodeList: n, nodeInfoList: i} = t;
    if (i.length) for (let t = 0; t < i.length; t++) {
        let r = i[t], o = n[t], s = r.bindings;
        if (s) for (let t = 0; t < s.length; t++) {
            let n = s[t];
            setupCompoundStorage(o, n), addNotifyListener(o, e, n);
        }
        o.__dataHost = e;
    }
}

function setupCompoundStorage(e, t) {
    if (t.isCompound) {
        let n = e.__dataCompoundStorage || (e.__dataCompoundStorage = {}), i = t.parts, r = new Array(i.length);
        for (let e = 0; e < i.length; e++) r[e] = i[e].literal;
        let o = t.target;
        n[o] = r, t.literal && "property" == t.kind && (e[o] = t.literal);
    }
}

function addNotifyListener(e, t, n) {
    if (n.listenerEvent) {
        let i = n.parts[0];
        e.addEventListener(n.listenerEvent, function(e) {
            handleNotification(e, t, n.target, i.source, i.negate);
        });
    }
}

function createMethodEffect(e, t, n, i, r, o) {
    o = t.static || o && ("object" != typeof o || o[t.methodName]);
    let s = {
        methodName: t.methodName,
        args: t.args,
        methodInfo: r,
        dynamicFn: o
    };
    for (let r, o = 0; o < t.args.length && (r = t.args[o]); o++) r.literal || e._addPropertyEffect(r.rootProperty, n, {
        fn: i,
        info: s,
        trigger: r
    });
    o && e._addPropertyEffect(t.methodName, n, {
        fn: i,
        info: s
    });
}

function runMethodEffect(e, t, n, i, r) {
    let o = e._methodHost || e, s = o[r.methodName];
    if (s) {
        let i = e._marshalArgs(r.args, t, n);
        return s.apply(o, i);
    }
    r.dynamicFn || console.warn("method `" + r.methodName + "` not defined");
}

const emptyArray = [], IDENT = "(?:[a-zA-Z_$][\\w.:$\\-*]*)", NUMBER = "(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)", SQUOTE_STRING = "(?:'(?:[^'\\\\]|\\\\.)*')", DQUOTE_STRING = '(?:"(?:[^"\\\\]|\\\\.)*")', STRING = "(?:" + SQUOTE_STRING + "|" + DQUOTE_STRING + ")", ARGUMENT = "(?:(" + IDENT + "|" + NUMBER + "|" + STRING + ")\\s*)", ARGUMENTS = "(?:" + ARGUMENT + "(?:,\\s*" + ARGUMENT + ")*)", ARGUMENT_LIST = "(?:\\(\\s*(?:" + ARGUMENTS + "?)\\)\\s*)", BINDING = "(" + IDENT + "\\s*" + ARGUMENT_LIST + "?)", OPEN_BRACKET = "(\\[\\[|{{)\\s*", CLOSE_BRACKET = "(?:]]|}})", NEGATE = "(?:(!)\\s*)?", EXPRESSION = OPEN_BRACKET + NEGATE + BINDING + "(?:]]|}})", bindingRegex = new RegExp(EXPRESSION, "g");

function literalFromParts(e) {
    let t = "";
    for (let n = 0; n < e.length; n++) {
        t += e[n].literal || "";
    }
    return t;
}

function parseMethod(e) {
    let t = e.match(/([^\s]+?)\(([\s\S]*)\)/);
    if (t) {
        let e = {
            methodName: t[1],
            static: !0,
            args: emptyArray
        };
        if (t[2].trim()) {
            return parseArgs(t[2].replace(/\\,/g, "&comma;").split(","), e);
        }
        return e;
    }
    return null;
}

function parseArgs(e, t) {
    return t.args = e.map(function(e) {
        let n = parseArg(e);
        return n.literal || (t.static = !1), n;
    }, this), t;
}

function parseArg(e) {
    let t = e.trim().replace(/&comma;/g, ",").replace(/\\(.)/g, "$1"), n = {
        name: t,
        value: "",
        literal: !1
    }, i = t[0];
    switch ("-" === i && (i = t[1]), i >= "0" && i <= "9" && (i = "#"), i) {
      case "'":
      case '"':
        n.value = t.slice(1, -1), n.literal = !0;
        break;

      case "#":
        n.value = Number(t), n.literal = !0;
    }
    return n.literal || (n.rootProperty = root(t), n.structured = isPath(t), n.structured && (n.wildcard = ".*" == t.slice(-2), 
    n.wildcard && (n.name = t.slice(0, -2)))), n;
}

function getArgValue(e, t, n) {
    let i = get(e, n);
    return void 0 === i && (i = t[n]), i;
}

function notifySplices(e, t, n, i) {
    e.notifyPath(n + ".splices", {
        indexSplices: i
    }), e.notifyPath(n + ".length", t.length);
}

function notifySplice(e, t, n, i, r, o) {
    notifySplices(e, t, n, [ {
        index: i,
        addedCount: r,
        removed: o,
        object: t,
        type: "splice"
    } ]);
}

function upper(e) {
    return e[0].toUpperCase() + e.substring(1);
}

const PropertyEffects = dedupingMixin(e => {
    const t = TemplateStamp(PropertyAccessors(e));
    return class extends t {
        constructor() {
            super(), this.__isPropertyEffectsClient = !0, this.__dataCounter = 0, this.__dataClientsReady, 
            this.__dataPendingClients, this.__dataToNotify, this.__dataLinkedPaths, this.__dataHasPaths, 
            this.__dataCompoundStorage, this.__dataHost, this.__dataTemp, this.__dataClientsInitialized, 
            this.__data, this.__dataPending, this.__dataOld, this.__computeEffects, this.__reflectEffects, 
            this.__notifyEffects, this.__propagateEffects, this.__observeEffects, this.__readOnly, 
            this.__templateInfo;
        }
        get PROPERTY_EFFECT_TYPES() {
            return TYPES;
        }
        _initializeProperties() {
            super._initializeProperties(), hostStack.registerHost(this), this.__dataClientsReady = !1, 
            this.__dataPendingClients = null, this.__dataToNotify = null, this.__dataLinkedPaths = null, 
            this.__dataHasPaths = !1, this.__dataCompoundStorage = this.__dataCompoundStorage || null, 
            this.__dataHost = this.__dataHost || null, this.__dataTemp = {}, this.__dataClientsInitialized = !1;
        }
        _initializeProtoProperties(e) {
            this.__data = Object.create(e), this.__dataPending = Object.create(e), this.__dataOld = {};
        }
        _initializeInstanceProperties(e) {
            let t = this[TYPES.READ_ONLY];
            for (let n in e) t && t[n] || (this.__dataPending = this.__dataPending || {}, this.__dataOld = this.__dataOld || {}, 
            this.__data[n] = this.__dataPending[n] = e[n]);
        }
        _addPropertyEffect(e, t, n) {
            this._createPropertyAccessor(e, t == TYPES.READ_ONLY);
            let i = ensureOwnEffectMap(this, t)[e];
            i || (i = this[t][e] = []), i.push(n);
        }
        _removePropertyEffect(e, t, n) {
            let i = ensureOwnEffectMap(this, t)[e], r = i.indexOf(n);
            r >= 0 && i.splice(r, 1);
        }
        _hasPropertyEffect(e, t) {
            let n = this[t];
            return Boolean(n && n[e]);
        }
        _hasReadOnlyEffect(e) {
            return this._hasPropertyEffect(e, TYPES.READ_ONLY);
        }
        _hasNotifyEffect(e) {
            return this._hasPropertyEffect(e, TYPES.NOTIFY);
        }
        _hasReflectEffect(e) {
            return this._hasPropertyEffect(e, TYPES.REFLECT);
        }
        _hasComputedEffect(e) {
            return this._hasPropertyEffect(e, TYPES.COMPUTE);
        }
        _setPendingPropertyOrPath(e, t, n, i) {
            if (i || root(Array.isArray(e) ? e[0] : e) !== e) {
                if (!i) {
                    let n = get(this, e);
                    if (!(e = set(this, e, t)) || !super._shouldPropertyChange(e, t, n)) return !1;
                }
                if (this.__dataHasPaths = !0, this._setPendingProperty(e, t, n)) return computeLinkedPaths(this, e, t), 
                !0;
            } else {
                if (this.__dataHasAccessor && this.__dataHasAccessor[e]) return this._setPendingProperty(e, t, n);
                this[e] = t;
            }
            return !1;
        }
        _setUnmanagedPropertyToNode(e, t, n) {
            n === e[t] && "object" != typeof n || (e[t] = n);
        }
        _setPendingProperty(e, t, n) {
            let i = this.__dataHasPaths && isPath(e), r = i ? this.__dataTemp : this.__data;
            return !!this._shouldPropertyChange(e, t, r[e]) && (this.__dataPending || (this.__dataPending = {}, 
            this.__dataOld = {}), e in this.__dataOld || (this.__dataOld[e] = this.__data[e]), 
            i ? this.__dataTemp[e] = t : this.__data[e] = t, this.__dataPending[e] = t, (i || this[TYPES.NOTIFY] && this[TYPES.NOTIFY][e]) && (this.__dataToNotify = this.__dataToNotify || {}, 
            this.__dataToNotify[e] = n), !0);
        }
        _setProperty(e, t) {
            this._setPendingProperty(e, t, !0) && this._invalidateProperties();
        }
        _invalidateProperties() {
            this.__dataReady && this._flushProperties();
        }
        _enqueueClient(e) {
            this.__dataPendingClients = this.__dataPendingClients || [], e !== this && this.__dataPendingClients.push(e);
        }
        _flushProperties() {
            this.__dataCounter++, super._flushProperties(), this.__dataCounter--;
        }
        _flushClients() {
            this.__dataClientsReady ? this.__enableOrFlushClients() : (this.__dataClientsReady = !0, 
            this._readyClients(), this.__dataReady = !0);
        }
        __enableOrFlushClients() {
            let e = this.__dataPendingClients;
            if (e) {
                this.__dataPendingClients = null;
                for (let t = 0; t < e.length; t++) {
                    let n = e[t];
                    n.__dataEnabled ? n.__dataPending && n._flushProperties() : n._enableProperties();
                }
            }
        }
        _readyClients() {
            this.__enableOrFlushClients();
        }
        setProperties(e, t) {
            for (let n in e) !t && this[TYPES.READ_ONLY] && this[TYPES.READ_ONLY][n] || this._setPendingPropertyOrPath(n, e[n], !0);
            this._invalidateProperties();
        }
        ready() {
            this._flushProperties(), this.__dataClientsReady || this._flushClients(), this.__dataPending && this._flushProperties();
        }
        _propertiesChanged(e, t, n) {
            let i = this.__dataHasPaths;
            this.__dataHasPaths = !1, runComputedEffects(this, t, n, i);
            let r = this.__dataToNotify;
            this.__dataToNotify = null, this._propagatePropertyChanges(t, n, i), this._flushClients(), 
            runEffects(this, this[TYPES.REFLECT], t, n, i), runEffects(this, this[TYPES.OBSERVE], t, n, i), 
            r && runNotifyEffects(this, r, t, n, i), 1 == this.__dataCounter && (this.__dataTemp = {});
        }
        _propagatePropertyChanges(e, t, n) {
            this[TYPES.PROPAGATE] && runEffects(this, this[TYPES.PROPAGATE], e, t, n);
            let i = this.__templateInfo;
            for (;i; ) runEffects(this, i.propertyEffects, e, t, n, i.nodeList), i = i.nextTemplateInfo;
        }
        linkPaths(e, t) {
            e = normalize(e), t = normalize(t), this.__dataLinkedPaths = this.__dataLinkedPaths || {}, 
            this.__dataLinkedPaths[e] = t;
        }
        unlinkPaths(e) {
            e = normalize(e), this.__dataLinkedPaths && delete this.__dataLinkedPaths[e];
        }
        notifySplices(e, t) {
            let n = {
                path: ""
            };
            notifySplices(this, get(this, e, n), n.path, t);
        }
        get(e, t) {
            return get(t || this, e);
        }
        set(e, t, n) {
            n ? set(n, e, t) : this[TYPES.READ_ONLY] && this[TYPES.READ_ONLY][e] || this._setPendingPropertyOrPath(e, t, !0) && this._invalidateProperties();
        }
        push(e, ...t) {
            let n = {
                path: ""
            }, i = get(this, e, n), r = i.length, o = i.push(...t);
            return t.length && notifySplice(this, i, n.path, r, t.length, []), o;
        }
        pop(e) {
            let t = {
                path: ""
            }, n = get(this, e, t), i = Boolean(n.length), r = n.pop();
            return i && notifySplice(this, n, t.path, n.length, 0, [ r ]), r;
        }
        splice(e, t, n, ...i) {
            let r, o = {
                path: ""
            }, s = get(this, e, o);
            return t < 0 ? t = s.length - Math.floor(-t) : t && (t = Math.floor(t)), r = 2 === arguments.length ? s.splice(t) : s.splice(t, n, ...i), 
            (i.length || r.length) && notifySplice(this, s, o.path, t, i.length, r), r;
        }
        shift(e) {
            let t = {
                path: ""
            }, n = get(this, e, t), i = Boolean(n.length), r = n.shift();
            return i && notifySplice(this, n, t.path, 0, 0, [ r ]), r;
        }
        unshift(e, ...t) {
            let n = {
                path: ""
            }, i = get(this, e, n), r = i.unshift(...t);
            return t.length && notifySplice(this, i, n.path, 0, t.length, []), r;
        }
        notifyPath(e, t) {
            let n;
            if (1 == arguments.length) {
                let i = {
                    path: ""
                };
                t = get(this, e, i), n = i.path;
            } else n = Array.isArray(e) ? normalize(e) : e;
            this._setPendingPropertyOrPath(n, t, !0, !0) && this._invalidateProperties();
        }
        _createReadOnlyProperty(e, t) {
            this._addPropertyEffect(e, TYPES.READ_ONLY), t && (this["_set" + upper(e)] = function(t) {
                this._setProperty(e, t);
            });
        }
        _createPropertyObserver(e, t, n) {
            let i = {
                property: e,
                method: t,
                dynamicFn: Boolean(n)
            };
            this._addPropertyEffect(e, TYPES.OBSERVE, {
                fn: runObserverEffect,
                info: i,
                trigger: {
                    name: e
                }
            }), n && this._addPropertyEffect(t, TYPES.OBSERVE, {
                fn: runObserverEffect,
                info: i,
                trigger: {
                    name: t
                }
            });
        }
        _createMethodObserver(e, t) {
            let n = parseMethod(e);
            if (!n) throw new Error("Malformed observer expression '" + e + "'");
            createMethodEffect(this, n, TYPES.OBSERVE, runMethodEffect, null, t);
        }
        _createNotifyingProperty(e) {
            this._addPropertyEffect(e, TYPES.NOTIFY, {
                fn: runNotifyEffect,
                info: {
                    eventName: camelToDashCase(e) + "-changed",
                    property: e
                }
            });
        }
        _createReflectedProperty(e) {
            let t = this.constructor.attributeNameForProperty(e);
            "-" === t[0] ? console.warn("Property " + e + " cannot be reflected to attribute " + t + ' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.') : this._addPropertyEffect(e, TYPES.REFLECT, {
                fn: runReflectEffect,
                info: {
                    attrName: t
                }
            });
        }
        _createComputedProperty(e, t, n) {
            let i = parseMethod(t);
            if (!i) throw new Error("Malformed computed expression '" + t + "'");
            createMethodEffect(this, i, TYPES.COMPUTE, runComputedEffect, e, n);
        }
        _marshalArgs(e, t, n) {
            const i = this.__data, r = [];
            for (let o = 0, s = e.length; o < s; o++) {
                let {name: s, structured: a, wildcard: l, value: c, literal: d} = e[o];
                if (!d) if (l) {
                    const e = isDescendant(s, t), r = getArgValue(i, n, e ? t : s);
                    c = {
                        path: e ? t : s,
                        value: r,
                        base: e ? get(i, s) : r
                    };
                } else c = a ? getArgValue(i, n, s) : i[s];
                r[o] = c;
            }
            return r;
        }
        static addPropertyEffect(e, t, n) {
            this.prototype._addPropertyEffect(e, t, n);
        }
        static createPropertyObserver(e, t, n) {
            this.prototype._createPropertyObserver(e, t, n);
        }
        static createMethodObserver(e, t) {
            this.prototype._createMethodObserver(e, t);
        }
        static createNotifyingProperty(e) {
            this.prototype._createNotifyingProperty(e);
        }
        static createReadOnlyProperty(e, t) {
            this.prototype._createReadOnlyProperty(e, t);
        }
        static createReflectedProperty(e) {
            this.prototype._createReflectedProperty(e);
        }
        static createComputedProperty(e, t, n) {
            this.prototype._createComputedProperty(e, t, n);
        }
        static bindTemplate(e) {
            return this.prototype._bindTemplate(e);
        }
        _bindTemplate(e, t) {
            let n = this.constructor._parseTemplate(e), i = this.__templateInfo == n;
            if (!i) for (let e in n.propertyEffects) this._createPropertyAccessor(e);
            if (t && ((n = Object.create(n)).wasPreBound = i, !i && this.__templateInfo)) {
                let e = this.__templateInfoLast || this.__templateInfo;
                return this.__templateInfoLast = e.nextTemplateInfo = n, n.previousTemplateInfo = e, 
                n;
            }
            return this.__templateInfo = n;
        }
        static _addTemplatePropertyEffect(e, t, n) {
            (e.hostProps = e.hostProps || {})[t] = !0;
            let i = e.propertyEffects = e.propertyEffects || {};
            (i[t] = i[t] || []).push(n);
        }
        _stampTemplate(e) {
            hostStack.beginHosting(this);
            let t = super._stampTemplate(e);
            hostStack.endHosting(this);
            let n = this._bindTemplate(e, !0);
            if (n.nodeList = t.nodeList, !n.wasPreBound) {
                let e = n.childNodes = [];
                for (let n = t.firstChild; n; n = n.nextSibling) e.push(n);
            }
            return t.templateInfo = n, setupBindings(this, n), this.__dataReady && runEffects(this, n.propertyEffects, this.__data, null, !1, n.nodeList), 
            t;
        }
        _removeBoundDom(e) {
            let t = e.templateInfo;
            t.previousTemplateInfo && (t.previousTemplateInfo.nextTemplateInfo = t.nextTemplateInfo), 
            t.nextTemplateInfo && (t.nextTemplateInfo.previousTemplateInfo = t.previousTemplateInfo), 
            this.__templateInfoLast == t && (this.__templateInfoLast = t.previousTemplateInfo), 
            t.previousTemplateInfo = t.nextTemplateInfo = null;
            let n = t.childNodes;
            for (let e = 0; e < n.length; e++) {
                let t = n[e];
                t.parentNode.removeChild(t);
            }
        }
        static _parseTemplateNode(e, t, n) {
            let i = super._parseTemplateNode(e, t, n);
            if (e.nodeType === Node.TEXT_NODE) {
                let r = this._parseBindings(e.textContent, t);
                r && (e.textContent = literalFromParts(r) || " ", addBinding(this, t, n, "text", "textContent", r), 
                i = !0);
            }
            return i;
        }
        static _parseTemplateNodeAttribute(e, t, n, i, r) {
            let o = this._parseBindings(r, t);
            if (o) {
                let r = i, s = "property";
                capitalAttributeRegex.test(i) ? s = "attribute" : "$" == i[i.length - 1] && (i = i.slice(0, -1), 
                s = "attribute");
                let a = literalFromParts(o);
                return a && "attribute" == s && ("class" == i && e.hasAttribute("class") && (a += " " + e.getAttribute(i)), 
                e.setAttribute(i, a)), "input" === e.localName && "value" === r && e.setAttribute(r, ""), 
                e.removeAttribute(r), "property" === s && (i = dashToCamelCase(i)), addBinding(this, t, n, s, i, o, a), 
                !0;
            }
            return super._parseTemplateNodeAttribute(e, t, n, i, r);
        }
        static _parseTemplateNestedTemplate(e, t, n) {
            let i = super._parseTemplateNestedTemplate(e, t, n), r = n.templateInfo.hostProps;
            for (let e in r) addBinding(this, t, n, "property", "_host_" + e, [ {
                mode: "{",
                source: e,
                dependencies: [ e ]
            } ]);
            return i;
        }
        static _parseBindings(e, t) {
            let n, i = [], r = 0;
            for (;null !== (n = bindingRegex.exec(e)); ) {
                n.index > r && i.push({
                    literal: e.slice(r, n.index)
                });
                let o = n[1][0], s = Boolean(n[2]), a = n[3].trim(), l = !1, c = "", d = -1;
                "{" == o && (d = a.indexOf("::")) > 0 && (c = a.substring(d + 2), a = a.substring(0, d), 
                l = !0);
                let p = parseMethod(a), u = [];
                if (p) {
                    let {args: e, methodName: n} = p;
                    for (let t = 0; t < e.length; t++) {
                        let n = e[t];
                        n.literal || u.push(n);
                    }
                    let i = t.dynamicFns;
                    (i && i[n] || p.static) && (u.push(n), p.dynamicFn = !0);
                } else u.push(a);
                i.push({
                    source: a,
                    mode: o,
                    negate: s,
                    customEvent: l,
                    signature: p,
                    dependencies: u,
                    event: c
                }), r = bindingRegex.lastIndex;
            }
            if (r && r < e.length) {
                let t = e.substring(r);
                t && i.push({
                    literal: t
                });
            }
            return i.length ? i : null;
        }
        static _evaluateBinding(e, t, n, i, r, o) {
            let s;
            return s = t.signature ? runMethodEffect(e, n, i, r, t.signature) : n != t.source ? get(e, t.source) : o && isPath(n) ? get(e, n) : e.__data[n], 
            t.negate && (s = !s), s;
        }
    };
});

class HostStack {
    constructor() {
        this.stack = [];
    }
    registerHost(e) {
        if (this.stack.length) {
            this.stack[this.stack.length - 1]._enqueueClient(e);
        }
    }
    beginHosting(e) {
        this.stack.push(e);
    }
    endHosting(e) {
        let t = this.stack.length;
        t && this.stack[t - 1] == e && this.stack.pop();
    }
}

const hostStack = new HostStack();

var propertyEffects = {
    PropertyEffects: PropertyEffects
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ let instanceCount = 0;

function incrementInstanceCount() {
    instanceCount++;
}

const registrations = [];

function _regLog(e) {
    console.log("[" + e.is + "]: registered");
}

function register(e) {
    registrations.push(e);
}

function dumpRegistrations() {
    registrations.forEach(_regLog);
}

var telemetry = {
    get instanceCount() {
        return instanceCount;
    },
    incrementInstanceCount: incrementInstanceCount,
    registrations: registrations,
    register: register,
    dumpRegistrations: dumpRegistrations
};

function normalizeProperties(e) {
    const t = {};
    for (let n in e) {
        const i = e[n];
        t[n] = "function" == typeof i ? {
            type: i
        } : i;
    }
    return t;
}

const PropertiesMixin = dedupingMixin(e => {
    const t = PropertiesChanged(e);
    function n(e) {
        const t = Object.getPrototypeOf(e);
        return t.prototype instanceof r ? t : null;
    }
    function i(e) {
        if (!e.hasOwnProperty(JSCompiler_renameProperty("__ownProperties", e))) {
            let t = null;
            if (e.hasOwnProperty(JSCompiler_renameProperty("properties", e))) {
                const n = e.properties;
                n && (t = normalizeProperties(n));
            }
            e.__ownProperties = t;
        }
        return e.__ownProperties;
    }
    class r extends t {
        static get observedAttributes() {
            if (!this.hasOwnProperty("__observedAttributes")) {
                register(this.prototype);
                const e = this._properties;
                this.__observedAttributes = e ? Object.keys(e).map(e => this.attributeNameForProperty(e)) : [];
            }
            return this.__observedAttributes;
        }
        static finalize() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("__finalized", this))) {
                const e = n(this);
                e && e.finalize(), this.__finalized = !0, this._finalizeClass();
            }
        }
        static _finalizeClass() {
            const e = i(this);
            e && this.createProperties(e);
        }
        static get _properties() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("__properties", this))) {
                const e = n(this);
                this.__properties = Object.assign({}, e && e._properties, i(this));
            }
            return this.__properties;
        }
        static typeForProperty(e) {
            const t = this._properties[e];
            return t && t.type;
        }
        _initializeProperties() {
            incrementInstanceCount(), this.constructor.finalize(), super._initializeProperties();
        }
        connectedCallback() {
            super.connectedCallback && super.connectedCallback(), this._enableProperties();
        }
        disconnectedCallback() {
            super.disconnectedCallback && super.disconnectedCallback();
        }
    }
    return r;
});

var propertiesMixin = {
    PropertiesMixin: PropertiesMixin
};

const bundledImportMeta = {
    ...import.meta,
    url: new URL("./node_modules/%40polymer/polymer/lib/mixins/element-mixin.js", import.meta.url).href
}, version = "3.2.0", builtCSS = window.ShadyCSS && window.ShadyCSS.cssBuild, ElementMixin = dedupingMixin(e => {
    const t = PropertiesMixin(PropertyEffects(e));
    return class extends t {
        static get polymerElementVersion() {
            return version;
        }
        static _finalizeClass() {
            super._finalizeClass();
            const e = ((t = this).hasOwnProperty(JSCompiler_renameProperty("__ownObservers", t)) || (t.__ownObservers = t.hasOwnProperty(JSCompiler_renameProperty("observers", t)) ? t.observers : null), 
            t.__ownObservers);
            var t;
            e && this.createObservers(e, this._properties), this._prepareTemplate();
        }
        static _prepareTemplate() {
            let e = this.template;
            e && ("string" == typeof e ? (console.error("template getter must return HTMLTemplateElement"), 
            e = null) : legacyOptimizations || (e = e.cloneNode(!0))), this.prototype._template = e;
        }
        static createProperties(e) {
            for (let o in e) t = this.prototype, n = o, i = e[o], r = e, i.computed && (i.readOnly = !0), 
            i.computed && (t._hasReadOnlyEffect(n) ? console.warn(`Cannot redefine computed property '${n}'.`) : t._createComputedProperty(n, i.computed, r)), 
            i.readOnly && !t._hasReadOnlyEffect(n) ? t._createReadOnlyProperty(n, !i.computed) : !1 === i.readOnly && t._hasReadOnlyEffect(n) && console.warn(`Cannot make readOnly property '${n}' non-readOnly.`), 
            i.reflectToAttribute && !t._hasReflectEffect(n) ? t._createReflectedProperty(n) : !1 === i.reflectToAttribute && t._hasReflectEffect(n) && console.warn(`Cannot make reflected property '${n}' non-reflected.`), 
            i.notify && !t._hasNotifyEffect(n) ? t._createNotifyingProperty(n) : !1 === i.notify && t._hasNotifyEffect(n) && console.warn(`Cannot make notify property '${n}' non-notify.`), 
            i.observer && t._createPropertyObserver(n, i.observer, r[i.observer]), t._addPropertyToAttributeMap(n);
            var t, n, i, r;
        }
        static createObservers(e, t) {
            const n = this.prototype;
            for (let i = 0; i < e.length; i++) n._createMethodObserver(e[i], t);
        }
        static get template() {
            return this.hasOwnProperty(JSCompiler_renameProperty("_template", this)) || (this._template = this.prototype.hasOwnProperty(JSCompiler_renameProperty("_template", this.prototype)) ? this.prototype._template : function(e) {
                let t = null;
                if (e && (!strictTemplatePolicy || allowTemplateFromDomModule) && (t = DomModule.import(e, "template"), 
                strictTemplatePolicy && !t)) throw new Error(`strictTemplatePolicy: expecting dom-module or null template for ${e}`);
                return t;
            }(this.is) || Object.getPrototypeOf(this.prototype).constructor.template), this._template;
        }
        static set template(e) {
            this._template = e;
        }
        static get importPath() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("_importPath", this))) {
                const e = this.importMeta;
                if (e) this._importPath = pathFromUrl(e.url); else {
                    const e = DomModule.import(this.is);
                    this._importPath = e && e.assetpath || Object.getPrototypeOf(this.prototype).constructor.importPath;
                }
            }
            return this._importPath;
        }
        constructor() {
            super(), this._template, this._importPath, this.rootPath, this.importPath, this.root, 
            this.$;
        }
        _initializeProperties() {
            this.constructor.finalize(), this.constructor._finalizeTemplate(this.localName), 
            super._initializeProperties(), this.rootPath = rootPath, this.importPath = this.constructor.importPath;
            let e = function(e) {
                if (!e.hasOwnProperty(JSCompiler_renameProperty("__propertyDefaults", e))) {
                    e.__propertyDefaults = null;
                    let t = e._properties;
                    for (let n in t) {
                        let i = t[n];
                        "value" in i && (e.__propertyDefaults = e.__propertyDefaults || {}, e.__propertyDefaults[n] = i);
                    }
                }
                return e.__propertyDefaults;
            }(this.constructor);
            if (e) for (let t in e) {
                let n = e[t];
                if (!this.hasOwnProperty(t)) {
                    let e = "function" == typeof n.value ? n.value.call(this) : n.value;
                    this._hasAccessor(t) ? this._setPendingProperty(t, e, !0) : this[t] = e;
                }
            }
        }
        static _processStyleText(e, t) {
            return resolveCss(e, t);
        }
        static _finalizeTemplate(e) {
            const t = this.prototype._template;
            if (t && !t.__polymerFinalized) {
                t.__polymerFinalized = !0;
                const n = this.importPath;
                !function(e, t, n, i) {
                    if (!builtCSS) {
                        const r = t.content.querySelectorAll("style"), o = stylesFromTemplate(t), s = stylesFromModuleImports(n), a = t.content.firstElementChild;
                        for (let n = 0; n < s.length; n++) {
                            let r = s[n];
                            r.textContent = e._processStyleText(r.textContent, i), t.content.insertBefore(r, a);
                        }
                        let l = 0;
                        for (let t = 0; t < o.length; t++) {
                            let n = o[t], s = r[l];
                            s !== n ? (n = n.cloneNode(!0), s.parentNode.insertBefore(n, s)) : l++, n.textContent = e._processStyleText(n.textContent, i);
                        }
                    }
                    window.ShadyCSS && window.ShadyCSS.prepareTemplate(t, n);
                }(this, t, e, n ? resolveUrl(n) : ""), this.prototype._bindTemplate(t);
            }
        }
        connectedCallback() {
            window.ShadyCSS && this._template && window.ShadyCSS.styleElement(this), super.connectedCallback();
        }
        ready() {
            this._template && (this.root = this._stampTemplate(this._template), this.$ = this.root.$), 
            super.ready();
        }
        _readyClients() {
            this._template && (this.root = this._attachDom(this.root)), super._readyClients();
        }
        _attachDom(e) {
            const t = wrap$1(this);
            if (t.attachShadow) return e ? (t.shadowRoot || t.attachShadow({
                mode: "open"
            }), t.shadowRoot.appendChild(e), syncInitialRender && window.ShadyDOM && ShadyDOM.flushInitial(t.shadowRoot), 
            t.shadowRoot) : null;
            throw new Error("ShadowDOM not available. PolymerElement can create dom as children instead of in ShadowDOM by setting `this.root = this;` before `ready`.");
        }
        updateStyles(e) {
            window.ShadyCSS && window.ShadyCSS.styleSubtree(this, e);
        }
        resolveUrl(e, t) {
            return !t && this.importPath && (t = resolveUrl(this.importPath)), resolveUrl(e, t);
        }
        static _parseTemplateContent(e, t, n) {
            return t.dynamicFns = t.dynamicFns || this._properties, super._parseTemplateContent(e, t, n);
        }
        static _addTemplatePropertyEffect(e, t, n) {
            return !legacyOptimizations || t in this._properties || console.warn(`Property '${t}' used in template but not declared in 'properties'; ` + "attribute will not be observed."), 
            super._addTemplatePropertyEffect(e, t, n);
        }
    };
}), updateStyles = function(e) {
    window.ShadyCSS && window.ShadyCSS.styleDocument(e);
};

var elementMixin = {
    version: version,
    ElementMixin: ElementMixin,
    updateStyles: updateStyles
};

class Debouncer {
    constructor() {
        this._asyncModule = null, this._callback = null, this._timer = null;
    }
    setConfig(e, t) {
        this._asyncModule = e, this._callback = t, this._timer = this._asyncModule.run(() => {
            this._timer = null, debouncerQueue.delete(this), this._callback();
        });
    }
    cancel() {
        this.isActive() && (this._cancelAsync(), debouncerQueue.delete(this));
    }
    _cancelAsync() {
        this.isActive() && (this._asyncModule.cancel(this._timer), this._timer = null);
    }
    flush() {
        this.isActive() && (this.cancel(), this._callback());
    }
    isActive() {
        return null != this._timer;
    }
    static debounce(e, t, n) {
        return e instanceof Debouncer ? e._cancelAsync() : e = new Debouncer(), e.setConfig(t, n), 
        e;
    }
}

let debouncerQueue = new Set();

const enqueueDebouncer = function(e) {
    debouncerQueue.add(e);
}, flushDebouncers = function() {
    const e = Boolean(debouncerQueue.size);
    return debouncerQueue.forEach(e => {
        try {
            e.flush();
        } catch (e) {
            setTimeout(() => {
                throw e;
            });
        }
    }), e;
};

var debounce = {
    Debouncer: Debouncer,
    enqueueDebouncer: enqueueDebouncer,
    flushDebouncers: flushDebouncers
};

let HAS_NATIVE_TA = "string" == typeof document.head.style.touchAction, GESTURE_KEY = "__polymerGestures", HANDLED_OBJ = "__polymerGesturesHandled", TOUCH_ACTION = "__polymerGesturesTouchAction", TAP_DISTANCE = 25, TRACK_DISTANCE = 5, TRACK_LENGTH = 2, MOUSE_TIMEOUT = 2500, MOUSE_EVENTS = [ "mousedown", "mousemove", "mouseup", "click" ], MOUSE_WHICH_TO_BUTTONS = [ 0, 1, 4, 2 ], MOUSE_HAS_BUTTONS = function() {
    try {
        return 1 === new MouseEvent("test", {
            buttons: 1
        }).buttons;
    } catch (e) {
        return !1;
    }
}();

function isMouseEvent(e) {
    return MOUSE_EVENTS.indexOf(e) > -1;
}

let SUPPORTS_PASSIVE = !1;

function PASSIVE_TOUCH(e) {
    if (!isMouseEvent(e) && "touchend" !== e) return HAS_NATIVE_TA && SUPPORTS_PASSIVE && passiveTouchGestures ? {
        passive: !0
    } : void 0;
}

!function() {
    try {
        let e = Object.defineProperty({}, "passive", {
            get() {
                SUPPORTS_PASSIVE = !0;
            }
        });
        window.addEventListener("test", null, e), window.removeEventListener("test", null, e);
    } catch (e) {}
}();

let IS_TOUCH_ONLY = navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/);

const clickedLabels = [], labellable = {
    button: !0,
    input: !0,
    keygen: !0,
    meter: !0,
    output: !0,
    textarea: !0,
    progress: !0,
    select: !0
}, canBeDisabled = {
    button: !0,
    command: !0,
    fieldset: !0,
    input: !0,
    keygen: !0,
    optgroup: !0,
    option: !0,
    select: !0,
    textarea: !0
};

function canBeLabelled(e) {
    return labellable[e.localName] || !1;
}

function matchingLabels(e) {
    let t = Array.prototype.slice.call(e.labels || []);
    if (!t.length) {
        t = [];
        let n = e.getRootNode();
        if (e.id) {
            let i = n.querySelectorAll(`label[for = ${e.id}]`);
            for (let e = 0; e < i.length; e++) t.push(i[e]);
        }
    }
    return t;
}

let mouseCanceller = function(e) {
    let t = e.sourceCapabilities;
    if ((!t || t.firesTouchEvents) && (e[HANDLED_OBJ] = {
        skip: !0
    }, "click" === e.type)) {
        let t = !1, n = getComposedPath(e);
        for (let e = 0; e < n.length; e++) {
            if (n[e].nodeType === Node.ELEMENT_NODE) if ("label" === n[e].localName) clickedLabels.push(n[e]); else if (canBeLabelled(n[e])) {
                let i = matchingLabels(n[e]);
                for (let e = 0; e < i.length; e++) t = t || clickedLabels.indexOf(i[e]) > -1;
            }
            if (n[e] === POINTERSTATE.mouse.target) return;
        }
        if (t) return;
        e.preventDefault(), e.stopPropagation();
    }
};

function setupTeardownMouseCanceller(e) {
    let t = IS_TOUCH_ONLY ? [ "click" ] : MOUSE_EVENTS;
    for (let n, i = 0; i < t.length; i++) n = t[i], e ? (clickedLabels.length = 0, document.addEventListener(n, mouseCanceller, !0)) : document.removeEventListener(n, mouseCanceller, !0);
}

function ignoreMouse(e) {
    POINTERSTATE.mouse.mouseIgnoreJob || setupTeardownMouseCanceller(!0);
    POINTERSTATE.mouse.target = getComposedPath(e)[0], POINTERSTATE.mouse.mouseIgnoreJob = Debouncer.debounce(POINTERSTATE.mouse.mouseIgnoreJob, timeOut.after(MOUSE_TIMEOUT), function() {
        setupTeardownMouseCanceller(), POINTERSTATE.mouse.target = null, POINTERSTATE.mouse.mouseIgnoreJob = null;
    });
}

function hasLeftMouseButton(e) {
    let t = e.type;
    if (!isMouseEvent(t)) return !1;
    if ("mousemove" === t) {
        let t = void 0 === e.buttons ? 1 : e.buttons;
        return e instanceof window.MouseEvent && !MOUSE_HAS_BUTTONS && (t = MOUSE_WHICH_TO_BUTTONS[e.which] || 0), 
        Boolean(1 & t);
    }
    return 0 === (void 0 === e.button ? 0 : e.button);
}

function isSyntheticClick(e) {
    if ("click" === e.type) {
        if (0 === e.detail) return !0;
        let t = _findOriginalTarget(e);
        if (!t.nodeType || t.nodeType !== Node.ELEMENT_NODE) return !0;
        let n = t.getBoundingClientRect(), i = e.pageX, r = e.pageY;
        return !(i >= n.left && i <= n.right && r >= n.top && r <= n.bottom);
    }
    return !1;
}

let POINTERSTATE = {
    mouse: {
        target: null,
        mouseIgnoreJob: null
    },
    touch: {
        x: 0,
        y: 0,
        id: -1,
        scrollDecided: !1
    }
};

function firstTouchAction(e) {
    let t = "auto", n = getComposedPath(e);
    for (let e, i = 0; i < n.length; i++) if ((e = n[i])[TOUCH_ACTION]) {
        t = e[TOUCH_ACTION];
        break;
    }
    return t;
}

function trackDocument(e, t, n) {
    e.movefn = t, e.upfn = n, document.addEventListener("mousemove", t), document.addEventListener("mouseup", n);
}

function untrackDocument(e) {
    document.removeEventListener("mousemove", e.movefn), document.removeEventListener("mouseup", e.upfn), 
    e.movefn = null, e.upfn = null;
}

document.addEventListener("touchend", ignoreMouse, !!SUPPORTS_PASSIVE && {
    passive: !0
});

const getComposedPath = window.ShadyDOM && window.ShadyDOM.noPatch ? window.ShadyDOM.composedPath : e => e.composedPath && e.composedPath() || [], gestures = {}, recognizers = [];

function deepTargetFind(e, t) {
    let n = document.elementFromPoint(e, t), i = n;
    for (;i && i.shadowRoot && !window.ShadyDOM; ) {
        if (i === (i = i.shadowRoot.elementFromPoint(e, t))) break;
        i && (n = i);
    }
    return n;
}

function _findOriginalTarget(e) {
    const t = getComposedPath(e);
    return t.length > 0 ? t[0] : e.target;
}

function _handleNative(e) {
    let t, n = e.type, i = e.currentTarget[GESTURE_KEY];
    if (!i) return;
    let r = i[n];
    if (r) {
        if (!e[HANDLED_OBJ] && (e[HANDLED_OBJ] = {}, "touch" === n.slice(0, 5))) {
            let t = (e = e).changedTouches[0];
            if ("touchstart" === n && 1 === e.touches.length && (POINTERSTATE.touch.id = t.identifier), 
            POINTERSTATE.touch.id !== t.identifier) return;
            HAS_NATIVE_TA || "touchstart" !== n && "touchmove" !== n || _handleTouchAction(e);
        }
        if (!(t = e[HANDLED_OBJ]).skip) {
            for (let n, i = 0; i < recognizers.length; i++) r[(n = recognizers[i]).name] && !t[n.name] && n.flow && n.flow.start.indexOf(e.type) > -1 && n.reset && n.reset();
            for (let i, o = 0; o < recognizers.length; o++) r[(i = recognizers[o]).name] && !t[i.name] && (t[i.name] = !0, 
            i[n](e));
        }
    }
}

function _handleTouchAction(e) {
    let t = e.changedTouches[0], n = e.type;
    if ("touchstart" === n) POINTERSTATE.touch.x = t.clientX, POINTERSTATE.touch.y = t.clientY, 
    POINTERSTATE.touch.scrollDecided = !1; else if ("touchmove" === n) {
        if (POINTERSTATE.touch.scrollDecided) return;
        POINTERSTATE.touch.scrollDecided = !0;
        let n = firstTouchAction(e), i = !1, r = Math.abs(POINTERSTATE.touch.x - t.clientX), o = Math.abs(POINTERSTATE.touch.y - t.clientY);
        e.cancelable && ("none" === n ? i = !0 : "pan-x" === n ? i = o > r : "pan-y" === n && (i = r > o)), 
        i ? e.preventDefault() : prevent("track");
    }
}

function addListener(e, t, n) {
    return !!gestures[t] && (_add(e, t, n), !0);
}

function removeListener(e, t, n) {
    return !!gestures[t] && (_remove(e, t, n), !0);
}

function _add(e, t, n) {
    let i = gestures[t], r = i.deps, o = i.name, s = e[GESTURE_KEY];
    s || (e[GESTURE_KEY] = s = {});
    for (let t, n, i = 0; i < r.length; i++) t = r[i], IS_TOUCH_ONLY && isMouseEvent(t) && "click" !== t || ((n = s[t]) || (s[t] = n = {
        _count: 0
    }), 0 === n._count && e.addEventListener(t, _handleNative, PASSIVE_TOUCH(t)), n[o] = (n[o] || 0) + 1, 
    n._count = (n._count || 0) + 1);
    e.addEventListener(t, n), i.touchAction && setTouchAction(e, i.touchAction);
}

function _remove(e, t, n) {
    let i = gestures[t], r = i.deps, o = i.name, s = e[GESTURE_KEY];
    if (s) for (let t, n, i = 0; i < r.length; i++) (n = s[t = r[i]]) && n[o] && (n[o] = (n[o] || 1) - 1, 
    n._count = (n._count || 1) - 1, 0 === n._count && e.removeEventListener(t, _handleNative, PASSIVE_TOUCH(t)));
    e.removeEventListener(t, n);
}

function register$1(e) {
    recognizers.push(e);
    for (let t = 0; t < e.emits.length; t++) gestures[e.emits[t]] = e;
}

function _findRecognizerByEvent(e) {
    for (let t, n = 0; n < recognizers.length; n++) {
        t = recognizers[n];
        for (let n, i = 0; i < t.emits.length; i++) if ((n = t.emits[i]) === e) return t;
    }
    return null;
}

function setTouchAction(e, t) {
    HAS_NATIVE_TA && e instanceof HTMLElement && microTask.run(() => {
        e.style.touchAction = t;
    }), e[TOUCH_ACTION] = t;
}

function _fire(e, t, n) {
    let i = new Event(t, {
        bubbles: !0,
        cancelable: !0,
        composed: !0
    });
    if (i.detail = n, wrap$1(e).dispatchEvent(i), i.defaultPrevented) {
        let e = n.preventer || n.sourceEvent;
        e && e.preventDefault && e.preventDefault();
    }
}

function prevent(e) {
    let t = _findRecognizerByEvent(e);
    t.info && (t.info.prevent = !0);
}

function resetMouseCanceller() {
    POINTERSTATE.mouse.mouseIgnoreJob && POINTERSTATE.mouse.mouseIgnoreJob.flush();
}

function downupFire(e, t, n, i) {
    t && _fire(t, e, {
        x: n.clientX,
        y: n.clientY,
        sourceEvent: n,
        preventer: i,
        prevent: function(e) {
            return prevent(e);
        }
    });
}

function trackHasMovedEnough(e, t, n) {
    if (e.prevent) return !1;
    if (e.started) return !0;
    let i = Math.abs(e.x - t), r = Math.abs(e.y - n);
    return i >= TRACK_DISTANCE || r >= TRACK_DISTANCE;
}

function trackFire(e, t, n) {
    if (!t) return;
    let i, r = e.moves[e.moves.length - 2], o = e.moves[e.moves.length - 1], s = o.x - e.x, a = o.y - e.y, l = 0;
    r && (i = o.x - r.x, l = o.y - r.y), _fire(t, "track", {
        state: e.state,
        x: n.clientX,
        y: n.clientY,
        dx: s,
        dy: a,
        ddx: i,
        ddy: l,
        sourceEvent: n,
        hover: function() {
            return deepTargetFind(n.clientX, n.clientY);
        }
    });
}

function trackForward(e, t, n) {
    let i = Math.abs(t.clientX - e.x), r = Math.abs(t.clientY - e.y), o = _findOriginalTarget(n || t);
    !o || canBeDisabled[o.localName] && o.hasAttribute("disabled") || (isNaN(i) || isNaN(r) || i <= TAP_DISTANCE && r <= TAP_DISTANCE || isSyntheticClick(t)) && (e.prevent || _fire(o, "tap", {
        x: t.clientX,
        y: t.clientY,
        sourceEvent: t,
        preventer: n
    }));
}

register$1({
    name: "downup",
    deps: [ "mousedown", "touchstart", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "mouseup", "touchend" ]
    },
    emits: [ "down", "up" ],
    info: {
        movefn: null,
        upfn: null
    },
    reset: function() {
        untrackDocument(this.info);
    },
    mousedown: function(e) {
        if (!hasLeftMouseButton(e)) return;
        let t = _findOriginalTarget(e), n = this;
        trackDocument(this.info, function(e) {
            hasLeftMouseButton(e) || (downupFire("up", t, e), untrackDocument(n.info));
        }, function(e) {
            hasLeftMouseButton(e) && downupFire("up", t, e), untrackDocument(n.info);
        }), downupFire("down", t, e);
    },
    touchstart: function(e) {
        downupFire("down", _findOriginalTarget(e), e.changedTouches[0], e);
    },
    touchend: function(e) {
        downupFire("up", _findOriginalTarget(e), e.changedTouches[0], e);
    }
}), register$1({
    name: "track",
    touchAction: "none",
    deps: [ "mousedown", "touchstart", "touchmove", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "mouseup", "touchend" ]
    },
    emits: [ "track" ],
    info: {
        x: 0,
        y: 0,
        state: "start",
        started: !1,
        moves: [],
        addMove: function(e) {
            this.moves.length > TRACK_LENGTH && this.moves.shift(), this.moves.push(e);
        },
        movefn: null,
        upfn: null,
        prevent: !1
    },
    reset: function() {
        this.info.state = "start", this.info.started = !1, this.info.moves = [], this.info.x = 0, 
        this.info.y = 0, this.info.prevent = !1, untrackDocument(this.info);
    },
    mousedown: function(e) {
        if (!hasLeftMouseButton(e)) return;
        let t = _findOriginalTarget(e), n = this, i = function(e) {
            let i = e.clientX, r = e.clientY;
            trackHasMovedEnough(n.info, i, r) && (n.info.state = n.info.started ? "mouseup" === e.type ? "end" : "track" : "start", 
            "start" === n.info.state && prevent("tap"), n.info.addMove({
                x: i,
                y: r
            }), hasLeftMouseButton(e) || (n.info.state = "end", untrackDocument(n.info)), t && trackFire(n.info, t, e), 
            n.info.started = !0);
        };
        trackDocument(this.info, i, function(e) {
            n.info.started && i(e), untrackDocument(n.info);
        }), this.info.x = e.clientX, this.info.y = e.clientY;
    },
    touchstart: function(e) {
        let t = e.changedTouches[0];
        this.info.x = t.clientX, this.info.y = t.clientY;
    },
    touchmove: function(e) {
        let t = _findOriginalTarget(e), n = e.changedTouches[0], i = n.clientX, r = n.clientY;
        trackHasMovedEnough(this.info, i, r) && ("start" === this.info.state && prevent("tap"), 
        this.info.addMove({
            x: i,
            y: r
        }), trackFire(this.info, t, n), this.info.state = "track", this.info.started = !0);
    },
    touchend: function(e) {
        let t = _findOriginalTarget(e), n = e.changedTouches[0];
        this.info.started && (this.info.state = "end", this.info.addMove({
            x: n.clientX,
            y: n.clientY
        }), trackFire(this.info, t, n));
    }
}), register$1({
    name: "tap",
    deps: [ "mousedown", "click", "touchstart", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "click", "touchend" ]
    },
    emits: [ "tap" ],
    info: {
        x: NaN,
        y: NaN,
        prevent: !1
    },
    reset: function() {
        this.info.x = NaN, this.info.y = NaN, this.info.prevent = !1;
    },
    mousedown: function(e) {
        hasLeftMouseButton(e) && (this.info.x = e.clientX, this.info.y = e.clientY);
    },
    click: function(e) {
        hasLeftMouseButton(e) && trackForward(this.info, e);
    },
    touchstart: function(e) {
        const t = e.changedTouches[0];
        this.info.x = t.clientX, this.info.y = t.clientY;
    },
    touchend: function(e) {
        trackForward(this.info, e.changedTouches[0], e);
    }
});

const findOriginalTarget = _findOriginalTarget, add = addListener, remove = removeListener;

var gestures$1 = {
    gestures: gestures,
    recognizers: recognizers,
    deepTargetFind: deepTargetFind,
    addListener: addListener,
    removeListener: removeListener,
    register: register$1,
    setTouchAction: setTouchAction,
    prevent: prevent,
    resetMouseCanceller: resetMouseCanceller,
    findOriginalTarget: findOriginalTarget,
    add: add,
    remove: remove
};

const GestureEventListeners = dedupingMixin(e => {
    return class extends e {
        _addEventListenerToNode(e, t, n) {
            addListener(e, t, n) || super._addEventListenerToNode(e, t, n);
        }
        _removeEventListenerFromNode(e, t, n) {
            removeListener(e, t, n) || super._removeEventListenerFromNode(e, t, n);
        }
    };
});

var gestureEventListeners = {
    GestureEventListeners: GestureEventListeners
};

const HOST_DIR = /:host\(:dir\((ltr|rtl)\)\)/g, HOST_DIR_REPLACMENT = ':host([dir="$1"])', EL_DIR = /([\s\w-#\.\[\]\*]*):dir\((ltr|rtl)\)/g, EL_DIR_REPLACMENT = ':host([dir="$2"]) $1', DIR_CHECK = /:dir\((?:ltr|rtl)\)/, SHIM_SHADOW = Boolean(window.ShadyDOM && window.ShadyDOM.inUse), DIR_INSTANCES = [];

let observer = null, DOCUMENT_DIR = "";

function getRTL() {
    DOCUMENT_DIR = document.documentElement.getAttribute("dir");
}

function setRTL(e) {
    if (!e.__autoDirOptOut) {
        e.setAttribute("dir", DOCUMENT_DIR);
    }
}

function updateDirection() {
    getRTL(), DOCUMENT_DIR = document.documentElement.getAttribute("dir");
    for (let e = 0; e < DIR_INSTANCES.length; e++) setRTL(DIR_INSTANCES[e]);
}

function takeRecords() {
    observer && observer.takeRecords().length && updateDirection();
}

const DirMixin = dedupingMixin(e => {
    SHIM_SHADOW || observer || (getRTL(), (observer = new MutationObserver(updateDirection)).observe(document.documentElement, {
        attributes: !0,
        attributeFilter: [ "dir" ]
    }));
    const t = PropertyAccessors(e);
    class n extends t {
        static _processStyleText(e, t) {
            return e = super._processStyleText(e, t), !SHIM_SHADOW && DIR_CHECK.test(e) && (e = this._replaceDirInCssText(e), 
            this.__activateDir = !0), e;
        }
        static _replaceDirInCssText(e) {
            let t = e;
            return t = (t = t.replace(HOST_DIR, HOST_DIR_REPLACMENT)).replace(EL_DIR, EL_DIR_REPLACMENT);
        }
        constructor() {
            super(), this.__autoDirOptOut = !1;
        }
        ready() {
            super.ready(), this.__autoDirOptOut = this.hasAttribute("dir");
        }
        connectedCallback() {
            t.prototype.connectedCallback && super.connectedCallback(), this.constructor.__activateDir && (takeRecords(), 
            DIR_INSTANCES.push(this), setRTL(this));
        }
        disconnectedCallback() {
            if (t.prototype.disconnectedCallback && super.disconnectedCallback(), this.constructor.__activateDir) {
                const e = DIR_INSTANCES.indexOf(this);
                e > -1 && DIR_INSTANCES.splice(e, 1);
            }
        }
    }
    return n.__activateDir = !1, n;
});

var dirMixin = {
    DirMixin: DirMixin
};

let scheduled = !1, beforeRenderQueue = [], afterRenderQueue = [];

function schedule() {
    scheduled = !0, requestAnimationFrame(function() {
        scheduled = !1, flushQueue(beforeRenderQueue), setTimeout(function() {
            runQueue(afterRenderQueue);
        });
    });
}

function flushQueue(e) {
    for (;e.length; ) callMethod(e.shift());
}

function runQueue(e) {
    for (let t = 0, n = e.length; t < n; t++) callMethod(e.shift());
}

function callMethod(e) {
    const t = e[0], n = e[1], i = e[2];
    try {
        n.apply(t, i);
    } catch (e) {
        setTimeout(() => {
            throw e;
        });
    }
}

function flush() {
    for (;beforeRenderQueue.length || afterRenderQueue.length; ) flushQueue(beforeRenderQueue), 
    flushQueue(afterRenderQueue);
    scheduled = !1;
}

function beforeNextRender(e, t, n) {
    scheduled || schedule(), beforeRenderQueue.push([ e, t, n ]);
}

function afterNextRender(e, t, n) {
    scheduled || schedule(), afterRenderQueue.push([ e, t, n ]);
}

var renderStatus = {
    flush: flush,
    beforeNextRender: beforeNextRender,
    afterNextRender: afterNextRender
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function resolve() {
    document.body.removeAttribute("unresolved");
}

function newSplice(e, t, n) {
    return {
        index: e,
        removed: t,
        addedCount: n
    };
}

"interactive" === document.readyState || "complete" === document.readyState ? resolve() : window.addEventListener("DOMContentLoaded", resolve);

const EDIT_LEAVE = 0, EDIT_UPDATE = 1, EDIT_ADD = 2, EDIT_DELETE = 3;

function calcEditDistances(e, t, n, i, r, o) {
    let s = o - r + 1, a = n - t + 1, l = new Array(s);
    for (let e = 0; e < s; e++) l[e] = new Array(a), l[e][0] = e;
    for (let e = 0; e < a; e++) l[0][e] = e;
    for (let n = 1; n < s; n++) for (let o = 1; o < a; o++) if (equals(e[t + o - 1], i[r + n - 1])) l[n][o] = l[n - 1][o - 1]; else {
        let e = l[n - 1][o] + 1, t = l[n][o - 1] + 1;
        l[n][o] = e < t ? e : t;
    }
    return l;
}

function spliceOperationsFromEditDistances(e) {
    let t = e.length - 1, n = e[0].length - 1, i = e[t][n], r = [];
    for (;t > 0 || n > 0; ) {
        if (0 == t) {
            r.push(EDIT_ADD), n--;
            continue;
        }
        if (0 == n) {
            r.push(EDIT_DELETE), t--;
            continue;
        }
        let o, s = e[t - 1][n - 1], a = e[t - 1][n], l = e[t][n - 1];
        (o = a < l ? a < s ? a : s : l < s ? l : s) == s ? (s == i ? r.push(EDIT_LEAVE) : (r.push(EDIT_UPDATE), 
        i = s), t--, n--) : o == a ? (r.push(EDIT_DELETE), t--, i = a) : (r.push(EDIT_ADD), 
        n--, i = l);
    }
    return r.reverse(), r;
}

function calcSplices(e, t, n, i, r, o) {
    let s, a = 0, l = 0, c = Math.min(n - t, o - r);
    if (0 == t && 0 == r && (a = sharedPrefix(e, i, c)), n == e.length && o == i.length && (l = sharedSuffix(e, i, c - a)), 
    r += a, o -= l, (n -= l) - (t += a) == 0 && o - r == 0) return [];
    if (t == n) {
        for (s = newSplice(t, [], 0); r < o; ) s.removed.push(i[r++]);
        return [ s ];
    }
    if (r == o) return [ newSplice(t, [], n - t) ];
    let d = spliceOperationsFromEditDistances(calcEditDistances(e, t, n, i, r, o));
    s = void 0;
    let p = [], u = t, h = r;
    for (let e = 0; e < d.length; e++) switch (d[e]) {
      case EDIT_LEAVE:
        s && (p.push(s), s = void 0), u++, h++;
        break;

      case EDIT_UPDATE:
        s || (s = newSplice(u, [], 0)), s.addedCount++, u++, s.removed.push(i[h]), h++;
        break;

      case EDIT_ADD:
        s || (s = newSplice(u, [], 0)), s.addedCount++, u++;
        break;

      case EDIT_DELETE:
        s || (s = newSplice(u, [], 0)), s.removed.push(i[h]), h++;
    }
    return s && p.push(s), p;
}

function sharedPrefix(e, t, n) {
    for (let i = 0; i < n; i++) if (!equals(e[i], t[i])) return i;
    return n;
}

function sharedSuffix(e, t, n) {
    let i = e.length, r = t.length, o = 0;
    for (;o < n && equals(e[--i], t[--r]); ) o++;
    return o;
}

function calculateSplices(e, t) {
    return calcSplices(e, 0, e.length, t, 0, t.length);
}

function equals(e, t) {
    return e === t;
}

var arraySplice = {
    calculateSplices: calculateSplices
};

function isSlot(e) {
    return "slot" === e.localName;
}

let FlattenedNodesObserver = class {
    static getFlattenedNodes(e) {
        const t = wrap$1(e);
        return isSlot(e) ? (e = e, t.assignedNodes({
            flatten: !0
        })) : Array.from(t.childNodes).map(e => isSlot(e) ? wrap$1(e = e).assignedNodes({
            flatten: !0
        }) : [ e ]).reduce((e, t) => e.concat(t), []);
    }
    constructor(e, t) {
        this._shadyChildrenObserver = null, this._nativeChildrenObserver = null, this._connected = !1, 
        this._target = e, this.callback = t, this._effectiveNodes = [], this._observer = null, 
        this._scheduled = !1, this._boundSchedule = (() => {
            this._schedule();
        }), this.connect(), this._schedule();
    }
    connect() {
        isSlot(this._target) ? this._listenSlots([ this._target ]) : wrap$1(this._target).children && (this._listenSlots(wrap$1(this._target).children), 
        window.ShadyDOM ? this._shadyChildrenObserver = ShadyDOM.observeChildren(this._target, e => {
            this._processMutations(e);
        }) : (this._nativeChildrenObserver = new MutationObserver(e => {
            this._processMutations(e);
        }), this._nativeChildrenObserver.observe(this._target, {
            childList: !0
        }))), this._connected = !0;
    }
    disconnect() {
        isSlot(this._target) ? this._unlistenSlots([ this._target ]) : wrap$1(this._target).children && (this._unlistenSlots(wrap$1(this._target).children), 
        window.ShadyDOM && this._shadyChildrenObserver ? (ShadyDOM.unobserveChildren(this._shadyChildrenObserver), 
        this._shadyChildrenObserver = null) : this._nativeChildrenObserver && (this._nativeChildrenObserver.disconnect(), 
        this._nativeChildrenObserver = null)), this._connected = !1;
    }
    _schedule() {
        this._scheduled || (this._scheduled = !0, microTask.run(() => this.flush()));
    }
    _processMutations(e) {
        this._processSlotMutations(e), this.flush();
    }
    _processSlotMutations(e) {
        if (e) for (let t = 0; t < e.length; t++) {
            let n = e[t];
            n.addedNodes && this._listenSlots(n.addedNodes), n.removedNodes && this._unlistenSlots(n.removedNodes);
        }
    }
    flush() {
        if (!this._connected) return !1;
        window.ShadyDOM && ShadyDOM.flush(), this._nativeChildrenObserver ? this._processSlotMutations(this._nativeChildrenObserver.takeRecords()) : this._shadyChildrenObserver && this._processSlotMutations(this._shadyChildrenObserver.takeRecords()), 
        this._scheduled = !1;
        let e = {
            target: this._target,
            addedNodes: [],
            removedNodes: []
        }, t = this.constructor.getFlattenedNodes(this._target), n = calculateSplices(t, this._effectiveNodes);
        for (let t, i = 0; i < n.length && (t = n[i]); i++) for (let n, i = 0; i < t.removed.length && (n = t.removed[i]); i++) e.removedNodes.push(n);
        for (let i, r = 0; r < n.length && (i = n[r]); r++) for (let n = i.index; n < i.index + i.addedCount; n++) e.addedNodes.push(t[n]);
        this._effectiveNodes = t;
        let i = !1;
        return (e.addedNodes.length || e.removedNodes.length) && (i = !0, this.callback.call(this._target, e)), 
        i;
    }
    _listenSlots(e) {
        for (let t = 0; t < e.length; t++) {
            let n = e[t];
            isSlot(n) && n.addEventListener("slotchange", this._boundSchedule);
        }
    }
    _unlistenSlots(e) {
        for (let t = 0; t < e.length; t++) {
            let n = e[t];
            isSlot(n) && n.removeEventListener("slotchange", this._boundSchedule);
        }
    }
};

var flattenedNodesObserver = {
    FlattenedNodesObserver: FlattenedNodesObserver
};

const flush$1 = function() {
    let e, t;
    do {
        e = window.ShadyDOM && ShadyDOM.flush(), window.ShadyCSS && window.ShadyCSS.ScopingShim && window.ShadyCSS.ScopingShim.flush(), 
        t = flushDebouncers();
    } while (e || t);
};

var flush$2 = {
    flush: flush$1,
    enqueueDebouncer: enqueueDebouncer
};

const p = Element.prototype, normalizedMatchesSelector = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector, matchesSelector = function(e, t) {
    return normalizedMatchesSelector.call(e, t);
};

class DomApiNative {
    constructor(e) {
        this.node = e;
    }
    observeNodes(e) {
        return new FlattenedNodesObserver(this.node, e);
    }
    unobserveNodes(e) {
        e.disconnect();
    }
    notifyObserver() {}
    deepContains(e) {
        if (wrap$1(this.node).contains(e)) return !0;
        let t = e, n = e.ownerDocument;
        for (;t && t !== n && t !== this.node; ) t = wrap$1(t).parentNode || wrap$1(t).host;
        return t === this.node;
    }
    getOwnerRoot() {
        return wrap$1(this.node).getRootNode();
    }
    getDistributedNodes() {
        return "slot" === this.node.localName ? wrap$1(this.node).assignedNodes({
            flatten: !0
        }) : [];
    }
    getDestinationInsertionPoints() {
        let e = [], t = wrap$1(this.node).assignedSlot;
        for (;t; ) e.push(t), t = wrap$1(t).assignedSlot;
        return e;
    }
    importNode(e, t) {
        let n = this.node instanceof Document ? this.node : this.node.ownerDocument;
        return wrap$1(n).importNode(e, t);
    }
    getEffectiveChildNodes() {
        return FlattenedNodesObserver.getFlattenedNodes(this.node);
    }
    queryDistributedElements(e) {
        let t = this.getEffectiveChildNodes(), n = [];
        for (let i, r = 0, o = t.length; r < o && (i = t[r]); r++) i.nodeType === Node.ELEMENT_NODE && matchesSelector(i, e) && n.push(i);
        return n;
    }
    get activeElement() {
        let e = this.node;
        return void 0 !== e._activeElement ? e._activeElement : e.activeElement;
    }
}

function forwardMethods(e, t) {
    for (let n = 0; n < t.length; n++) {
        let i = t[n];
        e[i] = function() {
            return this.node[i].apply(this.node, arguments);
        };
    }
}

function forwardReadOnlyProperties(e, t) {
    for (let n = 0; n < t.length; n++) {
        let i = t[n];
        Object.defineProperty(e, i, {
            get: function() {
                return this.node[i];
            },
            configurable: !0
        });
    }
}

function forwardProperties(e, t) {
    for (let n = 0; n < t.length; n++) {
        let i = t[n];
        Object.defineProperty(e, i, {
            get: function() {
                return this.node[i];
            },
            set: function(e) {
                this.node[i] = e;
            },
            configurable: !0
        });
    }
}

class EventApi {
    constructor(e) {
        this.event = e;
    }
    get rootTarget() {
        return this.path[0];
    }
    get localTarget() {
        return this.event.target;
    }
    get path() {
        return this.event.composedPath();
    }
}

DomApiNative.prototype.cloneNode, DomApiNative.prototype.appendChild, DomApiNative.prototype.insertBefore, 
DomApiNative.prototype.removeChild, DomApiNative.prototype.replaceChild, DomApiNative.prototype.setAttribute, 
DomApiNative.prototype.removeAttribute, DomApiNative.prototype.querySelector, DomApiNative.prototype.querySelectorAll, 
DomApiNative.prototype.parentNode, DomApiNative.prototype.firstChild, DomApiNative.prototype.lastChild, 
DomApiNative.prototype.nextSibling, DomApiNative.prototype.previousSibling, DomApiNative.prototype.firstElementChild, 
DomApiNative.prototype.lastElementChild, DomApiNative.prototype.nextElementSibling, 
DomApiNative.prototype.previousElementSibling, DomApiNative.prototype.childNodes, 
DomApiNative.prototype.children, DomApiNative.prototype.classList, DomApiNative.prototype.textContent, 
DomApiNative.prototype.innerHTML;

let DomApiImpl = DomApiNative;

if (window.ShadyDOM && window.ShadyDOM.inUse && window.ShadyDOM.noPatch && window.ShadyDOM.Wrapper) {
    class e extends window.ShadyDOM.Wrapper {}
    Object.getOwnPropertyNames(DomApiNative.prototype).forEach(t => {
        "activeElement" != t && (e.prototype[t] = DomApiNative.prototype[t]);
    }), forwardReadOnlyProperties(e.prototype, [ "classList" ]), DomApiImpl = e, Object.defineProperties(EventApi.prototype, {
        localTarget: {
            get() {
                return this.event.currentTarget;
            },
            configurable: !0
        },
        path: {
            get() {
                return window.ShadyDOM.composedPath(this.event);
            },
            configurable: !0
        }
    });
} else forwardMethods(DomApiNative.prototype, [ "cloneNode", "appendChild", "insertBefore", "removeChild", "replaceChild", "setAttribute", "removeAttribute", "querySelector", "querySelectorAll" ]), 
forwardReadOnlyProperties(DomApiNative.prototype, [ "parentNode", "firstChild", "lastChild", "nextSibling", "previousSibling", "firstElementChild", "lastElementChild", "nextElementSibling", "previousElementSibling", "childNodes", "children", "classList" ]), 
forwardProperties(DomApiNative.prototype, [ "textContent", "innerHTML" ]);

const DomApi = DomApiImpl, dom = function(e) {
    if ((e = e || document) instanceof DomApiImpl) return e;
    if (e instanceof EventApi) return e;
    let t = e.__domApi;
    return t || (t = e instanceof Event ? new EventApi(e) : new DomApiImpl(e), e.__domApi = t), 
    t;
};

var polymer_dom = {
    matchesSelector: matchesSelector,
    EventApi: EventApi,
    DomApi: DomApi,
    dom: dom,
    flush: flush$1,
    addDebouncer: enqueueDebouncer
};

const bundledImportMeta$1 = {
    ...import.meta,
    url: new URL("./node_modules/%40polymer/polymer/lib/legacy/legacy-element-mixin.js", import.meta.url).href
};

let styleInterface = window.ShadyCSS;

const LegacyElementMixin = dedupingMixin(e => {
    const t = DirMixin(GestureEventListeners(ElementMixin(e))), n = {
        x: "pan-x",
        y: "pan-y",
        none: "none",
        all: "auto"
    };
    class i extends t {
        constructor() {
            super(), this.isAttached, this.__boundListeners, this._debouncers;
        }
        static get importMeta() {
            return this.prototype.importMeta;
        }
        created() {}
        connectedCallback() {
            super.connectedCallback(), this.isAttached = !0, this.attached();
        }
        attached() {}
        disconnectedCallback() {
            super.disconnectedCallback(), this.isAttached = !1, this.detached();
        }
        detached() {}
        attributeChangedCallback(e, t, n, i) {
            t !== n && (super.attributeChangedCallback(e, t, n, i), this.attributeChanged(e, t, n));
        }
        attributeChanged(e, t, n) {}
        _initializeProperties() {
            let e = Object.getPrototypeOf(this);
            e.hasOwnProperty("__hasRegisterFinished") || (this._registered(), e.__hasRegisterFinished = !0), 
            super._initializeProperties(), this.root = this, this.created(), this._applyListeners();
        }
        _registered() {}
        ready() {
            this._ensureAttributes(), super.ready();
        }
        _ensureAttributes() {}
        _applyListeners() {}
        serialize(e) {
            return this._serializeValue(e);
        }
        deserialize(e, t) {
            return this._deserializeValue(e, t);
        }
        reflectPropertyToAttribute(e, t, n) {
            this._propertyToAttribute(e, t, n);
        }
        serializeValueToAttribute(e, t, n) {
            this._valueToNodeAttribute(n || this, e, t);
        }
        extend(e, t) {
            if (!e || !t) return e || t;
            let n = Object.getOwnPropertyNames(t);
            for (let i, r = 0; r < n.length && (i = n[r]); r++) {
                let n = Object.getOwnPropertyDescriptor(t, i);
                n && Object.defineProperty(e, i, n);
            }
            return e;
        }
        mixin(e, t) {
            for (let n in t) e[n] = t[n];
            return e;
        }
        chainObject(e, t) {
            return e && t && e !== t && (e.__proto__ = t), e;
        }
        instanceTemplate(e) {
            let t = this.constructor._contentForTemplate(e);
            return document.importNode(t, !0);
        }
        fire(e, t, n) {
            n = n || {}, t = null == t ? {} : t;
            let i = new Event(e, {
                bubbles: void 0 === n.bubbles || n.bubbles,
                cancelable: Boolean(n.cancelable),
                composed: void 0 === n.composed || n.composed
            });
            i.detail = t;
            let r = n.node || this;
            return wrap$1(r).dispatchEvent(i), i;
        }
        listen(e, t, n) {
            e = e || this;
            let i = this.__boundListeners || (this.__boundListeners = new WeakMap()), r = i.get(e);
            r || (r = {}, i.set(e, r));
            let o = t + n;
            r[o] || (r[o] = this._addMethodEventListenerToNode(e, t, n, this));
        }
        unlisten(e, t, n) {
            e = e || this;
            let i = this.__boundListeners && this.__boundListeners.get(e), r = t + n, o = i && i[r];
            o && (this._removeEventListenerFromNode(e, t, o), i[r] = null);
        }
        setScrollDirection(e, t) {
            setTouchAction(t || this, n[e] || "auto");
        }
        $$(e) {
            return this.root.querySelector(e);
        }
        get domHost() {
            let e = wrap$1(this).getRootNode();
            return e instanceof DocumentFragment ? e.host : e;
        }
        distributeContent() {
            const e = dom(this);
            window.ShadyDOM && e.shadowRoot && ShadyDOM.flush();
        }
        getEffectiveChildNodes() {
            return dom(this).getEffectiveChildNodes();
        }
        queryDistributedElements(e) {
            return dom(this).queryDistributedElements(e);
        }
        getEffectiveChildren() {
            return this.getEffectiveChildNodes().filter(function(e) {
                return e.nodeType === Node.ELEMENT_NODE;
            });
        }
        getEffectiveTextContent() {
            let e = this.getEffectiveChildNodes(), t = [];
            for (let n, i = 0; n = e[i]; i++) n.nodeType !== Node.COMMENT_NODE && t.push(n.textContent);
            return t.join("");
        }
        queryEffectiveChildren(e) {
            let t = this.queryDistributedElements(e);
            return t && t[0];
        }
        queryAllEffectiveChildren(e) {
            return this.queryDistributedElements(e);
        }
        getContentChildNodes(e) {
            let t = this.root.querySelector(e || "slot");
            return t ? dom(t).getDistributedNodes() : [];
        }
        getContentChildren(e) {
            return this.getContentChildNodes(e).filter(function(e) {
                return e.nodeType === Node.ELEMENT_NODE;
            });
        }
        isLightDescendant(e) {
            return this !== e && wrap$1(this).contains(e) && wrap$1(this).getRootNode() === wrap$1(e).getRootNode();
        }
        isLocalDescendant(e) {
            return this.root === wrap$1(e).getRootNode();
        }
        scopeSubtree(e, t) {}
        getComputedStyleValue(e) {
            return styleInterface.getComputedStyleValue(this, e);
        }
        debounce(e, t, n) {
            return this._debouncers = this._debouncers || {}, this._debouncers[e] = Debouncer.debounce(this._debouncers[e], n > 0 ? timeOut.after(n) : microTask, t.bind(this));
        }
        isDebouncerActive(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            return !(!t || !t.isActive());
        }
        flushDebouncer(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            t && t.flush();
        }
        cancelDebouncer(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            t && t.cancel();
        }
        async(e, t) {
            return t > 0 ? timeOut.run(e.bind(this), t) : ~microTask.run(e.bind(this));
        }
        cancelAsync(e) {
            e < 0 ? microTask.cancel(~e) : timeOut.cancel(e);
        }
        create(e, t) {
            let n = document.createElement(e);
            if (t) if (n.setProperties) n.setProperties(t); else for (let e in t) n[e] = t[e];
            return n;
        }
        elementMatches(e, t) {
            return matchesSelector(t || this, e);
        }
        toggleAttribute(e, t) {
            let n = this;
            return 3 === arguments.length && (n = arguments[2]), 1 == arguments.length && (t = !n.hasAttribute(e)), 
            t ? (wrap$1(n).setAttribute(e, ""), !0) : (wrap$1(n).removeAttribute(e), !1);
        }
        toggleClass(e, t, n) {
            n = n || this, 1 == arguments.length && (t = !n.classList.contains(e)), t ? n.classList.add(e) : n.classList.remove(e);
        }
        transform(e, t) {
            (t = t || this).style.webkitTransform = e, t.style.transform = e;
        }
        translate3d(e, t, n, i) {
            i = i || this, this.transform("translate3d(" + e + "," + t + "," + n + ")", i);
        }
        arrayDelete(e, t) {
            let n;
            if (Array.isArray(e)) {
                if ((n = e.indexOf(t)) >= 0) return e.splice(n, 1);
            } else {
                if ((n = get(this, e).indexOf(t)) >= 0) return this.splice(e, n, 1);
            }
            return null;
        }
        _logger(e, t) {
            switch (Array.isArray(t) && 1 === t.length && Array.isArray(t[0]) && (t = t[0]), 
            e) {
              case "log":
              case "warn":
              case "error":
                console[e](...t);
            }
        }
        _log(...e) {
            this._logger("log", e);
        }
        _warn(...e) {
            this._logger("warn", e);
        }
        _error(...e) {
            this._logger("error", e);
        }
        _logf(e, ...t) {
            return [ "[%s::%s]", this.is, e, ...t ];
        }
    }
    return i.prototype.is = "", i;
});

var legacyElementMixin = {
    LegacyElementMixin: LegacyElementMixin
};

const lifecycleProps = {
    attached: !0,
    detached: !0,
    ready: !0,
    created: !0,
    beforeRegister: !0,
    registered: !0,
    attributeChanged: !0,
    listeners: !0,
    hostAttributes: !0
}, excludeOnInfo = {
    attached: !0,
    detached: !0,
    ready: !0,
    created: !0,
    beforeRegister: !0,
    registered: !0,
    attributeChanged: !0,
    behaviors: !0,
    _noAccessors: !0
}, excludeOnBehaviors = Object.assign({
    listeners: !0,
    hostAttributes: !0,
    properties: !0,
    observers: !0
}, excludeOnInfo);

function copyProperties(e, t, n) {
    const i = e._noAccessors, r = Object.getOwnPropertyNames(e);
    for (let o = 0; o < r.length; o++) {
        let s = r[o];
        if (!(s in n)) if (i) t[s] = e[s]; else {
            let n = Object.getOwnPropertyDescriptor(e, s);
            n && (n.configurable = !0, Object.defineProperty(t, s, n));
        }
    }
}

function mixinBehaviors(e, t) {
    return GenerateClassFromInfo({}, LegacyElementMixin(t), e);
}

function applyBehaviors(e, t, n) {
    for (let i = 0; i < t.length; i++) applyInfo(e, t[i], n, excludeOnBehaviors);
}

function applyInfo(e, t, n, i) {
    copyProperties(t, e, i);
    for (let e in lifecycleProps) t[e] && (n[e] = n[e] || [], n[e].push(t[e]));
}

function flattenBehaviors(e, t, n) {
    t = t || [];
    for (let i = e.length - 1; i >= 0; i--) {
        let r = e[i];
        r ? Array.isArray(r) ? flattenBehaviors(r, t) : t.indexOf(r) < 0 && (!n || n.indexOf(r) < 0) && t.unshift(r) : console.warn("behavior is null, check for missing or 404 import");
    }
    return t;
}

function mergeProperties(e, t) {
    for (const n in t) {
        const i = e[n], r = t[n];
        e[n] = !("value" in r) && i && "value" in i ? Object.assign({
            value: i.value
        }, r) : r;
    }
}

function GenerateClassFromInfo(e, t, n) {
    let i;
    const r = {};
    class o extends t {
        static _finalizeClass() {
            if (this.hasOwnProperty(JSCompiler_renameProperty("generatedFrom", this))) {
                if (i) for (let e, t = 0; t < i.length; t++) (e = i[t]).properties && this.createProperties(e.properties), 
                e.observers && this.createObservers(e.observers, e.properties);
                e.properties && this.createProperties(e.properties), e.observers && this.createObservers(e.observers, e.properties), 
                this._prepareTemplate();
            } else super._finalizeClass();
        }
        static get properties() {
            const t = {};
            if (i) for (let e = 0; e < i.length; e++) mergeProperties(t, i[e].properties);
            return mergeProperties(t, e.properties), t;
        }
        static get observers() {
            let t = [];
            if (i) for (let e, n = 0; n < i.length; n++) (e = i[n]).observers && (t = t.concat(e.observers));
            return e.observers && (t = t.concat(e.observers)), t;
        }
        created() {
            super.created();
            const e = r.created;
            if (e) for (let t = 0; t < e.length; t++) e[t].call(this);
        }
        _registered() {
            const e = o.prototype;
            if (!e.hasOwnProperty("__hasRegisterFinished")) {
                e.__hasRegisterFinished = !0, super._registered(), legacyOptimizations && s(e);
                const t = Object.getPrototypeOf(this);
                let n = r.beforeRegister;
                if (n) for (let e = 0; e < n.length; e++) n[e].call(t);
                if (n = r.registered) for (let e = 0; e < n.length; e++) n[e].call(t);
            }
        }
        _applyListeners() {
            super._applyListeners();
            const e = r.listeners;
            if (e) for (let t = 0; t < e.length; t++) {
                const n = e[t];
                if (n) for (let e in n) this._addMethodEventListenerToNode(this, e, n[e]);
            }
        }
        _ensureAttributes() {
            const e = r.hostAttributes;
            if (e) for (let t = e.length - 1; t >= 0; t--) {
                const n = e[t];
                for (let e in n) this._ensureAttribute(e, n[e]);
            }
            super._ensureAttributes();
        }
        ready() {
            super.ready();
            let e = r.ready;
            if (e) for (let t = 0; t < e.length; t++) e[t].call(this);
        }
        attached() {
            super.attached();
            let e = r.attached;
            if (e) for (let t = 0; t < e.length; t++) e[t].call(this);
        }
        detached() {
            super.detached();
            let e = r.detached;
            if (e) for (let t = 0; t < e.length; t++) e[t].call(this);
        }
        attributeChanged(e, t, n) {
            super.attributeChanged();
            let i = r.attributeChanged;
            if (i) for (let r = 0; r < i.length; r++) i[r].call(this, e, t, n);
        }
    }
    if (n) {
        Array.isArray(n) || (n = [ n ]);
        let e = t.prototype.behaviors;
        i = flattenBehaviors(n, null, e), o.prototype.behaviors = e ? e.concat(n) : i;
    }
    const s = t => {
        i && applyBehaviors(t, i, r), applyInfo(t, e, r, excludeOnInfo);
    };
    return legacyOptimizations || s(o.prototype), o.generatedFrom = e, o;
}

const Class = function(e, t) {
    e || console.warn("Polymer.Class requires `info` argument");
    let n = t ? t(LegacyElementMixin(HTMLElement)) : LegacyElementMixin(HTMLElement);
    return (n = GenerateClassFromInfo(e, n, e.behaviors)).is = n.prototype.is = e.is, 
    n;
};

var _class = {
    mixinBehaviors: mixinBehaviors,
    Class: Class
};

const Polymer = function(e) {
    let t;
    return t = "function" == typeof e ? e : Polymer.Class(e), customElements.define(t.is, t), 
    t;
};

Polymer.Class = Class;

var polymerFn = {
    Polymer: Polymer
};

function mutablePropertyChange(e, t, n, i, r) {
    let o;
    r && (o = "object" == typeof n && null !== n) && (i = e.__dataTemp[t]);
    let s = i !== n && (i == i || n == n);
    return o && s && (e.__dataTemp[t] = n), s;
}

const MutableData = dedupingMixin(e => {
    return class extends e {
        _shouldPropertyChange(e, t, n) {
            return mutablePropertyChange(this, e, t, n, !0);
        }
    };
}), OptionalMutableData = dedupingMixin(e => {
    return class extends e {
        static get properties() {
            return {
                mutableData: Boolean
            };
        }
        _shouldPropertyChange(e, t, n) {
            return mutablePropertyChange(this, e, t, n, this.mutableData);
        }
    };
});

MutableData._mutablePropertyChange = mutablePropertyChange;

var mutableData = {
    MutableData: MutableData,
    OptionalMutableData: OptionalMutableData
};

let newInstance = null;

function HTMLTemplateElementExtension() {
    return newInstance;
}

HTMLTemplateElementExtension.prototype = Object.create(HTMLTemplateElement.prototype, {
    constructor: {
        value: HTMLTemplateElementExtension,
        writable: !0
    }
});

const DataTemplate = PropertyEffects(HTMLTemplateElementExtension), MutableDataTemplate = MutableData(DataTemplate);

function upgradeTemplate(e, t) {
    newInstance = e, Object.setPrototypeOf(e, t.prototype), new t(), newInstance = null;
}

const templateInstanceBase = PropertyEffects(class {});

class TemplateInstanceBase extends templateInstanceBase {
    constructor(e) {
        super(), this._configureProperties(e), this.root = this._stampTemplate(this.__dataHost);
        let t = this.children = [];
        for (let e = this.root.firstChild; e; e = e.nextSibling) t.push(e), e.__templatizeInstance = this;
        this.__templatizeOwner && this.__templatizeOwner.__hideTemplateChildren__ && this._showHideChildren(!0);
        let n = this.__templatizeOptions;
        (e && n.instanceProps || !n.instanceProps) && this._enableProperties();
    }
    _configureProperties(e) {
        if (this.__templatizeOptions.forwardHostProp) for (let e in this.__hostProps) this._setPendingProperty(e, this.__dataHost["_host_" + e]);
        for (let t in e) this._setPendingProperty(t, e[t]);
    }
    forwardHostProp(e, t) {
        this._setPendingPropertyOrPath(e, t, !1, !0) && this.__dataHost._enqueueClient(this);
    }
    _addEventListenerToNode(e, t, n) {
        if (this._methodHost && this.__templatizeOptions.parentModel) this._methodHost._addEventListenerToNode(e, t, e => {
            e.model = this, n(e);
        }); else {
            let i = this.__dataHost.__dataHost;
            i && i._addEventListenerToNode(e, t, n);
        }
    }
    _showHideChildren(e) {
        let t = this.children;
        for (let n = 0; n < t.length; n++) {
            let i = t[n];
            if (Boolean(e) != Boolean(i.__hideTemplateChildren__)) if (i.nodeType === Node.TEXT_NODE) e ? (i.__polymerTextContent__ = i.textContent, 
            i.textContent = "") : i.textContent = i.__polymerTextContent__; else if ("slot" === i.localName) if (e) i.__polymerReplaced__ = document.createComment("hidden-slot"), 
            wrap$1(wrap$1(i).parentNode).replaceChild(i.__polymerReplaced__, i); else {
                const e = i.__polymerReplaced__;
                e && wrap$1(wrap$1(e).parentNode).replaceChild(i, e);
            } else i.style && (e ? (i.__polymerDisplay__ = i.style.display, i.style.display = "none") : i.style.display = i.__polymerDisplay__);
            i.__hideTemplateChildren__ = e, i._showHideChildren && i._showHideChildren(e);
        }
    }
    _setUnmanagedPropertyToNode(e, t, n) {
        e.__hideTemplateChildren__ && e.nodeType == Node.TEXT_NODE && "textContent" == t ? e.__polymerTextContent__ = n : super._setUnmanagedPropertyToNode(e, t, n);
    }
    get parentModel() {
        let e = this.__parentModel;
        if (!e) {
            let t;
            e = this;
            do {
                e = e.__dataHost.__dataHost;
            } while ((t = e.__templatizeOptions) && !t.parentModel);
            this.__parentModel = e;
        }
        return e;
    }
    dispatchEvent(e) {
        return !0;
    }
}

TemplateInstanceBase.prototype.__dataHost, TemplateInstanceBase.prototype.__templatizeOptions, 
TemplateInstanceBase.prototype._methodHost, TemplateInstanceBase.prototype.__templatizeOwner, 
TemplateInstanceBase.prototype.__hostProps;

const MutableTemplateInstanceBase = MutableData(TemplateInstanceBase);

function findMethodHost(e) {
    let t = e.__dataHost;
    return t && t._methodHost || t;
}

function createTemplatizerClass(e, t, n) {
    let i = n.mutableData ? MutableTemplateInstanceBase : TemplateInstanceBase;
    templatize.mixin && (i = templatize.mixin(i));
    let r = class extends i {};
    return r.prototype.__templatizeOptions = n, r.prototype._bindTemplate(e), addNotifyEffects(r, e, t, n), 
    r;
}

function addPropagateEffects(e, t, n) {
    let i = n.forwardHostProp;
    if (i) {
        let r = t.templatizeTemplateClass;
        if (!r) {
            let e = n.mutableData ? MutableDataTemplate : DataTemplate;
            r = t.templatizeTemplateClass = class extends e {};
            let o = t.hostProps;
            for (let e in o) r.prototype._addPropertyEffect("_host_" + e, r.prototype.PROPERTY_EFFECT_TYPES.PROPAGATE, {
                fn: createForwardHostPropEffect(e, i)
            }), r.prototype._createNotifyingProperty("_host_" + e);
        }
        upgradeTemplate(e, r), e.__dataProto && Object.assign(e.__data, e.__dataProto), 
        e.__dataTemp = {}, e.__dataPending = null, e.__dataOld = null, e._enableProperties();
    }
}

function createForwardHostPropEffect(e, t) {
    return function(e, n, i) {
        t.call(e.__templatizeOwner, n.substring("_host_".length), i[n]);
    };
}

function addNotifyEffects(e, t, n, i) {
    let r = n.hostProps || {};
    for (let t in i.instanceProps) {
        delete r[t];
        let n = i.notifyInstanceProp;
        n && e.prototype._addPropertyEffect(t, e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY, {
            fn: createNotifyInstancePropEffect(t, n)
        });
    }
    if (i.forwardHostProp && t.__dataHost) for (let t in r) e.prototype._addPropertyEffect(t, e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY, {
        fn: createNotifyHostPropEffect()
    });
}

function createNotifyInstancePropEffect(e, t) {
    return function(e, n, i) {
        t.call(e.__templatizeOwner, e, n, i[n]);
    };
}

function createNotifyHostPropEffect() {
    return function(e, t, n) {
        e.__dataHost._setPendingPropertyOrPath("_host_" + t, n[t], !0, !0);
    };
}

function templatize(e, t, n) {
    if (strictTemplatePolicy && !findMethodHost(e)) throw new Error("strictTemplatePolicy: template owner not trusted");
    if (n = n || {}, e.__templatizeOwner) throw new Error("A <template> can only be templatized once");
    e.__templatizeOwner = t;
    let i = (t ? t.constructor : TemplateInstanceBase)._parseTemplate(e), r = i.templatizeInstanceClass;
    r || (r = createTemplatizerClass(e, i, n), i.templatizeInstanceClass = r), addPropagateEffects(e, i, n);
    let o = class extends r {};
    return o.prototype._methodHost = findMethodHost(e), o.prototype.__dataHost = e, 
    o.prototype.__templatizeOwner = t, o.prototype.__hostProps = i.hostProps, o = o;
}

function modelForElement(e, t) {
    let n;
    for (;t; ) if (n = t.__templatizeInstance) {
        if (n.__dataHost == e) return n;
        t = n.__dataHost;
    } else t = wrap$1(t).parentNode;
    return null;
}

var templatize$1 = {
    templatize: templatize,
    modelForElement: modelForElement,
    TemplateInstanceBase: TemplateInstanceBase
};

let TemplatizerUser;

const Templatizer = {
    templatize(e, t) {
        this._templatizerTemplate = e, this.ctor = templatize(e, this, {
            mutableData: Boolean(t),
            parentModel: this._parentModel,
            instanceProps: this._instanceProps,
            forwardHostProp: this._forwardHostPropV2,
            notifyInstanceProp: this._notifyInstancePropV2
        });
    },
    stamp(e) {
        return new this.ctor(e);
    },
    modelForElement(e) {
        return modelForElement(this._templatizerTemplate, e);
    }
};

var templatizerBehavior = {
    Templatizer: Templatizer
};

const domBindBase = GestureEventListeners(OptionalMutableData(PropertyEffects(HTMLElement)));

class DomBind extends domBindBase {
    static get observedAttributes() {
        return [ "mutable-data" ];
    }
    constructor() {
        if (super(), strictTemplatePolicy) throw new Error("strictTemplatePolicy: dom-bind not allowed");
        this.root = null, this.$ = null, this.__children = null;
    }
    attributeChangedCallback() {
        this.mutableData = !0;
    }
    connectedCallback() {
        this.style.display = "none", this.render();
    }
    disconnectedCallback() {
        this.__removeChildren();
    }
    __insertChildren() {
        wrap$1(wrap$1(this).parentNode).insertBefore(this.root, this);
    }
    __removeChildren() {
        if (this.__children) for (let e = 0; e < this.__children.length; e++) this.root.appendChild(this.__children[e]);
    }
    render() {
        let e;
        if (!this.__children) {
            if (!(e = e || this.querySelector("template"))) {
                let t = new MutationObserver(() => {
                    if (!(e = this.querySelector("template"))) throw new Error("dom-bind requires a <template> child");
                    t.disconnect(), this.render();
                });
                return void t.observe(this, {
                    childList: !0
                });
            }
            this.root = this._stampTemplate(e), this.$ = this.root.$, this.__children = [];
            for (let e = this.root.firstChild; e; e = e.nextSibling) this.__children[this.__children.length] = e;
            this._enableProperties();
        }
        this.__insertChildren(), this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        }));
    }
}

customElements.define("dom-bind", DomBind);

var domBind = {
    DomBind: DomBind
};

class LiteralString {
    constructor(e) {
        this.value = e.toString();
    }
    toString() {
        return this.value;
    }
}

function literalValue(e) {
    if (e instanceof LiteralString) return e.value;
    throw new Error(`non-literal value passed to Polymer's htmlLiteral function: ${e}`);
}

function htmlValue(e) {
    if (e instanceof HTMLTemplateElement) return e.innerHTML;
    if (e instanceof LiteralString) return literalValue(e);
    throw new Error(`non-template value passed to Polymer's html function: ${e}`);
}

const html = function(e, ...t) {
    const n = document.createElement("template");
    return n.innerHTML = t.reduce((t, n, i) => t + htmlValue(n) + e[i + 1], e[0]), n;
}, htmlLiteral = function(e, ...t) {
    return new LiteralString(t.reduce((t, n, i) => t + literalValue(n) + e[i + 1], e[0]));
};

var htmlTag = {
    html: html,
    htmlLiteral: htmlLiteral
};

const PolymerElement = ElementMixin(HTMLElement);

var polymerElement = {
    version: version,
    PolymerElement: PolymerElement,
    html: html
};

const domRepeatBase = OptionalMutableData(PolymerElement);

class DomRepeat extends domRepeatBase {
    static get is() {
        return "dom-repeat";
    }
    static get template() {
        return null;
    }
    static get properties() {
        return {
            items: {
                type: Array
            },
            as: {
                type: String,
                value: "item"
            },
            indexAs: {
                type: String,
                value: "index"
            },
            itemsIndexAs: {
                type: String,
                value: "itemsIndex"
            },
            sort: {
                type: Function,
                observer: "__sortChanged"
            },
            filter: {
                type: Function,
                observer: "__filterChanged"
            },
            observe: {
                type: String,
                observer: "__observeChanged"
            },
            delay: Number,
            renderedItemCount: {
                type: Number,
                notify: !0,
                readOnly: !0
            },
            initialCount: {
                type: Number,
                observer: "__initializeChunking"
            },
            targetFramerate: {
                type: Number,
                value: 20
            },
            _targetFrameTime: {
                type: Number,
                computed: "__computeFrameTime(targetFramerate)"
            }
        };
    }
    static get observers() {
        return [ "__itemsChanged(items.*)" ];
    }
    constructor() {
        super(), this.__instances = [], this.__limit = 1 / 0, this.__pool = [], this.__renderDebouncer = null, 
        this.__itemsIdxToInstIdx = {}, this.__chunkCount = null, this.__lastChunkTime = null, 
        this.__sortFn = null, this.__filterFn = null, this.__observePaths = null, this.__ctor = null, 
        this.__isDetached = !0, this.template = null;
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this.__isDetached = !0;
        for (let e = 0; e < this.__instances.length; e++) this.__detachInstance(e);
    }
    connectedCallback() {
        if (super.connectedCallback(), this.style.display = "none", this.__isDetached) {
            this.__isDetached = !1;
            let e = wrap$1(wrap$1(this).parentNode);
            for (let t = 0; t < this.__instances.length; t++) this.__attachInstance(t, e);
        }
    }
    __ensureTemplatized() {
        if (!this.__ctor) {
            let e = this.template = this.querySelector("template");
            if (!e) {
                let e = new MutationObserver(() => {
                    if (!this.querySelector("template")) throw new Error("dom-repeat requires a <template> child");
                    e.disconnect(), this.__render();
                });
                return e.observe(this, {
                    childList: !0
                }), !1;
            }
            let t = {};
            t[this.as] = !0, t[this.indexAs] = !0, t[this.itemsIndexAs] = !0, this.__ctor = templatize(e, this, {
                mutableData: this.mutableData,
                parentModel: !0,
                instanceProps: t,
                forwardHostProp: function(e, t) {
                    let n = this.__instances;
                    for (let i, r = 0; r < n.length && (i = n[r]); r++) i.forwardHostProp(e, t);
                },
                notifyInstanceProp: function(e, t, n) {
                    if (matches(this.as, t)) {
                        let i = e[this.itemsIndexAs];
                        t == this.as && (this.items[i] = n);
                        let r = translate(this.as, `${JSCompiler_renameProperty("items", this)}.${i}`, t);
                        this.notifyPath(r, n);
                    }
                }
            });
        }
        return !0;
    }
    __getMethodHost() {
        return this.__dataHost._methodHost || this.__dataHost;
    }
    __functionFromPropertyValue(e) {
        if ("string" == typeof e) {
            let t = e, n = this.__getMethodHost();
            return function() {
                return n[t].apply(n, arguments);
            };
        }
        return e;
    }
    __sortChanged(e) {
        this.__sortFn = this.__functionFromPropertyValue(e), this.items && this.__debounceRender(this.__render);
    }
    __filterChanged(e) {
        this.__filterFn = this.__functionFromPropertyValue(e), this.items && this.__debounceRender(this.__render);
    }
    __computeFrameTime(e) {
        return Math.ceil(1e3 / e);
    }
    __initializeChunking() {
        this.initialCount && (this.__limit = this.initialCount, this.__chunkCount = this.initialCount, 
        this.__lastChunkTime = performance.now());
    }
    __tryRenderChunk() {
        this.items && this.__limit < this.items.length && this.__debounceRender(this.__requestRenderChunk);
    }
    __requestRenderChunk() {
        requestAnimationFrame(() => this.__renderChunk());
    }
    __renderChunk() {
        let e = performance.now(), t = this._targetFrameTime / (e - this.__lastChunkTime);
        this.__chunkCount = Math.round(this.__chunkCount * t) || 1, this.__limit += this.__chunkCount, 
        this.__lastChunkTime = e, this.__debounceRender(this.__render);
    }
    __observeChanged() {
        this.__observePaths = this.observe && this.observe.replace(".*", ".").split(" ");
    }
    __itemsChanged(e) {
        this.items && !Array.isArray(this.items) && console.warn("dom-repeat expected array for `items`, found", this.items), 
        this.__handleItemPath(e.path, e.value) || (this.__initializeChunking(), this.__debounceRender(this.__render));
    }
    __handleObservedPaths(e) {
        if (this.__sortFn || this.__filterFn) if (e) {
            if (this.__observePaths) {
                let t = this.__observePaths;
                for (let n = 0; n < t.length; n++) 0 === e.indexOf(t[n]) && this.__debounceRender(this.__render, this.delay);
            }
        } else this.__debounceRender(this.__render, this.delay);
    }
    __debounceRender(e, t = 0) {
        this.__renderDebouncer = Debouncer.debounce(this.__renderDebouncer, t > 0 ? timeOut.after(t) : microTask, e.bind(this)), 
        enqueueDebouncer(this.__renderDebouncer);
    }
    render() {
        this.__debounceRender(this.__render), flush$1();
    }
    __render() {
        this.__ensureTemplatized() && (this.__applyFullRefresh(), this.__pool.length = 0, 
        this._setRenderedItemCount(this.__instances.length), this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        })), this.__tryRenderChunk());
    }
    __applyFullRefresh() {
        let e = this.items || [], t = new Array(e.length);
        for (let n = 0; n < e.length; n++) t[n] = n;
        this.__filterFn && (t = t.filter((t, n, i) => this.__filterFn(e[t], n, i))), this.__sortFn && t.sort((t, n) => this.__sortFn(e[t], e[n]));
        const n = this.__itemsIdxToInstIdx = {};
        let i = 0;
        const r = Math.min(t.length, this.__limit);
        for (;i < r; i++) {
            let r = this.__instances[i], o = t[i], s = e[o];
            n[o] = i, r ? (r._setPendingProperty(this.as, s), r._setPendingProperty(this.indexAs, i), 
            r._setPendingProperty(this.itemsIndexAs, o), r._flushProperties()) : this.__insertInstance(s, i, o);
        }
        for (let e = this.__instances.length - 1; e >= i; e--) this.__detachAndRemoveInstance(e);
    }
    __detachInstance(e) {
        let t = this.__instances[e];
        const n = wrap$1(t.root);
        for (let e = 0; e < t.children.length; e++) {
            let i = t.children[e];
            n.appendChild(i);
        }
        return t;
    }
    __attachInstance(e, t) {
        let n = this.__instances[e];
        t.insertBefore(n.root, this);
    }
    __detachAndRemoveInstance(e) {
        let t = this.__detachInstance(e);
        t && this.__pool.push(t), this.__instances.splice(e, 1);
    }
    __stampInstance(e, t, n) {
        let i = {};
        return i[this.as] = e, i[this.indexAs] = t, i[this.itemsIndexAs] = n, new this.__ctor(i);
    }
    __insertInstance(e, t, n) {
        let i = this.__pool.pop();
        i ? (i._setPendingProperty(this.as, e), i._setPendingProperty(this.indexAs, t), 
        i._setPendingProperty(this.itemsIndexAs, n), i._flushProperties()) : i = this.__stampInstance(e, t, n);
        let r = this.__instances[t + 1], o = r ? r.children[0] : this;
        return wrap$1(wrap$1(this).parentNode).insertBefore(i.root, o), this.__instances[t] = i, 
        i;
    }
    _showHideChildren(e) {
        for (let t = 0; t < this.__instances.length; t++) this.__instances[t]._showHideChildren(e);
    }
    __handleItemPath(e, t) {
        let n = e.slice(6), i = n.indexOf("."), r = i < 0 ? n : n.substring(0, i);
        if (r == parseInt(r, 10)) {
            let e = i < 0 ? "" : n.substring(i + 1);
            this.__handleObservedPaths(e);
            let o = this.__itemsIdxToInstIdx[r], s = this.__instances[o];
            if (s) {
                let n = this.as + (e ? "." + e : "");
                s._setPendingPropertyOrPath(n, t, !1, !0), s._flushProperties();
            }
            return !0;
        }
    }
    itemForElement(e) {
        let t = this.modelForElement(e);
        return t && t[this.as];
    }
    indexForElement(e) {
        let t = this.modelForElement(e);
        return t && t[this.indexAs];
    }
    modelForElement(e) {
        return modelForElement(this.template, e);
    }
}

customElements.define(DomRepeat.is, DomRepeat);

var domRepeat = {
    DomRepeat: DomRepeat
};

class DomIf extends PolymerElement {
    static get is() {
        return "dom-if";
    }
    static get template() {
        return null;
    }
    static get properties() {
        return {
            if: {
                type: Boolean,
                observer: "__debounceRender"
            },
            restamp: {
                type: Boolean,
                observer: "__debounceRender"
            }
        };
    }
    constructor() {
        super(), this.__renderDebouncer = null, this.__invalidProps = null, this.__instance = null, 
        this._lastIf = !1, this.__ctor = null, this.__hideTemplateChildren__ = !1;
    }
    __debounceRender() {
        this.__renderDebouncer = Debouncer.debounce(this.__renderDebouncer, microTask, () => this.__render()), 
        enqueueDebouncer(this.__renderDebouncer);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const e = wrap$1(this).parentNode;
        e && (e.nodeType != Node.DOCUMENT_FRAGMENT_NODE || wrap$1(e).host) || this.__teardownInstance();
    }
    connectedCallback() {
        super.connectedCallback(), this.style.display = "none", this.if && this.__debounceRender();
    }
    render() {
        flush$1();
    }
    __render() {
        if (this.if) {
            if (!this.__ensureInstance()) return;
            this._showHideChildren();
        } else this.restamp && this.__teardownInstance();
        !this.restamp && this.__instance && this._showHideChildren(), this.if != this._lastIf && (this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        })), this._lastIf = this.if);
    }
    __ensureInstance() {
        let e = wrap$1(this).parentNode;
        if (e) {
            if (!this.__ctor) {
                let e = wrap$1(this).querySelector("template");
                if (!e) {
                    let e = new MutationObserver(() => {
                        if (!wrap$1(this).querySelector("template")) throw new Error("dom-if requires a <template> child");
                        e.disconnect(), this.__render();
                    });
                    return e.observe(this, {
                        childList: !0
                    }), !1;
                }
                this.__ctor = templatize(e, this, {
                    mutableData: !0,
                    forwardHostProp: function(e, t) {
                        this.__instance && (this.if ? this.__instance.forwardHostProp(e, t) : (this.__invalidProps = this.__invalidProps || Object.create(null), 
                        this.__invalidProps[root(e)] = !0));
                    }
                });
            }
            if (this.__instance) {
                this.__syncHostProperties();
                let t = this.__instance.children;
                if (t && t.length) {
                    if (wrap$1(this).previousSibling !== t[t.length - 1]) for (let n, i = 0; i < t.length && (n = t[i]); i++) wrap$1(e).insertBefore(n, this);
                }
            } else this.__instance = new this.__ctor(), wrap$1(e).insertBefore(this.__instance.root, this);
        }
        return !0;
    }
    __syncHostProperties() {
        let e = this.__invalidProps;
        if (e) {
            for (let t in e) this.__instance._setPendingProperty(t, this.__dataHost[t]);
            this.__invalidProps = null, this.__instance._flushProperties();
        }
    }
    __teardownInstance() {
        if (this.__instance) {
            let e = this.__instance.children;
            if (e && e.length) {
                let t = wrap$1(e[0]).parentNode;
                if (t) {
                    t = wrap$1(t);
                    for (let n, i = 0; i < e.length && (n = e[i]); i++) t.removeChild(n);
                }
            }
            this.__instance = null, this.__invalidProps = null;
        }
    }
    _showHideChildren() {
        let e = this.__hideTemplateChildren__ || !this.if;
        this.__instance && this.__instance._showHideChildren(e);
    }
}

customElements.define(DomIf.is, DomIf);

var domIf = {
    DomIf: DomIf
};

let ArraySelectorMixin = dedupingMixin(e => {
    let t = ElementMixin(e);
    return class extends t {
        static get properties() {
            return {
                items: {
                    type: Array
                },
                multi: {
                    type: Boolean,
                    value: !1
                },
                selected: {
                    type: Object,
                    notify: !0
                },
                selectedItem: {
                    type: Object,
                    notify: !0
                },
                toggle: {
                    type: Boolean,
                    value: !1
                }
            };
        }
        static get observers() {
            return [ "__updateSelection(multi, items.*)" ];
        }
        constructor() {
            super(), this.__lastItems = null, this.__lastMulti = null, this.__selectedMap = null;
        }
        __updateSelection(e, t) {
            let n = t.path;
            if (n == JSCompiler_renameProperty("items", this)) {
                let n = t.base || [], i = this.__lastItems;
                if (e !== this.__lastMulti && this.clearSelection(), i) {
                    let e = calculateSplices(n, i);
                    this.__applySplices(e);
                }
                this.__lastItems = n, this.__lastMulti = e;
            } else if (t.path == `${JSCompiler_renameProperty("items", this)}.splices`) this.__applySplices(t.value.indexSplices); else {
                let e = n.slice(`${JSCompiler_renameProperty("items", this)}.`.length), t = parseInt(e, 10);
                e.indexOf(".") < 0 && e == t && this.__deselectChangedIdx(t);
            }
        }
        __applySplices(e) {
            let t = this.__selectedMap;
            for (let n = 0; n < e.length; n++) {
                let i = e[n];
                t.forEach((e, n) => {
                    e < i.index || (e >= i.index + i.removed.length ? t.set(n, e + i.addedCount - i.removed.length) : t.set(n, -1));
                });
                for (let e = 0; e < i.addedCount; e++) {
                    let n = i.index + e;
                    t.has(this.items[n]) && t.set(this.items[n], n);
                }
            }
            this.__updateLinks();
            let n = 0;
            t.forEach((e, i) => {
                e < 0 ? (this.multi ? this.splice(JSCompiler_renameProperty("selected", this), n, 1) : this.selected = this.selectedItem = null, 
                t.delete(i)) : n++;
            });
        }
        __updateLinks() {
            if (this.__dataLinkedPaths = {}, this.multi) {
                let e = 0;
                this.__selectedMap.forEach(t => {
                    t >= 0 && this.linkPaths(`${JSCompiler_renameProperty("items", this)}.${t}`, `${JSCompiler_renameProperty("selected", this)}.${e++}`);
                });
            } else this.__selectedMap.forEach(e => {
                this.linkPaths(JSCompiler_renameProperty("selected", this), `${JSCompiler_renameProperty("items", this)}.${e}`), 
                this.linkPaths(JSCompiler_renameProperty("selectedItem", this), `${JSCompiler_renameProperty("items", this)}.${e}`);
            });
        }
        clearSelection() {
            this.__dataLinkedPaths = {}, this.__selectedMap = new Map(), this.selected = this.multi ? [] : null, 
            this.selectedItem = null;
        }
        isSelected(e) {
            return this.__selectedMap.has(e);
        }
        isIndexSelected(e) {
            return this.isSelected(this.items[e]);
        }
        __deselectChangedIdx(e) {
            let t = this.__selectedIndexForItemIndex(e);
            if (t >= 0) {
                let e = 0;
                this.__selectedMap.forEach((n, i) => {
                    t == e++ && this.deselect(i);
                });
            }
        }
        __selectedIndexForItemIndex(e) {
            let t = this.__dataLinkedPaths[`${JSCompiler_renameProperty("items", this)}.${e}`];
            if (t) return parseInt(t.slice(`${JSCompiler_renameProperty("selected", this)}.`.length), 10);
        }
        deselect(e) {
            let t = this.__selectedMap.get(e);
            if (t >= 0) {
                let n;
                this.__selectedMap.delete(e), this.multi && (n = this.__selectedIndexForItemIndex(t)), 
                this.__updateLinks(), this.multi ? this.splice(JSCompiler_renameProperty("selected", this), n, 1) : this.selected = this.selectedItem = null;
            }
        }
        deselectIndex(e) {
            this.deselect(this.items[e]);
        }
        select(e) {
            this.selectIndex(this.items.indexOf(e));
        }
        selectIndex(e) {
            let t = this.items[e];
            this.isSelected(t) ? this.toggle && this.deselectIndex(e) : (this.multi || this.__selectedMap.clear(), 
            this.__selectedMap.set(t, e), this.__updateLinks(), this.multi ? this.push(JSCompiler_renameProperty("selected", this), t) : this.selected = this.selectedItem = t);
        }
    };
}), baseArraySelector = ArraySelectorMixin(PolymerElement);

class ArraySelector extends baseArraySelector {
    static get is() {
        return "array-selector";
    }
    static get template() {
        return null;
    }
}

customElements.define(ArraySelector.is, ArraySelector);

var arraySelector = {
    ArraySelectorMixin: ArraySelectorMixin,
    ArraySelector: ArraySelector
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const customStyleInterface$1 = new CustomStyleInterface();

window.ShadyCSS || (window.ShadyCSS = {
    prepareTemplate(e, t, n) {},
    prepareTemplateDom(e, t) {},
    prepareTemplateStyles(e, t, n) {},
    styleSubtree(e, t) {
        customStyleInterface$1.processStyles(), updateNativeProperties(e, t);
    },
    styleElement(e) {
        customStyleInterface$1.processStyles();
    },
    styleDocument(e) {
        customStyleInterface$1.processStyles(), updateNativeProperties(document.body, e);
    },
    getComputedStyleValue: (e, t) => getComputedStyleValue(e, t),
    flushCustomStyles() {},
    nativeCss: nativeCssVariables,
    nativeShadow: nativeShadow,
    cssBuild: cssBuild,
    disableRuntime: disableRuntime
}), window.ShadyCSS.CustomStyleInterface = customStyleInterface$1;

const attr = "include", CustomStyleInterface$1 = window.ShadyCSS.CustomStyleInterface;

class CustomStyle extends HTMLElement {
    constructor() {
        super(), this._style = null, CustomStyleInterface$1.addCustomStyle(this);
    }
    getStyle() {
        if (this._style) return this._style;
        const e = this.querySelector("style");
        if (!e) return null;
        this._style = e;
        const t = e.getAttribute(attr);
        return t && (e.removeAttribute(attr), e.textContent = cssFromModules(t) + e.textContent), 
        this.ownerDocument !== window.document && window.document.head.appendChild(this), 
        this._style;
    }
}

window.customElements.define("custom-style", CustomStyle);

var customStyle = {
    CustomStyle: CustomStyle
};

let mutablePropertyChange$1;

mutablePropertyChange$1 = MutableData._mutablePropertyChange;

const MutableDataBehavior = {
    _shouldPropertyChange(e, t, n) {
        return mutablePropertyChange$1(this, e, t, n, !0);
    }
}, OptionalMutableDataBehavior = {
    properties: {
        mutableData: Boolean
    },
    _shouldPropertyChange(e, t, n) {
        return mutablePropertyChange$1(this, e, t, n, this.mutableData);
    }
};

var mutableDataBehavior = {
    MutableDataBehavior: MutableDataBehavior,
    OptionalMutableDataBehavior: OptionalMutableDataBehavior
};

const Base = LegacyElementMixin(HTMLElement).prototype;

var polymerLegacy = {
    Base: Base,
    Polymer: Polymer,
    html: html
};

function parse$1(e) {
    let t = null;
    try {
        t = JSON.parse(e);
    } catch (e) {
        exception(e, `Caught: JSONUtils.parse: ${e.message}`, !1);
    }
    return t;
}

function shallowCopy(e) {
    let t = null;
    const n = JSON.stringify(e);
    return void 0 !== n && (t = parse$1(n)), t;
}

var json = {
    parse: parse$1,
    shallowCopy: shallowCopy
};

const chromep = new ChromePromise(), _DEBUG = !1;

async function _isOS(e) {
    try {
        const t = await chromep.runtime.getPlatformInfo();
        return Promise.resolve(t.os === e);
    } catch (e) {
        return Promise.resolve(!1);
    }
}

const DEBUG = !1;

function getExtensionName() {
    return `chrome-extension://${chrome.runtime.id}`;
}

function getVersion() {
    return chrome.runtime.getManifest().version;
}

function getChromeVersion() {
    const e = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
    return !!e && parseInt(e[2], 10);
}

function getFullChromeVersion() {
    const e = navigator.userAgent;
    return e || "Unknown";
}

async function getPlatformOS() {
    let e = "Unknown";
    try {
        switch ((await chromep.runtime.getPlatformInfo()).os) {
          case "win":
            e = "MS Windows";
            break;

          case "mac":
            e = "Mac";
            break;

          case "android":
            e = "Android";
            break;

          case "cros":
            e = "Chrome OS";
            break;

          case "linux":
            e = "Linux";
            break;

          case "openbsd":
            e = "OpenBSD";
        }
    } catch (e) {}
    return Promise.resolve(e);
}

function isWindows() {
    return _isOS("win");
}

function isChromeOS() {
    return _isOS("cros");
}

function isMac() {
    return _isOS("mac");
}

function noop() {}

function isWhiteSpace(e) {
    return !e || 0 === e.length || /^\s*$/.test(e);
}

function getRandomString(e = 8) {
    const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let n = "";
    for (let i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * t.length));
    return n;
}

function getRandomInt(e, t) {
    return Math.floor(Math.random() * (t - e + 1)) + e;
}

function shuffleArray(e) {
    for (let t = (e ? e.length : 0) - 1; t > 0; t--) {
        const n = Math.floor(Math.random() * (t + 1)), i = e[t];
        e[t] = e[n], e[n] = i;
    }
}

var utils = {
    DEBUG: DEBUG,
    getExtensionName: getExtensionName,
    getVersion: getVersion,
    getChromeVersion: getChromeVersion,
    getFullChromeVersion: getFullChromeVersion,
    getPlatformOS: getPlatformOS,
    isWindows: isWindows,
    isChromeOS: isChromeOS,
    isMac: isMac,
    noop: noop,
    isWhiteSpace: isWhiteSpace,
    getRandomString: getRandomString,
    getRandomInt: getRandomInt,
    shuffleArray: shuffleArray
};

const EVENT = {
    INSTALLED: {
        eventCategory: "extension",
        eventAction: "installed",
        eventLabel: ""
    },
    UPDATED: {
        eventCategory: "extension",
        eventAction: "updated",
        eventLabel: ""
    },
    REFRESHED_AUTH_TOKEN: {
        eventCategory: "user",
        eventAction: "refreshedAuthToken",
        eventLabel: ""
    },
    ALARM: {
        eventCategory: "alarm",
        eventAction: "triggered",
        eventLabel: ""
    },
    MENU: {
        eventCategory: "ui",
        eventAction: "menuSelect",
        eventLabel: ""
    },
    TOGGLE: {
        eventCategory: "ui",
        eventAction: "toggle",
        eventLabel: ""
    },
    LINK: {
        eventCategory: "ui",
        eventAction: "linkSelect",
        eventLabel: ""
    },
    TEXT: {
        eventCategory: "ui",
        eventAction: "textChanged",
        eventLabel: ""
    },
    SLIDER_VALUE: {
        eventCategory: "ui",
        eventAction: "sliderValueChanged",
        eventLabel: ""
    },
    SLIDER_UNITS: {
        eventCategory: "ui",
        eventAction: "sliderUnitsChanged",
        eventLabel: ""
    },
    BUTTON: {
        eventCategory: "ui",
        eventAction: "buttonClicked",
        eventLabel: ""
    },
    RADIO_BUTTON: {
        eventCategory: "ui",
        eventAction: "radioButtonClicked",
        eventLabel: ""
    },
    ICON: {
        eventCategory: "ui",
        eventAction: "toolbarIconClicked",
        eventLabel: ""
    },
    CHECK: {
        eventCategory: "ui",
        eventAction: "checkBoxClicked",
        eventLabel: ""
    },
    KEY_COMMAND: {
        eventCategory: "ui",
        eventAction: "keyCommand",
        eventLabel: ""
    }
};

function initialize(e, t, n, i) {
    var r, o, s, a, l, c;
    r = window, o = document, s = "script", a = "ga", r.GoogleAnalyticsObject = a, r.ga = r.ga || function() {
        (r.ga.q = r.ga.q || []).push(arguments);
    }, r.ga.l = 1 * new Date(), l = o.createElement(s), c = o.getElementsByTagName(s)[0], 
    l.async = 1, l.src = "https://www.google-analytics.com/analytics.js", c.parentNode.insertBefore(l, c), 
    ga("create", e, "auto"), ga("set", "checkProtocolTask", function() {}), ga("set", "appName", t), 
    ga("set", "appId", n), ga("set", "appVersion", i), ga("require", "displayfeatures");
}

function page(e) {
    e && (DEBUG || ga("send", "pageview", e));
}

function event(e, t = null, n = null) {
    if (e) {
        const i = shallowCopy(e);
        i.hitType = "event", i.eventLabel = t || i.eventLabel, i.eventAction = n || i.eventAction, 
        DEBUG ? console.log(i) : ga("send", i);
    }
}

function error(e = "unknown", t = "unknownMethod") {
    const n = {
        hitType: "event",
        eventCategory: "error",
        eventAction: t,
        eventLabel: `Err: ${e}`
    };
    DEBUG ? console.error(n) : ga("send", n);
}

function exception(e, t = null, n = !1) {
    try {
        let i = "Unknown";
        t ? i = t : e.message && (i = e.message), e.stack && (i += `\n\n${e.stack}`);
        const r = {
            hitType: "exception",
            exDescription: i,
            exFatal: n
        };
        DEBUG ? console.error(r) : ga("send", r);
    } catch (e) {
        noop();
    }
}

var analytics = {
    EVENT: EVENT,
    initialize: initialize,
    page: page,
    event: event,
    error: error,
    exception: exception
};

const chromep$1 = new ChromePromise();

class ChromeLastError extends Error {
    static async load() {
        const e = (await chromep$1.storage.local.get("lastError")).lastError;
        if (e) {
            const t = new ChromeLastError(e.title, e.message);
            return t.stack = e.stack, Promise.resolve(t);
        }
        return Promise.resolve(new ChromeLastError());
    }
    static save(e) {
        const t = {
            title: e.title || "",
            message: e.message || "",
            stack: e.stack || ""
        };
        return chromep$1.storage.local.set({
            lastError: t
        });
    }
    static reset() {
        return chromep$1.storage.local.set({
            lastError: new ChromeLastError()
        });
    }
    constructor(e = "An error occurred", ...t) {
        super(...t), Error.captureStackTrace && Error.captureStackTrace(this, ChromeLastError), 
        this.title = e;
    }
}

var last_error = {
    default: ChromeLastError
};

function error$1(e = null, t = null, n = null, i = null) {
    e = e || localize("err_unknown", "unknown"), t = t || localize("err_unknownMethod", "unknownMethod"), 
    n = n || localize("err_error", "An error occurred");
    const r = i ? `${e} ${i}` : e;
    ChromeLastError.save(new ChromeLastError(n, e)).catch(() => {}), error(r, t);
}

function exception$1(e, t = null, n = !1, i = null) {
    try {
        let r = t;
        !r && e && e.message && (r = e.message), i = i || localize("err_exception", "An exception occurred"), 
        ChromeLastError.save(new ChromeLastError(i, r)).catch(() => {}), exception(e, t, n);
    } catch (e) {
        noop();
    }
}

var ChromeLog = {
    error: error$1,
    exception: exception$1
};

class ExHandler {
    constructor() {
        "object" == typeof window.onerror && (window.onerror = function(e, t, n, i, r) {
            ChromeLog && r && exception$1(r, null, !0);
        });
    }
}

function localize(e, t = "") {
    let n = chrome.i18n.getMessage(e);
    return void 0 !== n && "" !== n || (n = t || ""), n;
}

function getLocale() {
    return chrome.i18n.getMessage("@@ui_locale");
}

new ExHandler();

var locales = {
    localize: localize,
    getLocale: getLocale
};

const LocalizeBehavior = {
    properties: {
        localize: {
            type: Function,
            value: () => (function() {
                return localize(arguments[0], arguments[1]);
            })
        }
    }
};

var localizeBehavior = {
    LocalizeBehavior: LocalizeBehavior
};

const sharedStyles = document.createElement("dom-module");

sharedStyles.innerHTML = "\x3c!--suppress CssUnresolvedCustomPropertySet, CssUnresolvedCustomProperty --\x3e\n<template>\n  <style>\n    .page-title {\n      @apply --paper-font-display2;\n    }\n\n    @media (max-width: 600px) {\n      .page-title {\n        font-size: 24px !important;\n      }\n    }\n\n    /* see https://github.com/Polymer/polymer/issues/3711#issuecomment-226361758*/\n    [hidden] {\n      display: none !important;\n    }\n\n    /* Scrollbars */\n    ::-webkit-scrollbar {\n      background: transparent;\n      width: 8px;\n    }\n\n    ::-webkit-scrollbar-button {\n      background: transparent;\n      height: 0;\n    }\n\n    ::-webkit-scrollbar-thumb {\n      background: rgba(48, 63, 159, 1);\n      -webkit-border-radius: 8px;\n      border-radius: 4px;\n      cursor: pointer;\n    }\n\n    paper-dialog {\n      min-width: 25vw;\n      max-width: 50vw;\n    }\n\n    paper-material {\n      border-radius: 2px;\n      background: white;\n      padding: 0;\n    }\n\n    paper-listbox iron-icon {\n      margin-right: 20px;\n      opacity: 0.54;\n    }\n\n    paper-listbox paper-item {\n      --paper-item: {\n        color: var(--menu-link-color);\n        text-rendering: optimizeLegibility;\n        cursor: pointer;\n      };\n      --paper-item-selected: {\n        color: var(--dark-primary-color);\n        background-color: var(--selected-color);\n        text-rendering: optimizeLegibility;\n        cursor: pointer;\n      };\n      --paper-item-focused-before: {\n        background-color: transparent;\n      };\n    }\n\n    paper-toggle-button {\n      cursor: pointer;\n      --paper-toggle-button-checked-button-color: var(--setting-item-color);\n      --paper-toggle-button-checked-bar-color: var(--setting-item-color);\n    }\n\n    paper-button {\n      margin-top: 8px;\n      margin-bottom: 16px;\n      @apply --layout-center;\n      @apply --layout-horizontal;\n    }\n\n    paper-button[raised] {\n      background: #FAFAFA;\n    }\n\n    paper-button iron-icon {\n      margin-right: 8px;\n    }\n\n    paper-dropdown-menu {\n      --paper-dropdown-menu: {\n        cursor: pointer;\n      };\n    }\n\n    app-drawer-layout:not([narrow]) [drawer-toggle] {\n      display: none;\n    }\n\n    app-drawer {\n      --app-drawer-content-container: {\n        border-right: var(--drawer-toolbar-border-color);\n      }\n    }\n\n    app-toolbar {\n      color: var(--text-primary-color);\n      background-color: var(--primary-color);\n    }\n\n    app-toolbar paper-toggle-button {\n      padding-left: 8px;\n      --paper-toggle-button-checked-button-color: white;\n      --paper-toggle-button-checked-bar-color: white;\n    }\n\n    .page-toolbar {\n      /*@apply --paper-font-title;*/\n      background-color: var(--primary-color);\n      margin-bottom: 8px;\n    }\n\n    .page-container {\n      max-width: 700px;\n      height: 100%;\n      margin-bottom: 16px;\n    }\n\n    .page-content {\n      margin-top: 16px;\n      margin-bottom: 16px;\n    }\n\n    .section-title {\n      color: var(--setting-item-color);\n      font-size: 14px;\n      font-weight: 500;\n      margin: 16px 0 8px 16px;\n    }\n\n    .setting-label {\n      white-space: normal;\n      word-wrap: break-word;\n      overflow: hidden;\n    }\n\n    :host([disabled]) .setting-label {\n      color: var(--disabled-text-color);\n    }\n\n    .setting-link-icon {\n      color: var(--setting-item-color);\n    }\n\n    .button-a {\n      text-decoration: none;\n      color: var(--menu-link-color);\n      display: -ms-flexbox;\n      display: -webkit-flex;\n      display: flex;\n      -webkit-flex-direction: row;\n      flex-direction: row;\n      -webkit-align-items: center;\n      align-items: center;\n      -webkit-font-smoothing: antialiased;\n      text-rendering: optimizeLegibility;\n      margin-right: 8px;\n    }\n\n    hr {\n      margin: 0 8px;\n      border: none;\n      border-top: 1px #CCCCCC solid;\n    }\n\n  </style>\n</template>", 
sharedStyles.register("shared-styles");

var SPLICES_RX = /\.splices$/, LENGTH_RX = /\.length$/, NUMBER_RX = /\.?#?([0-9]+)$/;

const AppStorageBehavior = {
    properties: {
        data: {
            type: Object,
            notify: !0,
            value: function() {
                return this.zeroValue;
            }
        },
        sequentialTransactions: {
            type: Boolean,
            value: !1
        },
        log: {
            type: Boolean,
            value: !1
        }
    },
    observers: [ "__dataChanged(data.*)" ],
    created: function() {
        this.__initialized = !1, this.__syncingToMemory = !1, this.__initializingStoredValue = null, 
        this.__transactionQueueAdvances = Promise.resolve();
    },
    ready: function() {
        this._initializeStoredValue();
    },
    get isNew() {
        return !0;
    },
    get transactionsComplete() {
        return this.__transactionQueueAdvances;
    },
    get zeroValue() {},
    saveValue: function(e) {
        return Promise.resolve();
    },
    reset: function() {},
    destroy: function() {
        return this.data = this.zeroValue, this.saveValue();
    },
    initializeStoredValue: function() {
        return this.isNew ? Promise.resolve() : this._getStoredValue("data").then(function(e) {
            if (this._log("Got stored value!", e, this.data), null == e) return this._setStoredValue("data", this.data || this.zeroValue);
            this.syncToMemory(function() {
                this.set("data", e);
            });
        }.bind(this));
    },
    getStoredValue: function(e) {
        return Promise.resolve();
    },
    setStoredValue: function(e, t) {
        return Promise.resolve(t);
    },
    memoryPathToStoragePath: function(e) {
        return e;
    },
    storagePathToMemoryPath: function(e) {
        return e;
    },
    syncToMemory: function(e) {
        this.__syncingToMemory || (this._group("Sync to memory."), this.__syncingToMemory = !0, 
        e.call(this), this.__syncingToMemory = !1, this._groupEnd("Sync to memory."));
    },
    valueIsEmpty: function(e) {
        return Array.isArray(e) ? 0 === e.length : Object.prototype.isPrototypeOf(e) ? 0 === Object.keys(e).length : null == e;
    },
    _getStoredValue: function(e) {
        return this.getStoredValue(this.memoryPathToStoragePath(e));
    },
    _setStoredValue: function(e, t) {
        return this.setStoredValue(this.memoryPathToStoragePath(e), t);
    },
    _enqueueTransaction: function(e) {
        if (this.sequentialTransactions) e = e.bind(this); else {
            var t = e.call(this);
            e = function() {
                return t;
            };
        }
        return this.__transactionQueueAdvances = this.__transactionQueueAdvances.then(e).catch(function(e) {
            this._error("Error performing queued transaction.", e);
        }.bind(this));
    },
    _log: function(...e) {
        this.log && console.log.apply(console, e);
    },
    _error: function(...e) {
        this.log && console.error.apply(console, e);
    },
    _group: function(...e) {
        this.log && console.group.apply(console, e);
    },
    _groupEnd: function(...e) {
        this.log && console.groupEnd.apply(console, e);
    },
    _initializeStoredValue: function() {
        if (!this.__initializingStoredValue) {
            this._group("Initializing stored value.");
            var e = this.__initializingStoredValue = this.initializeStoredValue().then(function() {
                this.__initialized = !0, this.__initializingStoredValue = null, this._groupEnd("Initializing stored value.");
            }.bind(this)).catch(function(e) {
                this.__initializingStoredValue = null, this._groupEnd("Initializing stored value.");
            }.bind(this));
            return this._enqueueTransaction(function() {
                return e;
            });
        }
    },
    __dataChanged: function(e) {
        if (!this.isNew && !this.__syncingToMemory && this.__initialized && !this.__pathCanBeIgnored(e.path)) {
            var t = this.__normalizeMemoryPath(e.path), n = e.value, i = n && n.indexSplices;
            this._enqueueTransaction(function() {
                return this._log("Setting", t + ":", i || n), i && this.__pathIsSplices(t) && (t = this.__parentPath(t), 
                n = this.get(t)), this._setStoredValue(t, n);
            });
        }
    },
    __normalizeMemoryPath: function(e) {
        for (var t = e.split("."), n = [], i = [], r = [], o = 0; o < t.length; ++o) i.push(t[o]), 
        /^#/.test(t[o]) ? r.push(this.get(n).indexOf(this.get(i))) : r.push(t[o]), n.push(t[o]);
        return r.join(".");
    },
    __parentPath: function(e) {
        var t = e.split(".");
        return t.slice(0, t.length - 1).join(".");
    },
    __pathCanBeIgnored: function(e) {
        return LENGTH_RX.test(e) && Array.isArray(this.get(this.__parentPath(e)));
    },
    __pathIsSplices: function(e) {
        return SPLICES_RX.test(e) && Array.isArray(this.get(this.__parentPath(e)));
    },
    __pathRefersToArray: function(e) {
        return (SPLICES_RX.test(e) || LENGTH_RX.test(e)) && Array.isArray(this.get(this.__parentPath(e)));
    },
    __pathTailToIndex: function(e) {
        var t = e.split(".").pop();
        return window.parseInt(t.replace(NUMBER_RX, "$1"), 10);
    }
};

var appStorageBehavior = {
    AppStorageBehavior: AppStorageBehavior
};

if (Polymer({
    is: "app-localstorage-document",
    behaviors: [ AppStorageBehavior ],
    properties: {
        key: {
            type: String,
            notify: !0
        },
        sessionOnly: {
            type: Boolean,
            value: !1
        },
        storage: {
            type: Object,
            computed: "__computeStorage(sessionOnly)"
        }
    },
    observers: [ "__storageSourceChanged(storage, key)" ],
    attached: function() {
        this.listen(window, "storage", "__onStorage"), this.listen(window.top, "app-local-storage-changed", "__onAppLocalStorageChanged");
    },
    detached: function() {
        this.unlisten(window, "storage", "__onStorage"), this.unlisten(window.top, "app-local-storage-changed", "__onAppLocalStorageChanged");
    },
    get isNew() {
        return !this.key;
    },
    saveValue: function(e) {
        try {
            this.__setStorageValue(e, this.data);
        } catch (e) {
            return Promise.reject(e);
        }
        return this.key = e, Promise.resolve();
    },
    reset: function() {
        this.key = null, this.data = this.zeroValue;
    },
    destroy: function() {
        try {
            this.storage.removeItem(this.key), this.reset();
        } catch (e) {
            return Promise.reject(e);
        }
        return Promise.resolve();
    },
    getStoredValue: function(e) {
        var t;
        if (null != this.key) try {
            t = null != (t = this.__parseValueFromStorage()) ? this.get(e, {
                data: t
            }) : void 0;
        } catch (e) {
            return Promise.reject(e);
        }
        return Promise.resolve(t);
    },
    setStoredValue: function(e, t) {
        if (null != this.key) {
            try {
                this.__setStorageValue(this.key, this.data);
            } catch (e) {
                return Promise.reject(e);
            }
            this.fire("app-local-storage-changed", this, {
                node: window.top
            });
        }
        return Promise.resolve(t);
    },
    __computeStorage: function(e) {
        return e ? window.sessionStorage : window.localStorage;
    },
    __storageSourceChanged: function(e, t) {
        this._initializeStoredValue();
    },
    __onStorage: function(e) {
        e.key === this.key && e.storageArea === this.storage && this.syncToMemory(function() {
            this.set("data", this.__parseValueFromStorage());
        });
    },
    __onAppLocalStorageChanged: function(e) {
        e.detail !== this && e.detail.key === this.key && e.detail.storage === this.storage && this.syncToMemory(function() {
            this.set("data", e.detail.data);
        });
    },
    __parseValueFromStorage: function() {
        try {
            return JSON.parse(this.storage.getItem(this.key));
        } catch (e) {
            console.error("Failed to parse value from storage for", this.key);
        }
    },
    __setStorageValue: function(e, t) {
        void 0 === t && (t = null), this.storage.setItem(e, JSON.stringify(t));
    }
}), !window.polymerSkipLoadingFontRoboto) {
    const e = document.createElement("link");
    e.rel = "stylesheet", e.type = "text/css", e.crossOrigin = "anonymous", e.href = "https://fonts.googleapis.com/css?family=Roboto+Mono:400,700|Roboto:400,300,300italic,400italic,500,500italic,700,700italic", 
    document.head.appendChild(e);
}

var KEY_IDENTIFIER = {
    "U+0008": "backspace",
    "U+0009": "tab",
    "U+001B": "esc",
    "U+0020": "space",
    "U+007F": "del"
}, KEY_CODE = {
    8: "backspace",
    9: "tab",
    13: "enter",
    27: "esc",
    33: "pageup",
    34: "pagedown",
    35: "end",
    36: "home",
    32: "space",
    37: "left",
    38: "up",
    39: "right",
    40: "down",
    46: "del",
    106: "*"
}, MODIFIER_KEYS = {
    shift: "shiftKey",
    ctrl: "ctrlKey",
    alt: "altKey",
    meta: "metaKey"
}, KEY_CHAR = /[a-z0-9*]/, IDENT_CHAR = /U\+/, ARROW_KEY = /^arrow/, SPACE_KEY = /^space(bar)?/, ESC_KEY = /^escape$/;

function transformKey(e, t) {
    var n = "";
    if (e) {
        var i = e.toLowerCase();
        " " === i || SPACE_KEY.test(i) ? n = "space" : ESC_KEY.test(i) ? n = "esc" : 1 == i.length ? t && !KEY_CHAR.test(i) || (n = i) : n = ARROW_KEY.test(i) ? i.replace("arrow", "") : "multiply" == i ? "*" : i;
    }
    return n;
}

function transformKeyIdentifier(e) {
    var t = "";
    return e && (e in KEY_IDENTIFIER ? t = KEY_IDENTIFIER[e] : IDENT_CHAR.test(e) ? (e = parseInt(e.replace("U+", "0x"), 16), 
    t = String.fromCharCode(e).toLowerCase()) : t = e.toLowerCase()), t;
}

function transformKeyCode(e) {
    var t = "";
    return Number(e) && (t = e >= 65 && e <= 90 ? String.fromCharCode(32 + e) : e >= 112 && e <= 123 ? "f" + (e - 112 + 1) : e >= 48 && e <= 57 ? String(e - 48) : e >= 96 && e <= 105 ? String(e - 96) : KEY_CODE[e]), 
    t;
}

function normalizedKeyForEvent(e, t) {
    return e.key ? transformKey(e.key, t) : e.detail && e.detail.key ? transformKey(e.detail.key, t) : transformKeyIdentifier(e.keyIdentifier) || transformKeyCode(e.keyCode) || "";
}

function keyComboMatchesEvent(e, t) {
    return normalizedKeyForEvent(t, e.hasModifiers) === e.key && (!e.hasModifiers || !!t.shiftKey == !!e.shiftKey && !!t.ctrlKey == !!e.ctrlKey && !!t.altKey == !!e.altKey && !!t.metaKey == !!e.metaKey);
}

function parseKeyComboString(e) {
    return 1 === e.length ? {
        combo: e,
        key: e,
        event: "keydown"
    } : e.split("+").reduce(function(e, t) {
        var n = t.split(":"), i = n[0], r = n[1];
        return i in MODIFIER_KEYS ? (e[MODIFIER_KEYS[i]] = !0, e.hasModifiers = !0) : (e.key = i, 
        e.event = r || "keydown"), e;
    }, {
        combo: e.split(":").shift()
    });
}

function parseEventString(e) {
    return e.trim().split(" ").map(function(e) {
        return parseKeyComboString(e);
    });
}

const IronA11yKeysBehavior = {
    properties: {
        keyEventTarget: {
            type: Object,
            value: function() {
                return this;
            }
        },
        stopKeyboardEventPropagation: {
            type: Boolean,
            value: !1
        },
        _boundKeyHandlers: {
            type: Array,
            value: function() {
                return [];
            }
        },
        _imperativeKeyBindings: {
            type: Object,
            value: function() {
                return {};
            }
        }
    },
    observers: [ "_resetKeyEventListeners(keyEventTarget, _boundKeyHandlers)" ],
    keyBindings: {},
    registered: function() {
        this._prepKeyBindings();
    },
    attached: function() {
        this._listenKeyEventListeners();
    },
    detached: function() {
        this._unlistenKeyEventListeners();
    },
    addOwnKeyBinding: function(e, t) {
        this._imperativeKeyBindings[e] = t, this._prepKeyBindings(), this._resetKeyEventListeners();
    },
    removeOwnKeyBindings: function() {
        this._imperativeKeyBindings = {}, this._prepKeyBindings(), this._resetKeyEventListeners();
    },
    keyboardEventMatchesKeys: function(e, t) {
        for (var n = parseEventString(t), i = 0; i < n.length; ++i) if (keyComboMatchesEvent(n[i], e)) return !0;
        return !1;
    },
    _collectKeyBindings: function() {
        var e = this.behaviors.map(function(e) {
            return e.keyBindings;
        });
        return -1 === e.indexOf(this.keyBindings) && e.push(this.keyBindings), e;
    },
    _prepKeyBindings: function() {
        for (var e in this._keyBindings = {}, this._collectKeyBindings().forEach(function(e) {
            for (var t in e) this._addKeyBinding(t, e[t]);
        }, this), this._imperativeKeyBindings) this._addKeyBinding(e, this._imperativeKeyBindings[e]);
        for (var t in this._keyBindings) this._keyBindings[t].sort(function(e, t) {
            var n = e[0].hasModifiers;
            return n === t[0].hasModifiers ? 0 : n ? -1 : 1;
        });
    },
    _addKeyBinding: function(e, t) {
        parseEventString(e).forEach(function(e) {
            this._keyBindings[e.event] = this._keyBindings[e.event] || [], this._keyBindings[e.event].push([ e, t ]);
        }, this);
    },
    _resetKeyEventListeners: function() {
        this._unlistenKeyEventListeners(), this.isAttached && this._listenKeyEventListeners();
    },
    _listenKeyEventListeners: function() {
        this.keyEventTarget && Object.keys(this._keyBindings).forEach(function(e) {
            var t = this._keyBindings[e], n = this._onKeyBindingEvent.bind(this, t);
            this._boundKeyHandlers.push([ this.keyEventTarget, e, n ]), this.keyEventTarget.addEventListener(e, n);
        }, this);
    },
    _unlistenKeyEventListeners: function() {
        for (var e, t, n, i; this._boundKeyHandlers.length; ) t = (e = this._boundKeyHandlers.pop())[0], 
        n = e[1], i = e[2], t.removeEventListener(n, i);
    },
    _onKeyBindingEvent: function(e, t) {
        if (this.stopKeyboardEventPropagation && t.stopPropagation(), !t.defaultPrevented) for (var n = 0; n < e.length; n++) {
            var i = e[n][0], r = e[n][1];
            if (keyComboMatchesEvent(i, t) && (this._triggerKeyHandler(i, r, t), t.defaultPrevented)) return;
        }
    },
    _triggerKeyHandler: function(e, t, n) {
        var i = Object.create(e);
        i.keyboardEvent = n;
        var r = new CustomEvent(e.event, {
            detail: i,
            cancelable: !0
        });
        this[t].call(this, r), r.defaultPrevented && n.preventDefault();
    }
};

var ironA11yKeysBehavior = {
    IronA11yKeysBehavior: IronA11yKeysBehavior
};

const IronControlState = {
    properties: {
        focused: {
            type: Boolean,
            value: !1,
            notify: !0,
            readOnly: !0,
            reflectToAttribute: !0
        },
        disabled: {
            type: Boolean,
            value: !1,
            notify: !0,
            observer: "_disabledChanged",
            reflectToAttribute: !0
        },
        _oldTabIndex: {
            type: String
        },
        _boundFocusBlurHandler: {
            type: Function,
            value: function() {
                return this._focusBlurHandler.bind(this);
            }
        }
    },
    observers: [ "_changedControlState(focused, disabled)" ],
    ready: function() {
        this.addEventListener("focus", this._boundFocusBlurHandler, !0), this.addEventListener("blur", this._boundFocusBlurHandler, !0);
    },
    _focusBlurHandler: function(e) {
        this._setFocused("focus" === e.type);
    },
    _disabledChanged: function(e, t) {
        this.setAttribute("aria-disabled", e ? "true" : "false"), this.style.pointerEvents = e ? "none" : "", 
        e ? (this._oldTabIndex = this.getAttribute("tabindex"), this._setFocused(!1), this.tabIndex = -1, 
        this.blur()) : void 0 !== this._oldTabIndex && (null === this._oldTabIndex ? this.removeAttribute("tabindex") : this.setAttribute("tabindex", this._oldTabIndex));
    },
    _changedControlState: function() {
        this._controlStateChanged && this._controlStateChanged();
    }
};

var ironControlState = {
    IronControlState: IronControlState
};

const IronButtonStateImpl = {
    properties: {
        pressed: {
            type: Boolean,
            readOnly: !0,
            value: !1,
            reflectToAttribute: !0,
            observer: "_pressedChanged"
        },
        toggles: {
            type: Boolean,
            value: !1,
            reflectToAttribute: !0
        },
        active: {
            type: Boolean,
            value: !1,
            notify: !0,
            reflectToAttribute: !0
        },
        pointerDown: {
            type: Boolean,
            readOnly: !0,
            value: !1
        },
        receivedFocusFromKeyboard: {
            type: Boolean,
            readOnly: !0
        },
        ariaActiveAttribute: {
            type: String,
            value: "aria-pressed",
            observer: "_ariaActiveAttributeChanged"
        }
    },
    listeners: {
        down: "_downHandler",
        up: "_upHandler",
        tap: "_tapHandler"
    },
    observers: [ "_focusChanged(focused)", "_activeChanged(active, ariaActiveAttribute)" ],
    keyBindings: {
        "enter:keydown": "_asyncClick",
        "space:keydown": "_spaceKeyDownHandler",
        "space:keyup": "_spaceKeyUpHandler"
    },
    _mouseEventRe: /^mouse/,
    _tapHandler: function() {
        this.toggles ? this._userActivate(!this.active) : this.active = !1;
    },
    _focusChanged: function(e) {
        this._detectKeyboardFocus(e), e || this._setPressed(!1);
    },
    _detectKeyboardFocus: function(e) {
        this._setReceivedFocusFromKeyboard(!this.pointerDown && e);
    },
    _userActivate: function(e) {
        this.active !== e && (this.active = e, this.fire("change"));
    },
    _downHandler: function(e) {
        this._setPointerDown(!0), this._setPressed(!0), this._setReceivedFocusFromKeyboard(!1);
    },
    _upHandler: function() {
        this._setPointerDown(!1), this._setPressed(!1);
    },
    _spaceKeyDownHandler: function(e) {
        var t = e.detail.keyboardEvent, n = dom(t).localTarget;
        this.isLightDescendant(n) || (t.preventDefault(), t.stopImmediatePropagation(), 
        this._setPressed(!0));
    },
    _spaceKeyUpHandler: function(e) {
        var t = e.detail.keyboardEvent, n = dom(t).localTarget;
        this.isLightDescendant(n) || (this.pressed && this._asyncClick(), this._setPressed(!1));
    },
    _asyncClick: function() {
        this.async(function() {
            this.click();
        }, 1);
    },
    _pressedChanged: function(e) {
        this._changedButtonState();
    },
    _ariaActiveAttributeChanged: function(e, t) {
        t && t != e && this.hasAttribute(t) && this.removeAttribute(t);
    },
    _activeChanged: function(e, t) {
        this.toggles ? this.setAttribute(this.ariaActiveAttribute, e ? "true" : "false") : this.removeAttribute(this.ariaActiveAttribute), 
        this._changedButtonState();
    },
    _controlStateChanged: function() {
        this.disabled ? this._setPressed(!1) : this._changedButtonState();
    },
    _changedButtonState: function() {
        this._buttonStateChanged && this._buttonStateChanged();
    }
}, IronButtonState = [ IronA11yKeysBehavior, IronButtonStateImpl ];

var ironButtonState = {
    IronButtonStateImpl: IronButtonStateImpl,
    IronButtonState: IronButtonState
};

const template = html`
/* Most common used flex styles*/
<dom-module id="iron-flex">
  <template>
    <style>
      .layout.horizontal,
      .layout.vertical {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.inline {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      }

      .layout.horizontal {
        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      }

      .layout.vertical {
        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      }

      .layout.wrap {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      }

      .layout.no-wrap {
        -ms-flex-wrap: nowrap;
        -webkit-flex-wrap: nowrap;
        flex-wrap: nowrap;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .flex {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-auto {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      }

      .flex-none {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      }
    </style>
  </template>
</dom-module>
/* Basic flexbox reverse styles */
<dom-module id="iron-flex-reverse">
  <template>
    <style>
      .layout.horizontal-reverse,
      .layout.vertical-reverse {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.horizontal-reverse {
        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      }

      .layout.vertical-reverse {
        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      }

      .layout.wrap-reverse {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      }
    </style>
  </template>
</dom-module>
/* Flexbox alignment */
<dom-module id="iron-flex-alignment">
  <template>
    <style>
      /**
       * Alignment in cross axis.
       */
      .layout.start {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.end {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      }

      .layout.baseline {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      }

      /**
       * Alignment in main axis.
       */
      .layout.start-justified {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .layout.end-justified {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      }

      .layout.around-justified {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      }

      .layout.justified {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      }

      /**
       * Self alignment.
       */
      .self-start {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      }

      .self-center {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      }

      .self-end {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      }

      .self-stretch {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      }

      .self-baseline {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      }

      /**
       * multi-line alignment in main axis.
       */
      .layout.start-aligned {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      }

      .layout.end-aligned {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      }

      .layout.center-aligned {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      }

      .layout.between-aligned {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      }

      .layout.around-aligned {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      }
    </style>
  </template>
</dom-module>
/* Non-flexbox positioning helper styles */
<dom-module id="iron-flex-factors">
  <template>
    <style>
      .flex,
      .flex-1 {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-2 {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      }

      .flex-3 {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      }

      .flex-4 {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      }

      .flex-5 {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      }

      .flex-6 {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      }

      .flex-7 {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      }

      .flex-8 {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      }

      .flex-9 {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      }

      .flex-10 {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      }

      .flex-11 {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      }

      .flex-12 {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      }
    </style>
  </template>
</dom-module>
<dom-module id="iron-positioning">
  <template>
    <style>
      .block {
        display: block;
      }

      [hidden] {
        display: none !important;
      }

      .invisible {
        visibility: hidden !important;
      }

      .relative {
        position: relative;
      }

      .fit {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      }

      body.fullbleed {
        margin: 0;
        height: 100vh;
      }

      .scroll {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      }

      /* fixed position */
      .fixed-bottom,
      .fixed-left,
      .fixed-right,
      .fixed-top {
        position: fixed;
      }

      .fixed-top {
        top: 0;
        left: 0;
        right: 0;
      }

      .fixed-right {
        top: 0;
        right: 0;
        bottom: 0;
      }

      .fixed-bottom {
        right: 0;
        bottom: 0;
        left: 0;
      }

      .fixed-left {
        top: 0;
        bottom: 0;
        left: 0;
      }
    </style>
  </template>
</dom-module>
`;

template.setAttribute("style", "display: none;"), document.head.appendChild(template.content);

const template$1 = html`
<custom-style>
  <style is="custom-style">
    [hidden] {
      display: none !important;
    }
  </style>
</custom-style>
<custom-style>
  <style is="custom-style">
    html {

      --layout: {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      };

      --layout-inline: {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      };

      --layout-horizontal: {
        @apply --layout;

        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      };

      --layout-horizontal-reverse: {
        @apply --layout;

        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      };

      --layout-vertical: {
        @apply --layout;

        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      };

      --layout-vertical-reverse: {
        @apply --layout;

        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      };

      --layout-wrap: {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      };

      --layout-wrap-reverse: {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      };

      --layout-flex-auto: {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      };

      --layout-flex-none: {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      };

      --layout-flex: {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      };

      --layout-flex-2: {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      };

      --layout-flex-3: {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      };

      --layout-flex-4: {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      };

      --layout-flex-5: {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      };

      --layout-flex-6: {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      };

      --layout-flex-7: {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      };

      --layout-flex-8: {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      };

      --layout-flex-9: {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      };

      --layout-flex-10: {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      };

      --layout-flex-11: {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      };

      --layout-flex-12: {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      };

      /* alignment in cross axis */

      --layout-start: {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      };

      --layout-center: {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      };

      --layout-end: {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      };

      --layout-baseline: {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      };

      /* alignment in main axis */

      --layout-start-justified: {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      };

      --layout-center-justified: {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      };

      --layout-end-justified: {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      };

      --layout-around-justified: {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      };

      --layout-justified: {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      };

      --layout-center-center: {
        @apply --layout-center;
        @apply --layout-center-justified;
      };

      /* self alignment */

      --layout-self-start: {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      };

      --layout-self-center: {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      };

      --layout-self-end: {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      };

      --layout-self-stretch: {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      };

      --layout-self-baseline: {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      };

      /* multi-line alignment in main axis */

      --layout-start-aligned: {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      };

      --layout-end-aligned: {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      };

      --layout-center-aligned: {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      };

      --layout-between-aligned: {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      };

      --layout-around-aligned: {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      };

      /*******************************
                Other Layout
      *******************************/

      --layout-block: {
        display: block;
      };

      --layout-invisible: {
        visibility: hidden !important;
      };

      --layout-relative: {
        position: relative;
      };

      --layout-fit: {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-scroll: {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      };

      --layout-fullbleed: {
        margin: 0;
        height: 100vh;
      };

      /* fixed position */

      --layout-fixed-top: {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
      };

      --layout-fixed-right: {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
      };

      --layout-fixed-bottom: {
        position: fixed;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-fixed-left: {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
      };

    }
  </style>
</custom-style>`;

template$1.setAttribute("style", "display: none;"), document.head.appendChild(template$1.content);

var style = document.createElement("style");

style.textContent = "[hidden] { display: none !important; }", document.head.appendChild(style), 
Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        overflow: hidden;
        position: relative;
      }

      #baseURIAnchor {
        display: none;
      }

      #sizedImgDiv {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        display: none;
      }

      #img {
        display: block;
        width: var(--iron-image-width, auto);
        height: var(--iron-image-height, auto);
      }

      :host([sizing]) #sizedImgDiv {
        display: block;
      }

      :host([sizing]) #img {
        display: none;
      }

      #placeholder {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        background-color: inherit;
        opacity: 1;

        @apply --iron-image-placeholder;
      }

      #placeholder.faded-out {
        transition: opacity 0.5s linear;
        opacity: 0;
      }
    </style>

    <a id="baseURIAnchor" href="#"></a>
    <div id="sizedImgDiv" role="img" hidden\$="[[_computeImgDivHidden(sizing)]]" aria-hidden\$="[[_computeImgDivARIAHidden(alt)]]" aria-label\$="[[_computeImgDivARIALabel(alt, src)]]"></div>
    <img id="img" alt\$="[[alt]]" hidden\$="[[_computeImgHidden(sizing)]]" crossorigin\$="[[crossorigin]]" on-load="_imgOnLoad" on-error="_imgOnError">
    <div id="placeholder" hidden\$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]" class\$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>
`,
    is: "iron-image",
    properties: {
        src: {
            type: String,
            value: ""
        },
        alt: {
            type: String,
            value: null
        },
        crossorigin: {
            type: String,
            value: null
        },
        preventLoad: {
            type: Boolean,
            value: !1
        },
        sizing: {
            type: String,
            value: null,
            reflectToAttribute: !0
        },
        position: {
            type: String,
            value: "center"
        },
        preload: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: String,
            value: null,
            observer: "_placeholderChanged"
        },
        fade: {
            type: Boolean,
            value: !1
        },
        loaded: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        loading: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        error: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        width: {
            observer: "_widthChanged",
            type: Number,
            value: null
        },
        height: {
            observer: "_heightChanged",
            type: Number,
            value: null
        }
    },
    observers: [ "_transformChanged(sizing, position)", "_loadStateObserver(src, preventLoad)" ],
    created: function() {
        this._resolvedSrc = "";
    },
    _imgOnLoad: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this._setLoading(!1), this._setLoaded(!0), 
        this._setError(!1));
    },
    _imgOnError: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", this._setLoading(!1), this._setLoaded(!1), 
        this._setError(!0));
    },
    _computePlaceholderHidden: function() {
        return !this.preload || !this.fade && !this.loading && this.loaded;
    },
    _computePlaceholderClassName: function() {
        return this.preload && this.fade && !this.loading && this.loaded ? "faded-out" : "";
    },
    _computeImgDivHidden: function() {
        return !this.sizing;
    },
    _computeImgDivARIAHidden: function() {
        return "" === this.alt ? "true" : void 0;
    },
    _computeImgDivARIALabel: function() {
        return null !== this.alt ? this.alt : "" === this.src ? "" : this._resolveSrc(this.src).replace(/[?|#].*/g, "").split("/").pop();
    },
    _computeImgHidden: function() {
        return !!this.sizing;
    },
    _widthChanged: function() {
        this.style.width = isNaN(this.width) ? this.width : this.width + "px";
    },
    _heightChanged: function() {
        this.style.height = isNaN(this.height) ? this.height : this.height + "px";
    },
    _loadStateObserver: function(e, t) {
        var n = this._resolveSrc(e);
        n !== this._resolvedSrc && (this._resolvedSrc = "", this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", "" === e || t ? (this._setLoading(!1), 
        this._setLoaded(!1), this._setError(!1)) : (this._resolvedSrc = n, this.$.img.src = this._resolvedSrc, 
        this.$.sizedImgDiv.style.backgroundImage = 'url("' + this._resolvedSrc + '")', this._setLoading(!0), 
        this._setLoaded(!1), this._setError(!1)));
    },
    _placeholderChanged: function() {
        this.$.placeholder.style.backgroundImage = this.placeholder ? 'url("' + this.placeholder + '")' : "";
    },
    _transformChanged: function() {
        var e = this.$.sizedImgDiv.style, t = this.$.placeholder.style;
        e.backgroundSize = t.backgroundSize = this.sizing, e.backgroundPosition = t.backgroundPosition = this.sizing ? this.position : "", 
        e.backgroundRepeat = t.backgroundRepeat = this.sizing ? "no-repeat" : "";
    },
    _resolveSrc: function(e) {
        var t = resolveUrl(e, this.$.baseURIAnchor.href);
        return "/" === t[0] && (t = (location.origin || location.protocol + "//" + location.host) + t), 
        t;
    }
});

var ORPHANS = new Set();

const IronResizableBehavior = {
    properties: {
        _parentResizable: {
            type: Object,
            observer: "_parentResizableChanged"
        },
        _notifyingDescendant: {
            type: Boolean,
            value: !1
        }
    },
    listeners: {
        "iron-request-resize-notifications": "_onIronRequestResizeNotifications"
    },
    created: function() {
        this._interestedResizables = [], this._boundNotifyResize = this.notifyResize.bind(this), 
        this._boundOnDescendantIronResize = this._onDescendantIronResize.bind(this);
    },
    attached: function() {
        this._requestResizeNotifications();
    },
    detached: function() {
        this._parentResizable ? this._parentResizable.stopResizeNotificationsFor(this) : (ORPHANS.delete(this), 
        window.removeEventListener("resize", this._boundNotifyResize)), this._parentResizable = null;
    },
    notifyResize: function() {
        this.isAttached && (this._interestedResizables.forEach(function(e) {
            this.resizerShouldNotify(e) && this._notifyDescendant(e);
        }, this), this._fireResize());
    },
    assignParentResizable: function(e) {
        this._parentResizable && this._parentResizable.stopResizeNotificationsFor(this), 
        this._parentResizable = e, e && -1 === e._interestedResizables.indexOf(this) && (e._interestedResizables.push(this), 
        e._subscribeIronResize(this));
    },
    stopResizeNotificationsFor: function(e) {
        var t = this._interestedResizables.indexOf(e);
        t > -1 && (this._interestedResizables.splice(t, 1), this._unsubscribeIronResize(e));
    },
    _subscribeIronResize: function(e) {
        e.addEventListener("iron-resize", this._boundOnDescendantIronResize);
    },
    _unsubscribeIronResize: function(e) {
        e.removeEventListener("iron-resize", this._boundOnDescendantIronResize);
    },
    resizerShouldNotify: function(e) {
        return !0;
    },
    _onDescendantIronResize: function(e) {
        this._notifyingDescendant ? e.stopPropagation() : useShadow || this._fireResize();
    },
    _fireResize: function() {
        this.fire("iron-resize", null, {
            node: this,
            bubbles: !1
        });
    },
    _onIronRequestResizeNotifications: function(e) {
        var t = dom(e).rootTarget;
        t !== this && (t.assignParentResizable(this), this._notifyDescendant(t), e.stopPropagation());
    },
    _parentResizableChanged: function(e) {
        e && window.removeEventListener("resize", this._boundNotifyResize);
    },
    _notifyDescendant: function(e) {
        this.isAttached && (this._notifyingDescendant = !0, e.notifyResize(), this._notifyingDescendant = !1);
    },
    _requestResizeNotifications: function() {
        if (this.isAttached) if ("loading" === document.readyState) {
            var e = this._requestResizeNotifications.bind(this);
            document.addEventListener("readystatechange", function t() {
                document.removeEventListener("readystatechange", t), e();
            });
        } else this._findParent(), this._parentResizable ? this._parentResizable._interestedResizables.forEach(function(e) {
            e !== this && e._findParent();
        }, this) : (ORPHANS.forEach(function(e) {
            e !== this && e._findParent();
        }, this), window.addEventListener("resize", this._boundNotifyResize), this.notifyResize());
    },
    _findParent: function() {
        this.assignParentResizable(null), this.fire("iron-request-resize-notifications", null, {
            node: this,
            bubbles: !0,
            cancelable: !0
        }), this._parentResizable ? ORPHANS.delete(this) : ORPHANS.add(this);
    }
};

var ironResizableBehavior = {
    IronResizableBehavior: IronResizableBehavior
};

class IronSelection {
    constructor(e) {
        this.selection = [], this.selectCallback = e;
    }
    get() {
        return this.multi ? this.selection.slice() : this.selection[0];
    }
    clear(e) {
        this.selection.slice().forEach(function(t) {
            (!e || e.indexOf(t) < 0) && this.setItemSelected(t, !1);
        }, this);
    }
    isSelected(e) {
        return this.selection.indexOf(e) >= 0;
    }
    setItemSelected(e, t) {
        if (null != e && t !== this.isSelected(e)) {
            if (t) this.selection.push(e); else {
                var n = this.selection.indexOf(e);
                n >= 0 && this.selection.splice(n, 1);
            }
            this.selectCallback && this.selectCallback(e, t);
        }
    }
    select(e) {
        this.multi ? this.toggle(e) : this.get() !== e && (this.setItemSelected(this.get(), !1), 
        this.setItemSelected(e, !0));
    }
    toggle(e) {
        this.setItemSelected(e, !this.isSelected(e));
    }
}

var ironSelection = {
    IronSelection: IronSelection
};

const IronSelectableBehavior = {
    properties: {
        attrForSelected: {
            type: String,
            value: null
        },
        selected: {
            type: String,
            notify: !0
        },
        selectedItem: {
            type: Object,
            readOnly: !0,
            notify: !0
        },
        activateEvent: {
            type: String,
            value: "tap",
            observer: "_activateEventChanged"
        },
        selectable: String,
        selectedClass: {
            type: String,
            value: "iron-selected"
        },
        selectedAttribute: {
            type: String,
            value: null
        },
        fallbackSelection: {
            type: String,
            value: null
        },
        items: {
            type: Array,
            readOnly: !0,
            notify: !0,
            value: function() {
                return [];
            }
        },
        _excludedLocalNames: {
            type: Object,
            value: function() {
                return {
                    template: 1,
                    "dom-bind": 1,
                    "dom-if": 1,
                    "dom-repeat": 1
                };
            }
        }
    },
    observers: [ "_updateAttrForSelected(attrForSelected)", "_updateSelected(selected)", "_checkFallback(fallbackSelection)" ],
    created: function() {
        this._bindFilterItem = this._filterItem.bind(this), this._selection = new IronSelection(this._applySelection.bind(this));
    },
    attached: function() {
        this._observer = this._observeItems(this), this._addListener(this.activateEvent);
    },
    detached: function() {
        this._observer && dom(this).unobserveNodes(this._observer), this._removeListener(this.activateEvent);
    },
    indexOf: function(e) {
        return this.items ? this.items.indexOf(e) : -1;
    },
    select: function(e) {
        this.selected = e;
    },
    selectPrevious: function() {
        var e = this.items.length, t = e - 1;
        void 0 !== this.selected && (t = (Number(this._valueToIndex(this.selected)) - 1 + e) % e), 
        this.selected = this._indexToValue(t);
    },
    selectNext: function() {
        var e = 0;
        void 0 !== this.selected && (e = (Number(this._valueToIndex(this.selected)) + 1) % this.items.length), 
        this.selected = this._indexToValue(e);
    },
    selectIndex: function(e) {
        this.select(this._indexToValue(e));
    },
    forceSynchronousItemUpdate: function() {
        this._observer && "function" == typeof this._observer.flush ? this._observer.flush() : this._updateItems();
    },
    get _shouldUpdateSelection() {
        return null != this.selected;
    },
    _checkFallback: function() {
        this._updateSelected();
    },
    _addListener: function(e) {
        this.listen(this, e, "_activateHandler");
    },
    _removeListener: function(e) {
        this.unlisten(this, e, "_activateHandler");
    },
    _activateEventChanged: function(e, t) {
        this._removeListener(t), this._addListener(e);
    },
    _updateItems: function() {
        var e = dom(this).queryDistributedElements(this.selectable || "*");
        e = Array.prototype.filter.call(e, this._bindFilterItem), this._setItems(e);
    },
    _updateAttrForSelected: function() {
        this.selectedItem && (this.selected = this._valueForItem(this.selectedItem));
    },
    _updateSelected: function() {
        this._selectSelected(this.selected);
    },
    _selectSelected: function(e) {
        if (this.items) {
            var t = this._valueToItem(this.selected);
            t ? this._selection.select(t) : this._selection.clear(), this.fallbackSelection && this.items.length && void 0 === this._selection.get() && (this.selected = this.fallbackSelection);
        }
    },
    _filterItem: function(e) {
        return !this._excludedLocalNames[e.localName];
    },
    _valueToItem: function(e) {
        return null == e ? null : this.items[this._valueToIndex(e)];
    },
    _valueToIndex: function(e) {
        if (!this.attrForSelected) return Number(e);
        for (var t, n = 0; t = this.items[n]; n++) if (this._valueForItem(t) == e) return n;
    },
    _indexToValue: function(e) {
        if (!this.attrForSelected) return e;
        var t = this.items[e];
        return t ? this._valueForItem(t) : void 0;
    },
    _valueForItem: function(e) {
        if (!e) return null;
        if (!this.attrForSelected) {
            var t = this.indexOf(e);
            return -1 === t ? null : t;
        }
        var n = e[dashToCamelCase(this.attrForSelected)];
        return null != n ? n : e.getAttribute(this.attrForSelected);
    },
    _applySelection: function(e, t) {
        this.selectedClass && this.toggleClass(this.selectedClass, t, e), this.selectedAttribute && this.toggleAttribute(this.selectedAttribute, t, e), 
        this._selectionChange(), this.fire("iron-" + (t ? "select" : "deselect"), {
            item: e
        });
    },
    _selectionChange: function() {
        this._setSelectedItem(this._selection.get());
    },
    _observeItems: function(e) {
        return dom(e).observeNodes(function(e) {
            this._updateItems(), this._updateSelected(), this.fire("iron-items-changed", e, {
                bubbles: !1,
                cancelable: !1
            });
        });
    },
    _activateHandler: function(e) {
        for (var t = e.target, n = this.items; t && t != this; ) {
            var i = n.indexOf(t);
            if (i >= 0) {
                var r = this._indexToValue(i);
                return void this._itemActivate(r, t);
            }
            t = t.parentNode;
        }
    },
    _itemActivate: function(e, t) {
        this.fire("iron-activate", {
            selected: e,
            item: t
        }, {
            cancelable: !0
        }).defaultPrevented || this.select(e);
    }
};

var ironSelectable = {
    IronSelectableBehavior: IronSelectableBehavior
};

const NeonAnimationBehavior = {
    properties: {
        animationTiming: {
            type: Object,
            value: function() {
                return {
                    duration: 500,
                    easing: "cubic-bezier(0.4, 0, 0.2, 1)",
                    fill: "both"
                };
            }
        }
    },
    isNeonAnimation: !0,
    created: function() {
        document.body.animate || console.warn("No web animations detected. This element will not function without a web animations polyfill.");
    },
    timingFromConfig: function(e) {
        if (e.timing) for (var t in e.timing) this.animationTiming[t] = e.timing[t];
        return this.animationTiming;
    },
    setPrefixedProperty: function(e, t, n) {
        for (var i, r = {
            transform: [ "webkitTransform" ],
            transformOrigin: [ "mozTransformOrigin", "webkitTransformOrigin" ]
        }[t], o = 0; i = r[o]; o++) e.style[i] = n;
        e.style[t] = n;
    },
    complete: function(e) {}
};

var neonAnimationBehavior = {
    NeonAnimationBehavior: NeonAnimationBehavior
};

Polymer({
    is: "cascaded-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        this._animations = [];
        var t = e.nodes, n = [], i = e.nodeDelay || 50;
        e.timing = e.timing || {}, e.timing.delay = e.timing.delay || 0;
        for (var r, o, s = e.timing.delay, a = 0; o = t[a]; a++) {
            e.timing.delay += i, e.node = o;
            var l = document.createElement(e.animation);
            if (!l.isNeonAnimation) {
                console.warn(this.is + ":", e.animation, "not found!"), r = !0;
                break;
            }
            var c = l.configure(e);
            this._animations.push(l), n.push(c);
        }
        if (e.timing.delay = s, e.node = null, !r) return this._effect = new GroupEffect(n), 
        this._effect;
    },
    complete: function() {
        for (var e, t = 0; e = this._animations[t]; t++) e.complete(e.config);
    }
}), Polymer({
    is: "fade-in-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "0"
        }, {
            opacity: "1"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "fade-out-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "1"
        }, {
            opacity: "0"
        } ], this.timingFromConfig(e)), this._effect;
    }
});

const NeonSharedElementAnimationBehaviorImpl = {
    properties: {
        sharedElements: {
            type: Object
        }
    },
    findSharedElements: function(e) {
        var t = e.fromPage, n = e.toPage;
        if (!t || !n) return console.warn(this.is + ":", t ? "toPage" : "fromPage", "is undefined!"), 
        null;
        if (!t.sharedElements || !n.sharedElements) return console.warn(this.is + ":", "sharedElements are undefined for", t.sharedElements ? n : t), 
        null;
        var i = t.sharedElements[e.id], r = n.sharedElements[e.id];
        return i && r ? (this.sharedElements = {
            from: i,
            to: r
        }, this.sharedElements) : (console.warn(this.is + ":", "sharedElement with id", e.id, "not found in", i ? n : t), 
        null);
    }
}, NeonSharedElementAnimationBehavior = [ NeonAnimationBehavior, NeonSharedElementAnimationBehaviorImpl ];

var neonSharedElementAnimationBehavior = {
    NeonSharedElementAnimationBehaviorImpl: NeonSharedElementAnimationBehaviorImpl,
    NeonSharedElementAnimationBehavior: NeonSharedElementAnimationBehavior
};

Polymer({
    is: "hero-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t = this.findSharedElements(e);
        if (t) {
            var n = t.from.getBoundingClientRect(), i = t.to.getBoundingClientRect(), r = n.left - i.left, o = n.top - i.top, s = n.width / i.width, a = n.height / i.height;
            return this._effect = new KeyframeEffect(t.to, [ {
                transform: "translate(" + r + "px," + o + "px) scale(" + s + "," + a + ")"
            }, {
                transform: "none"
            } ], this.timingFromConfig(e)), this.setPrefixedProperty(t.to, "transformOrigin", "0 0"), 
            t.to.style.zIndex = 1e4, t.from.style.visibility = "hidden", this._effect;
        }
    },
    complete: function(e) {
        var t = this.findSharedElements(e);
        if (!t) return null;
        t.to.style.zIndex = "", t.from.style.visibility = "";
    }
}), Polymer({
    is: "opaque-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "1"
        }, {
            opacity: "1"
        } ], this.timingFromConfig(e)), t.style.opacity = "0", this._effect;
    },
    complete: function(e) {
        e.node.style.opacity = "";
    }
}), Polymer({
    is: "reverse-ripple-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t, n, i = this.findSharedElements(e);
        if (!i) return null;
        var r = i.from.getBoundingClientRect();
        if (e.gesture) t = e.gesture.x - (r.left + r.width / 2), n = e.gesture.y - (r.top + r.height / 2); else {
            var o = i.to.getBoundingClientRect();
            t = o.left + o.width / 2 - (r.left + r.width / 2), n = o.top + o.height / 2 - (r.top + r.height / 2);
        }
        var s = "translate(" + t + "px," + n + "px)", a = Math.max(r.width + 2 * Math.abs(t), r.height + 2 * Math.abs(n)), l = Math.sqrt(2 * a * a), c = "scale(" + l / r.width + "," + l / r.height + ")";
        return this._effect = new KeyframeEffect(i.from, [ {
            transform: s + " " + c
        }, {
            transform: s + " scale(0)"
        } ], this.timingFromConfig(e)), this.setPrefixedProperty(i.from, "transformOrigin", "50% 50%"), 
        i.from.style.borderRadius = "50%", this._effect;
    },
    complete: function() {
        this.sharedElements && (this.setPrefixedProperty(this.sharedElements.from, "transformOrigin", ""), 
        this.sharedElements.from.style.borderRadius = "");
    }
}), Polymer({
    is: "ripple-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t, n, i = this.findSharedElements(e);
        if (!i) return null;
        var r = i.to.getBoundingClientRect();
        if (e.gesture) t = e.gesture.x - (r.left + r.width / 2), n = e.gesture.y - (r.top + r.height / 2); else {
            var o = i.from.getBoundingClientRect();
            t = o.left + o.width / 2 - (r.left + r.width / 2), n = o.top + o.height / 2 - (r.top + r.height / 2);
        }
        var s = "translate(" + t + "px," + n + "px)", a = Math.max(r.width + 2 * Math.abs(t), r.height + 2 * Math.abs(n)), l = Math.sqrt(2 * a * a), c = "scale(" + l / r.width + "," + l / r.height + ")";
        return this._effect = new KeyframeEffect(i.to, [ {
            transform: s + " scale(0)"
        }, {
            transform: s + " " + c
        } ], this.timingFromConfig(e)), this.setPrefixedProperty(i.to, "transformOrigin", "50% 50%"), 
        i.to.style.borderRadius = "50%", this._effect;
    },
    complete: function() {
        this.sharedElements && (this.setPrefixedProperty(this.sharedElements.to, "transformOrigin", ""), 
        this.sharedElements.to.style.borderRadius = "");
    }
}), Polymer({
    is: "scale-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, n = "scale(0, 0)";
        return "x" === e.axis ? n = "scale(0, 1)" : "y" === e.axis && (n = "scale(1, 0)"), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(1,1)"
        }, {
            transform: n
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
}), Polymer({
    is: "scale-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, n = "scale(0)";
        return "x" === e.axis ? n = "scale(0, 1)" : "y" === e.axis && (n = "scale(1, 0)"), 
        this._effect = new KeyframeEffect(t, [ {
            transform: n
        }, {
            transform: "scale(1, 1)"
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
}), Polymer({
    is: "slide-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(0%)"
        }, {
            transform: "translateY(100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-bottom-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(100%)"
        }, {
            transform: "translateY(0)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-left-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateX(-100%)"
        }, {
            transform: "none"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-right-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateX(100%)"
        }, {
            transform: "none"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-top-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(-100%)"
        }, {
            transform: "translateY(0%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-left-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "none"
        }, {
            transform: "translateX(-100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-right-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "none"
        }, {
            transform: "translateX(100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translate(0)"
        }, {
            transform: "translateY(-100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "transform-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, n = e.transformFrom || "none", i = e.transformTo || "none";
        return this._effect = new KeyframeEffect(t, [ {
            transform: n
        }, {
            transform: i
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
});

const NeonAnimatableBehavior = {
    properties: {
        animationConfig: {
            type: Object
        },
        entryAnimation: {
            observer: "_entryAnimationChanged",
            type: String
        },
        exitAnimation: {
            observer: "_exitAnimationChanged",
            type: String
        }
    },
    _entryAnimationChanged: function() {
        this.animationConfig = this.animationConfig || {}, this.animationConfig.entry = [ {
            name: this.entryAnimation,
            node: this
        } ];
    },
    _exitAnimationChanged: function() {
        this.animationConfig = this.animationConfig || {}, this.animationConfig.exit = [ {
            name: this.exitAnimation,
            node: this
        } ];
    },
    _copyProperties: function(e, t) {
        for (var n in t) e[n] = t[n];
    },
    _cloneConfig: function(e) {
        var t = {
            isClone: !0
        };
        return this._copyProperties(t, e), t;
    },
    _getAnimationConfigRecursive: function(e, t, n) {
        var i;
        if (this.animationConfig) if (this.animationConfig.value && "function" == typeof this.animationConfig.value) this._warn(this._logf("playAnimation", "Please put 'animationConfig' inside of your components 'properties' object instead of outside of it.")); else if (i = e ? this.animationConfig[e] : this.animationConfig, 
        Array.isArray(i) || (i = [ i ]), i) for (var r, o = 0; r = i[o]; o++) if (r.animatable) r.animatable._getAnimationConfigRecursive(r.type || e, t, n); else if (r.id) {
            var s = t[r.id];
            s ? (s.isClone || (t[r.id] = this._cloneConfig(s), s = t[r.id]), this._copyProperties(s, r)) : t[r.id] = r;
        } else n.push(r);
    },
    getAnimationConfig: function(e) {
        var t = {}, n = [];
        for (var i in this._getAnimationConfigRecursive(e, t, n), t) n.push(t[i]);
        return n;
    }
};

var neonAnimatableBehavior = {
    NeonAnimatableBehavior: NeonAnimatableBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }
    </style>

    <slot></slot>
  `,
    is: "neon-animatable",
    behaviors: [ NeonAnimatableBehavior, IronResizableBehavior ]
});

const NeonAnimationRunnerBehaviorImpl = {
    _configureAnimations: function(e) {
        var t = [], n = [];
        if (e.length > 0) for (let t, i = 0; t = e[i]; i++) {
            let e = document.createElement(t.name);
            if (e.isNeonAnimation) {
                let i = null;
                e.configure || (e.configure = function(e) {
                    return null;
                }), i = e.configure(t), n.push({
                    result: i,
                    config: t,
                    neonAnimation: e
                });
            } else console.warn(this.is + ":", t.name, "not found!");
        }
        for (var i = 0; i < n.length; i++) {
            let e = n[i].result, r = n[i].config, o = n[i].neonAnimation;
            try {
                "function" != typeof e.cancel && (e = document.timeline.play(e));
            } catch (t) {
                e = null, console.warn("Couldnt play", "(", r.name, ").", t);
            }
            e && t.push({
                neonAnimation: o,
                config: r,
                animation: e
            });
        }
        return t;
    },
    _shouldComplete: function(e) {
        for (var t = !0, n = 0; n < e.length; n++) if ("finished" != e[n].animation.playState) {
            t = !1;
            break;
        }
        return t;
    },
    _complete: function(e) {
        for (var t = 0; t < e.length; t++) e[t].neonAnimation.complete(e[t].config);
        for (t = 0; t < e.length; t++) e[t].animation.cancel();
    },
    playAnimation: function(e, t) {
        var n = this.getAnimationConfig(e);
        if (n) {
            this._active = this._active || {}, this._active[e] && (this._complete(this._active[e]), 
            delete this._active[e]);
            var i = this._configureAnimations(n);
            if (0 != i.length) {
                this._active[e] = i;
                for (var r = 0; r < i.length; r++) i[r].animation.onfinish = function() {
                    this._shouldComplete(i) && (this._complete(i), delete this._active[e], this.fire("neon-animation-finish", t, {
                        bubbles: !1
                    }));
                }.bind(this);
            } else this.fire("neon-animation-finish", t, {
                bubbles: !1
            });
        }
    },
    cancelAnimation: function() {
        for (var e in this._active) {
            var t = this._active[e];
            for (var n in t) t[n].animation.cancel();
        }
        this._active = {};
    }
}, NeonAnimationRunnerBehavior = [ NeonAnimatableBehavior, NeonAnimationRunnerBehaviorImpl ];

var neonAnimationRunnerBehavior = {
    NeonAnimationRunnerBehaviorImpl: NeonAnimationRunnerBehaviorImpl,
    NeonAnimationRunnerBehavior: NeonAnimationRunnerBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        position: relative;
      }

      :host > ::slotted(*) {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
      }

      :host > ::slotted(:not(.iron-selected):not(.neon-animating))
       {
        display: none !important;
      }

      :host > ::slotted(.neon-animating) {
        pointer-events: none;
      }
    </style>

    <slot id="content"></slot>
  `,
    is: "neon-animated-pages",
    behaviors: [ IronResizableBehavior, IronSelectableBehavior, NeonAnimationRunnerBehavior ],
    properties: {
        activateEvent: {
            type: String,
            value: ""
        },
        animateInitialSelection: {
            type: Boolean,
            value: !1
        }
    },
    listeners: {
        "iron-select": "_onIronSelect",
        "neon-animation-finish": "_onNeonAnimationFinish"
    },
    _onIronSelect: function(e) {
        var t = e.detail.item;
        if (!(this.items.indexOf(t) < 0)) {
            var n = this._valueToItem(this._prevSelected) || !1;
            this._prevSelected = this.selected, n || this.animateInitialSelection ? (this.animationConfig = [], 
            this.entryAnimation ? this.animationConfig.push({
                name: this.entryAnimation,
                node: t
            }) : t.getAnimationConfig && this.animationConfig.push({
                animatable: t,
                type: "entry"
            }), n && (n.classList.contains("neon-animating") && (this._squelchNextFinishEvent = !0, 
            this.cancelAnimation(), this._completeSelectedChanged(), this._squelchNextFinishEvent = !1), 
            this.exitAnimation ? this.animationConfig.push({
                name: this.exitAnimation,
                node: n
            }) : n.getAnimationConfig && this.animationConfig.push({
                animatable: n,
                type: "exit"
            }), n.classList.add("neon-animating")), t.classList.add("neon-animating"), this.animationConfig.length >= 1 ? this.isAttached ? this.playAnimation(void 0, {
                fromPage: n,
                toPage: t
            }) : this.async(function() {
                this.playAnimation(void 0, {
                    fromPage: null,
                    toPage: t
                });
            }) : this._completeSelectedChanged(n, t)) : this._completeSelectedChanged();
        }
    },
    _completeSelectedChanged: function(e, t) {
        if (t && t.classList.remove("neon-animating"), e && e.classList.remove("neon-animating"), 
        !t || !e) for (var n, i = dom(this.$.content).getDistributedNodes(), r = 0; n = i[r]; r++) n.classList && n.classList.remove("neon-animating");
        this.async(this._notifyPageResize);
    },
    _onNeonAnimationFinish: function(e) {
        this._squelchNextFinishEvent ? this._squelchNextFinishEvent = !1 : this._completeSelectedChanged(e.detail.fromPage, e.detail.toPage);
    },
    _notifyPageResize: function() {
        var e = this.selectedItem || this._valueToItem(this.selected);
        this.resizerShouldNotify = function(t) {
            return t == e;
        }, this.notifyResize();
    }
});

const PaperItemBehaviorImpl = {
    hostAttributes: {
        role: "option",
        tabindex: "0"
    }
}, PaperItemBehavior = [ IronButtonState, IronControlState, PaperItemBehaviorImpl ];

var paperItemBehavior = {
    PaperItemBehaviorImpl: PaperItemBehaviorImpl,
    PaperItemBehavior: PaperItemBehavior
};

const template$2 = html`
<custom-style>
  <style is="custom-style">
    html {

      /* Material Design color palette for Google products */

      --google-red-100: #f4c7c3;
      --google-red-300: #e67c73;
      --google-red-500: #db4437;
      --google-red-700: #c53929;

      --google-blue-100: #c6dafc;
      --google-blue-300: #7baaf7;
      --google-blue-500: #4285f4;
      --google-blue-700: #3367d6;

      --google-green-100: #b7e1cd;
      --google-green-300: #57bb8a;
      --google-green-500: #0f9d58;
      --google-green-700: #0b8043;

      --google-yellow-100: #fce8b2;
      --google-yellow-300: #f7cb4d;
      --google-yellow-500: #f4b400;
      --google-yellow-700: #f09300;

      --google-grey-100: #f5f5f5;
      --google-grey-300: #e0e0e0;
      --google-grey-500: #9e9e9e;
      --google-grey-700: #616161;

      /* Material Design color palette from online spec document */

      --paper-red-50: #ffebee;
      --paper-red-100: #ffcdd2;
      --paper-red-200: #ef9a9a;
      --paper-red-300: #e57373;
      --paper-red-400: #ef5350;
      --paper-red-500: #f44336;
      --paper-red-600: #e53935;
      --paper-red-700: #d32f2f;
      --paper-red-800: #c62828;
      --paper-red-900: #b71c1c;
      --paper-red-a100: #ff8a80;
      --paper-red-a200: #ff5252;
      --paper-red-a400: #ff1744;
      --paper-red-a700: #d50000;

      --paper-pink-50: #fce4ec;
      --paper-pink-100: #f8bbd0;
      --paper-pink-200: #f48fb1;
      --paper-pink-300: #f06292;
      --paper-pink-400: #ec407a;
      --paper-pink-500: #e91e63;
      --paper-pink-600: #d81b60;
      --paper-pink-700: #c2185b;
      --paper-pink-800: #ad1457;
      --paper-pink-900: #880e4f;
      --paper-pink-a100: #ff80ab;
      --paper-pink-a200: #ff4081;
      --paper-pink-a400: #f50057;
      --paper-pink-a700: #c51162;

      --paper-purple-50: #f3e5f5;
      --paper-purple-100: #e1bee7;
      --paper-purple-200: #ce93d8;
      --paper-purple-300: #ba68c8;
      --paper-purple-400: #ab47bc;
      --paper-purple-500: #9c27b0;
      --paper-purple-600: #8e24aa;
      --paper-purple-700: #7b1fa2;
      --paper-purple-800: #6a1b9a;
      --paper-purple-900: #4a148c;
      --paper-purple-a100: #ea80fc;
      --paper-purple-a200: #e040fb;
      --paper-purple-a400: #d500f9;
      --paper-purple-a700: #aa00ff;

      --paper-deep-purple-50: #ede7f6;
      --paper-deep-purple-100: #d1c4e9;
      --paper-deep-purple-200: #b39ddb;
      --paper-deep-purple-300: #9575cd;
      --paper-deep-purple-400: #7e57c2;
      --paper-deep-purple-500: #673ab7;
      --paper-deep-purple-600: #5e35b1;
      --paper-deep-purple-700: #512da8;
      --paper-deep-purple-800: #4527a0;
      --paper-deep-purple-900: #311b92;
      --paper-deep-purple-a100: #b388ff;
      --paper-deep-purple-a200: #7c4dff;
      --paper-deep-purple-a400: #651fff;
      --paper-deep-purple-a700: #6200ea;

      --paper-indigo-50: #e8eaf6;
      --paper-indigo-100: #c5cae9;
      --paper-indigo-200: #9fa8da;
      --paper-indigo-300: #7986cb;
      --paper-indigo-400: #5c6bc0;
      --paper-indigo-500: #3f51b5;
      --paper-indigo-600: #3949ab;
      --paper-indigo-700: #303f9f;
      --paper-indigo-800: #283593;
      --paper-indigo-900: #1a237e;
      --paper-indigo-a100: #8c9eff;
      --paper-indigo-a200: #536dfe;
      --paper-indigo-a400: #3d5afe;
      --paper-indigo-a700: #304ffe;

      --paper-blue-50: #e3f2fd;
      --paper-blue-100: #bbdefb;
      --paper-blue-200: #90caf9;
      --paper-blue-300: #64b5f6;
      --paper-blue-400: #42a5f5;
      --paper-blue-500: #2196f3;
      --paper-blue-600: #1e88e5;
      --paper-blue-700: #1976d2;
      --paper-blue-800: #1565c0;
      --paper-blue-900: #0d47a1;
      --paper-blue-a100: #82b1ff;
      --paper-blue-a200: #448aff;
      --paper-blue-a400: #2979ff;
      --paper-blue-a700: #2962ff;

      --paper-light-blue-50: #e1f5fe;
      --paper-light-blue-100: #b3e5fc;
      --paper-light-blue-200: #81d4fa;
      --paper-light-blue-300: #4fc3f7;
      --paper-light-blue-400: #29b6f6;
      --paper-light-blue-500: #03a9f4;
      --paper-light-blue-600: #039be5;
      --paper-light-blue-700: #0288d1;
      --paper-light-blue-800: #0277bd;
      --paper-light-blue-900: #01579b;
      --paper-light-blue-a100: #80d8ff;
      --paper-light-blue-a200: #40c4ff;
      --paper-light-blue-a400: #00b0ff;
      --paper-light-blue-a700: #0091ea;

      --paper-cyan-50: #e0f7fa;
      --paper-cyan-100: #b2ebf2;
      --paper-cyan-200: #80deea;
      --paper-cyan-300: #4dd0e1;
      --paper-cyan-400: #26c6da;
      --paper-cyan-500: #00bcd4;
      --paper-cyan-600: #00acc1;
      --paper-cyan-700: #0097a7;
      --paper-cyan-800: #00838f;
      --paper-cyan-900: #006064;
      --paper-cyan-a100: #84ffff;
      --paper-cyan-a200: #18ffff;
      --paper-cyan-a400: #00e5ff;
      --paper-cyan-a700: #00b8d4;

      --paper-teal-50: #e0f2f1;
      --paper-teal-100: #b2dfdb;
      --paper-teal-200: #80cbc4;
      --paper-teal-300: #4db6ac;
      --paper-teal-400: #26a69a;
      --paper-teal-500: #009688;
      --paper-teal-600: #00897b;
      --paper-teal-700: #00796b;
      --paper-teal-800: #00695c;
      --paper-teal-900: #004d40;
      --paper-teal-a100: #a7ffeb;
      --paper-teal-a200: #64ffda;
      --paper-teal-a400: #1de9b6;
      --paper-teal-a700: #00bfa5;

      --paper-green-50: #e8f5e9;
      --paper-green-100: #c8e6c9;
      --paper-green-200: #a5d6a7;
      --paper-green-300: #81c784;
      --paper-green-400: #66bb6a;
      --paper-green-500: #4caf50;
      --paper-green-600: #43a047;
      --paper-green-700: #388e3c;
      --paper-green-800: #2e7d32;
      --paper-green-900: #1b5e20;
      --paper-green-a100: #b9f6ca;
      --paper-green-a200: #69f0ae;
      --paper-green-a400: #00e676;
      --paper-green-a700: #00c853;

      --paper-light-green-50: #f1f8e9;
      --paper-light-green-100: #dcedc8;
      --paper-light-green-200: #c5e1a5;
      --paper-light-green-300: #aed581;
      --paper-light-green-400: #9ccc65;
      --paper-light-green-500: #8bc34a;
      --paper-light-green-600: #7cb342;
      --paper-light-green-700: #689f38;
      --paper-light-green-800: #558b2f;
      --paper-light-green-900: #33691e;
      --paper-light-green-a100: #ccff90;
      --paper-light-green-a200: #b2ff59;
      --paper-light-green-a400: #76ff03;
      --paper-light-green-a700: #64dd17;

      --paper-lime-50: #f9fbe7;
      --paper-lime-100: #f0f4c3;
      --paper-lime-200: #e6ee9c;
      --paper-lime-300: #dce775;
      --paper-lime-400: #d4e157;
      --paper-lime-500: #cddc39;
      --paper-lime-600: #c0ca33;
      --paper-lime-700: #afb42b;
      --paper-lime-800: #9e9d24;
      --paper-lime-900: #827717;
      --paper-lime-a100: #f4ff81;
      --paper-lime-a200: #eeff41;
      --paper-lime-a400: #c6ff00;
      --paper-lime-a700: #aeea00;

      --paper-yellow-50: #fffde7;
      --paper-yellow-100: #fff9c4;
      --paper-yellow-200: #fff59d;
      --paper-yellow-300: #fff176;
      --paper-yellow-400: #ffee58;
      --paper-yellow-500: #ffeb3b;
      --paper-yellow-600: #fdd835;
      --paper-yellow-700: #fbc02d;
      --paper-yellow-800: #f9a825;
      --paper-yellow-900: #f57f17;
      --paper-yellow-a100: #ffff8d;
      --paper-yellow-a200: #ffff00;
      --paper-yellow-a400: #ffea00;
      --paper-yellow-a700: #ffd600;

      --paper-amber-50: #fff8e1;
      --paper-amber-100: #ffecb3;
      --paper-amber-200: #ffe082;
      --paper-amber-300: #ffd54f;
      --paper-amber-400: #ffca28;
      --paper-amber-500: #ffc107;
      --paper-amber-600: #ffb300;
      --paper-amber-700: #ffa000;
      --paper-amber-800: #ff8f00;
      --paper-amber-900: #ff6f00;
      --paper-amber-a100: #ffe57f;
      --paper-amber-a200: #ffd740;
      --paper-amber-a400: #ffc400;
      --paper-amber-a700: #ffab00;

      --paper-orange-50: #fff3e0;
      --paper-orange-100: #ffe0b2;
      --paper-orange-200: #ffcc80;
      --paper-orange-300: #ffb74d;
      --paper-orange-400: #ffa726;
      --paper-orange-500: #ff9800;
      --paper-orange-600: #fb8c00;
      --paper-orange-700: #f57c00;
      --paper-orange-800: #ef6c00;
      --paper-orange-900: #e65100;
      --paper-orange-a100: #ffd180;
      --paper-orange-a200: #ffab40;
      --paper-orange-a400: #ff9100;
      --paper-orange-a700: #ff6500;

      --paper-deep-orange-50: #fbe9e7;
      --paper-deep-orange-100: #ffccbc;
      --paper-deep-orange-200: #ffab91;
      --paper-deep-orange-300: #ff8a65;
      --paper-deep-orange-400: #ff7043;
      --paper-deep-orange-500: #ff5722;
      --paper-deep-orange-600: #f4511e;
      --paper-deep-orange-700: #e64a19;
      --paper-deep-orange-800: #d84315;
      --paper-deep-orange-900: #bf360c;
      --paper-deep-orange-a100: #ff9e80;
      --paper-deep-orange-a200: #ff6e40;
      --paper-deep-orange-a400: #ff3d00;
      --paper-deep-orange-a700: #dd2c00;

      --paper-brown-50: #efebe9;
      --paper-brown-100: #d7ccc8;
      --paper-brown-200: #bcaaa4;
      --paper-brown-300: #a1887f;
      --paper-brown-400: #8d6e63;
      --paper-brown-500: #795548;
      --paper-brown-600: #6d4c41;
      --paper-brown-700: #5d4037;
      --paper-brown-800: #4e342e;
      --paper-brown-900: #3e2723;

      --paper-grey-50: #fafafa;
      --paper-grey-100: #f5f5f5;
      --paper-grey-200: #eeeeee;
      --paper-grey-300: #e0e0e0;
      --paper-grey-400: #bdbdbd;
      --paper-grey-500: #9e9e9e;
      --paper-grey-600: #757575;
      --paper-grey-700: #616161;
      --paper-grey-800: #424242;
      --paper-grey-900: #212121;

      --paper-blue-grey-50: #eceff1;
      --paper-blue-grey-100: #cfd8dc;
      --paper-blue-grey-200: #b0bec5;
      --paper-blue-grey-300: #90a4ae;
      --paper-blue-grey-400: #78909c;
      --paper-blue-grey-500: #607d8b;
      --paper-blue-grey-600: #546e7a;
      --paper-blue-grey-700: #455a64;
      --paper-blue-grey-800: #37474f;
      --paper-blue-grey-900: #263238;

      /* opacity for dark text on a light background */
      --dark-divider-opacity: 0.12;
      --dark-disabled-opacity: 0.38; /* or hint text or icon */
      --dark-secondary-opacity: 0.54;
      --dark-primary-opacity: 0.87;

      /* opacity for light text on a dark background */
      --light-divider-opacity: 0.12;
      --light-disabled-opacity: 0.3; /* or hint text or icon */
      --light-secondary-opacity: 0.7;
      --light-primary-opacity: 1.0;

    }

  </style>
</custom-style>
`;

template$2.setAttribute("style", "display: none;"), document.head.appendChild(template$2.content);

const template$3 = html`
<custom-style>
  <style is="custom-style">
    html {
      /*
       * You can use these generic variables in your elements for easy theming.
       * For example, if all your elements use \`--primary-text-color\` as its main
       * color, then switching from a light to a dark theme is just a matter of
       * changing the value of \`--primary-text-color\` in your application.
       */
      --primary-text-color: var(--light-theme-text-color);
      --primary-background-color: var(--light-theme-background-color);
      --secondary-text-color: var(--light-theme-secondary-color);
      --disabled-text-color: var(--light-theme-disabled-color);
      --divider-color: var(--light-theme-divider-color);
      --error-color: var(--paper-deep-orange-a700);

      /*
       * Primary and accent colors. Also see color.js for more colors.
       */
      --primary-color: var(--paper-indigo-500);
      --light-primary-color: var(--paper-indigo-100);
      --dark-primary-color: var(--paper-indigo-700);

      --accent-color: var(--paper-pink-a200);
      --light-accent-color: var(--paper-pink-a100);
      --dark-accent-color: var(--paper-pink-a400);


      /*
       * Material Design Light background theme
       */
      --light-theme-background-color: #ffffff;
      --light-theme-base-color: #000000;
      --light-theme-text-color: var(--paper-grey-900);
      --light-theme-secondary-color: #737373;  /* for secondary text and icons */
      --light-theme-disabled-color: #9b9b9b;  /* disabled/hint text */
      --light-theme-divider-color: #dbdbdb;

      /*
       * Material Design Dark background theme
       */
      --dark-theme-background-color: var(--paper-grey-900);
      --dark-theme-base-color: #ffffff;
      --dark-theme-text-color: #ffffff;
      --dark-theme-secondary-color: #bcbcbc;  /* for secondary text and icons */
      --dark-theme-disabled-color: #646464;  /* disabled/hint text */
      --dark-theme-divider-color: #3c3c3c;

      /*
       * Deprecated values because of their confusing names.
       */
      --text-primary-color: var(--dark-theme-text-color);
      --default-primary-color: var(--primary-color);
    }
  </style>
</custom-style>`;

template$3.setAttribute("style", "display: none;"), document.head.appendChild(template$3.content);

const template$4 = html`<custom-style>
  <style is="custom-style">
    html {

      /* Shared Styles */
      --paper-font-common-base: {
        font-family: 'Roboto', 'Noto', sans-serif;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-code: {
        font-family: 'Roboto Mono', 'Consolas', 'Menlo', monospace;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-expensive-kerning: {
        text-rendering: optimizeLegibility;
      };

      --paper-font-common-nowrap: {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      };

      /* Material Font Styles */

      --paper-font-display4: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 112px;
        font-weight: 300;
        letter-spacing: -.044em;
        line-height: 120px;
      };

      --paper-font-display3: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 56px;
        font-weight: 400;
        letter-spacing: -.026em;
        line-height: 60px;
      };

      --paper-font-display2: {
        @apply --paper-font-common-base;

        font-size: 45px;
        font-weight: 400;
        letter-spacing: -.018em;
        line-height: 48px;
      };

      --paper-font-display1: {
        @apply --paper-font-common-base;

        font-size: 34px;
        font-weight: 400;
        letter-spacing: -.01em;
        line-height: 40px;
      };

      --paper-font-headline: {
        @apply --paper-font-common-base;

        font-size: 24px;
        font-weight: 400;
        letter-spacing: -.012em;
        line-height: 32px;
      };

      --paper-font-title: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 20px;
        font-weight: 500;
        line-height: 28px;
      };

      --paper-font-subhead: {
        @apply --paper-font-common-base;

        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
      };

      --paper-font-body2: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-body1: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
      };

      --paper-font-caption: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 12px;
        font-weight: 400;
        letter-spacing: 0.011em;
        line-height: 20px;
      };

      --paper-font-menu: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 13px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-button: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 14px;
        font-weight: 500;
        letter-spacing: 0.018em;
        line-height: 24px;
        text-transform: uppercase;
      };

      --paper-font-code2: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 700;
        line-height: 20px;
      };

      --paper-font-code1: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
      };

    }

  </style>
</custom-style>`;

template$4.setAttribute("style", "display: none;"), document.head.appendChild(template$4.content);

const $_documentContainer = document.createElement("template");

$_documentContainer.setAttribute("style", "display: none;"), $_documentContainer.innerHTML = "<dom-module id=\"paper-item-shared-styles\">\n  <template>\n    <style>\n      :host, .paper-item {\n        display: block;\n        position: relative;\n        min-height: var(--paper-item-min-height, 48px);\n        padding: 0px 16px;\n      }\n\n      .paper-item {\n        @apply --paper-font-subhead;\n        border:none;\n        outline: none;\n        background: white;\n        width: 100%;\n        text-align: left;\n      }\n\n      :host([hidden]), .paper-item[hidden] {\n        display: none !important;\n      }\n\n      :host(.iron-selected), .paper-item.iron-selected {\n        font-weight: var(--paper-item-selected-weight, bold);\n\n        @apply --paper-item-selected;\n      }\n\n      :host([disabled]), .paper-item[disabled] {\n        color: var(--paper-item-disabled-color, var(--disabled-text-color));\n\n        @apply --paper-item-disabled;\n      }\n\n      :host(:focus), .paper-item:focus {\n        position: relative;\n        outline: 0;\n\n        @apply --paper-item-focused;\n      }\n\n      :host(:focus):before, .paper-item:focus:before {\n        @apply --layout-fit;\n\n        background: currentColor;\n        content: '';\n        opacity: var(--dark-divider-opacity);\n        pointer-events: none;\n\n        @apply --paper-item-focused-before;\n      }\n    </style>\n  </template>\n</dom-module>", 
document.head.appendChild($_documentContainer.content), Polymer({
    _template: html`
    <style include="paper-item-shared-styles">
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
      }
    </style>
    <slot></slot>
`,
    is: "paper-item",
    behaviors: [ PaperItemBehavior ]
});

const chromep$2 = new ChromePromise();

async function getToken(e = !1, t = null) {
    const n = {
        interactive: e
    };
    t && t.length && (n.scopes = t);
    const i = await chromep$2.identity.getAuthToken(n);
    return Promise.resolve(i);
}

async function removeCachedToken(e = !1, t = "", n = null) {
    let i = t;
    return isWhiteSpace(i) && (i = await getToken(e, n)), await chromep$2.identity.removeCachedAuthToken({
        token: i
    }), Promise.resolve(i);
}

async function isSignedIn() {
    let e = !0;
    try {
        await chromep$2.identity.getAuthToken({
            interactive: !1
        });
    } catch (t) {
        t.message.match(/not signed in/) && (e = !1);
    }
    return Promise.resolve(e);
}

async function isRevoked() {
    let e = !1;
    try {
        await chromep$2.identity.getAuthToken({
            interactive: !1
        });
    } catch (t) {
        t.message.match(/OAuth2 not granted or revoked/) && (e = !0);
    }
    return Promise.resolve(e);
}

var auth = {
    getToken: getToken,
    removeCachedToken: removeCachedToken,
    isSignedIn: isSignedIn,
    isRevoked: isRevoked
};

const _AUTH_HEADER = "Authorization", _BEARER = "Bearer", _MAX_RETRIES = 4, _DELAY = 1e3, CONFIG = {
    isAuth: !1,
    retryToken: !1,
    interactive: !1,
    token: null,
    backoff: !0,
    maxRetries: 4,
    body: null
};

async function doGet(e, t = CONFIG) {
    const n = {
        method: "GET",
        headers: new Headers({})
    }, i = await _doIt(e, n, t);
    return Promise.resolve(i);
}

async function doPost(e, t = CONFIG) {
    const n = {
        method: "POST",
        headers: new Headers({})
    }, i = await _doIt(e, n, t);
    return Promise.resolve(i);
}

async function _processResponse(e, t, n, i, r) {
    if (e.ok) return Promise.resolve(e.json());
    if (r >= i.maxRetries) throw _getError(e);
    const o = e.status;
    if (i.backoff && o >= 500 && o < 600) {
        const e = await _retry(t, n, i, r);
        return Promise.resolve(e);
    }
    if (i.isAuth && i.token && i.retryToken && 401 === o) {
        const e = await _retryToken(t, n, i, r);
        return Promise.resolve(e);
    }
    if (i.isAuth && i.interactive && i.token && i.retryToken && 403 === o) {
        const e = await _retryToken(t, n, i, r);
        return Promise.resolve(e);
    }
    throw _getError(e);
}

function _getError(e) {
    let t = "Unknown error.";
    if (e && e.status && void 0 !== e.statusText) {
        t = `${localize("err_status", "Status")}: ${e.status}`, t += `\n${e.statusText}`;
    }
    return new Error(t);
}

async function _getAuthToken(e, t) {
    if (!e) return Promise.resolve(null);
    try {
        const e = await getToken(t);
        return Promise.resolve(e);
    } catch (e) {
        if (t && (e.message.includes("revoked") || e.message.includes("Authorization page could not be loaded"))) {
            const e = await getToken(!1);
            return Promise.resolve(e);
        }
        throw e;
    }
}

async function _retry(e, t, n, i) {
    i++;
    const r = (Math.pow(2, i) - 1) * _DELAY;
    await (e => new Promise(t => setTimeout(t, e)))(r), error(`Retry fetch, attempt: ${i}`, "ChromeHttp._retry");
    const o = await _fetch(e, t, n, i);
    return Promise.resolve(o);
}

async function _retryToken(e, t, n, i) {
    event(EVENT.REFRESHED_AUTH_TOKEN), await removeCachedToken(n.interactive, n.token), 
    n.token = null, n.retryToken = !1;
    const r = await _fetch(e, t, n, i);
    return Promise.resolve(r);
}

async function _fetch(e, t, n, i) {
    try {
        const r = await _getAuthToken(n.isAuth, n.interactive);
        n.isAuth && (n.token = r, t.headers.set(_AUTH_HEADER, `${_BEARER} ${n.token}`)), 
        n.body && (t.body = JSON.stringify(n.body));
        const o = await fetch(e, t), s = await _processResponse(o, e, t, n, i);
        return Promise.resolve(s);
    } catch (e) {
        let t = e.message;
        throw "Failed to fetch" === t && (void 0 !== (t = localize("err_network")) && "" !== t || (t = "Network error")), 
        new Error(t);
    }
}

async function _doIt(e, t, n) {
    (n = n || CONFIG).isAuth && t.headers.set(_AUTH_HEADER, `${_BEARER} unknown`);
    const i = await _fetch(e, t, n, 0);
    return Promise.resolve(i);
}

var http = {
    CONFIG: CONFIG,
    doGet: doGet,
    doPost: doPost
};

const _MSG = {
    HIGHLIGHT: {
        message: "highlightTab"
    },
    RESTORE_DEFAULTS: {
        message: "restoreDefaults"
    },
    STORAGE_EXCEEDED: {
        message: "storageExceeded"
    },
    STORE: {
        message: "store",
        key: "",
        value: ""
    }
}, HIGHLIGHT = _MSG.HIGHLIGHT, RESTORE_DEFAULTS = _MSG.RESTORE_DEFAULTS, STORAGE_EXCEEDED = _MSG.STORAGE_EXCEEDED, STORE = _MSG.STORE;

async function send(e) {
    const t = new ChromePromise();
    try {
        const n = await t.runtime.sendMessage(e);
        return Promise.resolve(n);
    } catch (t) {
        if (t.message && !t.message.includes("port closed") && !t.message.includes("Receiving end does not exist")) {
            error(`type: ${e.message}, ${t.message}`, "Msg.send");
        }
        throw t;
    }
}

function listen(e) {
    chrome.runtime.onMessage.addListener(e);
}

var msg = {
    HIGHLIGHT: HIGHLIGHT,
    RESTORE_DEFAULTS: RESTORE_DEFAULTS,
    STORAGE_EXCEEDED: STORAGE_EXCEEDED,
    STORE: STORE,
    send: send,
    listen: listen
};

function get$1(e, t = null) {
    const n = localStorage.getItem(e);
    let i = t;
    return null !== n && (i = parse$1(n)), i;
}

function getInt(e, t = null) {
    const n = localStorage.getItem(e);
    let i = parseInt(n, 10);
    return Number.isNaN(i) && (i = null === t ? i : t, null === t && error(`NaN value for: ${e} equals ${n}`, "Storage.getInt")), 
    i;
}

function getBool(e, t = null) {
    return get$1(e, t);
}

function set$1(e, t = null) {
    if (null === t) localStorage.removeItem(e); else {
        const n = JSON.stringify(t);
        localStorage.setItem(e, n);
    }
}

function safeSet(e, t, n = null) {
    let i = !0;
    const r = get$1(e);
    try {
        set$1(e, t);
    } catch (t) {
        i = !1, r && set$1(e, r), n && (r && r.length ? set$1(n, !0) : set$1(n, !1)), send(STORAGE_EXCEEDED).catch(() => {});
    }
    return i;
}

async function asyncGet(e, t = null) {
    let n = null;
    const i = new ChromePromise();
    try {
        n = (await i.storage.local.get([ e ]))[e];
    } catch (e) {
        t && (n = t);
    }
    return void 0 === n && (n = t), n;
}

async function asyncSet(e, t, n = null) {
    let i = !0;
    const r = new ChromePromise(), o = {
        [e]: t
    };
    try {
        await r.storage.local.set(o);
    } catch (e) {
        send(STORAGE_EXCEEDED).catch(() => {}), i = !1;
    }
    return i;
}

var storage = {
    get: get$1,
    getInt: getInt,
    getBool: getBool,
    set: set$1,
    safeSet: safeSet,
    asyncGet: asyncGet,
    asyncSet: asyncSet
};

class ChromeTime {
    static get MSEC_IN_MIN() {
        return 6e4;
    }
    static get MIN_IN_HOUR() {
        return 60;
    }
    static get MSEC_IN_HOUR() {
        return 60 * ChromeTime.MIN_IN_HOUR * 1e3;
    }
    static get MIN_IN_DAY() {
        return 1440;
    }
    static get MSEC_IN_DAY() {
        return 60 * ChromeTime.MIN_IN_DAY * 1e3;
    }
    static getTime(e) {
        const t = new Date(), n = new ChromeTime(e);
        return t.setHours(n._hr), t.setMinutes(n._min), t.setSeconds(0), t.setMilliseconds(0), 
        t.getTime();
    }
    static getTimeDelta(e) {
        const t = Date.now();
        let n = (ChromeTime.getTime(e) - t) / 1e3 / 60;
        return n < 0 && (n = ChromeTime.MIN_IN_DAY + n), n;
    }
    static isInRange(e, t) {
        const n = Date.now(), i = ChromeTime.getTime(e), r = ChromeTime.getTime(t);
        let o = !1;
        return e === t ? o = !0 : r > i ? n >= i && n <= r && (o = !0) : (n >= i || n <= r) && (o = !0), 
        o;
    }
    static getStringFull(e, t = null) {
        return new ChromeTime(e).toString(t);
    }
    static getStringShort() {
        let e = new ChromeTime().toString();
        return e = (e = e.replace(/[^\d:]/g, "")).replace(/(.*?:.*?):.*/g, "$1");
    }
    static _is24Hr(e = null) {
        let t = !1, n = getInt("showTime", 0);
        null !== e && (n = e);
        const i = localize("time_format");
        return 2 === n ? t = !0 : 0 === n && "24" === i && (t = !0), t;
    }
    constructor(e = null) {
        this._hr = null, this._parse(e);
    }
    toString(e = null) {
        const t = new Date();
        t.setHours(this._hr, this._min), t.setSeconds(0), t.setMilliseconds(0);
        let n = t.toTimeString();
        const i = [];
        void 0 !== navigator.language && i.push(navigator.language), i.push("en-US");
        const r = {
            hour: "numeric",
            minute: "2-digit",
            hour12: !ChromeTime._is24Hr(e)
        };
        try {
            n = t.toLocaleTimeString(i, r);
        } catch (e) {
            noop();
        }
        return n;
    }
    _parse(e) {
        if (e) this._hr = parseInt(e.substr(0, 2), 10), this._min = parseInt(e.substr(3, 2), 10); else {
            const e = new Date();
            this._hr = e.getHours(), this._min = e.getMinutes();
        }
    }
}

var time = {
    default: ChromeTime
};

const _TRACKING_ID = "UA-61314754-1", EVENT$1 = {
    CHROME_SIGN_OUT: {
        eventCategory: "user",
        eventAction: "chromeSignOut",
        eventLabel: ""
    },
    LOAD_ALBUM_LIST: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadAlbumList",
        eventLabel: ""
    },
    SELECT_ALBUM: {
        eventCategory: "googlePhotosAPI",
        eventAction: "selectAlbum",
        eventLabel: ""
    },
    LOAD_ALBUM: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadAlbum",
        eventLabel: ""
    },
    LOAD_PHOTO: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadPhoto",
        eventLabel: ""
    },
    LOAD_PHOTOS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadPhotos",
        eventLabel: ""
    },
    LOAD_FILTERED_PHOTOS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadFilteredPhotos",
        eventLabel: ""
    },
    FETCH_ALBUMS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "fetchAlbums",
        eventLabel: ""
    },
    FETCH_PHOTOS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "fetchPhotos",
        eventLabel: ""
    },
    PHOTOS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedAlbumPhotos",
        eventLabel: ""
    },
    ALBUMS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedAlbums",
        eventLabel: ""
    },
    PHOTO_SELECTIONS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedTotalPhotos",
        eventLabel: ""
    },
    VIEW_PHOTO: {
        eventCategory: "ui",
        eventAction: "viewPhoto",
        eventLabel: ""
    },
    WEATHER_UPDATED: {
        eventCategory: "weather",
        eventAction: "updatedWeather",
        eventLabel: ""
    }
};

function initialize$1() {
    initialize(_TRACKING_ID, "Photo Screensaver", "screensaver", getVersion());
}

var my_analytics = {
    EVENT: EVENT$1,
    initialize: initialize$1
};

const _MSG$1 = {
    SS_SHOW: {
        message: "showScreensaver"
    },
    SS_CLOSE: {
        message: "closeScreensaver"
    },
    SS_IS_SHOWING: {
        message: "isScreensaverShowing"
    },
    PHOTO_SOURCE_FAILED: {
        message: "photoSourceFailed",
        key: "",
        error: ""
    },
    LOAD_FILTERED_PHOTOS: {
        message: "loadFilteredPhotos"
    },
    FILTERED_PHOTOS_COUNT: {
        message: "filteredPhotosCount",
        count: 0
    },
    LOAD_ALBUMS: {
        message: "loadAlbums"
    },
    LOAD_ALBUM: {
        message: "loadAlbum"
    },
    ALBUM_COUNT: {
        message: "albumCount",
        count: 0
    },
    UPDATE_WEATHER_ALARM: {
        message: "updateWeatherAlarm"
    },
    UPDATE_WEATHER: {
        message: "updateWeather"
    }
}, SS_SHOW = _MSG$1.SS_SHOW, SS_CLOSE = _MSG$1.SS_CLOSE, SS_IS_SHOWING = _MSG$1.SS_IS_SHOWING, PHOTO_SOURCE_FAILED = _MSG$1.PHOTO_SOURCE_FAILED, LOAD_FILTERED_PHOTOS = _MSG$1.LOAD_FILTERED_PHOTOS, FILTERED_PHOTOS_COUNT = _MSG$1.FILTERED_PHOTOS_COUNT, LOAD_ALBUMS = _MSG$1.LOAD_ALBUMS, LOAD_ALBUM = _MSG$1.LOAD_ALBUM, ALBUM_COUNT = _MSG$1.ALBUM_COUNT, UPDATE_WEATHER_ALARM = _MSG$1.UPDATE_WEATHER_ALARM, UPDATE_WEATHER = _MSG$1.UPDATE_WEATHER;

var my_msg = {
    SS_SHOW: SS_SHOW,
    SS_CLOSE: SS_CLOSE,
    SS_IS_SHOWING: SS_IS_SHOWING,
    PHOTO_SOURCE_FAILED: PHOTO_SOURCE_FAILED,
    LOAD_FILTERED_PHOTOS: LOAD_FILTERED_PHOTOS,
    FILTERED_PHOTOS_COUNT: FILTERED_PHOTOS_COUNT,
    LOAD_ALBUMS: LOAD_ALBUMS,
    LOAD_ALBUM: LOAD_ALBUM,
    ALBUM_COUNT: ALBUM_COUNT,
    UPDATE_WEATHER_ALARM: UPDATE_WEATHER_ALARM,
    UPDATE_WEATHER: UPDATE_WEATHER
};

const _DEBUG$1 = !1, DEBUG$1 = !1;

function getEmail() {
    return "photoscreensaver@gmail.com";
}

function getEmailBody() {
    return `Extension version: ${getVersion()}\n` + `Chrome version: ${getFullChromeVersion()}\n` + `OS: ${get$1("os")}\n\n\n`;
}

function getEmailUrl(e, t) {
    return `mailto:${encodeURIComponent(getEmail())}?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(t)}`;
}

function getGithubPath() {
    return "https://github.com/opus1269/screensaver/";
}

function getGithubPagesPath() {
    return DEBUG$1 ? "http://127.0.0.1:4000/" : "https://opus1269.github.io/screensaver/";
}

var my_utils = {
    DEBUG: DEBUG$1,
    getEmail: getEmail,
    getEmailBody: getEmailBody,
    getEmailUrl: getEmailUrl,
    getGithubPath: getGithubPath,
    getGithubPagesPath: getGithubPagesPath
};

class PhotoSource {
    static addPhoto(e, t, n, i, r, o = "") {
        const s = {
            url: t,
            author: n,
            asp: i.toPrecision(3)
        };
        r && (s.ex = r), o && !isWhiteSpace(o) && (s.point = o), e.push(s);
    }
    static createPoint(e, t) {
        return "number" == typeof e && "number" == typeof t ? `${e.toFixed(6)} ${t.toFixed(6)}` : `${e} ${t}`;
    }
    constructor(e, t, n, i, r, o, s = null) {
        this._useKey = e, this._photosKey = t, this._type = n, this._desc = i, this._isDaily = r, 
        this._isArray = o, this._loadArg = s;
    }
    getType() {
        return this._type;
    }
    getPhotosKey() {
        return this._photosKey;
    }
    getDesc() {
        return this._desc;
    }
    getUseKey() {
        return this._useKey;
    }
    getLoadArg() {
        return this._loadArg;
    }
    isDaily() {
        return this._isDaily;
    }
    async getPhotos() {
        const e = {
            type: this._type,
            photos: []
        };
        if (this.use()) {
            let t = [];
            if (this._isArray) {
                let e = await asyncGet(this._photosKey);
                e = e || [];
                for (const n of e) t = t.concat(n.photos);
            } else t = (t = await asyncGet(this._photosKey)) || [];
            e.photos = t;
        }
        return Promise.resolve(e);
    }
    use() {
        return getBool(this._useKey);
    }
    async process() {
        if (this.use()) try {
            const e = await this.fetchPhotos(), t = await this._save(e);
            if (!isWhiteSpace(t)) return Promise.reject(new Error(t));
        } catch (e) {
            let t = localize("err_photo_source_title");
            return t += `: ${this._desc}`, error$1(e.message, "PhotoSource.process", t, `source: ${this._useKey}`), 
            Promise.reject(e);
        } else {
            const e = getBool("useGoogle", !0);
            let t = !1;
            if ("albumSelections" !== this._photosKey && "googleImages" !== this._photosKey || (t = !0), 
            !t || e) try {
                const e = new ChromePromise();
                await e.storage.local.remove(this._photosKey);
            } catch (e) {}
        }
        return Promise.resolve();
    }
    async _save(e) {
        let t = null;
        const n = this._useKey;
        if (e && e.length) {
            await asyncSet(this._photosKey, e, n) || (t = "Exceeded storage capacity.");
        }
        return t;
    }
}

var photo_source = {
    PhotoSource: PhotoSource
};

class CCSource extends PhotoSource {
    constructor(e, t, n, i, r, o, s = null) {
        super(e, t, n, i, r, o, s);
    }
    async fetchPhotos() {
        let e = await doGet("/assets/chromecast.json");
        e = e || [];
        for (const t of e) t.asp = "1.78";
        return Promise.resolve(e);
    }
}

var photo_source_chromecast = {
    default: CCSource
};

const _URL_BASE = "https://api.flickr.com/services/rest/", _KEY = "1edd9926740f0e0d01d4ecd42de60ac6", _MAX_PHOTOS = 250;

class FlickrSource extends PhotoSource {
    static _processPhotos(e) {
        if (!e.photos || !e.photos.photo) throw new Error(localize("err_photo_source_title"));
        const t = [];
        for (const n of e.photos.photo) {
            let e, i, r = null;
            if (n && "photo" === n.media && "0" !== n.isfriend && "0" !== n.isfamily && (r = n.url_k || r, 
            r = n.url_o || r)) {
                n.url_o ? (e = parseInt(n.width_o, 10), i = parseInt(n.height_o, 10)) : (e = parseInt(n.width_k, 10), 
                i = parseInt(n.height_k, 10));
                const o = e / i;
                let s = "";
                n.latitude && n.longitude && (s = PhotoSource.createPoint(n.latitude, n.longitude)), 
                PhotoSource.addPhoto(t, r, n.ownername, o, n.owner, s);
            }
        }
        return t;
    }
    constructor(e, t, n, i, r, o, s = null) {
        super(e, t, n, i, r, o, s);
    }
    async fetchPhotos() {
        let e;
        if (this.getLoadArg()) {
            e = `${_URL_BASE}?method=flickr.people.getPublicPhotos` + `&api_key=${_KEY}&user_id=${"86149994@N06"}` + `&extras=owner_name,url_o,media,geo&per_page=${_MAX_PHOTOS}` + "&format=json&nojsoncallback=1";
        } else e = `${_URL_BASE}?method=flickr.interestingness.getList` + `&api_key=${_KEY}&extras=owner_name,url_k,media,geo` + `&per_page=${_MAX_PHOTOS}` + "&format=json&nojsoncallback=1";
        const t = await doGet(e);
        if ("ok" !== t.stat) throw new Error(t.message);
        const n = FlickrSource._processPhotos(t);
        return Promise.resolve(n);
    }
}

var photo_source_flickr = {
    default: FlickrSource
};

const UseKey = {
    ALBUMS_GOOGLE: "useGoogleAlbums",
    PHOTOS_GOOGLE: "useGooglePhotos",
    CHROMECAST: "useChromecast",
    SPACE_RED: "useSpaceReddit",
    EARTH_RED: "useEarthReddit",
    ANIMAL_RED: "useAnimalReddit",
    INT_FLICKR: "useInterestingFlickr",
    AUTHOR: "useAuthors"
};

function getSelectedSources() {
    const e = [], t = getUseKeys();
    for (const n of t) {
        if (getBool(n, !1)) {
            const t = create(n);
            t && e.push(t);
        }
    }
    return e;
}

function getUseKeys() {
    const e = [];
    for (const t of Object.values(UseKey)) e.push(t);
    return e;
}

function isUseKey(e) {
    let t = !1;
    for (const n of Object.values(UseKey)) if (n === e) {
        t = !0;
        break;
    }
    return t;
}

async function process(e) {
    const t = create(e);
    return t && await t.process(), Promise.resolve();
}

async function getSelectedPhotos() {
    const e = [], t = getSelectedSources();
    for (const n of t) {
        const t = await n.getPhotos();
        e.push(t);
    }
    return Promise.resolve(e);
}

async function processAll(e = !1) {
    const t = getSelectedSources();
    for (const n of t) {
        let t = !1;
        if ("Google User" === n.getType() && (t = !e), !t) try {
            await n.process();
        } catch (e) {}
    }
    return Promise.resolve();
}

async function processDaily() {
    const e = getSelectedSources();
    for (const t of e) if (t.isDaily()) try {
        await t.process();
    } catch (e) {}
    return Promise.resolve();
}

var photo_sources = {
    UseKey: UseKey,
    getSelectedSources: getSelectedSources,
    getUseKeys: getUseKeys,
    isUseKey: isUseKey,
    process: process,
    getSelectedPhotos: getSelectedPhotos,
    processAll: processAll,
    processDaily: processDaily
};

const _URL_BASE$1 = "https://photoslibrary.googleapis.com/v1/", _ALBUMS_QUERY = "?pageSize=50&fields=nextPageToken,albums(id,title,mediaItemsCount,coverPhotoBaseUrl)", _MEDIA_ITEMS_FIELDS = "fields=nextPageToken,mediaItems(id,productUrl,baseUrl,mimeType,mediaMetadata/width,mediaMetadata/height)", _MEDIA_ITEMS_RESULTS_FIELDS = "fields=mediaItemResults(status/code,mediaItem/id,mediaItem/productUrl,mediaItem/baseUrl,mediaItem/mimeType,mediaItem/mediaMetadata/width,mediaItem/mediaMetadata/height)";

class GoogleSource extends PhotoSource {
    static get DEF_FILTER() {
        return {
            mediaTypeFilter: {
                mediaTypes: [ "PHOTO" ]
            },
            contentFilter: {
                includedContentCategories: [ "LANDSCAPES", "CITYSCAPES", "LANDMARKS" ]
            }
        };
    }
    static get NO_FILTER() {
        return {
            mediaTypeFilter: {
                mediaTypes: [ "PHOTO" ]
            }
        };
    }
    static get MAX_ALBUMS() {
        return 200;
    }
    static get MAX_ALBUM_PHOTOS() {
        return 2e3;
    }
    static get MAX_PHOTOS() {
        return 3e4;
    }
    static get MAX_FILTERED_PHOTOS() {
        return 3e3;
    }
    static isAuthRevokedError(e, t) {
        let n = !1;
        return e.message.includes("OAuth2 not granted or revoked") && (asyncSet("albumSelections", []).catch(() => {}), 
        asyncSet("googleImages", []).catch(() => {}), error$1(e.message, t, localize("err_auth_revoked")), 
        n = !0), n;
    }
    static async loadAlbumList() {
        let e, t = [];
        const n = [];
        let i = 0;
        const r = `${_URL_BASE$1}albums/${_ALBUMS_QUERY}`;
        let o = r;
        const s = shallowCopy(CONFIG);
        s.isAuth = !0, s.retryToken = !0, s.interactive = !0;
        do {
            let n = await doGet(o, s);
            (n = n || {}).albums = n.albums || [], n.albums.length && (t = t.concat(n.albums)), 
            o = `${r}&pageToken=${e = n.nextPageToken}`;
        } while (e);
        for (const e of t) if (e && e.mediaItemsCount && e.mediaItemsCount > 0) {
            const t = {
                index: i,
                uid: "album" + i,
                name: e.title,
                id: e.id,
                ct: e.mediaItemsCount,
                thumb: `${e.coverPhotoBaseUrl}=w76-h76`,
                checked: !1,
                photos: []
            };
            n.push(t), i++;
        }
        return event(EVENT$1.LOAD_ALBUM_LIST, `nAlbums: ${n.length}`), n;
    }
    static async loadAlbum(e, t, n = !0, i = !1) {
        const r = `${_URL_BASE$1}mediaItems:search?${_MEDIA_ITEMS_FIELDS}`, o = {
            pageSize: 100
        };
        o.albumId = e;
        const s = shallowCopy(CONFIG);
        let a;
        s.isAuth = !0, s.retryToken = !0, s.interactive = n, s.body = o;
        let l = [];
        do {
            if (i) {
                const e = shallowCopy(ALBUM_COUNT);
                e.name = t, e.count = l.length;
                try {
                    await send(e);
                } catch (e) {}
            }
            const e = await doPost(r, s);
            a = e.nextPageToken, s.body.pageToken = a;
            const n = e.mediaItems;
            if (n) {
                const e = this._processPhotos(n, t);
                l = l.concat(e);
            }
            if (l.length > this.MAX_ALBUM_PHOTOS) {
                event(EVENT$1.PHOTOS_LIMITED, `nPhotos: ${this.MAX_ALBUM_PHOTOS}`);
                const e = l.length - this.MAX_ALBUM_PHOTOS;
                l.splice(this.MAX_ALBUM_PHOTOS, e);
            }
        } while (a && l.length < this.MAX_ALBUM_PHOTOS);
        const c = {
            index: 0,
            uid: "album0",
            name: t,
            id: e,
            thumb: "",
            checked: !0,
            photos: l,
            ct: l.length
        };
        return event(EVENT$1.LOAD_ALBUM, `nPhotos: ${c.ct}`), Promise.resolve(c);
    }
    static async loadAlbums(e = !1, t = !1) {
        const n = "GoogleSource.loadAlbums", i = await asyncGet("albumSelections", []);
        if (0 === i.length) return Promise.resolve(i);
        let r = 0;
        for (let o = i.length - 1; o >= 0; o--) {
            const s = i[o] || [];
            let a = null;
            try {
                a = await GoogleSource.loadAlbum(s.id, s.name, e, t);
            } catch (e) {
                if (e.message.match(/404/)) {
                    let e = localize("removed_album");
                    error$1(e += `: ${s.name}`, n), i.splice(o, 1);
                    continue;
                }
                throw e;
            }
            const l = a.photos || [];
            if (i.splice(o, 1, {
                id: s.id,
                name: a.name,
                photos: l
            }), (r += l.length) > GoogleSource.MAX_PHOTOS) {
                event(EVENT$1.PHOTO_SELECTIONS_LIMITED, `limit: ${r}`), error$1(localize("err_max_photos"), n);
                break;
            }
        }
        return Promise.resolve(i);
    }
    static async loadFilteredPhotos(e = !1, t = !1) {
        const n = await asyncGet("googleImages", []);
        if (!e && !this._isFetch()) return Promise.resolve(n);
        const i = GoogleSource.MAX_FILTERED_PHOTOS;
        let r;
        const o = {
            pageSize: 100,
            filters: r = get$1("googlePhotosNoFilter", !1) ? this.NO_FILTER : get$1("googlePhotosFilter", this.DEF_FILTER)
        }, s = `${_URL_BASE$1}mediaItems:search?${_MEDIA_ITEMS_FIELDS}`, a = shallowCopy(CONFIG);
        let l;
        a.isAuth = !0, a.retryToken = !0, a.interactive = e, a.body = o;
        let c = [];
        try {
            do {
                if (t) {
                    const e = shallowCopy(FILTERED_PHOTOS_COUNT);
                    e.count = c.length;
                    try {
                        await send(e);
                    } catch (e) {}
                }
                let e = await doPost(s, a);
                e = e || {};
                const n = this._processPhotos(e.mediaItems);
                n.length > 0 && (c = c.concat(n)), c.length > i && c.splice(i, c.length - i), l = e.nextPageToken, 
                a.body.pageToken = l;
            } while (l && c.length < i);
        } catch (e) {
            throw e;
        }
        return event(EVENT$1.LOAD_FILTERED_PHOTOS, `nPhotos: ${c.length}`), Promise.resolve(c);
    }
    static async loadPhotos(e) {
        let t = [];
        if (0 === (e = e || []).length) return t;
        const n = shallowCopy(CONFIG);
        n.isAuth = !0, n.retryToken = !0, n.interactive = !1;
        let i = !1, r = 0, o = Math.min(50, e.length), s = 0;
        do {
            let a = `${_URL_BASE$1}mediaItems:batchGet?${_MEDIA_ITEMS_RESULTS_FIELDS}`, l = "";
            for (let t = r; t < o; t++) l = l.concat(`&mediaItemIds=${e[t]}`);
            a = a.concat(l);
            const c = await doGet(a, n);
            s++;
            const d = [];
            for (const e of c.mediaItemResults) !e.status && e.mediaItem && d.push(e.mediaItem);
            const p = this._processPhotos(d, "");
            t = t.concat(p), o === e.length ? i = !0 : (r = o, o = Math.min(o + 50, e.length));
        } while (!i);
        return event(EVENT$1.LOAD_PHOTOS, `nPhotos: ${t.length}, nCalls: ${s}`), t;
    }
    static async updateBaseUrls(e) {
        let t = !0;
        if (0 === (e = e || []).length) return t;
        return get$1("useGoogleAlbums", !1) && (t = await GoogleSource._updateAlbumsBaseUrls(e)), 
        get$1("useGooglePhotos", !1) && (t = await GoogleSource._updatePhotosBaseUrls(e)), 
        t;
    }
    static async _updateAlbumsBaseUrls(e) {
        let t = !0;
        if (0 === (e = e || []).length) return t;
        const n = await asyncGet("albumSelections", []);
        if (0 === n.length) return t;
        for (const t of e) for (const e of n) {
            const n = e.photos, i = n.findIndex(e => e.ex.id === t.ex.id);
            i >= 0 && (n[i].url = t.url);
        }
        return await asyncSet("albumSelections", n, null) || (t = !1, error$1(localize("err_storage_title"), "GoogleSource._updateAlbumsBaseUrls")), 
        t;
    }
    static async _updatePhotosBaseUrls(e) {
        let t = !0;
        if (0 === (e = e || []).length) return t;
        const n = await asyncGet("googleImages", []);
        if (0 === n.length) return t;
        for (const t of e) {
            const e = n.findIndex(e => e.ex.id === t.ex.id);
            e >= 0 && (n[e].url = t.url);
        }
        return await asyncSet("googleImages", n, null) || (t = !1, error$1(localize("err_storage_title"), "GoogleSource._updatePhotosBaseUrls")), 
        t;
    }
    static _isFetch() {
        const e = "allowed" === get$1("permPicasa", "notSet"), t = getBool("enabled", !0), n = getBool("useGoogle", !0);
        return e && t && n;
    }
    static async _fetchAlbums() {
        if (!this._isFetch()) {
            const e = await asyncGet("albumSelections", []);
            return Promise.resolve(e);
        }
        let e = 0;
        const t = await this.loadAlbums(!1, !1);
        for (const n of t) e += n.photos.length;
        return t.length > 0 && event(EVENT$1.FETCH_ALBUMS, `nAlbums: ${t.length} nPhotos: ${e}`), 
        Promise.resolve(t);
    }
    static _isImage(e) {
        return e && e.mimeType && e.mimeType.startsWith("image/") && e.mediaMetadata && e.mediaMetadata.width && e.mediaMetadata.height;
    }
    static _getImageSize(e) {
        const t = {};
        if (t.width = parseInt(e.width, 10), t.height = parseInt(e.height, 10), !getBool("fullResGoogle")) {
            const e = Math.max(1920, t.width, t.height);
            e > 1920 && (t.width === e ? (t.width = 1920, t.height = Math.round(t.height * (1920 / e))) : (t.height = 1920, 
            t.width = Math.round(t.width * (1920 / e))));
        }
        return t;
    }
    static _processPhoto(e, t) {
        let n = null;
        if (e && e.mediaMetadata && this._isImage(e)) {
            const i = e.mediaMetadata, r = this._getImageSize(i), o = r.width, s = r.height;
            n = {
                url: `${e.baseUrl}=w${o}-h${s}`,
                asp: (o / s).toPrecision(3),
                author: t,
                ex: {
                    id: e.id,
                    url: e.productUrl
                },
                point: null
            };
        }
        return n;
    }
    static _processPhotos(e, t = "") {
        const n = [];
        if (!e) return n;
        for (const i of e) {
            const e = this._processPhoto(i, t);
            if (e) {
                const t = parseFloat(e.asp);
                this.addPhoto(n, e.url, e.author, t, e.ex, e.point);
            }
        }
        return n;
    }
    constructor(e, t, n, i, r, o, s = null) {
        super(e, t, n, i, r, o, s);
    }
    async fetchPhotos() {
        if (!navigator.onLine) throw new Error(localize("err_network"));
        try {
            return this.getUseKey() === UseKey.ALBUMS_GOOGLE ? await GoogleSource._fetchAlbums() : await GoogleSource.loadFilteredPhotos(!1);
        } catch (e) {
            return GoogleSource.isAuthRevokedError(e, "GoogleSource.fetchPhotos") ? Promise.resolve([]) : Promise.reject(e);
        }
    }
}

var photo_source_google = {
    GoogleSource: GoogleSource
};

const _REDIRECT_URI = `https://${chrome.runtime.id}.chromiumapp.org/reddit`, _KEY$1 = "bATkDOUNW_tOlg", _MAX_PHOTOS$1 = 200, _MIN_SIZE = 750, _MAX_SIZE = 3500;

let _snoocore;

class RedditSource extends PhotoSource {
    static _getSize(e) {
        const t = {
            width: -1,
            height: -1
        }, n = e.match(/\[(\d*)\D*(\d*)]/);
        return n && (t.width = parseInt(n[1], 10), t.height = parseInt(n[2], 10)), t;
    }
    static _processChildren(e) {
        const t = [];
        let n, i = 1, r = 1;
        for (const o of e) {
            const e = o.data;
            if (!e.over_18) if (e.preview && e.preview.images) {
                let t = e.preview.images[0];
                n = t.source.url.replace(/&amp;/g, "&"), i = parseInt(t.source.width, 10), r = parseInt(t.source.height, 10), 
                Math.max(i, r) > _MAX_SIZE && (n = (t = t.resolutions[t.resolutions.length - 1]).url.replace(/&amp;/g, "&"), 
                i = parseInt(t.width, 10), r = parseInt(t.height, 10));
            } else if (e.title) {
                const t = RedditSource._getSize(e.title);
                n = e.url, i = t.width, r = t.height;
            }
            const s = i / r, a = e.author;
            s && !isNaN(s) && Math.max(i, r) >= _MIN_SIZE && Math.max(i, r) <= _MAX_SIZE && PhotoSource.addPhoto(t, n, a, s, e.url);
        }
        return t;
    }
    constructor(e, t, n, i, r, o, s = null) {
        super(e, t, n, i, r, o, s);
    }
    async fetchPhotos() {
        let e = [];
        const t = `${this.getLoadArg()}hot`, n = window.Snoocore;
        if (void 0 === n) throw new Error("Reddit library failed to load");
        try {
            _snoocore = new n({
                userAgent: "photo-screen-saver",
                throttle: 0,
                oauth: {
                    type: "implicit",
                    key: _KEY$1,
                    redirectUri: _REDIRECT_URI,
                    scope: [ "read" ]
                }
            });
            let i, r = await _snoocore(t).listing({
                limit: _MAX_PHOTOS$1
            });
            if (!(r && r.children && r.children.length)) return Promise.reject(new Error("No reddit photos found"));
            for (i = (i = RedditSource._processChildren(r.children)) || [], e = e.concat(i); e.length < _MAX_PHOTOS$1 && (r = await r.next()) && r.children && r.children.length && (i = (i = RedditSource._processChildren(r.children)) || []).length; ) e = e.concat(i);
        } catch (e) {
            let t = e.message;
            if (t) {
                const e = t.indexOf("\n");
                -1 !== e && (t = t.substring(0, e + 1));
            } else t = "Unknown Error";
            throw new Error(t);
        }
        return Promise.resolve(e);
    }
}

var photo_source_reddit = {
    default: RedditSource
};

function create(e) {
    switch (e) {
      case UseKey.ALBUMS_GOOGLE:
        return new GoogleSource(e, "albumSelections", "Google User", localize("google_title"), !0, !0, null);

      case UseKey.PHOTOS_GOOGLE:
        return new GoogleSource(e, "googleImages", "Google User", localize("google_title_photos"), !0, !1, null);

      case UseKey.CHROMECAST:
        return new CCSource(e, "ccImages", "Google", localize("setting_chromecast"), !1, !1, null);

      case UseKey.INT_FLICKR:
        return new FlickrSource(e, "flickrInterestingImages", "flickr", localize("setting_flickr_int"), !0, !1, !1);

      case UseKey.AUTHOR:
        return new FlickrSource(e, "authorImages", "flickr", localize("setting_mine"), !1, !1, !0);

      case UseKey.SPACE_RED:
        return new RedditSource(e, "spaceRedditImages", "reddit", localize("setting_reddit_space"), !0, !1, "r/spaceporn/");

      case UseKey.EARTH_RED:
        return new RedditSource(e, "earthRedditImages", "reddit", localize("setting_reddit_earth"), !0, !1, "r/EarthPorn/");

      case UseKey.ANIMAL_RED:
        return new RedditSource(e, "animalRedditImages", "reddit", localize("setting_reddit_animal"), !0, !1, "r/animalporn/");

      default:
        return error(`Bad PhotoSource type: ${e}`, "PhotoSourceFactory.create"), null;
    }
}

var photo_source_factory = {
    create: create
};

const DEF_WEATHER = {
    time: 0,
    id: 0,
    dayNight: "",
    tempValue: 0,
    temp: "",
    description: "",
    city: ""
}, DEF_LOC_OPTIONS = {
    enableHighAccuracy: !1,
    timeout: 6e4,
    maximumAge: 0
}, MIN_CALL_FREQ = ChromeTime.MSEC_IN_HOUR, _DEF_LOC = {
    lat: 0,
    lon: 0
}, _KEY$2 = "2eab968d43699c1b6e126228b34880c9", _URL_BASE$2 = "https://api.openweathermap.org/data/2.5/weather";

async function update(e = !1) {
    const t = localize("err_weather_update"), n = get$1("showCurrentWeather", !1), i = getInt("weatherTempUnit", 0);
    if (!n) return Promise.resolve();
    if (!e) {
        const e = get$1("currentWeather", DEF_WEATHER).time;
        if (Date.now() - e < MIN_CALL_FREQ) return Promise.resolve();
    }
    let r;
    try {
        r = await getLocation();
    } catch (e) {
        r = get$1("location", _DEF_LOC);
    } finally {
        set$1("location", r);
    }
    try {
        const e = shallowCopy(CONFIG);
        e.maxRetries = 2;
        let n = _URL_BASE$2;
        n += `?lat=${r.lat}&lon=${r.lon}&APPID=${_KEY$2}`;
        const o = await doGet(n, e);
        if (200 !== o.cod) {
            return error$1(`${localize("err_status")}: ${o.cod}`, "Weather.update", t), Promise.resolve();
        }
        const s = shallowCopy(DEF_WEATHER);
        s.time = Date.now(), o.name && (s.city = o.name);
        const a = o.sys;
        if (a && a.sunrise && a.sunset) {
            const e = s.time / 1e3;
            e > a.sunrise && e < a.sunset ? s.dayNight = "day-" : s.dayNight = "night-";
        }
        const l = o.main;
        l && l.temp && (s.tempValue = l.temp, s.temp = 1 === i ? _kToF(s.tempValue) : _kToC(s.tempValue));
        const c = o.weather || [];
        return c[0].description && (s.description = c[0].description), c[0].id && (s.id = c[0].id), 
        set$1("currentWeather", s), event(EVENT$1.WEATHER_UPDATED), Promise.resolve();
    } catch (e) {
        throw error$1(e.message, "Weather.update", t), e;
    }
}

function updateUnits() {
    const e = get$1("currentWeather", DEF_WEATHER), t = getInt("weatherTempUnit", 0);
    e.temp = 1 === t ? _kToF(e.tempValue) : _kToC(e.tempValue), set$1("currentWeather", e);
}

async function getLocation(e = DEF_LOC_OPTIONS) {
    const t = "Weather.getLocation", n = localize("err_geolocation_title");
    if (!navigator.onLine) {
        const e = localize("err_network");
        throw error$1(e, t, n), new Error(e);
    }
    let i;
    try {
        i = await new Promise((t, n) => {
            navigator.geolocation.getCurrentPosition(t, n, e);
        });
    } catch (e) {
        throw error$1(e.message, t, n), e;
    }
    const r = {
        lat: i.coords.latitude,
        lon: i.coords.longitude
    };
    return set$1("location", r), Promise.resolve(r);
}

function _kToF(e) {
    return `${(9 * (e - 273.17) / 5 + 32).toFixed(0)} °F`;
}

function _kToC(e) {
    return `${(e - 273.17).toFixed(0)} °C`;
}

var weather = {
    DEF_WEATHER: DEF_WEATHER,
    DEF_LOC_OPTIONS: DEF_LOC_OPTIONS,
    update: update,
    updateUnits: updateUnits,
    getLocation: getLocation
};

export { analytics as $analytics, appStorageBehavior as $appStorageBehavior, applyShim as $applyShim$1, ApplyShim as $applyShimDefault, applyShimUtils as $applyShimUtils, arraySelector as $arraySelector, arraySplice as $arraySplice, async as $async, auth as $auth, caseMap$1 as $caseMap, _class as $class, commonRegex as $commonRegex, commonUtils as $commonUtils, cssParse as $cssParse, customStyle as $customStyle, customStyleInterface as $customStyleInterface$1, CustomStyleInterface as $customStyleInterfaceDefault, debounce as $debounce, dirMixin as $dirMixin, documentWait$1 as $documentWait, documentWait as $documentWaitDefault, domBind as $domBind, domIf as $domIf, domModule as $domModule, domRepeat as $domRepeat, elementMixin as $elementMixin, flattenedNodesObserver as $flattenedNodesObserver, flush$2 as $flush, gestureEventListeners as $gestureEventListeners, gestures$1 as $gestures, htmlTag as $htmlTag, http as $http, ironA11yKeysBehavior as $ironA11yKeysBehavior, ironButtonState as $ironButtonState, ironControlState as $ironControlState, ironResizableBehavior as $ironResizableBehavior, ironSelectable as $ironSelectable, ironSelection as $ironSelection, json as $json, last_error as $lastError, ChromeLastError as $lastErrorDefault, legacyElementMixin as $legacyElementMixin, locales as $locales, localizeBehavior as $localizeBehavior, ChromeLog as $log, mixin as $mixin, msg as $msg, mutableData as $mutableData, mutableDataBehavior as $mutableDataBehavior, my_analytics as $myAnalytics, my_msg as $myMsg, my_utils as $myUtils, neonAnimatableBehavior as $neonAnimatableBehavior, neonAnimationBehavior as $neonAnimationBehavior, neonAnimationRunnerBehavior as $neonAnimationRunnerBehavior, neonSharedElementAnimationBehavior as $neonSharedElementAnimationBehavior, paperItemBehavior as $paperItemBehavior, path as $path, photo_source as $photoSource, photo_source_chromecast as $photoSourceChromecast, CCSource as $photoSourceChromecastDefault, photo_source_factory as $photoSourceFactory, photo_source_flickr as $photoSourceFlickr, FlickrSource as $photoSourceFlickrDefault, photo_source_google as $photoSourceGoogle, photo_source_reddit as $photoSourceReddit, RedditSource as $photoSourceRedditDefault, photo_sources as $photoSources, polymer_dom as $polymerDom, polymerElement as $polymerElement, polymerFn as $polymerFn, polymerLegacy as $polymerLegacy, propertiesChanged as $propertiesChanged, propertiesMixin as $propertiesMixin, propertyAccessors as $propertyAccessors, propertyEffects as $propertyEffects, renderStatus as $renderStatus, resolveUrl$1 as $resolveUrl, settings as $settings, storage as $storage, styleGather as $styleGather, styleSettings as $styleSettings, styleUtil as $styleUtil, telemetry as $telemetry, templateMap$1 as $templateMap, templateMap as $templateMapDefault, templateStamp as $templateStamp, templatize$1 as $templatize, templatizerBehavior as $templatizerBehavior, time as $time, ChromeTime as $timeDefault, unscopedStyleHandler as $unscopedStyleHandler, utils as $utils, weather as $weather, wrap$2 as $wrap, ALBUM_COUNT, ANIMATION_MATCH, AppStorageBehavior, ArraySelector, ArraySelectorMixin, BRACKETED, Base, CONFIG, Class, CustomStyle, CustomStyleInterfaceInterface, CustomStyleProvider, DEBUG$1 as DEBUG, DEBUG as DEBUG$1, DEF_LOC_OPTIONS, DEF_WEATHER, Debouncer, DirMixin, DomApi, DomBind, DomIf, DomModule, DomRepeat, EVENT, EVENT$1, ElementMixin, EventApi, FILTERED_PHOTOS_COUNT, FlattenedNodesObserver, GestureEventListeners, GoogleSource, HIGHLIGHT, HOST_PREFIX, HOST_SUFFIX, IS_VAR, IronA11yKeysBehavior, IronButtonState, IronButtonStateImpl, IronControlState, IronResizableBehavior, IronSelectableBehavior, IronSelection, LOAD_ALBUM, LOAD_ALBUMS, LOAD_FILTERED_PHOTOS, LegacyElementMixin, LocalizeBehavior, MEDIA_MATCH, MIXIN_MATCH, MutableData, MutableDataBehavior, NeonAnimatableBehavior, NeonAnimationBehavior, NeonAnimationRunnerBehavior, NeonAnimationRunnerBehaviorImpl, NeonSharedElementAnimationBehavior, NeonSharedElementAnimationBehaviorImpl, OptionalMutableData, OptionalMutableDataBehavior, PHOTO_SOURCE_FAILED, PaperItemBehavior, PaperItemBehaviorImpl, PhotoSource, Polymer, Polymer as Polymer$1, PolymerElement, PropertiesChanged, PropertiesMixin, PropertyAccessors, PropertyEffects, RESTORE_DEFAULTS, SS_CLOSE, SS_IS_SHOWING, SS_SHOW, STORAGE_EXCEEDED, STORE, StyleNode, TemplateInstanceBase, TemplateStamp, Templatizer, UPDATE_WEATHER, UPDATE_WEATHER_ALARM, UseKey, VAR_ASSIGN, VAR_CONSUMED, add, enqueueDebouncer as addDebouncer, addListener, afterNextRender, allowTemplateFromDomModule, animationFrame, applyCss, applyStyle, applyStylePlaceHolder, asyncGet, asyncSet, beforeNextRender, calculateSplices, camelToDashCase, create, createScopeStyle, cssBuild, cssFromModule, cssFromModuleImports, cssFromModules, cssFromTemplate, dashToCamelCase, dedupingMixin, deepTargetFind, detectMixin, disableRuntime, doGet, doPost, dom, dumpRegistrations, elementHasBuiltCss, elementsAreInvalid, enqueueDebouncer, enqueueDebouncer as enqueueDebouncer$1, error, error$1, event, exception, exception$1, findMatchingParen, findOriginalTarget, flush$1 as flush, flush$1, flush as flush$2, flushDebouncers, forEachRule, gatherStyleText, gestures, get$1 as get, get as get$1, getBool, getBuildComment, getChromeVersion, getComputedStyleValue, getCssBuild, getEmail, getEmailBody, getEmailUrl, getExtensionName, getFullChromeVersion, getGithubPagesPath, getGithubPath, getInt, getIsExtends, getLocale, getLocation, getPlatformOS, getRandomInt, getRandomString, getSelectedPhotos, getSelectedSources, getToken, getUseKeys, getVersion, html, html as html$1, html as html$2, htmlLiteral, idlePeriod, incrementInstanceCount, initialize$1 as initialize, initialize as initialize$1, instanceCount, invalidate, invalidateTemplate, isAncestor, isChromeOS, isDeep, isDescendant, isKeyframesSelector, isMac, isOptimalCssBuild, isPath, isRevoked, isSignedIn, isTargetedBuild, isUnscopedStyle, isUseKey, isValid, isValidating, isWhiteSpace, isWindows, legacyOptimizations, listen, localize, matches, matchesSelector, microTask, mixinBehaviors, modelForElement, nativeCssVariables, nativeShadow, noop, normalize, page, parse, parse$1, passiveTouchGestures, pathFromUrl, prevent, process, processAll, processDaily, processUnscopedStyle, processVariableAndFallback, recognizers, register$1 as register, register as register$1, registrations, remove, removeCachedToken, removeCustomPropAssignment, removeListener, resetMouseCanceller, resolveCss, resolveUrl, root, rootPath, rulesForStyle, safeSet, sanitizeDOMValue, scopingAttribute, send, set$1 as set, set as set$1, setAllowTemplateFromDomModule, setElementClassRaw, setLegacyOptimizations, setPassiveTouchGestures, setRootPath, setSanitizeDOMValue, setStrictTemplatePolicy, setSyncInitialRender, setTouchAction, shallowCopy, shuffleArray, split, splitSelectorList, startValidating, startValidatingTemplate, strictTemplatePolicy, stringify, stylesFromModule, stylesFromModuleImports, stylesFromModules, stylesFromTemplate, syncInitialRender, templateIsValid, templateIsValidating, templatize, timeOut, toCssText, translate, types, update, updateNativeProperties, updateStyles, updateUnits, useNativeCSSProperties, useNativeCustomElements, useShadow, version, version as version$1, wrap$1 as wrap, wrap as wrap$1 };