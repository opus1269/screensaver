import { registerEffect } from "./shared_bundle_11.js";

function interpolate(e, t, a, r) {
    a.apply(r, t.map(function(t) {
        return t[0] + (t[1] - t[0]) * e;
    }));
}

registerEffect("blend-background", {
    setUp: function() {
        var e = {};
        e.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), e.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), 
        e.backgroundFrontLayer.style.willChange = "opacity", e.backgroundFrontLayer.style.transform = "translateZ(0)", 
        e.backgroundRearLayer.style.willChange = "opacity", e.backgroundRearLayer.style.transform = "translateZ(0)", 
        e.backgroundRearLayer.style.opacity = 0, this._fxBlendBackground = e;
    },
    run: function(e, t) {
        var a = this._fxBlendBackground;
        a.backgroundFrontLayer.style.opacity = 1 - e, a.backgroundRearLayer.style.opacity = e;
    },
    tearDown: function() {
        delete this._fxBlendBackground;
    }
}), registerEffect("fade-background", {
    setUp: function(e) {
        var t = {}, a = e.duration || "0.5s";
        t.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), t.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), 
        t.backgroundFrontLayer.style.willChange = "opacity", t.backgroundFrontLayer.style.webkitTransform = "translateZ(0)", 
        t.backgroundFrontLayer.style.transitionProperty = "opacity", t.backgroundFrontLayer.style.transitionDuration = a, 
        t.backgroundRearLayer.style.willChange = "opacity", t.backgroundRearLayer.style.webkitTransform = "translateZ(0)", 
        t.backgroundRearLayer.style.transitionProperty = "opacity", t.backgroundRearLayer.style.transitionDuration = a, 
        this._fxFadeBackground = t;
    },
    run: function(e, t) {
        var a = this._fxFadeBackground;
        e >= 1 ? (a.backgroundFrontLayer.style.opacity = 0, a.backgroundRearLayer.style.opacity = 1) : (a.backgroundFrontLayer.style.opacity = 1, 
        a.backgroundRearLayer.style.opacity = 0);
    },
    tearDown: function() {
        delete this._fxFadeBackground;
    }
}), registerEffect("waterfall", {
    run: function() {
        this.shadow = this.isOnScreen() && this.isContentBelow();
    }
}), registerEffect("resize-title", {
    setUp: function() {
        var e = this._getDOMRef("mainTitle"), t = this._getDOMRef("condensedTitle");
        if (!t) return console.warn("Scroll effect `resize-title`: undefined `condensed-title`"), 
        !1;
        if (!e) return console.warn("Scroll effect `resize-title`: undefined `main-title`"), 
        !1;
        t.style.willChange = "opacity", t.style.webkitTransform = "translateZ(0)", t.style.transform = "translateZ(0)", 
        t.style.webkitTransformOrigin = "left top", t.style.transformOrigin = "left top", 
        e.style.willChange = "opacity", e.style.webkitTransformOrigin = "left top", e.style.transformOrigin = "left top", 
        e.style.webkitTransform = "translateZ(0)", e.style.transform = "translateZ(0)";
        var a = e.getBoundingClientRect(), r = t.getBoundingClientRect(), n = {};
        n.scale = parseInt(window.getComputedStyle(t)["font-size"], 10) / parseInt(window.getComputedStyle(e)["font-size"], 10), 
        n.titleDX = a.left - r.left, n.titleDY = a.top - r.top, n.condensedTitle = t, n.title = e, 
        this._fxResizeTitle = n;
    },
    run: function(e, t) {
        var a = this._fxResizeTitle;
        this.condenses || (t = 0), e >= 1 ? (a.title.style.opacity = 0, a.condensedTitle.style.opacity = 1) : (a.title.style.opacity = 1, 
        a.condensedTitle.style.opacity = 0), interpolate(Math.min(1, e), [ [ 1, a.scale ], [ 0, -a.titleDX ], [ t, t - a.titleDY ] ], function(e, t, r) {
            this.transform("translate(" + t + "px, " + r + "px) scale3d(" + e + ", " + e + ", 1)", a.title);
        }, this);
    },
    tearDown: function() {
        delete this._fxResizeTitle;
    }
}), registerEffect("parallax-background", {
    setUp: function(e) {
        var t = {}, a = parseFloat(e.scalar);
        t.background = this._getDOMRef("background"), t.backgroundFrontLayer = this._getDOMRef("backgroundFrontLayer"), 
        t.backgroundRearLayer = this._getDOMRef("backgroundRearLayer"), t.deltaBg = t.backgroundFrontLayer.offsetHeight - t.background.offsetHeight, 
        0 === t.deltaBg ? (isNaN(a) && (a = .8), t.deltaBg = (this._dHeight || 0) * a) : (isNaN(a) && (a = 1), 
        t.deltaBg = t.deltaBg * a), this._fxParallaxBackground = t;
    },
    run: function(e, t) {
        var a = this._fxParallaxBackground;
        this.transform("translate3d(0px, " + a.deltaBg * Math.min(1, e) + "px, 0px)", a.backgroundFrontLayer), 
        a.backgroundRearLayer && this.transform("translate3d(0px, " + a.deltaBg * Math.min(1, e) + "px, 0px)", a.backgroundRearLayer);
    },
    tearDown: function() {
        delete this._fxParallaxBackground;
    }
}), registerEffect("material", {
    setUp: function() {
        return this.effects = "waterfall resize-title blend-background parallax-background", 
        !1;
    }
}), registerEffect("resize-snapped-title", {
    setUp: function(e) {
        var t = this._getDOMRef("mainTitle"), a = this._getDOMRef("condensedTitle"), r = e.duration || "0.2s", n = {};
        return a ? t ? (t.style.transitionProperty = "opacity", t.style.transitionDuration = r, 
        a.style.transitionProperty = "opacity", a.style.transitionDuration = r, n.condensedTitle = a, 
        n.title = t, void (this._fxResizeSnappedTitle = n)) : (console.warn("Scroll effect `resize-snapped-title`: undefined `main-title`"), 
        !1) : (console.warn("Scroll effect `resize-snapped-title`: undefined `condensed-title`"), 
        !1);
    },
    run: function(e, t) {
        var a = this._fxResizeSnappedTitle;
        e > 0 ? (a.title.style.opacity = 0, a.condensedTitle.style.opacity = 1) : (a.title.style.opacity = 1, 
        a.condensedTitle.style.opacity = 0);
    },
    tearDown: function() {
        var e = this._fxResizeSnappedTitle;
        e.title.style.transition = "", e.condensedTitle.style.transition = "", delete this._fxResizeSnappedTitle;
    }
});