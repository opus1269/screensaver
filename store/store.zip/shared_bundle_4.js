if (!window.polymerSkipLoadingFontRoboto) {
    const e = document.createElement("link");
    e.rel = "stylesheet", e.type = "text/css", e.crossOrigin = "anonymous", e.href = "https://fonts.googleapis.com/css?family=Roboto+Mono:400,700|Roboto:400,300,300italic,400italic,500,500italic,700,700italic", 
    document.head.appendChild(e);
}

/**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  */ const nativeShadow = !(window.ShadyDOM && window.ShadyDOM.inUse);

let nativeCssVariables_, cssBuild;

function calcCssVariables(e) {
    nativeCssVariables_ = (!e || !e.shimcssproperties) && (nativeShadow || Boolean(!navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/) && window.CSS && CSS.supports && CSS.supports("box-shadow", "0 0 0 var(--foo)")));
}

window.ShadyCSS && void 0 !== window.ShadyCSS.cssBuild && (cssBuild = window.ShadyCSS.cssBuild);

const disableRuntime = Boolean(window.ShadyCSS && window.ShadyCSS.disableRuntime);

window.ShadyCSS && void 0 !== window.ShadyCSS.nativeCss ? nativeCssVariables_ = window.ShadyCSS.nativeCss : window.ShadyCSS ? (calcCssVariables(window.ShadyCSS), 
window.ShadyCSS = void 0) : calcCssVariables(window.WebComponents && window.WebComponents.flags);

const nativeCssVariables = nativeCssVariables_;

var styleSettings = {
    nativeShadow: nativeShadow,
    get cssBuild() {
        return cssBuild;
    },
    disableRuntime: disableRuntime,
    nativeCssVariables: nativeCssVariables
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ class StyleNode {
    constructor() {
        this.start = 0, this.end = 0, this.previous = null, this.parent = null, this.rules = null, 
        this.parsedCssText = "", this.cssText = "", this.atRule = !1, this.type = 0, this.keyframesName = "", 
        this.selector = "", this.parsedSelector = "";
    }
}

function parse(e) {
    return parseCss(lex(e = clean(e)), e);
}

function clean(e) {
    return e.replace(RX.comments, "").replace(RX.port, "");
}

function lex(e) {
    let t = new StyleNode();
    t.start = 0, t.end = e.length;
    let i = t;
    for (let n = 0, s = e.length; n < s; n++) if (e[n] === OPEN_BRACE) {
        i.rules || (i.rules = []);
        let e = i, t = e.rules[e.rules.length - 1] || null;
        (i = new StyleNode()).start = n + 1, i.parent = e, i.previous = t, e.rules.push(i);
    } else e[n] === CLOSE_BRACE && (i.end = n + 1, i = i.parent || t);
    return t;
}

function parseCss(e, t) {
    let i = t.substring(e.start, e.end - 1);
    if (e.parsedCssText = e.cssText = i.trim(), e.parent) {
        let n = e.previous ? e.previous.end : e.parent.start;
        i = (i = (i = _expandUnicodeEscapes(i = t.substring(n, e.start - 1))).replace(RX.multipleSpaces, " ")).substring(i.lastIndexOf(";") + 1);
        let s = e.parsedSelector = e.selector = i.trim();
        e.atRule = 0 === s.indexOf(AT_START), e.atRule ? 0 === s.indexOf(MEDIA_START) ? e.type = types.MEDIA_RULE : s.match(RX.keyframesRule) && (e.type = types.KEYFRAMES_RULE, 
        e.keyframesName = e.selector.split(RX.multipleSpaces).pop()) : 0 === s.indexOf(VAR_START) ? e.type = types.MIXIN_RULE : e.type = types.STYLE_RULE;
    }
    let n = e.rules;
    if (n) for (let e, i = 0, s = n.length; i < s && (e = n[i]); i++) parseCss(e, t);
    return e;
}

function _expandUnicodeEscapes(e) {
    return e.replace(/\\([0-9a-f]{1,6})\s/gi, function() {
        let e = arguments[1], t = 6 - e.length;
        for (;t--; ) e = "0" + e;
        return "\\" + e;
    });
}

function stringify(e, t, i = "") {
    let n = "";
    if (e.cssText || e.rules) {
        let i = e.rules;
        if (i && !_hasMixinRules(i)) for (let e, s = 0, r = i.length; s < r && (e = i[s]); s++) n = stringify(e, t, n); else (n = (n = t ? e.cssText : removeCustomProps(e.cssText)).trim()) && (n = "  " + n + "\n");
    }
    return n && (e.selector && (i += e.selector + " " + OPEN_BRACE + "\n"), i += n, 
    e.selector && (i += CLOSE_BRACE + "\n\n")), i;
}

function _hasMixinRules(e) {
    let t = e[0];
    return Boolean(t) && Boolean(t.selector) && 0 === t.selector.indexOf(VAR_START);
}

function removeCustomProps(e) {
    return removeCustomPropApply(e = removeCustomPropAssignment(e));
}

function removeCustomPropAssignment(e) {
    return e.replace(RX.customProp, "").replace(RX.mixinProp, "");
}

function removeCustomPropApply(e) {
    return e.replace(RX.mixinApply, "").replace(RX.varApply, "");
}

const types = {
    STYLE_RULE: 1,
    KEYFRAMES_RULE: 7,
    MEDIA_RULE: 4,
    MIXIN_RULE: 1e3
}, OPEN_BRACE = "{", CLOSE_BRACE = "}", RX = {
    comments: /\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim,
    port: /@import[^;]*;/gim,
    customProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,
    mixinProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,
    mixinApply: /@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,
    varApply: /[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,
    keyframesRule: /^@[^\s]*keyframes/,
    multipleSpaces: /\s+/g
}, VAR_START = "--", MEDIA_START = "@media", AT_START = "@";

var cssParse = {
    StyleNode: StyleNode,
    parse: parse,
    stringify: stringify,
    removeCustomPropAssignment: removeCustomPropAssignment,
    types: types
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const VAR_ASSIGN = /(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi, MIXIN_MATCH = /(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi, VAR_CONSUMED = /(--[\w-]+)\s*([:,;)]|$)/gi, ANIMATION_MATCH = /(animation\s*:)|(animation-name\s*:)/, MEDIA_MATCH = /@media\s(.*)/, IS_VAR = /^--/, BRACKETED = /\{[^}]*\}/g, HOST_PREFIX = "(?:^|[^.#[:])", HOST_SUFFIX = "($|[.:[\\s>+~])";

var commonRegex = {
    VAR_ASSIGN: VAR_ASSIGN,
    MIXIN_MATCH: MIXIN_MATCH,
    VAR_CONSUMED: VAR_CONSUMED,
    ANIMATION_MATCH: ANIMATION_MATCH,
    MEDIA_MATCH: MEDIA_MATCH,
    IS_VAR: IS_VAR,
    BRACKETED: BRACKETED,
    HOST_PREFIX: HOST_PREFIX,
    HOST_SUFFIX: HOST_SUFFIX
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const styleTextSet = new Set(), scopingAttribute = "shady-unscoped";

function processUnscopedStyle(e) {
    const t = e.textContent;
    if (!styleTextSet.has(t)) {
        styleTextSet.add(t);
        const i = e.cloneNode(!0);
        document.head.appendChild(i);
    }
}

function isUnscopedStyle(e) {
    return e.hasAttribute(scopingAttribute);
}

var unscopedStyleHandler = {
    scopingAttribute: scopingAttribute,
    processUnscopedStyle: processUnscopedStyle,
    isUnscopedStyle: isUnscopedStyle
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function toCssText(e, t) {
    return e ? ("string" == typeof e && (e = parse(e)), t && forEachRule(e, t), stringify(e, nativeCssVariables)) : "";
}

function rulesForStyle(e) {
    return !e.__cssRules && e.textContent && (e.__cssRules = parse(e.textContent)), 
    e.__cssRules || null;
}

function isKeyframesSelector(e) {
    return Boolean(e.parent) && e.parent.type === types.KEYFRAMES_RULE;
}

function forEachRule(e, t, i, n) {
    if (!e) return;
    let s = !1, r = e.type;
    if (n && r === types.MEDIA_RULE) {
        let t = e.selector.match(MEDIA_MATCH);
        t && (window.matchMedia(t[1]).matches || (s = !0));
    }
    r === types.STYLE_RULE ? t(e) : i && r === types.KEYFRAMES_RULE ? i(e) : r === types.MIXIN_RULE && (s = !0);
    let o = e.rules;
    if (o && !s) for (let e, s = 0, r = o.length; s < r && (e = o[s]); s++) forEachRule(e, t, i, n);
}

function applyCss(e, t, i, n) {
    let s = createScopeStyle(e, t);
    return applyStyle(s, i, n), s;
}

function createScopeStyle(e, t) {
    let i = document.createElement("style");
    return t && i.setAttribute("scope", t), i.textContent = e, i;
}

let lastHeadApplyNode = null;

function applyStylePlaceHolder(e) {
    let t = document.createComment(" Shady DOM styles for " + e + " "), i = lastHeadApplyNode ? lastHeadApplyNode.nextSibling : null, n = document.head;
    return n.insertBefore(t, i || n.firstChild), lastHeadApplyNode = t, t;
}

function applyStyle(e, t, i) {
    t = t || document.head;
    let n = i && i.nextSibling || t.firstChild;
    if (t.insertBefore(e, n), lastHeadApplyNode) {
        e.compareDocumentPosition(lastHeadApplyNode) === Node.DOCUMENT_POSITION_PRECEDING && (lastHeadApplyNode = e);
    } else lastHeadApplyNode = e;
}

function isTargetedBuild(e) {
    return nativeShadow ? "shadow" === e : "shady" === e;
}

function findMatchingParen(e, t) {
    let i = 0;
    for (let n = t, s = e.length; n < s; n++) if ("(" === e[n]) i++; else if (")" === e[n] && 0 == --i) return n;
    return -1;
}

function processVariableAndFallback(e, t) {
    let i = e.indexOf("var(");
    if (-1 === i) return t(e, "", "", "");
    let n = findMatchingParen(e, i + 3), s = e.substring(i + 4, n), r = e.substring(0, i), o = processVariableAndFallback(e.substring(n + 1), t), a = s.indexOf(",");
    return -1 === a ? t(r, s.trim(), "", o) : t(r, s.substring(0, a).trim(), s.substring(a + 1).trim(), o);
}

function setElementClassRaw(e, t) {
    nativeShadow ? e.setAttribute("class", t) : window.ShadyDOM.nativeMethods.setAttribute.call(e, "class", t);
}

const wrap = window.ShadyDOM && window.ShadyDOM.wrap || (e => e);

function getIsExtends(e) {
    let t = e.localName, i = "", n = "";
    return t ? t.indexOf("-") > -1 ? i = t : (n = t, i = e.getAttribute && e.getAttribute("is") || "") : (i = e.is, 
    n = e.extends), {
        is: i,
        typeExtension: n
    };
}

function gatherStyleText(e) {
    const t = [], i = e.querySelectorAll("style");
    for (let e = 0; e < i.length; e++) {
        const n = i[e];
        isUnscopedStyle(n) ? nativeShadow || (processUnscopedStyle(n), n.parentNode.removeChild(n)) : (t.push(n.textContent), 
        n.parentNode.removeChild(n));
    }
    return t.join("").trim();
}

function splitSelectorList(e) {
    const t = [];
    let i = "";
    for (let n = 0; n >= 0 && n < e.length; n++) if ("(" === e[n]) {
        const t = findMatchingParen(e, n);
        i += e.slice(n, t + 1), n = t;
    } else "," === e[n] ? (t.push(i), i = "") : i += e[n];
    return i && t.push(i), t;
}

const CSS_BUILD_ATTR = "css-build";

function getCssBuild(e) {
    if (void 0 !== cssBuild) return cssBuild;
    if (void 0 === e.__cssBuild) {
        const t = e.getAttribute(CSS_BUILD_ATTR);
        if (t) e.__cssBuild = t; else {
            const t = getBuildComment(e);
            "" !== t && removeBuildComment(e), e.__cssBuild = t;
        }
    }
    return e.__cssBuild || "";
}

function elementHasBuiltCss(e) {
    return "" !== getCssBuild(e);
}

function getBuildComment(e) {
    const t = "template" === e.localName ? e.content.firstChild : e.firstChild;
    if (t instanceof Comment) {
        const e = t.textContent.trim().split(":");
        if (e[0] === CSS_BUILD_ATTR) return e[1];
    }
    return "";
}

function isOptimalCssBuild(e = "") {
    return !("" === e || !nativeCssVariables) && (nativeShadow ? "shadow" === e : "shady" === e);
}

function removeBuildComment(e) {
    const t = "template" === e.localName ? e.content.firstChild : e.firstChild;
    t.parentNode.removeChild(t);
}

var styleUtil = {
    toCssText: toCssText,
    rulesForStyle: rulesForStyle,
    isKeyframesSelector: isKeyframesSelector,
    forEachRule: forEachRule,
    applyCss: applyCss,
    createScopeStyle: createScopeStyle,
    applyStylePlaceHolder: applyStylePlaceHolder,
    applyStyle: applyStyle,
    isTargetedBuild: isTargetedBuild,
    findMatchingParen: findMatchingParen,
    processVariableAndFallback: processVariableAndFallback,
    setElementClassRaw: setElementClassRaw,
    wrap: wrap,
    getIsExtends: getIsExtends,
    gatherStyleText: gatherStyleText,
    splitSelectorList: splitSelectorList,
    getCssBuild: getCssBuild,
    elementHasBuiltCss: elementHasBuiltCss,
    getBuildComment: getBuildComment,
    isOptimalCssBuild: isOptimalCssBuild
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function updateNativeProperties(e, t) {
    for (let i in t) null === i ? e.style.removeProperty(i) : e.style.setProperty(i, t[i]);
}

function getComputedStyleValue(e, t) {
    const i = window.getComputedStyle(e).getPropertyValue(t);
    return i ? i.trim() : "";
}

function detectMixin(e) {
    const t = MIXIN_MATCH.test(e) || VAR_ASSIGN.test(e);
    return MIXIN_MATCH.lastIndex = 0, VAR_ASSIGN.lastIndex = 0, t;
}

var commonUtils = {
    updateNativeProperties: updateNativeProperties,
    getComputedStyleValue: getComputedStyleValue,
    detectMixin: detectMixin
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const APPLY_NAME_CLEAN = /;\s*/m, INITIAL_INHERIT = /^\s*(initial)|(inherit)\s*$/, IMPORTANT = /\s*!important/, MIXIN_VAR_SEP = "_-_";

let PropertyEntry, DependantsEntry, MixinMapEntry;

class MixinMap {
    constructor() {
        this._map = {};
    }
    set(e, t) {
        e = e.trim(), this._map[e] = {
            properties: t,
            dependants: {}
        };
    }
    get(e) {
        return e = e.trim(), this._map[e] || null;
    }
}

let invalidCallback = null;

class ApplyShim {
    constructor() {
        this._currentElement = null, this._measureElement = null, this._map = new MixinMap();
    }
    detectMixin(e) {
        return detectMixin(e);
    }
    gatherStyles(e) {
        const t = gatherStyleText(e.content);
        if (t) {
            const i = document.createElement("style");
            return i.textContent = t, e.content.insertBefore(i, e.content.firstChild), i;
        }
        return null;
    }
    transformTemplate(e, t) {
        void 0 === e._gatheredStyle && (e._gatheredStyle = this.gatherStyles(e));
        const i = e._gatheredStyle;
        return i ? this.transformStyle(i, t) : null;
    }
    transformStyle(e, t = "") {
        let i = rulesForStyle(e);
        return this.transformRules(i, t), e.textContent = toCssText(i), i;
    }
    transformCustomStyle(e) {
        let t = rulesForStyle(e);
        return forEachRule(t, e => {
            ":root" === e.selector && (e.selector = "html"), this.transformRule(e);
        }), e.textContent = toCssText(t), t;
    }
    transformRules(e, t) {
        this._currentElement = t, forEachRule(e, e => {
            this.transformRule(e);
        }), this._currentElement = null;
    }
    transformRule(e) {
        e.cssText = this.transformCssText(e.parsedCssText, e), ":root" === e.selector && (e.selector = ":host > *");
    }
    transformCssText(e, t) {
        return e = e.replace(VAR_ASSIGN, (e, i, n, s) => this._produceCssProperties(e, i, n, s, t)), 
        this._consumeCssProperties(e, t);
    }
    _getInitialValueForProperty(e) {
        return this._measureElement || (this._measureElement = document.createElement("meta"), 
        this._measureElement.setAttribute("apply-shim-measure", ""), this._measureElement.style.all = "initial", 
        document.head.appendChild(this._measureElement)), window.getComputedStyle(this._measureElement).getPropertyValue(e);
    }
    _fallbacksFromPreviousRules(e) {
        let t = e;
        for (;t.parent; ) t = t.parent;
        const i = {};
        let n = !1;
        return forEachRule(t, t => {
            (n = n || t === e) || t.selector === e.selector && Object.assign(i, this._cssTextToMap(t.parsedCssText));
        }), i;
    }
    _consumeCssProperties(e, t) {
        let i = null;
        for (;i = MIXIN_MATCH.exec(e); ) {
            let n = i[0], s = i[1], r = i.index, o = r + n.indexOf("@apply"), a = r + n.length, l = e.slice(0, o), c = e.slice(a), h = t ? this._fallbacksFromPreviousRules(t) : {};
            Object.assign(h, this._cssTextToMap(l));
            let d = this._atApplyToCssProperties(s, h);
            e = `${l}${d}${c}`, MIXIN_MATCH.lastIndex = r + d.length;
        }
        return e;
    }
    _atApplyToCssProperties(e, t) {
        e = e.replace(APPLY_NAME_CLEAN, "");
        let i = [], n = this._map.get(e);
        if (n || (this._map.set(e, {}), n = this._map.get(e)), n) {
            let s, r, o;
            this._currentElement && (n.dependants[this._currentElement] = !0);
            const a = n.properties;
            for (s in a) o = t && t[s], r = [ s, ": var(", e, MIXIN_VAR_SEP, s ], o && r.push(",", o.replace(IMPORTANT, "")), 
            r.push(")"), IMPORTANT.test(a[s]) && r.push(" !important"), i.push(r.join(""));
        }
        return i.join("; ");
    }
    _replaceInitialOrInherit(e, t) {
        let i = INITIAL_INHERIT.exec(t);
        return i && (t = i[1] ? this._getInitialValueForProperty(e) : "apply-shim-inherit"), 
        t;
    }
    _cssTextToMap(e, t = !1) {
        let i, n, s = e.split(";"), r = {};
        for (let e, o, a = 0; a < s.length; a++) (e = s[a]) && (o = e.split(":")).length > 1 && (i = o[0].trim(), 
        n = o.slice(1).join(":"), t && (n = this._replaceInitialOrInherit(i, n)), r[i] = n);
        return r;
    }
    _invalidateMixinEntry(e) {
        if (invalidCallback) for (let t in e.dependants) t !== this._currentElement && invalidCallback(t);
    }
    _produceCssProperties(e, t, i, n, s) {
        if (i && processVariableAndFallback(i, (e, t) => {
            t && this._map.get(t) && (n = `@apply ${t};`);
        }), !n) return e;
        let r = this._consumeCssProperties("" + n, s), o = e.slice(0, e.indexOf("--")), a = this._cssTextToMap(r, !0), l = a, c = this._map.get(t), h = c && c.properties;
        h ? l = Object.assign(Object.create(h), a) : this._map.set(t, l);
        let d, u, p = [], m = !1;
        for (d in l) void 0 === (u = a[d]) && (u = "initial"), !h || d in h || (m = !0), 
        p.push(`${t}${MIXIN_VAR_SEP}${d}: ${u}`);
        return m && this._invalidateMixinEntry(c), c && (c.properties = l), i && (o = `${e};${o}`), 
        `${o}${p.join("; ")};`;
    }
}

ApplyShim.prototype.detectMixin = ApplyShim.prototype.detectMixin, ApplyShim.prototype.transformStyle = ApplyShim.prototype.transformStyle, 
ApplyShim.prototype.transformCustomStyle = ApplyShim.prototype.transformCustomStyle, 
ApplyShim.prototype.transformRules = ApplyShim.prototype.transformRules, ApplyShim.prototype.transformRule = ApplyShim.prototype.transformRule, 
ApplyShim.prototype.transformTemplate = ApplyShim.prototype.transformTemplate, ApplyShim.prototype._separator = MIXIN_VAR_SEP, 
Object.defineProperty(ApplyShim.prototype, "invalidCallback", {
    get: () => invalidCallback,
    set(e) {
        invalidCallback = e;
    }
});

var applyShim = {
    default: ApplyShim
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const templateMap = {};

var templateMap$1 = {
    default: templateMap
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const CURRENT_VERSION = "_applyShimCurrentVersion", NEXT_VERSION = "_applyShimNextVersion", VALIDATING_VERSION = "_applyShimValidatingVersion", promise = Promise.resolve();

function invalidate(e) {
    let t = templateMap[e];
    t && invalidateTemplate(t);
}

function invalidateTemplate(e) {
    e[CURRENT_VERSION] = e[CURRENT_VERSION] || 0, e[VALIDATING_VERSION] = e[VALIDATING_VERSION] || 0, 
    e[NEXT_VERSION] = (e[NEXT_VERSION] || 0) + 1;
}

function isValid(e) {
    let t = templateMap[e];
    return !t || templateIsValid(t);
}

function templateIsValid(e) {
    return e[CURRENT_VERSION] === e[NEXT_VERSION];
}

function isValidating(e) {
    let t = templateMap[e];
    return !!t && templateIsValidating(t);
}

function templateIsValidating(e) {
    return !templateIsValid(e) && e[VALIDATING_VERSION] === e[NEXT_VERSION];
}

function startValidating(e) {
    startValidatingTemplate(templateMap[e]);
}

function startValidatingTemplate(e) {
    e[VALIDATING_VERSION] = e[NEXT_VERSION], e._validating || (e._validating = !0, promise.then(function() {
        e[CURRENT_VERSION] = e[NEXT_VERSION], e._validating = !1;
    }));
}

function elementsAreInvalid() {
    for (let e in templateMap) {
        if (!templateIsValid(templateMap[e])) return !0;
    }
    return !1;
}

var applyShimUtils = {
    invalidate: invalidate,
    invalidateTemplate: invalidateTemplate,
    isValid: isValid,
    templateIsValid: templateIsValid,
    isValidating: isValidating,
    templateIsValidating: templateIsValidating,
    startValidating: startValidating,
    startValidatingTemplate: startValidatingTemplate,
    elementsAreInvalid: elementsAreInvalid
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ let resolveFn, readyPromise = null, whenReady = window.HTMLImports && window.HTMLImports.whenReady || null;

function documentWait(e) {
    requestAnimationFrame(function() {
        whenReady ? whenReady(e) : (readyPromise || (readyPromise = new Promise(e => {
            resolveFn = e;
        }), "complete" === document.readyState ? resolveFn() : document.addEventListener("readystatechange", () => {
            "complete" === document.readyState && resolveFn();
        })), readyPromise.then(function() {
            e && e();
        }));
    });
}

var documentWait$1 = {
    default: documentWait
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ let CustomStyleProvider;

const SEEN_MARKER = "__seenByShadyCSS", CACHED_STYLE = "__shadyCSSCachedStyle";

let transformFn = null, validateFn = null;

class CustomStyleInterface {
    constructor() {
        this.customStyles = [], this.enqueued = !1, documentWait(() => {
            window.ShadyCSS.flushCustomStyles && window.ShadyCSS.flushCustomStyles();
        });
    }
    enqueueDocumentValidation() {
        !this.enqueued && validateFn && (this.enqueued = !0, documentWait(validateFn));
    }
    addCustomStyle(e) {
        e[SEEN_MARKER] || (e[SEEN_MARKER] = !0, this.customStyles.push(e), this.enqueueDocumentValidation());
    }
    getStyleForCustomStyle(e) {
        if (e[CACHED_STYLE]) return e[CACHED_STYLE];
        let t;
        return t = e.getStyle ? e.getStyle() : e;
    }
    processStyles() {
        const e = this.customStyles;
        for (let t = 0; t < e.length; t++) {
            const i = e[t];
            if (i[CACHED_STYLE]) continue;
            const n = this.getStyleForCustomStyle(i);
            if (n) {
                const e = n.__appliedElement || n;
                transformFn && transformFn(e), i[CACHED_STYLE] = e;
            }
        }
        return e;
    }
}

CustomStyleInterface.prototype.addCustomStyle = CustomStyleInterface.prototype.addCustomStyle, 
CustomStyleInterface.prototype.getStyleForCustomStyle = CustomStyleInterface.prototype.getStyleForCustomStyle, 
CustomStyleInterface.prototype.processStyles = CustomStyleInterface.prototype.processStyles, 
Object.defineProperties(CustomStyleInterface.prototype, {
    transformCallback: {
        get: () => transformFn,
        set(e) {
            transformFn = e;
        }
    },
    validateCallback: {
        get: () => validateFn,
        set(e) {
            let t = !1;
            validateFn || (t = !0), validateFn = e, t && this.enqueueDocumentValidation();
        }
    }
});

const CustomStyleInterfaceInterface = {};

var customStyleInterface = {
    CustomStyleProvider: CustomStyleProvider,
    default: CustomStyleInterface,
    CustomStyleInterfaceInterface: CustomStyleInterfaceInterface
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const applyShim$1 = new ApplyShim();

class ApplyShimInterface {
    constructor() {
        this.customStyleInterface = null, applyShim$1.invalidCallback = invalidate;
    }
    ensure() {
        this.customStyleInterface || window.ShadyCSS.CustomStyleInterface && (this.customStyleInterface = window.ShadyCSS.CustomStyleInterface, 
        this.customStyleInterface.transformCallback = (e => {
            applyShim$1.transformCustomStyle(e);
        }), this.customStyleInterface.validateCallback = (() => {
            requestAnimationFrame(() => {
                this.customStyleInterface.enqueued && this.flushCustomStyles();
            });
        }));
    }
    prepareTemplate(e, t) {
        if (this.ensure(), elementHasBuiltCss(e)) return;
        templateMap[t] = e;
        let i = applyShim$1.transformTemplate(e, t);
        e._styleAst = i;
    }
    flushCustomStyles() {
        if (this.ensure(), !this.customStyleInterface) return;
        let e = this.customStyleInterface.processStyles();
        if (this.customStyleInterface.enqueued) {
            for (let t = 0; t < e.length; t++) {
                let i = e[t], n = this.customStyleInterface.getStyleForCustomStyle(i);
                n && applyShim$1.transformCustomStyle(n);
            }
            this.customStyleInterface.enqueued = !1;
        }
    }
    styleSubtree(e, t) {
        if (this.ensure(), t && updateNativeProperties(e, t), e.shadowRoot) {
            this.styleElement(e);
            let t = e.shadowRoot.children || e.shadowRoot.childNodes;
            for (let e = 0; e < t.length; e++) this.styleSubtree(t[e]);
        } else {
            let t = e.children || e.childNodes;
            for (let e = 0; e < t.length; e++) this.styleSubtree(t[e]);
        }
    }
    styleElement(e) {
        this.ensure();
        let {is: t} = getIsExtends(e), i = templateMap[t];
        if ((!i || !elementHasBuiltCss(i)) && i && !templateIsValid(i)) {
            templateIsValidating(i) || (this.prepareTemplate(i, t), startValidatingTemplate(i));
            let n = e.shadowRoot;
            if (n) {
                let e = n.querySelector("style");
                e && (e.__cssRules = i._styleAst, e.textContent = toCssText(i._styleAst));
            }
        }
    }
    styleDocument(e) {
        this.ensure(), this.styleSubtree(document.body, e);
    }
}

if (!window.ShadyCSS || !window.ShadyCSS.ScopingShim) {
    const e = new ApplyShimInterface();
    let t = window.ShadyCSS && window.ShadyCSS.CustomStyleInterface;
    window.ShadyCSS = {
        prepareTemplate(t, i, n) {
            e.flushCustomStyles(), e.prepareTemplate(t, i);
        },
        prepareTemplateStyles(e, t, i) {
            window.ShadyCSS.prepareTemplate(e, t, i);
        },
        prepareTemplateDom(e, t) {},
        styleSubtree(t, i) {
            e.flushCustomStyles(), e.styleSubtree(t, i);
        },
        styleElement(t) {
            e.flushCustomStyles(), e.styleElement(t);
        },
        styleDocument(t) {
            e.flushCustomStyles(), e.styleDocument(t);
        },
        getComputedStyleValue: (e, t) => getComputedStyleValue(e, t),
        flushCustomStyles() {
            e.flushCustomStyles();
        },
        nativeCss: nativeCssVariables,
        nativeShadow: nativeShadow,
        cssBuild: cssBuild,
        disableRuntime: disableRuntime
    }, t && (window.ShadyCSS.CustomStyleInterface = t);
}

window.ShadyCSS.ApplyShim = applyShim$1, 
/**
                                         @license
                                         Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
                                         This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
                                         The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
                                         The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
                                         Code distributed by Google as part of the polymer project is also
                                         subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
                                         */
window.JSCompiler_renameProperty = function(e, t) {
    return e;
};

let workingURL, resolveDoc, CSS_URL_RX = /(url\()([^)]*)(\))/g, ABS_URL = /(^\/)|(^#)|(^[\w-\d]*:)/;

function resolveUrl(e, t) {
    if (e && ABS_URL.test(e)) return e;
    if (void 0 === workingURL) {
        workingURL = !1;
        try {
            const e = new URL("b", "http://a");
            e.pathname = "c%20d", workingURL = "http://a/c%20d" === e.href;
        } catch (e) {}
    }
    return t || (t = document.baseURI || window.location.href), workingURL ? new URL(e, t).href : (resolveDoc || ((resolveDoc = document.implementation.createHTMLDocument("temp")).base = resolveDoc.createElement("base"), 
    resolveDoc.head.appendChild(resolveDoc.base), resolveDoc.anchor = resolveDoc.createElement("a"), 
    resolveDoc.body.appendChild(resolveDoc.anchor)), resolveDoc.base.href = t, resolveDoc.anchor.href = e, 
    resolveDoc.anchor.href || e);
}

function resolveCss(e, t) {
    return e.replace(CSS_URL_RX, function(e, i, n, s) {
        return i + "'" + resolveUrl(n.replace(/["']/g, ""), t) + "'" + s;
    });
}

function pathFromUrl(e) {
    return e.substring(0, e.lastIndexOf("/") + 1);
}

var resolveUrl$1 = {
    resolveUrl: resolveUrl,
    resolveCss: resolveCss,
    pathFromUrl: pathFromUrl
};

const useShadow = !window.ShadyDOM, useNativeCSSProperties = Boolean(!window.ShadyCSS || window.ShadyCSS.nativeCss), useNativeCustomElements = !window.customElements.polyfillWrapFlushCallback;

let rootPath = pathFromUrl(document.baseURI || window.location.href);

const setRootPath = function(e) {
    rootPath = e;
};

let sanitizeDOMValue = window.Polymer && window.Polymer.sanitizeDOMValue || void 0;

const setSanitizeDOMValue = function(e) {
    sanitizeDOMValue = e;
};

let passiveTouchGestures = !1;

const setPassiveTouchGestures = function(e) {
    passiveTouchGestures = e;
};

let strictTemplatePolicy = !1;

const setStrictTemplatePolicy = function(e) {
    strictTemplatePolicy = e;
};

let allowTemplateFromDomModule = !1;

const setAllowTemplateFromDomModule = function(e) {
    allowTemplateFromDomModule = e;
};

var settings = {
    useShadow: useShadow,
    useNativeCSSProperties: useNativeCSSProperties,
    useNativeCustomElements: useNativeCustomElements,
    get rootPath() {
        return rootPath;
    },
    setRootPath: setRootPath,
    get sanitizeDOMValue() {
        return sanitizeDOMValue;
    },
    setSanitizeDOMValue: setSanitizeDOMValue,
    get passiveTouchGestures() {
        return passiveTouchGestures;
    },
    setPassiveTouchGestures: setPassiveTouchGestures,
    get strictTemplatePolicy() {
        return strictTemplatePolicy;
    },
    setStrictTemplatePolicy: setStrictTemplatePolicy,
    get allowTemplateFromDomModule() {
        return allowTemplateFromDomModule;
    },
    setAllowTemplateFromDomModule: setAllowTemplateFromDomModule
};

let dedupeId = 0;

function MixinFunction() {}

MixinFunction.prototype.__mixinApplications, MixinFunction.prototype.__mixinSet;

const dedupingMixin = function(e) {
    let t = e.__mixinApplications;
    t || (t = new WeakMap(), e.__mixinApplications = t);
    let i = dedupeId++;
    return function(n) {
        let s = n.__mixinSet;
        if (s && s[i]) return n;
        let r = t, o = r.get(n);
        o || (o = e(n), r.set(n, o));
        let a = Object.create(o.__mixinSet || s || null);
        return a[i] = !0, o.__mixinSet = a, o;
    };
};

var mixin = {
    dedupingMixin: dedupingMixin
};

let modules = {}, lcModules = {};

function setModule(e, t) {
    modules[e] = lcModules[e.toLowerCase()] = t;
}

function findModule(e) {
    return modules[e] || lcModules[e.toLowerCase()];
}

function styleOutsideTemplateCheck(e) {
    e.querySelector("style") && console.warn("dom-module %s has style outside template", e.id);
}

class DomModule extends HTMLElement {
    static get observedAttributes() {
        return [ "id" ];
    }
    static import(e, t) {
        if (e) {
            let i = findModule(e);
            return i && t ? i.querySelector(t) : i;
        }
        return null;
    }
    attributeChangedCallback(e, t, i, n) {
        t !== i && this.register();
    }
    get assetpath() {
        if (!this.__assetpath) {
            const e = window.HTMLImports && HTMLImports.importForElement ? HTMLImports.importForElement(this) || document : this.ownerDocument, t = resolveUrl(this.getAttribute("assetpath") || "", e.baseURI);
            this.__assetpath = pathFromUrl(t);
        }
        return this.__assetpath;
    }
    register(e) {
        if (e = e || this.id) {
            if (strictTemplatePolicy && void 0 !== findModule(e)) throw setModule(e, null), 
            new Error(`strictTemplatePolicy: dom-module ${e} re-registered`);
            this.id = e, setModule(e, this), styleOutsideTemplateCheck(this);
        }
    }
}

DomModule.prototype.modules = modules, customElements.define("dom-module", DomModule);

var domModule = {
    DomModule: DomModule
};

const MODULE_STYLE_LINK_SELECTOR = "link[rel=import][type~=css]", INCLUDE_ATTR = "include", SHADY_UNSCOPED_ATTR = "shady-unscoped";

function importModule(e) {
    return DomModule.import(e);
}

function styleForImport(e) {
    const t = resolveCss((e.body ? e.body : e).textContent, e.baseURI), i = document.createElement("style");
    return i.textContent = t, i;
}

let templateWithAssetPath;

function stylesFromModules(e) {
    const t = e.trim().split(/\s+/), i = [];
    for (let e = 0; e < t.length; e++) i.push(...stylesFromModule(t[e]));
    return i;
}

function stylesFromModule(e) {
    const t = importModule(e);
    if (!t) return console.warn("Could not find style data in module named", e), [];
    if (void 0 === t._styles) {
        const e = [];
        e.push(..._stylesFromModuleImports(t));
        const i = t.querySelector("template");
        i && e.push(...stylesFromTemplate(i, t.assetpath)), t._styles = e;
    }
    return t._styles;
}

function stylesFromTemplate(e, t) {
    if (!e._styles) {
        const i = [], n = e.content.querySelectorAll("style");
        for (let e = 0; e < n.length; e++) {
            let s = n[e], r = s.getAttribute(INCLUDE_ATTR);
            r && i.push(...stylesFromModules(r).filter(function(e, t, i) {
                return i.indexOf(e) === t;
            })), t && (s.textContent = resolveCss(s.textContent, t)), i.push(s);
        }
        e._styles = i;
    }
    return e._styles;
}

function stylesFromModuleImports(e) {
    let t = importModule(e);
    return t ? _stylesFromModuleImports(t) : [];
}

function _stylesFromModuleImports(e) {
    const t = [], i = e.querySelectorAll(MODULE_STYLE_LINK_SELECTOR);
    for (let e = 0; e < i.length; e++) {
        let n = i[e];
        if (n.import) {
            const e = n.import, i = n.hasAttribute(SHADY_UNSCOPED_ATTR);
            if (i && !e._unscopedStyle) {
                const t = styleForImport(e);
                t.setAttribute(SHADY_UNSCOPED_ATTR, ""), e._unscopedStyle = t;
            } else e._style || (e._style = styleForImport(e));
            t.push(i ? e._unscopedStyle : e._style);
        }
    }
    return t;
}

function cssFromModules(e) {
    let t = e.trim().split(/\s+/), i = "";
    for (let e = 0; e < t.length; e++) i += cssFromModule(t[e]);
    return i;
}

function cssFromModule(e) {
    let t = importModule(e);
    if (t && void 0 === t._cssText) {
        let e = _cssFromModuleImports(t), i = t.querySelector("template");
        i && (e += cssFromTemplate(i, t.assetpath)), t._cssText = e || null;
    }
    return t || console.warn("Could not find style data in module named", e), t && t._cssText || "";
}

function cssFromTemplate(e, t) {
    let i = "";
    const n = stylesFromTemplate(e, t);
    for (let e = 0; e < n.length; e++) {
        let t = n[e];
        t.parentNode && t.parentNode.removeChild(t), i += t.textContent;
    }
    return i;
}

function cssFromModuleImports(e) {
    let t = importModule(e);
    return t ? _cssFromModuleImports(t) : "";
}

function _cssFromModuleImports(e) {
    let t = "", i = _stylesFromModuleImports(e);
    for (let e = 0; e < i.length; e++) t += i[e].textContent;
    return t;
}

var styleGather = {
    stylesFromModules: stylesFromModules,
    stylesFromModule: stylesFromModule,
    stylesFromTemplate: stylesFromTemplate,
    stylesFromModuleImports: stylesFromModuleImports,
    cssFromModules: cssFromModules,
    cssFromModule: cssFromModule,
    cssFromTemplate: cssFromTemplate,
    cssFromModuleImports: cssFromModuleImports
};

function isPath(e) {
    return e.indexOf(".") >= 0;
}

function root(e) {
    let t = e.indexOf(".");
    return -1 === t ? e : e.slice(0, t);
}

function isAncestor(e, t) {
    return 0 === e.indexOf(t + ".");
}

function isDescendant(e, t) {
    return 0 === t.indexOf(e + ".");
}

function translate(e, t, i) {
    return t + i.slice(e.length);
}

function matches(e, t) {
    return e === t || isAncestor(e, t) || isDescendant(e, t);
}

function normalize(e) {
    if (Array.isArray(e)) {
        let t = [];
        for (let i = 0; i < e.length; i++) {
            let n = e[i].toString().split(".");
            for (let e = 0; e < n.length; e++) t.push(n[e]);
        }
        return t.join(".");
    }
    return e;
}

function split(e) {
    return Array.isArray(e) ? normalize(e).split(".") : e.toString().split(".");
}

function get(e, t, i) {
    let n = e, s = split(t);
    for (let e = 0; e < s.length; e++) {
        if (!n) return;
        n = n[s[e]];
    }
    return i && (i.path = s.join(".")), n;
}

function set(e, t, i) {
    let n = e, s = split(t), r = s[s.length - 1];
    if (s.length > 1) {
        for (let e = 0; e < s.length - 1; e++) {
            if (!(n = n[s[e]])) return;
        }
        n[r] = i;
    } else n[t] = i;
    return s.join(".");
}

const isDeep = isPath;

var path = {
    isPath: isPath,
    root: root,
    isAncestor: isAncestor,
    isDescendant: isDescendant,
    translate: translate,
    matches: matches,
    normalize: normalize,
    split: split,
    get: get,
    set: set,
    isDeep: isDeep
};

const caseMap = {}, DASH_TO_CAMEL = /-[a-z]/g, CAMEL_TO_DASH = /([A-Z])/g;

function dashToCamelCase(e) {
    return caseMap[e] || (caseMap[e] = e.indexOf("-") < 0 ? e : e.replace(DASH_TO_CAMEL, e => e[1].toUpperCase()));
}

function camelToDashCase(e) {
    return caseMap[e] || (caseMap[e] = e.replace(CAMEL_TO_DASH, "-$1").toLowerCase());
}

var caseMap$1 = {
    dashToCamelCase: dashToCamelCase,
    camelToDashCase: camelToDashCase
};

let microtaskCurrHandle = 0, microtaskLastHandle = 0, microtaskCallbacks = [], microtaskNodeContent = 0, microtaskNode = document.createTextNode("");

function microtaskFlush() {
    const e = microtaskCallbacks.length;
    for (let t = 0; t < e; t++) {
        let e = microtaskCallbacks[t];
        if (e) try {
            e();
        } catch (e) {
            setTimeout(() => {
                throw e;
            });
        }
    }
    microtaskCallbacks.splice(0, e), microtaskLastHandle += e;
}

new window.MutationObserver(microtaskFlush).observe(microtaskNode, {
    characterData: !0
});

const timeOut = {
    after: e => ({
        run: t => window.setTimeout(t, e),
        cancel(e) {
            window.clearTimeout(e);
        }
    }),
    run: (e, t) => window.setTimeout(e, t),
    cancel(e) {
        window.clearTimeout(e);
    }
}, animationFrame = {
    run: e => window.requestAnimationFrame(e),
    cancel(e) {
        window.cancelAnimationFrame(e);
    }
}, idlePeriod = {
    run: e => window.requestIdleCallback ? window.requestIdleCallback(e) : window.setTimeout(e, 16),
    cancel(e) {
        window.cancelIdleCallback ? window.cancelIdleCallback(e) : window.clearTimeout(e);
    }
}, microTask = {
    run: e => (microtaskNode.textContent = microtaskNodeContent++, microtaskCallbacks.push(e), 
    microtaskCurrHandle++),
    cancel(e) {
        const t = e - microtaskLastHandle;
        if (t >= 0) {
            if (!microtaskCallbacks[t]) throw new Error("invalid async handle: " + e);
            microtaskCallbacks[t] = null;
        }
    }
};

var async = {
    timeOut: timeOut,
    animationFrame: animationFrame,
    idlePeriod: idlePeriod,
    microTask: microTask
};

const microtask = microTask, PropertiesChanged = dedupingMixin(e => {
    return class extends e {
        static createProperties(e) {
            const t = this.prototype;
            for (let i in e) i in t || t._createPropertyAccessor(i);
        }
        static attributeNameForProperty(e) {
            return e.toLowerCase();
        }
        static typeForProperty(e) {}
        _createPropertyAccessor(e, t) {
            this._addPropertyToAttributeMap(e), this.hasOwnProperty("__dataHasAccessor") || (this.__dataHasAccessor = Object.assign({}, this.__dataHasAccessor)), 
            this.__dataHasAccessor[e] || (this.__dataHasAccessor[e] = !0, this._definePropertyAccessor(e, t));
        }
        _addPropertyToAttributeMap(e) {
            if (this.hasOwnProperty("__dataAttributes") || (this.__dataAttributes = Object.assign({}, this.__dataAttributes)), 
            !this.__dataAttributes[e]) {
                const t = this.constructor.attributeNameForProperty(e);
                this.__dataAttributes[t] = e;
            }
        }
        _definePropertyAccessor(e, t) {
            Object.defineProperty(this, e, {
                get() {
                    return this._getProperty(e);
                },
                set: t ? function() {} : function(t) {
                    this._setProperty(e, t);
                }
            });
        }
        constructor() {
            super(), this.__dataEnabled = !1, this.__dataReady = !1, this.__dataInvalid = !1, 
            this.__data = {}, this.__dataPending = null, this.__dataOld = null, this.__dataInstanceProps = null, 
            this.__serializing = !1, this._initializeProperties();
        }
        ready() {
            this.__dataReady = !0, this._flushProperties();
        }
        _initializeProperties() {
            for (let e in this.__dataHasAccessor) this.hasOwnProperty(e) && (this.__dataInstanceProps = this.__dataInstanceProps || {}, 
            this.__dataInstanceProps[e] = this[e], delete this[e]);
        }
        _initializeInstanceProperties(e) {
            Object.assign(this, e);
        }
        _setProperty(e, t) {
            this._setPendingProperty(e, t) && this._invalidateProperties();
        }
        _getProperty(e) {
            return this.__data[e];
        }
        _setPendingProperty(e, t, i) {
            let n = this.__data[e], s = this._shouldPropertyChange(e, t, n);
            return s && (this.__dataPending || (this.__dataPending = {}, this.__dataOld = {}), 
            !this.__dataOld || e in this.__dataOld || (this.__dataOld[e] = n), this.__data[e] = t, 
            this.__dataPending[e] = t), s;
        }
        _invalidateProperties() {
            !this.__dataInvalid && this.__dataReady && (this.__dataInvalid = !0, microtask.run(() => {
                this.__dataInvalid && (this.__dataInvalid = !1, this._flushProperties());
            }));
        }
        _enableProperties() {
            this.__dataEnabled || (this.__dataEnabled = !0, this.__dataInstanceProps && (this._initializeInstanceProperties(this.__dataInstanceProps), 
            this.__dataInstanceProps = null), this.ready());
        }
        _flushProperties() {
            const e = this.__data, t = this.__dataPending, i = this.__dataOld;
            this._shouldPropertiesChange(e, t, i) && (this.__dataPending = null, this.__dataOld = null, 
            this._propertiesChanged(e, t, i));
        }
        _shouldPropertiesChange(e, t, i) {
            return Boolean(t);
        }
        _propertiesChanged(e, t, i) {}
        _shouldPropertyChange(e, t, i) {
            return i !== t && (i == i || t == t);
        }
        attributeChangedCallback(e, t, i, n) {
            t !== i && this._attributeToProperty(e, i), super.attributeChangedCallback && super.attributeChangedCallback(e, t, i, n);
        }
        _attributeToProperty(e, t, i) {
            if (!this.__serializing) {
                const n = this.__dataAttributes, s = n && n[e] || e;
                this[s] = this._deserializeValue(t, i || this.constructor.typeForProperty(s));
            }
        }
        _propertyToAttribute(e, t, i) {
            this.__serializing = !0, i = arguments.length < 3 ? this[e] : i, this._valueToNodeAttribute(this, i, t || this.constructor.attributeNameForProperty(e)), 
            this.__serializing = !1;
        }
        _valueToNodeAttribute(e, t, i) {
            const n = this._serializeValue(t);
            void 0 === n ? e.removeAttribute(i) : e.setAttribute(i, n);
        }
        _serializeValue(e) {
            switch (typeof e) {
              case "boolean":
                return e ? "" : void 0;

              default:
                return null != e ? e.toString() : void 0;
            }
        }
        _deserializeValue(e, t) {
            switch (t) {
              case Boolean:
                return null !== e;

              case Number:
                return Number(e);

              default:
                return e;
            }
        }
    };
});

var propertiesChanged = {
    PropertiesChanged: PropertiesChanged
};

const nativeProperties = {};

let proto = HTMLElement.prototype;

for (;proto; ) {
    let e = Object.getOwnPropertyNames(proto);
    for (let t = 0; t < e.length; t++) nativeProperties[e[t]] = !0;
    proto = Object.getPrototypeOf(proto);
}

function saveAccessorValue(e, t) {
    if (!nativeProperties[t]) {
        let i = e[t];
        void 0 !== i && (e.__data ? e._setPendingProperty(t, i) : (e.__dataProto ? e.hasOwnProperty(JSCompiler_renameProperty("__dataProto", e)) || (e.__dataProto = Object.create(e.__dataProto)) : e.__dataProto = {}, 
        e.__dataProto[t] = i));
    }
}

const PropertyAccessors = dedupingMixin(e => {
    const t = PropertiesChanged(e);
    return class extends t {
        static createPropertiesForAttributes() {
            let e = this.observedAttributes;
            for (let t = 0; t < e.length; t++) this.prototype._createPropertyAccessor(dashToCamelCase(e[t]));
        }
        static attributeNameForProperty(e) {
            return camelToDashCase(e);
        }
        _initializeProperties() {
            this.__dataProto && (this._initializeProtoProperties(this.__dataProto), this.__dataProto = null), 
            super._initializeProperties();
        }
        _initializeProtoProperties(e) {
            for (let t in e) this._setProperty(t, e[t]);
        }
        _ensureAttribute(e, t) {
            const i = this;
            i.hasAttribute(e) || this._valueToNodeAttribute(i, t, e);
        }
        _serializeValue(e) {
            switch (typeof e) {
              case "object":
                if (e instanceof Date) return e.toString();
                if (e) try {
                    return JSON.stringify(e);
                } catch (e) {
                    return "";
                }

              default:
                return super._serializeValue(e);
            }
        }
        _deserializeValue(e, t) {
            let i;
            switch (t) {
              case Object:
                try {
                    i = JSON.parse(e);
                } catch (t) {
                    i = e;
                }
                break;

              case Array:
                try {
                    i = JSON.parse(e);
                } catch (t) {
                    i = null, console.warn(`Polymer::Attributes: couldn't decode Array as JSON: ${e}`);
                }
                break;

              case Date:
                i = isNaN(e) ? String(e) : Number(e), i = new Date(i);
                break;

              default:
                i = super._deserializeValue(e, t);
            }
            return i;
        }
        _definePropertyAccessor(e, t) {
            saveAccessorValue(this, e), super._definePropertyAccessor(e, t);
        }
        _hasAccessor(e) {
            return this.__dataHasAccessor && this.__dataHasAccessor[e];
        }
        _isPropertyPending(e) {
            return Boolean(this.__dataPending && e in this.__dataPending);
        }
    };
});

var propertyAccessors = {
    PropertyAccessors: PropertyAccessors
};

const templateExtensions = {
    "dom-if": !0,
    "dom-repeat": !0
};

function wrapTemplateExtension(e) {
    let t = e.getAttribute("is");
    if (t && templateExtensions[t]) {
        let i = e;
        for (i.removeAttribute("is"), e = i.ownerDocument.createElement(t), i.parentNode.replaceChild(e, i), 
        e.appendChild(i); i.attributes.length; ) e.setAttribute(i.attributes[0].name, i.attributes[0].value), 
        i.removeAttribute(i.attributes[0].name);
    }
    return e;
}

function findTemplateNode(e, t) {
    let i = t.parentInfo && findTemplateNode(e, t.parentInfo);
    if (!i) return e;
    for (let e = i.firstChild, n = 0; e; e = e.nextSibling) if (t.parentIndex === n++) return e;
}

function applyIdToMap(e, t, i, n) {
    n.id && (t[n.id] = i);
}

function applyEventListener(e, t, i) {
    if (i.events && i.events.length) for (let n, s = 0, r = i.events; s < r.length && (n = r[s]); s++) e._addMethodEventListenerToNode(t, n.name, n.value, e);
}

function applyTemplateContent(e, t, i) {
    i.templateInfo && (t._templateInfo = i.templateInfo);
}

function createNodeEventHandler(e, t, i) {
    e = e._methodHost || e;
    return function(t) {
        e[i] ? e[i](t, t.detail) : console.warn("listener method `" + i + "` not defined");
    };
}

const TemplateStamp = dedupingMixin(e => {
    return class extends e {
        static _parseTemplate(e, t) {
            if (!e._templateInfo) {
                let i = e._templateInfo = {};
                i.nodeInfoList = [], i.stripWhiteSpace = t && t.stripWhiteSpace || e.hasAttribute("strip-whitespace"), 
                this._parseTemplateContent(e, i, {
                    parent: null
                });
            }
            return e._templateInfo;
        }
        static _parseTemplateContent(e, t, i) {
            return this._parseTemplateNode(e.content, t, i);
        }
        static _parseTemplateNode(e, t, i) {
            let n, s = e;
            return "template" != s.localName || s.hasAttribute("preserve-content") ? "slot" === s.localName && (t.hasInsertionPoint = !0) : n = this._parseTemplateNestedTemplate(s, t, i) || n, 
            s.firstChild && (n = this._parseTemplateChildNodes(s, t, i) || n), s.hasAttributes && s.hasAttributes() && (n = this._parseTemplateNodeAttributes(s, t, i) || n), 
            n;
        }
        static _parseTemplateChildNodes(e, t, i) {
            if ("script" !== e.localName && "style" !== e.localName) for (let n, s = e.firstChild, r = 0; s; s = n) {
                if ("template" == s.localName && (s = wrapTemplateExtension(s)), n = s.nextSibling, 
                s.nodeType === Node.TEXT_NODE) {
                    let i = n;
                    for (;i && i.nodeType === Node.TEXT_NODE; ) s.textContent += i.textContent, n = i.nextSibling, 
                    e.removeChild(i), i = n;
                    if (t.stripWhiteSpace && !s.textContent.trim()) {
                        e.removeChild(s);
                        continue;
                    }
                }
                let o = {
                    parentIndex: r,
                    parentInfo: i
                };
                this._parseTemplateNode(s, t, o) && (o.infoIndex = t.nodeInfoList.push(o) - 1), 
                s.parentNode && r++;
            }
        }
        static _parseTemplateNestedTemplate(e, t, i) {
            let n = this._parseTemplate(e, t);
            return (n.content = e.content.ownerDocument.createDocumentFragment()).appendChild(e.content), 
            i.templateInfo = n, !0;
        }
        static _parseTemplateNodeAttributes(e, t, i) {
            let n = !1, s = Array.from(e.attributes);
            for (let r, o = s.length - 1; r = s[o]; o--) n = this._parseTemplateNodeAttribute(e, t, i, r.name, r.value) || n;
            return n;
        }
        static _parseTemplateNodeAttribute(e, t, i, n, s) {
            return "on-" === n.slice(0, 3) ? (e.removeAttribute(n), i.events = i.events || [], 
            i.events.push({
                name: n.slice(3),
                value: s
            }), !0) : "id" === n && (i.id = s, !0);
        }
        static _contentForTemplate(e) {
            let t = e._templateInfo;
            return t && t.content || e.content;
        }
        _stampTemplate(e) {
            e && !e.content && window.HTMLTemplateElement && HTMLTemplateElement.decorate && HTMLTemplateElement.decorate(e);
            let t = this.constructor._parseTemplate(e), i = t.nodeInfoList, n = t.content || e.content, s = document.importNode(n, !0);
            s.__noInsertionPoint = !t.hasInsertionPoint;
            let r = s.nodeList = new Array(i.length);
            s.$ = {};
            for (let e, t = 0, n = i.length; t < n && (e = i[t]); t++) {
                let i = r[t] = findTemplateNode(s, e);
                applyIdToMap(this, s.$, i, e), applyTemplateContent(this, i, e), applyEventListener(this, i, e);
            }
            return s = s;
        }
        _addMethodEventListenerToNode(e, t, i, n) {
            let s = createNodeEventHandler(n = n || e, t, i);
            return this._addEventListenerToNode(e, t, s), s;
        }
        _addEventListenerToNode(e, t, i) {
            e.addEventListener(t, i);
        }
        _removeEventListenerFromNode(e, t, i) {
            e.removeEventListener(t, i);
        }
    };
});

var templateStamp = {
    TemplateStamp: TemplateStamp
};

let dedupeId$1 = 0;

const TYPES = {
    COMPUTE: "__computeEffects",
    REFLECT: "__reflectEffects",
    NOTIFY: "__notifyEffects",
    PROPAGATE: "__propagateEffects",
    OBSERVE: "__observeEffects",
    READ_ONLY: "__readOnly"
}, capitalAttributeRegex = /[A-Z]/;

let DataTrigger, DataEffect, PropertyEffectsType;

function ensureOwnEffectMap(e, t) {
    let i = e[t];
    if (i) {
        if (!e.hasOwnProperty(t)) {
            i = e[t] = Object.create(e[t]);
            for (let e in i) {
                let t = i[e], n = i[e] = Array(t.length);
                for (let e = 0; e < t.length; e++) n[e] = t[e];
            }
        }
    } else i = e[t] = {};
    return i;
}

function runEffects(e, t, i, n, s, r) {
    if (t) {
        let o = !1, a = dedupeId$1++;
        for (let l in i) runEffectsForProperty(e, t, a, l, i, n, s, r) && (o = !0);
        return o;
    }
    return !1;
}

function runEffectsForProperty(e, t, i, n, s, r, o, a) {
    let l = !1, c = t[o ? root(n) : n];
    if (c) for (let t, h = 0, d = c.length; h < d && (t = c[h]); h++) t.info && t.info.lastRun === i || o && !pathMatchesTrigger(n, t.trigger) || (t.info && (t.info.lastRun = i), 
    t.fn(e, n, s, r, t.info, o, a), l = !0);
    return l;
}

function pathMatchesTrigger(e, t) {
    if (t) {
        let i = t.name;
        return i == e || t.structured && isAncestor(i, e) || t.wildcard && isDescendant(i, e);
    }
    return !0;
}

function runObserverEffect(e, t, i, n, s) {
    let r = "string" == typeof s.method ? e[s.method] : s.method, o = s.property;
    r ? r.call(e, e.__data[o], n[o]) : s.dynamicFn || console.warn("observer method `" + s.method + "` not defined");
}

function runNotifyEffects(e, t, i, n, s) {
    let r, o, a = e[TYPES.NOTIFY], l = dedupeId$1++;
    for (let o in t) t[o] && (a && runEffectsForProperty(e, a, l, o, i, n, s) ? r = !0 : s && notifyPath(e, o, i) && (r = !0));
    r && (o = e.__dataHost) && o._invalidateProperties && o._invalidateProperties();
}

function notifyPath(e, t, i) {
    let n = root(t);
    if (n !== t) {
        return dispatchNotifyEvent(e, camelToDashCase(n) + "-changed", i[t], t), !0;
    }
    return !1;
}

function dispatchNotifyEvent(e, t, i, n) {
    let s = {
        value: i,
        queueProperty: !0
    };
    n && (s.path = n), e.dispatchEvent(new CustomEvent(t, {
        detail: s
    }));
}

function runNotifyEffect(e, t, i, n, s, r) {
    let o = (r ? root(t) : t) != t ? t : null, a = o ? get(e, o) : e.__data[t];
    o && void 0 === a && (a = i[t]), dispatchNotifyEvent(e, s.eventName, a, o);
}

function handleNotification(e, t, i, n, s) {
    let r, o = e.detail, a = o && o.path;
    a ? (n = translate(i, n, a), r = o && o.value) : r = e.currentTarget[i], r = s ? !r : r, 
    t[TYPES.READ_ONLY] && t[TYPES.READ_ONLY][n] || !t._setPendingPropertyOrPath(n, r, !0, Boolean(a)) || o && o.queueProperty || t._invalidateProperties();
}

function runReflectEffect(e, t, i, n, s) {
    let r = e.__data[t];
    sanitizeDOMValue && (r = sanitizeDOMValue(r, s.attrName, "attribute", e)), e._propertyToAttribute(t, s.attrName, r);
}

function runComputedEffects(e, t, i, n) {
    let s = e[TYPES.COMPUTE];
    if (s) {
        let r = t;
        for (;runEffects(e, s, r, i, n); ) Object.assign(i, e.__dataOld), Object.assign(t, e.__dataPending), 
        r = e.__dataPending, e.__dataPending = null;
    }
}

function runComputedEffect(e, t, i, n, s) {
    let r = runMethodEffect(e, t, i, n, s), o = s.methodInfo;
    e.__dataHasAccessor && e.__dataHasAccessor[o] ? e._setPendingProperty(o, r, !0) : e[o] = r;
}

function computeLinkedPaths(e, t, i) {
    let n = e.__dataLinkedPaths;
    if (n) {
        let s;
        for (let r in n) {
            let o = n[r];
            isDescendant(r, t) ? (s = translate(r, o, t), e._setPendingPropertyOrPath(s, i, !0, !0)) : isDescendant(o, t) && (s = translate(o, r, t), 
            e._setPendingPropertyOrPath(s, i, !0, !0));
        }
    }
}

function addBinding(e, t, i, n, s, r, o) {
    i.bindings = i.bindings || [];
    let a = {
        kind: n,
        target: s,
        parts: r,
        literal: o,
        isCompound: 1 !== r.length
    };
    if (i.bindings.push(a), shouldAddListener(a)) {
        let {event: e, negate: t} = a.parts[0];
        a.listenerEvent = e || camelToDashCase(s) + "-changed", a.listenerNegate = t;
    }
    let l = t.nodeInfoList.length;
    for (let i = 0; i < a.parts.length; i++) {
        let n = a.parts[i];
        n.compoundIndex = i, addEffectForBindingPart(e, t, a, n, l);
    }
}

function addEffectForBindingPart(e, t, i, n, s) {
    if (!n.literal) if ("attribute" === i.kind && "-" === i.target[0]) console.warn("Cannot set attribute " + i.target + ' because "-" is not a valid attribute starting character'); else {
        let r = n.dependencies, o = {
            index: s,
            binding: i,
            part: n,
            evaluator: e
        };
        for (let i = 0; i < r.length; i++) {
            let n = r[i];
            "string" == typeof n && ((n = parseArg(n)).wildcard = !0), e._addTemplatePropertyEffect(t, n.rootProperty, {
                fn: runBindingEffect,
                info: o,
                trigger: n
            });
        }
    }
}

function runBindingEffect(e, t, i, n, s, r, o) {
    let a = o[s.index], l = s.binding, c = s.part;
    if (r && c.source && t.length > c.source.length && "property" == l.kind && !l.isCompound && a.__isPropertyEffectsClient && a.__dataHasAccessor && a.__dataHasAccessor[l.target]) {
        let n = i[t];
        t = translate(c.source, l.target, t), a._setPendingPropertyOrPath(t, n, !1, !0) && e._enqueueClient(a);
    } else {
        applyBindingValue(e, a, l, c, s.evaluator._evaluateBinding(e, c, t, i, n, r));
    }
}

function applyBindingValue(e, t, i, n, s) {
    if (s = computeBindingValue(t, s, i, n), sanitizeDOMValue && (s = sanitizeDOMValue(s, i.target, i.kind, t)), 
    "attribute" == i.kind) e._valueToNodeAttribute(t, s, i.target); else {
        let n = i.target;
        t.__isPropertyEffectsClient && t.__dataHasAccessor && t.__dataHasAccessor[n] ? t[TYPES.READ_ONLY] && t[TYPES.READ_ONLY][n] || t._setPendingProperty(n, s) && e._enqueueClient(t) : e._setUnmanagedPropertyToNode(t, n, s);
    }
}

function computeBindingValue(e, t, i, n) {
    if (i.isCompound) {
        let s = e.__dataCompoundStorage[i.target];
        s[n.compoundIndex] = t, t = s.join("");
    }
    return "attribute" !== i.kind && ("textContent" !== i.target && ("value" !== i.target || "input" !== e.localName && "textarea" !== e.localName) || (t = null == t ? "" : t)), 
    t;
}

function shouldAddListener(e) {
    return Boolean(e.target) && "attribute" != e.kind && "text" != e.kind && !e.isCompound && "{" === e.parts[0].mode;
}

function setupBindings(e, t) {
    let {nodeList: i, nodeInfoList: n} = t;
    if (n.length) for (let t = 0; t < n.length; t++) {
        let s = n[t], r = i[t], o = s.bindings;
        if (o) for (let t = 0; t < o.length; t++) {
            let i = o[t];
            setupCompoundStorage(r, i), addNotifyListener(r, e, i);
        }
        r.__dataHost = e;
    }
}

function setupCompoundStorage(e, t) {
    if (t.isCompound) {
        let i = e.__dataCompoundStorage || (e.__dataCompoundStorage = {}), n = t.parts, s = new Array(n.length);
        for (let e = 0; e < n.length; e++) s[e] = n[e].literal;
        let r = t.target;
        i[r] = s, t.literal && "property" == t.kind && (e[r] = t.literal);
    }
}

function addNotifyListener(e, t, i) {
    if (i.listenerEvent) {
        let n = i.parts[0];
        e.addEventListener(i.listenerEvent, function(e) {
            handleNotification(e, t, i.target, n.source, n.negate);
        });
    }
}

function createMethodEffect(e, t, i, n, s, r) {
    r = t.static || r && ("object" != typeof r || r[t.methodName]);
    let o = {
        methodName: t.methodName,
        args: t.args,
        methodInfo: s,
        dynamicFn: r
    };
    for (let s, r = 0; r < t.args.length && (s = t.args[r]); r++) s.literal || e._addPropertyEffect(s.rootProperty, i, {
        fn: n,
        info: o,
        trigger: s
    });
    r && e._addPropertyEffect(t.methodName, i, {
        fn: n,
        info: o
    });
}

function runMethodEffect(e, t, i, n, s) {
    let r = e._methodHost || e, o = r[s.methodName];
    if (o) {
        let n = e._marshalArgs(s.args, t, i);
        return o.apply(r, n);
    }
    s.dynamicFn || console.warn("method `" + s.methodName + "` not defined");
}

const emptyArray = [], IDENT = "(?:[a-zA-Z_$][\\w.:$\\-*]*)", NUMBER = "(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)", SQUOTE_STRING = "(?:'(?:[^'\\\\]|\\\\.)*')", DQUOTE_STRING = '(?:"(?:[^"\\\\]|\\\\.)*")', STRING = "(?:" + SQUOTE_STRING + "|" + DQUOTE_STRING + ")", ARGUMENT = "(?:(" + IDENT + "|" + NUMBER + "|" + STRING + ")\\s*)", ARGUMENTS = "(?:" + ARGUMENT + "(?:,\\s*" + ARGUMENT + ")*)", ARGUMENT_LIST = "(?:\\(\\s*(?:" + ARGUMENTS + "?)\\)\\s*)", BINDING = "(" + IDENT + "\\s*" + ARGUMENT_LIST + "?)", OPEN_BRACKET = "(\\[\\[|{{)\\s*", CLOSE_BRACKET = "(?:]]|}})", NEGATE = "(?:(!)\\s*)?", EXPRESSION = OPEN_BRACKET + NEGATE + BINDING + "(?:]]|}})", bindingRegex = new RegExp(EXPRESSION, "g");

function literalFromParts(e) {
    let t = "";
    for (let i = 0; i < e.length; i++) {
        t += e[i].literal || "";
    }
    return t;
}

function parseMethod(e) {
    let t = e.match(/([^\s]+?)\(([\s\S]*)\)/);
    if (t) {
        let e = {
            methodName: t[1],
            static: !0,
            args: emptyArray
        };
        if (t[2].trim()) {
            return parseArgs(t[2].replace(/\\,/g, "&comma;").split(","), e);
        }
        return e;
    }
    return null;
}

function parseArgs(e, t) {
    return t.args = e.map(function(e) {
        let i = parseArg(e);
        return i.literal || (t.static = !1), i;
    }, this), t;
}

function parseArg(e) {
    let t = e.trim().replace(/&comma;/g, ",").replace(/\\(.)/g, "$1"), i = {
        name: t,
        value: "",
        literal: !1
    }, n = t[0];
    switch ("-" === n && (n = t[1]), n >= "0" && n <= "9" && (n = "#"), n) {
      case "'":
      case '"':
        i.value = t.slice(1, -1), i.literal = !0;
        break;

      case "#":
        i.value = Number(t), i.literal = !0;
    }
    return i.literal || (i.rootProperty = root(t), i.structured = isPath(t), i.structured && (i.wildcard = ".*" == t.slice(-2), 
    i.wildcard && (i.name = t.slice(0, -2)))), i;
}

function notifySplices(e, t, i, n) {
    let s = i + ".splices";
    e.notifyPath(s, {
        indexSplices: n
    }), e.notifyPath(i + ".length", t.length), e.__data[s] = {
        indexSplices: null
    };
}

function notifySplice(e, t, i, n, s, r) {
    notifySplices(e, t, i, [ {
        index: n,
        addedCount: s,
        removed: r,
        object: t,
        type: "splice"
    } ]);
}

function upper(e) {
    return e[0].toUpperCase() + e.substring(1);
}

const PropertyEffects = dedupingMixin(e => {
    const t = TemplateStamp(PropertyAccessors(e));
    class i extends t {
        constructor() {
            super(), this.__isPropertyEffectsClient = !0, this.__dataCounter = 0, this.__dataClientsReady, 
            this.__dataPendingClients, this.__dataToNotify, this.__dataLinkedPaths, this.__dataHasPaths, 
            this.__dataCompoundStorage, this.__dataHost, this.__dataTemp, this.__dataClientsInitialized, 
            this.__data, this.__dataPending, this.__dataOld, this.__computeEffects, this.__reflectEffects, 
            this.__notifyEffects, this.__propagateEffects, this.__observeEffects, this.__readOnly, 
            this.__templateInfo;
        }
        get PROPERTY_EFFECT_TYPES() {
            return TYPES;
        }
        _initializeProperties() {
            super._initializeProperties(), hostStack.registerHost(this), this.__dataClientsReady = !1, 
            this.__dataPendingClients = null, this.__dataToNotify = null, this.__dataLinkedPaths = null, 
            this.__dataHasPaths = !1, this.__dataCompoundStorage = this.__dataCompoundStorage || null, 
            this.__dataHost = this.__dataHost || null, this.__dataTemp = {}, this.__dataClientsInitialized = !1;
        }
        _initializeProtoProperties(e) {
            this.__data = Object.create(e), this.__dataPending = Object.create(e), this.__dataOld = {};
        }
        _initializeInstanceProperties(e) {
            let t = this[TYPES.READ_ONLY];
            for (let i in e) t && t[i] || (this.__dataPending = this.__dataPending || {}, this.__dataOld = this.__dataOld || {}, 
            this.__data[i] = this.__dataPending[i] = e[i]);
        }
        _addPropertyEffect(e, t, i) {
            this._createPropertyAccessor(e, t == TYPES.READ_ONLY);
            let n = ensureOwnEffectMap(this, t)[e];
            n || (n = this[t][e] = []), n.push(i);
        }
        _removePropertyEffect(e, t, i) {
            let n = ensureOwnEffectMap(this, t)[e], s = n.indexOf(i);
            s >= 0 && n.splice(s, 1);
        }
        _hasPropertyEffect(e, t) {
            let i = this[t];
            return Boolean(i && i[e]);
        }
        _hasReadOnlyEffect(e) {
            return this._hasPropertyEffect(e, TYPES.READ_ONLY);
        }
        _hasNotifyEffect(e) {
            return this._hasPropertyEffect(e, TYPES.NOTIFY);
        }
        _hasReflectEffect(e) {
            return this._hasPropertyEffect(e, TYPES.REFLECT);
        }
        _hasComputedEffect(e) {
            return this._hasPropertyEffect(e, TYPES.COMPUTE);
        }
        _setPendingPropertyOrPath(e, t, i, n) {
            if (n || root(Array.isArray(e) ? e[0] : e) !== e) {
                if (!n) {
                    let i = get(this, e);
                    if (!(e = set(this, e, t)) || !super._shouldPropertyChange(e, t, i)) return !1;
                }
                if (this.__dataHasPaths = !0, this._setPendingProperty(e, t, i)) return computeLinkedPaths(this, e, t), 
                !0;
            } else {
                if (this.__dataHasAccessor && this.__dataHasAccessor[e]) return this._setPendingProperty(e, t, i);
                this[e] = t;
            }
            return !1;
        }
        _setUnmanagedPropertyToNode(e, t, i) {
            i === e[t] && "object" != typeof i || (e[t] = i);
        }
        _setPendingProperty(e, t, i) {
            let n = this.__dataHasPaths && isPath(e), s = n ? this.__dataTemp : this.__data;
            return !!this._shouldPropertyChange(e, t, s[e]) && (this.__dataPending || (this.__dataPending = {}, 
            this.__dataOld = {}), e in this.__dataOld || (this.__dataOld[e] = this.__data[e]), 
            n ? this.__dataTemp[e] = t : this.__data[e] = t, this.__dataPending[e] = t, (n || this[TYPES.NOTIFY] && this[TYPES.NOTIFY][e]) && (this.__dataToNotify = this.__dataToNotify || {}, 
            this.__dataToNotify[e] = i), !0);
        }
        _setProperty(e, t) {
            this._setPendingProperty(e, t, !0) && this._invalidateProperties();
        }
        _invalidateProperties() {
            this.__dataReady && this._flushProperties();
        }
        _enqueueClient(e) {
            this.__dataPendingClients = this.__dataPendingClients || [], e !== this && this.__dataPendingClients.push(e);
        }
        _flushProperties() {
            this.__dataCounter++, super._flushProperties(), this.__dataCounter--;
        }
        _flushClients() {
            this.__dataClientsReady ? this.__enableOrFlushClients() : (this.__dataClientsReady = !0, 
            this._readyClients(), this.__dataReady = !0);
        }
        __enableOrFlushClients() {
            let e = this.__dataPendingClients;
            if (e) {
                this.__dataPendingClients = null;
                for (let t = 0; t < e.length; t++) {
                    let i = e[t];
                    i.__dataEnabled ? i.__dataPending && i._flushProperties() : i._enableProperties();
                }
            }
        }
        _readyClients() {
            this.__enableOrFlushClients();
        }
        setProperties(e, t) {
            for (let i in e) !t && this[TYPES.READ_ONLY] && this[TYPES.READ_ONLY][i] || this._setPendingPropertyOrPath(i, e[i], !0);
            this._invalidateProperties();
        }
        ready() {
            this._flushProperties(), this.__dataClientsReady || this._flushClients(), this.__dataPending && this._flushProperties();
        }
        _propertiesChanged(e, t, i) {
            let n = this.__dataHasPaths;
            this.__dataHasPaths = !1, runComputedEffects(this, t, i, n);
            let s = this.__dataToNotify;
            this.__dataToNotify = null, this._propagatePropertyChanges(t, i, n), this._flushClients(), 
            runEffects(this, this[TYPES.REFLECT], t, i, n), runEffects(this, this[TYPES.OBSERVE], t, i, n), 
            s && runNotifyEffects(this, s, t, i, n), 1 == this.__dataCounter && (this.__dataTemp = {});
        }
        _propagatePropertyChanges(e, t, i) {
            this[TYPES.PROPAGATE] && runEffects(this, this[TYPES.PROPAGATE], e, t, i);
            let n = this.__templateInfo;
            for (;n; ) runEffects(this, n.propertyEffects, e, t, i, n.nodeList), n = n.nextTemplateInfo;
        }
        linkPaths(e, t) {
            e = normalize(e), t = normalize(t), this.__dataLinkedPaths = this.__dataLinkedPaths || {}, 
            this.__dataLinkedPaths[e] = t;
        }
        unlinkPaths(e) {
            e = normalize(e), this.__dataLinkedPaths && delete this.__dataLinkedPaths[e];
        }
        notifySplices(e, t) {
            let i = {
                path: ""
            };
            notifySplices(this, get(this, e, i), i.path, t);
        }
        get(e, t) {
            return get(t || this, e);
        }
        set(e, t, i) {
            i ? set(i, e, t) : this[TYPES.READ_ONLY] && this[TYPES.READ_ONLY][e] || this._setPendingPropertyOrPath(e, t, !0) && this._invalidateProperties();
        }
        push(e, ...t) {
            let i = {
                path: ""
            }, n = get(this, e, i), s = n.length, r = n.push(...t);
            return t.length && notifySplice(this, n, i.path, s, t.length, []), r;
        }
        pop(e) {
            let t = {
                path: ""
            }, i = get(this, e, t), n = Boolean(i.length), s = i.pop();
            return n && notifySplice(this, i, t.path, i.length, 0, [ s ]), s;
        }
        splice(e, t, i, ...n) {
            let s, r = {
                path: ""
            }, o = get(this, e, r);
            return t < 0 ? t = o.length - Math.floor(-t) : t && (t = Math.floor(t)), s = 2 === arguments.length ? o.splice(t) : o.splice(t, i, ...n), 
            (n.length || s.length) && notifySplice(this, o, r.path, t, n.length, s), s;
        }
        shift(e) {
            let t = {
                path: ""
            }, i = get(this, e, t), n = Boolean(i.length), s = i.shift();
            return n && notifySplice(this, i, t.path, 0, 0, [ s ]), s;
        }
        unshift(e, ...t) {
            let i = {
                path: ""
            }, n = get(this, e, i), s = n.unshift(...t);
            return t.length && notifySplice(this, n, i.path, 0, t.length, []), s;
        }
        notifyPath(e, t) {
            let i;
            if (1 == arguments.length) {
                let n = {
                    path: ""
                };
                t = get(this, e, n), i = n.path;
            } else i = Array.isArray(e) ? normalize(e) : e;
            this._setPendingPropertyOrPath(i, t, !0, !0) && this._invalidateProperties();
        }
        _createReadOnlyProperty(e, t) {
            this._addPropertyEffect(e, TYPES.READ_ONLY), t && (this["_set" + upper(e)] = function(t) {
                this._setProperty(e, t);
            });
        }
        _createPropertyObserver(e, t, i) {
            let n = {
                property: e,
                method: t,
                dynamicFn: Boolean(i)
            };
            this._addPropertyEffect(e, TYPES.OBSERVE, {
                fn: runObserverEffect,
                info: n,
                trigger: {
                    name: e
                }
            }), i && this._addPropertyEffect(t, TYPES.OBSERVE, {
                fn: runObserverEffect,
                info: n,
                trigger: {
                    name: t
                }
            });
        }
        _createMethodObserver(e, t) {
            let i = parseMethod(e);
            if (!i) throw new Error("Malformed observer expression '" + e + "'");
            createMethodEffect(this, i, TYPES.OBSERVE, runMethodEffect, null, t);
        }
        _createNotifyingProperty(e) {
            this._addPropertyEffect(e, TYPES.NOTIFY, {
                fn: runNotifyEffect,
                info: {
                    eventName: camelToDashCase(e) + "-changed",
                    property: e
                }
            });
        }
        _createReflectedProperty(e) {
            let t = this.constructor.attributeNameForProperty(e);
            "-" === t[0] ? console.warn("Property " + e + " cannot be reflected to attribute " + t + ' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.') : this._addPropertyEffect(e, TYPES.REFLECT, {
                fn: runReflectEffect,
                info: {
                    attrName: t
                }
            });
        }
        _createComputedProperty(e, t, i) {
            let n = parseMethod(t);
            if (!n) throw new Error("Malformed computed expression '" + t + "'");
            createMethodEffect(this, n, TYPES.COMPUTE, runComputedEffect, e, i);
        }
        _marshalArgs(e, t, i) {
            const n = this.__data;
            let s = [];
            for (let r = 0, o = e.length; r < o; r++) {
                let o, a = e[r], l = a.name;
                if (a.literal ? o = a.value : a.structured ? void 0 === (o = get(n, l)) && (o = i[l]) : o = n[l], 
                a.wildcard) {
                    let e = 0 === l.indexOf(t + "."), n = 0 === t.indexOf(l) && !e;
                    s[r] = {
                        path: n ? t : l,
                        value: n ? i[t] : o,
                        base: o
                    };
                } else s[r] = o;
            }
            return s;
        }
        static addPropertyEffect(e, t, i) {
            this.prototype._addPropertyEffect(e, t, i);
        }
        static createPropertyObserver(e, t, i) {
            this.prototype._createPropertyObserver(e, t, i);
        }
        static createMethodObserver(e, t) {
            this.prototype._createMethodObserver(e, t);
        }
        static createNotifyingProperty(e) {
            this.prototype._createNotifyingProperty(e);
        }
        static createReadOnlyProperty(e, t) {
            this.prototype._createReadOnlyProperty(e, t);
        }
        static createReflectedProperty(e) {
            this.prototype._createReflectedProperty(e);
        }
        static createComputedProperty(e, t, i) {
            this.prototype._createComputedProperty(e, t, i);
        }
        static bindTemplate(e) {
            return this.prototype._bindTemplate(e);
        }
        _bindTemplate(e, t) {
            let i = this.constructor._parseTemplate(e), n = this.__templateInfo == i;
            if (!n) for (let e in i.propertyEffects) this._createPropertyAccessor(e);
            if (t && ((i = Object.create(i)).wasPreBound = n, !n && this.__templateInfo)) {
                let e = this.__templateInfoLast || this.__templateInfo;
                return this.__templateInfoLast = e.nextTemplateInfo = i, i.previousTemplateInfo = e, 
                i;
            }
            return this.__templateInfo = i;
        }
        static _addTemplatePropertyEffect(e, t, i) {
            (e.hostProps = e.hostProps || {})[t] = !0;
            let n = e.propertyEffects = e.propertyEffects || {};
            (n[t] = n[t] || []).push(i);
        }
        _stampTemplate(e) {
            hostStack.beginHosting(this);
            let t = super._stampTemplate(e);
            hostStack.endHosting(this);
            let i = this._bindTemplate(e, !0);
            if (i.nodeList = t.nodeList, !i.wasPreBound) {
                let e = i.childNodes = [];
                for (let i = t.firstChild; i; i = i.nextSibling) e.push(i);
            }
            return t.templateInfo = i, setupBindings(this, i), this.__dataReady && runEffects(this, i.propertyEffects, this.__data, null, !1, i.nodeList), 
            t;
        }
        _removeBoundDom(e) {
            let t = e.templateInfo;
            t.previousTemplateInfo && (t.previousTemplateInfo.nextTemplateInfo = t.nextTemplateInfo), 
            t.nextTemplateInfo && (t.nextTemplateInfo.previousTemplateInfo = t.previousTemplateInfo), 
            this.__templateInfoLast == t && (this.__templateInfoLast = t.previousTemplateInfo), 
            t.previousTemplateInfo = t.nextTemplateInfo = null;
            let i = t.childNodes;
            for (let e = 0; e < i.length; e++) {
                let t = i[e];
                t.parentNode.removeChild(t);
            }
        }
        static _parseTemplateNode(e, t, i) {
            let n = super._parseTemplateNode(e, t, i);
            if (e.nodeType === Node.TEXT_NODE) {
                let s = this._parseBindings(e.textContent, t);
                s && (e.textContent = literalFromParts(s) || " ", addBinding(this, t, i, "text", "textContent", s), 
                n = !0);
            }
            return n;
        }
        static _parseTemplateNodeAttribute(e, t, i, n, s) {
            let r = this._parseBindings(s, t);
            if (r) {
                let s = n, o = "property";
                capitalAttributeRegex.test(n) ? o = "attribute" : "$" == n[n.length - 1] && (n = n.slice(0, -1), 
                o = "attribute");
                let a = literalFromParts(r);
                return a && "attribute" == o && e.setAttribute(n, a), "input" === e.localName && "value" === s && e.setAttribute(s, ""), 
                e.removeAttribute(s), "property" === o && (n = dashToCamelCase(n)), addBinding(this, t, i, o, n, r, a), 
                !0;
            }
            return super._parseTemplateNodeAttribute(e, t, i, n, s);
        }
        static _parseTemplateNestedTemplate(e, t, i) {
            let n = super._parseTemplateNestedTemplate(e, t, i), s = i.templateInfo.hostProps;
            for (let e in s) {
                addBinding(this, t, i, "property", "_host_" + e, [ {
                    mode: "{",
                    source: e,
                    dependencies: [ e ]
                } ]);
            }
            return n;
        }
        static _parseBindings(e, t) {
            let i, n = [], s = 0;
            for (;null !== (i = bindingRegex.exec(e)); ) {
                i.index > s && n.push({
                    literal: e.slice(s, i.index)
                });
                let r = i[1][0], o = Boolean(i[2]), a = i[3].trim(), l = !1, c = "", h = -1;
                "{" == r && (h = a.indexOf("::")) > 0 && (c = a.substring(h + 2), a = a.substring(0, h), 
                l = !0);
                let d = parseMethod(a), u = [];
                if (d) {
                    let {args: e, methodName: i} = d;
                    for (let t = 0; t < e.length; t++) {
                        let i = e[t];
                        i.literal || u.push(i);
                    }
                    let n = t.dynamicFns;
                    (n && n[i] || d.static) && (u.push(i), d.dynamicFn = !0);
                } else u.push(a);
                n.push({
                    source: a,
                    mode: r,
                    negate: o,
                    customEvent: l,
                    signature: d,
                    dependencies: u,
                    event: c
                }), s = bindingRegex.lastIndex;
            }
            if (s && s < e.length) {
                let t = e.substring(s);
                t && n.push({
                    literal: t
                });
            }
            return n.length ? n : null;
        }
        static _evaluateBinding(e, t, i, n, s, r) {
            let o;
            return o = t.signature ? runMethodEffect(e, i, n, s, t.signature) : i != t.source ? get(e, t.source) : r && isPath(i) ? get(e, i) : e.__data[i], 
            t.negate && (o = !o), o;
        }
    }
    return PropertyEffectsType = i, i;
});

class HostStack {
    constructor() {
        this.stack = [];
    }
    registerHost(e) {
        if (this.stack.length) {
            this.stack[this.stack.length - 1]._enqueueClient(e);
        }
    }
    beginHosting(e) {
        this.stack.push(e);
    }
    endHosting(e) {
        let t = this.stack.length;
        t && this.stack[t - 1] == e && this.stack.pop();
    }
}

const hostStack = new HostStack();

var propertyEffects = {
    PropertyEffects: PropertyEffects
};

function normalizeProperties(e) {
    const t = {};
    for (let i in e) {
        const n = e[i];
        t[i] = "function" == typeof n ? {
            type: n
        } : n;
    }
    return t;
}

const PropertiesMixin = dedupingMixin(e => {
    const t = PropertiesChanged(e);
    function i(e) {
        const t = Object.getPrototypeOf(e);
        return t.prototype instanceof s ? t : null;
    }
    function n(e) {
        if (!e.hasOwnProperty(JSCompiler_renameProperty("__ownProperties", e))) {
            let t = null;
            if (e.hasOwnProperty(JSCompiler_renameProperty("properties", e))) {
                const i = e.properties;
                i && (t = normalizeProperties(i));
            }
            e.__ownProperties = t;
        }
        return e.__ownProperties;
    }
    class s extends t {
        static get observedAttributes() {
            const e = this._properties;
            return e ? Object.keys(e).map(e => this.attributeNameForProperty(e)) : [];
        }
        static finalize() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("__finalized", this))) {
                const e = i(this);
                e && e.finalize(), this.__finalized = !0, this._finalizeClass();
            }
        }
        static _finalizeClass() {
            const e = n(this);
            e && this.createProperties(e);
        }
        static get _properties() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("__properties", this))) {
                const e = i(this);
                this.__properties = Object.assign({}, e && e._properties, n(this));
            }
            return this.__properties;
        }
        static typeForProperty(e) {
            const t = this._properties[e];
            return t && t.type;
        }
        _initializeProperties() {
            this.constructor.finalize(), super._initializeProperties();
        }
        connectedCallback() {
            super.connectedCallback && super.connectedCallback(), this._enableProperties();
        }
        disconnectedCallback() {
            super.disconnectedCallback && super.disconnectedCallback();
        }
    }
    return s;
});

var propertiesMixin = {
    PropertiesMixin: PropertiesMixin
};

const bundledImportMeta = {
    ...import.meta,
    url: new URL("./node_modules/%40polymer/polymer/lib/mixins/element-mixin.js", import.meta.url).href
}, version = "3.0.5", ElementMixin = dedupingMixin(e => {
    const t = PropertiesMixin(PropertyEffects(e));
    return class extends t {
        static get polymerElementVersion() {
            return version;
        }
        static _finalizeClass() {
            super._finalizeClass(), this.hasOwnProperty(JSCompiler_renameProperty("is", this)) && this.is && register(this.prototype);
            const e = ((t = this).hasOwnProperty(JSCompiler_renameProperty("__ownObservers", t)) || (t.__ownObservers = t.hasOwnProperty(JSCompiler_renameProperty("observers", t)) ? t.observers : null), 
            t.__ownObservers);
            var t;
            e && this.createObservers(e, this._properties);
            let i = this.template;
            i && ("string" == typeof i ? (console.error("template getter must return HTMLTemplateElement"), 
            i = null) : i = i.cloneNode(!0)), this.prototype._template = i;
        }
        static createProperties(e) {
            for (let r in e) t = this.prototype, i = r, n = e[r], s = e, n.computed && (n.readOnly = !0), 
            n.computed && !t._hasReadOnlyEffect(i) && t._createComputedProperty(i, n.computed, s), 
            n.readOnly && !t._hasReadOnlyEffect(i) && t._createReadOnlyProperty(i, !n.computed), 
            n.reflectToAttribute && !t._hasReflectEffect(i) && t._createReflectedProperty(i), 
            n.notify && !t._hasNotifyEffect(i) && t._createNotifyingProperty(i), n.observer && t._createPropertyObserver(i, n.observer, s[n.observer]), 
            t._addPropertyToAttributeMap(i);
            var t, i, n, s;
        }
        static createObservers(e, t) {
            const i = this.prototype;
            for (let n = 0; n < e.length; n++) i._createMethodObserver(e[n], t);
        }
        static get template() {
            return this.hasOwnProperty(JSCompiler_renameProperty("_template", this)) || (this._template = this.prototype.hasOwnProperty(JSCompiler_renameProperty("_template", this.prototype)) ? this.prototype._template : function(e) {
                let t = null;
                if (e && (!strictTemplatePolicy || allowTemplateFromDomModule) && (t = DomModule.import(e, "template"), 
                strictTemplatePolicy && !t)) throw new Error(`strictTemplatePolicy: expecting dom-module or null template for ${e}`);
                return t;
            }(this.is) || Object.getPrototypeOf(this.prototype).constructor.template), this._template;
        }
        static set template(e) {
            this._template = e;
        }
        static get importPath() {
            if (!this.hasOwnProperty(JSCompiler_renameProperty("_importPath", this))) {
                const e = this.importMeta;
                if (e) this._importPath = pathFromUrl(e.url); else {
                    const e = DomModule.import(this.is);
                    this._importPath = e && e.assetpath || Object.getPrototypeOf(this.prototype).constructor.importPath;
                }
            }
            return this._importPath;
        }
        constructor() {
            super(), this._template, this._importPath, this.rootPath, this.importPath, this.root, 
            this.$;
        }
        _initializeProperties() {
            instanceCount++, this.constructor.finalize(), this.constructor._finalizeTemplate(this.localName), 
            super._initializeProperties(), this.rootPath = rootPath, this.importPath = this.constructor.importPath;
            let e = function(e) {
                if (!e.hasOwnProperty(JSCompiler_renameProperty("__propertyDefaults", e))) {
                    e.__propertyDefaults = null;
                    let t = e._properties;
                    for (let i in t) {
                        let n = t[i];
                        "value" in n && (e.__propertyDefaults = e.__propertyDefaults || {}, e.__propertyDefaults[i] = n);
                    }
                }
                return e.__propertyDefaults;
            }(this.constructor);
            if (e) for (let t in e) {
                let i = e[t];
                if (!this.hasOwnProperty(t)) {
                    let e = "function" == typeof i.value ? i.value.call(this) : i.value;
                    this._hasAccessor(t) ? this._setPendingProperty(t, e, !0) : this[t] = e;
                }
            }
        }
        static _processStyleText(e, t) {
            return resolveCss(e, t);
        }
        static _finalizeTemplate(e) {
            const t = this.prototype._template;
            if (t && !t.__polymerFinalized) {
                t.__polymerFinalized = !0;
                const i = this.importPath;
                !function(e, t, i, n) {
                    const s = t.content.querySelectorAll("style"), r = stylesFromTemplate(t), o = stylesFromModuleImports(i), a = t.content.firstElementChild;
                    for (let i = 0; i < o.length; i++) {
                        let s = o[i];
                        s.textContent = e._processStyleText(s.textContent, n), t.content.insertBefore(s, a);
                    }
                    let l = 0;
                    for (let t = 0; t < r.length; t++) {
                        let i = r[t], o = s[l];
                        o !== i ? (i = i.cloneNode(!0), o.parentNode.insertBefore(i, o)) : l++, i.textContent = e._processStyleText(i.textContent, n);
                    }
                    window.ShadyCSS && window.ShadyCSS.prepareTemplate(t, i);
                }(this, t, e, i ? resolveUrl(i) : ""), this.prototype._bindTemplate(t);
            }
        }
        connectedCallback() {
            window.ShadyCSS && this._template && window.ShadyCSS.styleElement(this), super.connectedCallback();
        }
        ready() {
            this._template && (this.root = this._stampTemplate(this._template), this.$ = this.root.$), 
            super.ready();
        }
        _readyClients() {
            this._template && (this.root = this._attachDom(this.root)), super._readyClients();
        }
        _attachDom(e) {
            if (this.attachShadow) return e ? (this.shadowRoot || this.attachShadow({
                mode: "open"
            }), this.shadowRoot.appendChild(e), this.shadowRoot) : null;
            throw new Error("ShadowDOM not available. PolymerElement can create dom as children instead of in ShadowDOM by setting `this.root = this;` before `ready`.");
        }
        updateStyles(e) {
            window.ShadyCSS && window.ShadyCSS.styleSubtree(this, e);
        }
        resolveUrl(e, t) {
            return !t && this.importPath && (t = resolveUrl(this.importPath)), resolveUrl(e, t);
        }
        static _parseTemplateContent(e, t, i) {
            return t.dynamicFns = t.dynamicFns || this._properties, super._parseTemplateContent(e, t, i);
        }
    };
});

let instanceCount = 0;

const registrations = [];

function _regLog(e) {
    console.log("[" + e.is + "]: registered");
}

function register(e) {
    registrations.push(e);
}

function dumpRegistrations() {
    registrations.forEach(_regLog);
}

const updateStyles = function(e) {
    window.ShadyCSS && window.ShadyCSS.styleDocument(e);
};

var elementMixin = {
    version: version,
    ElementMixin: ElementMixin,
    get instanceCount() {
        return instanceCount;
    },
    registrations: registrations,
    register: register,
    dumpRegistrations: dumpRegistrations,
    updateStyles: updateStyles
};

class Debouncer {
    constructor() {
        this._asyncModule = null, this._callback = null, this._timer = null;
    }
    setConfig(e, t) {
        this._asyncModule = e, this._callback = t, this._timer = this._asyncModule.run(() => {
            this._timer = null, this._callback();
        });
    }
    cancel() {
        this.isActive() && (this._asyncModule.cancel(this._timer), this._timer = null);
    }
    flush() {
        this.isActive() && (this.cancel(), this._callback());
    }
    isActive() {
        return null != this._timer;
    }
    static debounce(e, t, i) {
        return e instanceof Debouncer ? e.cancel() : e = new Debouncer(), e.setConfig(t, i), 
        e;
    }
}

var debounce = {
    Debouncer: Debouncer
};

let HAS_NATIVE_TA = "string" == typeof document.head.style.touchAction, GESTURE_KEY = "__polymerGestures", HANDLED_OBJ = "__polymerGesturesHandled", TOUCH_ACTION = "__polymerGesturesTouchAction", TAP_DISTANCE = 25, TRACK_DISTANCE = 5, TRACK_LENGTH = 2, MOUSE_TIMEOUT = 2500, MOUSE_EVENTS = [ "mousedown", "mousemove", "mouseup", "click" ], MOUSE_WHICH_TO_BUTTONS = [ 0, 1, 4, 2 ], MOUSE_HAS_BUTTONS = function() {
    try {
        return 1 === new MouseEvent("test", {
            buttons: 1
        }).buttons;
    } catch (e) {
        return !1;
    }
}();

function isMouseEvent(e) {
    return MOUSE_EVENTS.indexOf(e) > -1;
}

let SUPPORTS_PASSIVE = !1;

function PASSIVE_TOUCH(e) {
    if (!isMouseEvent(e) && "touchend" !== e) return HAS_NATIVE_TA && SUPPORTS_PASSIVE && passiveTouchGestures ? {
        passive: !0
    } : void 0;
}

!function() {
    try {
        let e = Object.defineProperty({}, "passive", {
            get() {
                SUPPORTS_PASSIVE = !0;
            }
        });
        window.addEventListener("test", null, e), window.removeEventListener("test", null, e);
    } catch (e) {}
}();

let IS_TOUCH_ONLY = navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/);

const clickedLabels = [], labellable = {
    button: !0,
    input: !0,
    keygen: !0,
    meter: !0,
    output: !0,
    textarea: !0,
    progress: !0,
    select: !0
}, canBeDisabled = {
    button: !0,
    command: !0,
    fieldset: !0,
    input: !0,
    keygen: !0,
    optgroup: !0,
    option: !0,
    select: !0,
    textarea: !0
};

function canBeLabelled(e) {
    return labellable[e.localName] || !1;
}

function matchingLabels(e) {
    let t = Array.prototype.slice.call(e.labels || []);
    if (!t.length) {
        t = [];
        let i = e.getRootNode();
        if (e.id) {
            let n = i.querySelectorAll(`label[for = ${e.id}]`);
            for (let e = 0; e < n.length; e++) t.push(n[e]);
        }
    }
    return t;
}

let mouseCanceller = function(e) {
    let t = e.sourceCapabilities;
    if ((!t || t.firesTouchEvents) && (e[HANDLED_OBJ] = {
        skip: !0
    }, "click" === e.type)) {
        let t = !1, i = e.composedPath && e.composedPath();
        if (i) for (let e = 0; e < i.length; e++) {
            if (i[e].nodeType === Node.ELEMENT_NODE) if ("label" === i[e].localName) clickedLabels.push(i[e]); else if (canBeLabelled(i[e])) {
                let n = matchingLabels(i[e]);
                for (let e = 0; e < n.length; e++) t = t || clickedLabels.indexOf(n[e]) > -1;
            }
            if (i[e] === POINTERSTATE.mouse.target) return;
        }
        if (t) return;
        e.preventDefault(), e.stopPropagation();
    }
};

function setupTeardownMouseCanceller(e) {
    let t = IS_TOUCH_ONLY ? [ "click" ] : MOUSE_EVENTS;
    for (let i, n = 0; n < t.length; n++) i = t[n], e ? (clickedLabels.length = 0, document.addEventListener(i, mouseCanceller, !0)) : document.removeEventListener(i, mouseCanceller, !0);
}

function ignoreMouse(e) {
    POINTERSTATE.mouse.mouseIgnoreJob || setupTeardownMouseCanceller(!0);
    POINTERSTATE.mouse.target = e.composedPath()[0], POINTERSTATE.mouse.mouseIgnoreJob = Debouncer.debounce(POINTERSTATE.mouse.mouseIgnoreJob, timeOut.after(MOUSE_TIMEOUT), function() {
        setupTeardownMouseCanceller(), POINTERSTATE.mouse.target = null, POINTERSTATE.mouse.mouseIgnoreJob = null;
    });
}

function hasLeftMouseButton(e) {
    let t = e.type;
    if (!isMouseEvent(t)) return !1;
    if ("mousemove" === t) {
        let t = void 0 === e.buttons ? 1 : e.buttons;
        return e instanceof window.MouseEvent && !MOUSE_HAS_BUTTONS && (t = MOUSE_WHICH_TO_BUTTONS[e.which] || 0), 
        Boolean(1 & t);
    }
    return 0 === (void 0 === e.button ? 0 : e.button);
}

function isSyntheticClick(e) {
    if ("click" === e.type) {
        if (0 === e.detail) return !0;
        let t = _findOriginalTarget(e);
        if (!t.nodeType || t.nodeType !== Node.ELEMENT_NODE) return !0;
        let i = t.getBoundingClientRect(), n = e.pageX, s = e.pageY;
        return !(n >= i.left && n <= i.right && s >= i.top && s <= i.bottom);
    }
    return !1;
}

let POINTERSTATE = {
    mouse: {
        target: null,
        mouseIgnoreJob: null
    },
    touch: {
        x: 0,
        y: 0,
        id: -1,
        scrollDecided: !1
    }
};

function firstTouchAction(e) {
    let t = "auto", i = e.composedPath && e.composedPath();
    if (i) for (let e, n = 0; n < i.length; n++) if ((e = i[n])[TOUCH_ACTION]) {
        t = e[TOUCH_ACTION];
        break;
    }
    return t;
}

function trackDocument(e, t, i) {
    e.movefn = t, e.upfn = i, document.addEventListener("mousemove", t), document.addEventListener("mouseup", i);
}

function untrackDocument(e) {
    document.removeEventListener("mousemove", e.movefn), document.removeEventListener("mouseup", e.upfn), 
    e.movefn = null, e.upfn = null;
}

document.addEventListener("touchend", ignoreMouse, !!SUPPORTS_PASSIVE && {
    passive: !0
});

const gestures = {}, recognizers = [];

function deepTargetFind(e, t) {
    let i = document.elementFromPoint(e, t), n = i;
    for (;n && n.shadowRoot && !window.ShadyDOM; ) {
        if (n === (n = n.shadowRoot.elementFromPoint(e, t))) break;
        n && (i = n);
    }
    return i;
}

function _findOriginalTarget(e) {
    if (e.composedPath) {
        const t = e.composedPath();
        return t.length > 0 ? t[0] : e.target;
    }
    return e.target;
}

function _handleNative(e) {
    let t, i = e.type, n = e.currentTarget[GESTURE_KEY];
    if (!n) return;
    let s = n[i];
    if (s) {
        if (!e[HANDLED_OBJ] && (e[HANDLED_OBJ] = {}, "touch" === i.slice(0, 5))) {
            let t = (e = e).changedTouches[0];
            if ("touchstart" === i && 1 === e.touches.length && (POINTERSTATE.touch.id = t.identifier), 
            POINTERSTATE.touch.id !== t.identifier) return;
            HAS_NATIVE_TA || "touchstart" !== i && "touchmove" !== i || _handleTouchAction(e);
        }
        if (!(t = e[HANDLED_OBJ]).skip) {
            for (let i, n = 0; n < recognizers.length; n++) s[(i = recognizers[n]).name] && !t[i.name] && i.flow && i.flow.start.indexOf(e.type) > -1 && i.reset && i.reset();
            for (let n, r = 0; r < recognizers.length; r++) s[(n = recognizers[r]).name] && !t[n.name] && (t[n.name] = !0, 
            n[i](e));
        }
    }
}

function _handleTouchAction(e) {
    let t = e.changedTouches[0], i = e.type;
    if ("touchstart" === i) POINTERSTATE.touch.x = t.clientX, POINTERSTATE.touch.y = t.clientY, 
    POINTERSTATE.touch.scrollDecided = !1; else if ("touchmove" === i) {
        if (POINTERSTATE.touch.scrollDecided) return;
        POINTERSTATE.touch.scrollDecided = !0;
        let i = firstTouchAction(e), n = !1, s = Math.abs(POINTERSTATE.touch.x - t.clientX), r = Math.abs(POINTERSTATE.touch.y - t.clientY);
        e.cancelable && ("none" === i ? n = !0 : "pan-x" === i ? n = r > s : "pan-y" === i && (n = s > r)), 
        n ? e.preventDefault() : prevent("track");
    }
}

function addListener(e, t, i) {
    return !!gestures[t] && (_add(e, t, i), !0);
}

function removeListener(e, t, i) {
    return !!gestures[t] && (_remove(e, t, i), !0);
}

function _add(e, t, i) {
    let n = gestures[t], s = n.deps, r = n.name, o = e[GESTURE_KEY];
    o || (e[GESTURE_KEY] = o = {});
    for (let t, i, n = 0; n < s.length; n++) t = s[n], IS_TOUCH_ONLY && isMouseEvent(t) && "click" !== t || ((i = o[t]) || (o[t] = i = {
        _count: 0
    }), 0 === i._count && e.addEventListener(t, _handleNative, PASSIVE_TOUCH(t)), i[r] = (i[r] || 0) + 1, 
    i._count = (i._count || 0) + 1);
    e.addEventListener(t, i), n.touchAction && setTouchAction(e, n.touchAction);
}

function _remove(e, t, i) {
    let n = gestures[t], s = n.deps, r = n.name, o = e[GESTURE_KEY];
    if (o) for (let t, i, n = 0; n < s.length; n++) (i = o[t = s[n]]) && i[r] && (i[r] = (i[r] || 1) - 1, 
    i._count = (i._count || 1) - 1, 0 === i._count && e.removeEventListener(t, _handleNative, PASSIVE_TOUCH(t)));
    e.removeEventListener(t, i);
}

function register$1(e) {
    recognizers.push(e);
    for (let t = 0; t < e.emits.length; t++) gestures[e.emits[t]] = e;
}

function _findRecognizerByEvent(e) {
    for (let t, i = 0; i < recognizers.length; i++) {
        t = recognizers[i];
        for (let i, n = 0; n < t.emits.length; n++) if ((i = t.emits[n]) === e) return t;
    }
    return null;
}

function setTouchAction(e, t) {
    HAS_NATIVE_TA && e instanceof HTMLElement && microTask.run(() => {
        e.style.touchAction = t;
    }), e[TOUCH_ACTION] = t;
}

function _fire(e, t, i) {
    let n = new Event(t, {
        bubbles: !0,
        cancelable: !0,
        composed: !0
    });
    if (n.detail = i, e.dispatchEvent(n), n.defaultPrevented) {
        let e = i.preventer || i.sourceEvent;
        e && e.preventDefault && e.preventDefault();
    }
}

function prevent(e) {
    let t = _findRecognizerByEvent(e);
    t.info && (t.info.prevent = !0);
}

function resetMouseCanceller() {
    POINTERSTATE.mouse.mouseIgnoreJob && POINTERSTATE.mouse.mouseIgnoreJob.flush();
}

function downupFire(e, t, i, n) {
    t && _fire(t, e, {
        x: i.clientX,
        y: i.clientY,
        sourceEvent: i,
        preventer: n,
        prevent: function(e) {
            return prevent(e);
        }
    });
}

function trackHasMovedEnough(e, t, i) {
    if (e.prevent) return !1;
    if (e.started) return !0;
    let n = Math.abs(e.x - t), s = Math.abs(e.y - i);
    return n >= TRACK_DISTANCE || s >= TRACK_DISTANCE;
}

function trackFire(e, t, i) {
    if (!t) return;
    let n, s = e.moves[e.moves.length - 2], r = e.moves[e.moves.length - 1], o = r.x - e.x, a = r.y - e.y, l = 0;
    s && (n = r.x - s.x, l = r.y - s.y), _fire(t, "track", {
        state: e.state,
        x: i.clientX,
        y: i.clientY,
        dx: o,
        dy: a,
        ddx: n,
        ddy: l,
        sourceEvent: i,
        hover: function() {
            return deepTargetFind(i.clientX, i.clientY);
        }
    });
}

function trackForward(e, t, i) {
    let n = Math.abs(t.clientX - e.x), s = Math.abs(t.clientY - e.y), r = _findOriginalTarget(i || t);
    !r || canBeDisabled[r.localName] && r.hasAttribute("disabled") || (isNaN(n) || isNaN(s) || n <= TAP_DISTANCE && s <= TAP_DISTANCE || isSyntheticClick(t)) && (e.prevent || _fire(r, "tap", {
        x: t.clientX,
        y: t.clientY,
        sourceEvent: t,
        preventer: i
    }));
}

register$1({
    name: "downup",
    deps: [ "mousedown", "touchstart", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "mouseup", "touchend" ]
    },
    emits: [ "down", "up" ],
    info: {
        movefn: null,
        upfn: null
    },
    reset: function() {
        untrackDocument(this.info);
    },
    mousedown: function(e) {
        if (!hasLeftMouseButton(e)) return;
        let t = _findOriginalTarget(e), i = this;
        trackDocument(this.info, function(e) {
            hasLeftMouseButton(e) || (downupFire("up", t, e), untrackDocument(i.info));
        }, function(e) {
            hasLeftMouseButton(e) && downupFire("up", t, e), untrackDocument(i.info);
        }), downupFire("down", t, e);
    },
    touchstart: function(e) {
        downupFire("down", _findOriginalTarget(e), e.changedTouches[0], e);
    },
    touchend: function(e) {
        downupFire("up", _findOriginalTarget(e), e.changedTouches[0], e);
    }
}), register$1({
    name: "track",
    touchAction: "none",
    deps: [ "mousedown", "touchstart", "touchmove", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "mouseup", "touchend" ]
    },
    emits: [ "track" ],
    info: {
        x: 0,
        y: 0,
        state: "start",
        started: !1,
        moves: [],
        addMove: function(e) {
            this.moves.length > TRACK_LENGTH && this.moves.shift(), this.moves.push(e);
        },
        movefn: null,
        upfn: null,
        prevent: !1
    },
    reset: function() {
        this.info.state = "start", this.info.started = !1, this.info.moves = [], this.info.x = 0, 
        this.info.y = 0, this.info.prevent = !1, untrackDocument(this.info);
    },
    mousedown: function(e) {
        if (!hasLeftMouseButton(e)) return;
        let t = _findOriginalTarget(e), i = this, n = function(e) {
            let n = e.clientX, s = e.clientY;
            trackHasMovedEnough(i.info, n, s) && (i.info.state = i.info.started ? "mouseup" === e.type ? "end" : "track" : "start", 
            "start" === i.info.state && prevent("tap"), i.info.addMove({
                x: n,
                y: s
            }), hasLeftMouseButton(e) || (i.info.state = "end", untrackDocument(i.info)), t && trackFire(i.info, t, e), 
            i.info.started = !0);
        };
        trackDocument(this.info, n, function(e) {
            i.info.started && n(e), untrackDocument(i.info);
        }), this.info.x = e.clientX, this.info.y = e.clientY;
    },
    touchstart: function(e) {
        let t = e.changedTouches[0];
        this.info.x = t.clientX, this.info.y = t.clientY;
    },
    touchmove: function(e) {
        let t = _findOriginalTarget(e), i = e.changedTouches[0], n = i.clientX, s = i.clientY;
        trackHasMovedEnough(this.info, n, s) && ("start" === this.info.state && prevent("tap"), 
        this.info.addMove({
            x: n,
            y: s
        }), trackFire(this.info, t, i), this.info.state = "track", this.info.started = !0);
    },
    touchend: function(e) {
        let t = _findOriginalTarget(e), i = e.changedTouches[0];
        this.info.started && (this.info.state = "end", this.info.addMove({
            x: i.clientX,
            y: i.clientY
        }), trackFire(this.info, t, i));
    }
}), register$1({
    name: "tap",
    deps: [ "mousedown", "click", "touchstart", "touchend" ],
    flow: {
        start: [ "mousedown", "touchstart" ],
        end: [ "click", "touchend" ]
    },
    emits: [ "tap" ],
    info: {
        x: NaN,
        y: NaN,
        prevent: !1
    },
    reset: function() {
        this.info.x = NaN, this.info.y = NaN, this.info.prevent = !1;
    },
    mousedown: function(e) {
        hasLeftMouseButton(e) && (this.info.x = e.clientX, this.info.y = e.clientY);
    },
    click: function(e) {
        hasLeftMouseButton(e) && trackForward(this.info, e);
    },
    touchstart: function(e) {
        const t = e.changedTouches[0];
        this.info.x = t.clientX, this.info.y = t.clientY;
    },
    touchend: function(e) {
        trackForward(this.info, e.changedTouches[0], e);
    }
});

const findOriginalTarget = _findOriginalTarget, add = addListener, remove = removeListener;

var gestures$1 = {
    gestures: gestures,
    recognizers: recognizers,
    deepTargetFind: deepTargetFind,
    addListener: addListener,
    removeListener: removeListener,
    register: register$1,
    setTouchAction: setTouchAction,
    prevent: prevent,
    resetMouseCanceller: resetMouseCanceller,
    findOriginalTarget: findOriginalTarget,
    add: add,
    remove: remove
};

const GestureEventListeners = dedupingMixin(e => {
    return class extends e {
        _addEventListenerToNode(e, t, i) {
            addListener(e, t, i) || super._addEventListenerToNode(e, t, i);
        }
        _removeEventListenerFromNode(e, t, i) {
            removeListener(e, t, i) || super._removeEventListenerFromNode(e, t, i);
        }
    };
});

var gestureEventListeners = {
    GestureEventListeners: GestureEventListeners
};

const HOST_DIR = /:host\(:dir\((ltr|rtl)\)\)/g, HOST_DIR_REPLACMENT = ':host([dir="$1"])', EL_DIR = /([\s\w-#\.\[\]\*]*):dir\((ltr|rtl)\)/g, EL_DIR_REPLACMENT = ':host([dir="$2"]) $1', DIR_INSTANCES = [];

let observer = null, DOCUMENT_DIR = "";

function getRTL() {
    DOCUMENT_DIR = document.documentElement.getAttribute("dir");
}

function setRTL(e) {
    if (!e.__autoDirOptOut) {
        e.setAttribute("dir", DOCUMENT_DIR);
    }
}

function updateDirection() {
    getRTL(), DOCUMENT_DIR = document.documentElement.getAttribute("dir");
    for (let e = 0; e < DIR_INSTANCES.length; e++) setRTL(DIR_INSTANCES[e]);
}

function takeRecords() {
    observer && observer.takeRecords().length && updateDirection();
}

const DirMixin = dedupingMixin(e => {
    observer || (getRTL(), (observer = new MutationObserver(updateDirection)).observe(document.documentElement, {
        attributes: !0,
        attributeFilter: [ "dir" ]
    }));
    const t = PropertyAccessors(e);
    class i extends t {
        static _processStyleText(e, t) {
            return e = super._processStyleText(e, t), e = this._replaceDirInCssText(e);
        }
        static _replaceDirInCssText(e) {
            let t = e;
            return e !== (t = (t = t.replace(HOST_DIR, HOST_DIR_REPLACMENT)).replace(EL_DIR, EL_DIR_REPLACMENT)) && (this.__activateDir = !0), 
            t;
        }
        constructor() {
            super(), this.__autoDirOptOut = !1;
        }
        ready() {
            super.ready(), this.__autoDirOptOut = this.hasAttribute("dir");
        }
        connectedCallback() {
            t.prototype.connectedCallback && super.connectedCallback(), this.constructor.__activateDir && (takeRecords(), 
            DIR_INSTANCES.push(this), setRTL(this));
        }
        disconnectedCallback() {
            if (t.prototype.disconnectedCallback && super.disconnectedCallback(), this.constructor.__activateDir) {
                const e = DIR_INSTANCES.indexOf(this);
                e > -1 && DIR_INSTANCES.splice(e, 1);
            }
        }
    }
    return i.__activateDir = !1, i;
});

var dirMixin = {
    DirMixin: DirMixin
};

let scheduled = !1, beforeRenderQueue = [], afterRenderQueue = [];

function schedule() {
    scheduled = !0, requestAnimationFrame(function() {
        scheduled = !1, flushQueue(beforeRenderQueue), setTimeout(function() {
            runQueue(afterRenderQueue);
        });
    });
}

function flushQueue(e) {
    for (;e.length; ) callMethod(e.shift());
}

function runQueue(e) {
    for (let t = 0, i = e.length; t < i; t++) callMethod(e.shift());
}

function callMethod(e) {
    const t = e[0], i = e[1], n = e[2];
    try {
        i.apply(t, n);
    } catch (e) {
        setTimeout(() => {
            throw e;
        });
    }
}

function flush() {
    for (;beforeRenderQueue.length || afterRenderQueue.length; ) flushQueue(beforeRenderQueue), 
    flushQueue(afterRenderQueue);
    scheduled = !1;
}

function beforeNextRender(e, t, i) {
    scheduled || schedule(), beforeRenderQueue.push([ e, t, i ]);
}

function afterNextRender(e, t, i) {
    scheduled || schedule(), afterRenderQueue.push([ e, t, i ]);
}

var renderStatus = {
    flush: flush,
    beforeNextRender: beforeNextRender,
    afterNextRender: afterNextRender
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ function resolve() {
    document.body.removeAttribute("unresolved");
}

function newSplice(e, t, i) {
    return {
        index: e,
        removed: t,
        addedCount: i
    };
}

"interactive" === document.readyState || "complete" === document.readyState ? resolve() : window.addEventListener("DOMContentLoaded", resolve);

const EDIT_LEAVE = 0, EDIT_UPDATE = 1, EDIT_ADD = 2, EDIT_DELETE = 3;

function calcEditDistances(e, t, i, n, s, r) {
    let o = r - s + 1, a = i - t + 1, l = new Array(o);
    for (let e = 0; e < o; e++) l[e] = new Array(a), l[e][0] = e;
    for (let e = 0; e < a; e++) l[0][e] = e;
    for (let i = 1; i < o; i++) for (let r = 1; r < a; r++) if (equals(e[t + r - 1], n[s + i - 1])) l[i][r] = l[i - 1][r - 1]; else {
        let e = l[i - 1][r] + 1, t = l[i][r - 1] + 1;
        l[i][r] = e < t ? e : t;
    }
    return l;
}

function spliceOperationsFromEditDistances(e) {
    let t = e.length - 1, i = e[0].length - 1, n = e[t][i], s = [];
    for (;t > 0 || i > 0; ) {
        if (0 == t) {
            s.push(EDIT_ADD), i--;
            continue;
        }
        if (0 == i) {
            s.push(EDIT_DELETE), t--;
            continue;
        }
        let r, o = e[t - 1][i - 1], a = e[t - 1][i], l = e[t][i - 1];
        (r = a < l ? a < o ? a : o : l < o ? l : o) == o ? (o == n ? s.push(EDIT_LEAVE) : (s.push(EDIT_UPDATE), 
        n = o), t--, i--) : r == a ? (s.push(EDIT_DELETE), t--, n = a) : (s.push(EDIT_ADD), 
        i--, n = l);
    }
    return s.reverse(), s;
}

function calcSplices(e, t, i, n, s, r) {
    let o, a = 0, l = 0, c = Math.min(i - t, r - s);
    if (0 == t && 0 == s && (a = sharedPrefix(e, n, c)), i == e.length && r == n.length && (l = sharedSuffix(e, n, c - a)), 
    s += a, r -= l, (i -= l) - (t += a) == 0 && r - s == 0) return [];
    if (t == i) {
        for (o = newSplice(t, [], 0); s < r; ) o.removed.push(n[s++]);
        return [ o ];
    }
    if (s == r) return [ newSplice(t, [], i - t) ];
    let h = spliceOperationsFromEditDistances(calcEditDistances(e, t, i, n, s, r));
    o = void 0;
    let d = [], u = t, p = s;
    for (let e = 0; e < h.length; e++) switch (h[e]) {
      case EDIT_LEAVE:
        o && (d.push(o), o = void 0), u++, p++;
        break;

      case EDIT_UPDATE:
        o || (o = newSplice(u, [], 0)), o.addedCount++, u++, o.removed.push(n[p]), p++;
        break;

      case EDIT_ADD:
        o || (o = newSplice(u, [], 0)), o.addedCount++, u++;
        break;

      case EDIT_DELETE:
        o || (o = newSplice(u, [], 0)), o.removed.push(n[p]), p++;
    }
    return o && d.push(o), d;
}

function sharedPrefix(e, t, i) {
    for (let n = 0; n < i; n++) if (!equals(e[n], t[n])) return n;
    return i;
}

function sharedSuffix(e, t, i) {
    let n = e.length, s = t.length, r = 0;
    for (;r < i && equals(e[--n], t[--s]); ) r++;
    return r;
}

function calculateSplices(e, t) {
    return calcSplices(e, 0, e.length, t, 0, t.length);
}

function equals(e, t) {
    return e === t;
}

var arraySplice = {
    calculateSplices: calculateSplices
};

function isSlot(e) {
    return "slot" === e.localName;
}

class FlattenedNodesObserver {
    static getFlattenedNodes(e) {
        return isSlot(e) ? (e = e).assignedNodes({
            flatten: !0
        }) : Array.from(e.childNodes).map(e => isSlot(e) ? (e = e).assignedNodes({
            flatten: !0
        }) : [ e ]).reduce((e, t) => e.concat(t), []);
    }
    constructor(e, t) {
        this._shadyChildrenObserver = null, this._nativeChildrenObserver = null, this._connected = !1, 
        this._target = e, this.callback = t, this._effectiveNodes = [], this._observer = null, 
        this._scheduled = !1, this._boundSchedule = (() => {
            this._schedule();
        }), this.connect(), this._schedule();
    }
    connect() {
        isSlot(this._target) ? this._listenSlots([ this._target ]) : this._target.children && (this._listenSlots(this._target.children), 
        window.ShadyDOM ? this._shadyChildrenObserver = ShadyDOM.observeChildren(this._target, e => {
            this._processMutations(e);
        }) : (this._nativeChildrenObserver = new MutationObserver(e => {
            this._processMutations(e);
        }), this._nativeChildrenObserver.observe(this._target, {
            childList: !0
        }))), this._connected = !0;
    }
    disconnect() {
        isSlot(this._target) ? this._unlistenSlots([ this._target ]) : this._target.children && (this._unlistenSlots(this._target.children), 
        window.ShadyDOM && this._shadyChildrenObserver ? (ShadyDOM.unobserveChildren(this._shadyChildrenObserver), 
        this._shadyChildrenObserver = null) : this._nativeChildrenObserver && (this._nativeChildrenObserver.disconnect(), 
        this._nativeChildrenObserver = null)), this._connected = !1;
    }
    _schedule() {
        this._scheduled || (this._scheduled = !0, microTask.run(() => this.flush()));
    }
    _processMutations(e) {
        this._processSlotMutations(e), this.flush();
    }
    _processSlotMutations(e) {
        if (e) for (let t = 0; t < e.length; t++) {
            let i = e[t];
            i.addedNodes && this._listenSlots(i.addedNodes), i.removedNodes && this._unlistenSlots(i.removedNodes);
        }
    }
    flush() {
        if (!this._connected) return !1;
        window.ShadyDOM && ShadyDOM.flush(), this._nativeChildrenObserver ? this._processSlotMutations(this._nativeChildrenObserver.takeRecords()) : this._shadyChildrenObserver && this._processSlotMutations(this._shadyChildrenObserver.takeRecords()), 
        this._scheduled = !1;
        let e = {
            target: this._target,
            addedNodes: [],
            removedNodes: []
        }, t = this.constructor.getFlattenedNodes(this._target), i = calculateSplices(t, this._effectiveNodes);
        for (let t, n = 0; n < i.length && (t = i[n]); n++) for (let i, n = 0; n < t.removed.length && (i = t.removed[n]); n++) e.removedNodes.push(i);
        for (let n, s = 0; s < i.length && (n = i[s]); s++) for (let i = n.index; i < n.index + n.addedCount; i++) e.addedNodes.push(t[i]);
        this._effectiveNodes = t;
        let n = !1;
        return (e.addedNodes.length || e.removedNodes.length) && (n = !0, this.callback.call(this._target, e)), 
        n;
    }
    _listenSlots(e) {
        for (let t = 0; t < e.length; t++) {
            let i = e[t];
            isSlot(i) && i.addEventListener("slotchange", this._boundSchedule);
        }
    }
    _unlistenSlots(e) {
        for (let t = 0; t < e.length; t++) {
            let i = e[t];
            isSlot(i) && i.removeEventListener("slotchange", this._boundSchedule);
        }
    }
}

var flattenedNodesObserver = {
    FlattenedNodesObserver: FlattenedNodesObserver
};

let debouncerQueue = [];

const enqueueDebouncer = function(e) {
    debouncerQueue.push(e);
};

function flushDebouncers() {
    const e = Boolean(debouncerQueue.length);
    for (;debouncerQueue.length; ) try {
        debouncerQueue.shift().flush();
    } catch (e) {
        setTimeout(() => {
            throw e;
        });
    }
    return e;
}

const flush$1 = function() {
    let e, t;
    do {
        e = window.ShadyDOM && ShadyDOM.flush(), window.ShadyCSS && window.ShadyCSS.ScopingShim && window.ShadyCSS.ScopingShim.flush(), 
        t = flushDebouncers();
    } while (e || t);
};

var flush$2 = {
    enqueueDebouncer: enqueueDebouncer,
    flush: flush$1
};

const p = Element.prototype, normalizedMatchesSelector = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector, matchesSelector = function(e, t) {
    return normalizedMatchesSelector.call(e, t);
};

class DomApi {
    constructor(e) {
        this.node = e;
    }
    observeNodes(e) {
        return new FlattenedNodesObserver(this.node, e);
    }
    unobserveNodes(e) {
        e.disconnect();
    }
    notifyObserver() {}
    deepContains(e) {
        if (this.node.contains(e)) return !0;
        let t = e, i = e.ownerDocument;
        for (;t && t !== i && t !== this.node; ) t = t.parentNode || t.host;
        return t === this.node;
    }
    getOwnerRoot() {
        return this.node.getRootNode();
    }
    getDistributedNodes() {
        return "slot" === this.node.localName ? this.node.assignedNodes({
            flatten: !0
        }) : [];
    }
    getDestinationInsertionPoints() {
        let e = [], t = this.node.assignedSlot;
        for (;t; ) e.push(t), t = t.assignedSlot;
        return e;
    }
    importNode(e, t) {
        return (this.node instanceof Document ? this.node : this.node.ownerDocument).importNode(e, t);
    }
    getEffectiveChildNodes() {
        return FlattenedNodesObserver.getFlattenedNodes(this.node);
    }
    queryDistributedElements(e) {
        let t = this.getEffectiveChildNodes(), i = [];
        for (let n, s = 0, r = t.length; s < r && (n = t[s]); s++) n.nodeType === Node.ELEMENT_NODE && matchesSelector(n, e) && i.push(n);
        return i;
    }
    get activeElement() {
        let e = this.node;
        return void 0 !== e._activeElement ? e._activeElement : e.activeElement;
    }
}

function forwardMethods(e, t) {
    for (let i = 0; i < t.length; i++) {
        let n = t[i];
        e[n] = function() {
            return this.node[n].apply(this.node, arguments);
        };
    }
}

function forwardReadOnlyProperties(e, t) {
    for (let i = 0; i < t.length; i++) {
        let n = t[i];
        Object.defineProperty(e, n, {
            get: function() {
                return this.node[n];
            },
            configurable: !0
        });
    }
}

function forwardProperties(e, t) {
    for (let i = 0; i < t.length; i++) {
        let n = t[i];
        Object.defineProperty(e, n, {
            get: function() {
                return this.node[n];
            },
            set: function(e) {
                this.node[n] = e;
            },
            configurable: !0
        });
    }
}

class EventApi {
    constructor(e) {
        this.event = e;
    }
    get rootTarget() {
        return this.event.composedPath()[0];
    }
    get localTarget() {
        return this.event.target;
    }
    get path() {
        return this.event.composedPath();
    }
}

DomApi.prototype.cloneNode, DomApi.prototype.appendChild, DomApi.prototype.insertBefore, 
DomApi.prototype.removeChild, DomApi.prototype.replaceChild, DomApi.prototype.setAttribute, 
DomApi.prototype.removeAttribute, DomApi.prototype.querySelector, DomApi.prototype.querySelectorAll, 
DomApi.prototype.parentNode, DomApi.prototype.firstChild, DomApi.prototype.lastChild, 
DomApi.prototype.nextSibling, DomApi.prototype.previousSibling, DomApi.prototype.firstElementChild, 
DomApi.prototype.lastElementChild, DomApi.prototype.nextElementSibling, DomApi.prototype.previousElementSibling, 
DomApi.prototype.childNodes, DomApi.prototype.children, DomApi.prototype.classList, 
DomApi.prototype.textContent, DomApi.prototype.innerHTML, forwardMethods(DomApi.prototype, [ "cloneNode", "appendChild", "insertBefore", "removeChild", "replaceChild", "setAttribute", "removeAttribute", "querySelector", "querySelectorAll" ]), 
forwardReadOnlyProperties(DomApi.prototype, [ "parentNode", "firstChild", "lastChild", "nextSibling", "previousSibling", "firstElementChild", "lastElementChild", "nextElementSibling", "previousElementSibling", "childNodes", "children", "classList" ]), 
forwardProperties(DomApi.prototype, [ "textContent", "innerHTML" ]);

const dom = function(e) {
    if (!(e = e || document).__domApi) {
        let t;
        t = e instanceof Event ? new EventApi(e) : new DomApi(e), e.__domApi = t;
    }
    return e.__domApi;
};

var polymer_dom = {
    matchesSelector: matchesSelector,
    DomApi: DomApi,
    EventApi: EventApi,
    dom: dom,
    flush: flush$1,
    addDebouncer: enqueueDebouncer
};

const bundledImportMeta$1 = {
    ...import.meta,
    url: new URL("./node_modules/%40polymer/polymer/lib/legacy/legacy-element-mixin.js", import.meta.url).href
};

let styleInterface = window.ShadyCSS;

const LegacyElementMixin = dedupingMixin(e => {
    const t = DirMixin(GestureEventListeners(ElementMixin(e))), i = {
        x: "pan-x",
        y: "pan-y",
        none: "none",
        all: "auto"
    };
    class n extends t {
        constructor() {
            super(), this.isAttached, this.__boundListeners, this._debouncers, this._applyListeners();
        }
        static get importMeta() {
            return this.prototype.importMeta;
        }
        created() {}
        connectedCallback() {
            super.connectedCallback(), this.isAttached = !0, this.attached();
        }
        attached() {}
        disconnectedCallback() {
            super.disconnectedCallback(), this.isAttached = !1, this.detached();
        }
        detached() {}
        attributeChangedCallback(e, t, i, n) {
            t !== i && (super.attributeChangedCallback(e, t, i, n), this.attributeChanged(e, t, i));
        }
        attributeChanged(e, t, i) {}
        _initializeProperties() {
            let e = Object.getPrototypeOf(this);
            e.hasOwnProperty("__hasRegisterFinished") || (e.__hasRegisterFinished = !0, this._registered()), 
            super._initializeProperties(), this.root = this, this.created();
        }
        _registered() {}
        ready() {
            this._ensureAttributes(), super.ready();
        }
        _ensureAttributes() {}
        _applyListeners() {}
        serialize(e) {
            return this._serializeValue(e);
        }
        deserialize(e, t) {
            return this._deserializeValue(e, t);
        }
        reflectPropertyToAttribute(e, t, i) {
            this._propertyToAttribute(e, t, i);
        }
        serializeValueToAttribute(e, t, i) {
            this._valueToNodeAttribute(i || this, e, t);
        }
        extend(e, t) {
            if (!e || !t) return e || t;
            let i = Object.getOwnPropertyNames(t);
            for (let n, s = 0; s < i.length && (n = i[s]); s++) {
                let i = Object.getOwnPropertyDescriptor(t, n);
                i && Object.defineProperty(e, n, i);
            }
            return e;
        }
        mixin(e, t) {
            for (let i in t) e[i] = t[i];
            return e;
        }
        chainObject(e, t) {
            return e && t && e !== t && (e.__proto__ = t), e;
        }
        instanceTemplate(e) {
            let t = this.constructor._contentForTemplate(e);
            return document.importNode(t, !0);
        }
        fire(e, t, i) {
            i = i || {}, t = null == t ? {} : t;
            let n = new Event(e, {
                bubbles: void 0 === i.bubbles || i.bubbles,
                cancelable: Boolean(i.cancelable),
                composed: void 0 === i.composed || i.composed
            });
            return n.detail = t, (i.node || this).dispatchEvent(n), n;
        }
        listen(e, t, i) {
            e = e || this;
            let n = this.__boundListeners || (this.__boundListeners = new WeakMap()), s = n.get(e);
            s || (s = {}, n.set(e, s));
            let r = t + i;
            s[r] || (s[r] = this._addMethodEventListenerToNode(e, t, i, this));
        }
        unlisten(e, t, i) {
            e = e || this;
            let n = this.__boundListeners && this.__boundListeners.get(e), s = t + i, r = n && n[s];
            r && (this._removeEventListenerFromNode(e, t, r), n[s] = null);
        }
        setScrollDirection(e, t) {
            setTouchAction(t || this, i[e] || "auto");
        }
        $$(e) {
            return this.root.querySelector(e);
        }
        get domHost() {
            let e = this.getRootNode();
            return e instanceof DocumentFragment ? e.host : e;
        }
        distributeContent() {
            window.ShadyDOM && this.shadowRoot && ShadyDOM.flush();
        }
        getEffectiveChildNodes() {
            return dom(this).getEffectiveChildNodes();
        }
        queryDistributedElements(e) {
            return dom(this).queryDistributedElements(e);
        }
        getEffectiveChildren() {
            return this.getEffectiveChildNodes().filter(function(e) {
                return e.nodeType === Node.ELEMENT_NODE;
            });
        }
        getEffectiveTextContent() {
            let e = this.getEffectiveChildNodes(), t = [];
            for (let i, n = 0; i = e[n]; n++) i.nodeType !== Node.COMMENT_NODE && t.push(i.textContent);
            return t.join("");
        }
        queryEffectiveChildren(e) {
            let t = this.queryDistributedElements(e);
            return t && t[0];
        }
        queryAllEffectiveChildren(e) {
            return this.queryDistributedElements(e);
        }
        getContentChildNodes(e) {
            let t = this.root.querySelector(e || "slot");
            return t ? dom(t).getDistributedNodes() : [];
        }
        getContentChildren(e) {
            return this.getContentChildNodes(e).filter(function(e) {
                return e.nodeType === Node.ELEMENT_NODE;
            });
        }
        isLightDescendant(e) {
            return this !== e && this.contains(e) && this.getRootNode() === e.getRootNode();
        }
        isLocalDescendant(e) {
            return this.root === e.getRootNode();
        }
        scopeSubtree(e, t) {}
        getComputedStyleValue(e) {
            return styleInterface.getComputedStyleValue(this, e);
        }
        debounce(e, t, i) {
            return this._debouncers = this._debouncers || {}, this._debouncers[e] = Debouncer.debounce(this._debouncers[e], i > 0 ? timeOut.after(i) : microTask, t.bind(this));
        }
        isDebouncerActive(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            return !(!t || !t.isActive());
        }
        flushDebouncer(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            t && t.flush();
        }
        cancelDebouncer(e) {
            this._debouncers = this._debouncers || {};
            let t = this._debouncers[e];
            t && t.cancel();
        }
        async(e, t) {
            return t > 0 ? timeOut.run(e.bind(this), t) : ~microTask.run(e.bind(this));
        }
        cancelAsync(e) {
            e < 0 ? microTask.cancel(~e) : timeOut.cancel(e);
        }
        create(e, t) {
            let i = document.createElement(e);
            if (t) if (i.setProperties) i.setProperties(t); else for (let e in t) i[e] = t[e];
            return i;
        }
        elementMatches(e, t) {
            return matchesSelector(t || this, e);
        }
        toggleAttribute(e, t) {
            let i = this;
            return 3 === arguments.length && (i = arguments[2]), 1 == arguments.length && (t = !i.hasAttribute(e)), 
            t ? (i.setAttribute(e, ""), !0) : (i.removeAttribute(e), !1);
        }
        toggleClass(e, t, i) {
            i = i || this, 1 == arguments.length && (t = !i.classList.contains(e)), t ? i.classList.add(e) : i.classList.remove(e);
        }
        transform(e, t) {
            (t = t || this).style.webkitTransform = e, t.style.transform = e;
        }
        translate3d(e, t, i, n) {
            n = n || this, this.transform("translate3d(" + e + "," + t + "," + i + ")", n);
        }
        arrayDelete(e, t) {
            let i;
            if (Array.isArray(e)) {
                if ((i = e.indexOf(t)) >= 0) return e.splice(i, 1);
            } else {
                if ((i = get(this, e).indexOf(t)) >= 0) return this.splice(e, i, 1);
            }
            return null;
        }
        _logger(e, t) {
            switch (Array.isArray(t) && 1 === t.length && Array.isArray(t[0]) && (t = t[0]), 
            e) {
              case "log":
              case "warn":
              case "error":
                console[e](...t);
            }
        }
        _log(...e) {
            this._logger("log", e);
        }
        _warn(...e) {
            this._logger("warn", e);
        }
        _error(...e) {
            this._logger("error", e);
        }
        _logf(e, ...t) {
            return [ "[%s::%s]", this.is, e, ...t ];
        }
    }
    return n.prototype.is = "", n;
});

var legacyElementMixin = {
    LegacyElementMixin: LegacyElementMixin
};

let metaProps = {
    attached: !0,
    detached: !0,
    ready: !0,
    created: !0,
    beforeRegister: !0,
    registered: !0,
    attributeChanged: !0,
    behaviors: !0
};

function mixinBehaviors(e, t) {
    if (!e) return t = t;
    t = LegacyElementMixin(t), Array.isArray(e) || (e = [ e ]);
    let i = t.prototype.behaviors;
    return t = _mixinBehaviors(e = flattenBehaviors(e, null, i), t), i && (e = i.concat(e)), 
    t.prototype.behaviors = e, t;
}

function _mixinBehaviors(e, t) {
    for (let i = 0; i < e.length; i++) {
        let n = e[i];
        n && (t = Array.isArray(n) ? _mixinBehaviors(n, t) : GenerateClassFromInfo(n, t));
    }
    return t;
}

function flattenBehaviors(e, t, i) {
    t = t || [];
    for (let n = e.length - 1; n >= 0; n--) {
        let s = e[n];
        s ? Array.isArray(s) ? flattenBehaviors(s, t) : t.indexOf(s) < 0 && (!i || i.indexOf(s) < 0) && t.unshift(s) : console.warn("behavior is null, check for missing or 404 import");
    }
    return t;
}

function GenerateClassFromInfo(e, t) {
    class i extends t {
        static get properties() {
            return e.properties;
        }
        static get observers() {
            return e.observers;
        }
        created() {
            super.created(), e.created && e.created.call(this);
        }
        _registered() {
            super._registered(), e.beforeRegister && e.beforeRegister.call(Object.getPrototypeOf(this)), 
            e.registered && e.registered.call(Object.getPrototypeOf(this));
        }
        _applyListeners() {
            if (super._applyListeners(), e.listeners) for (let t in e.listeners) this._addMethodEventListenerToNode(this, t, e.listeners[t]);
        }
        _ensureAttributes() {
            if (e.hostAttributes) for (let t in e.hostAttributes) this._ensureAttribute(t, e.hostAttributes[t]);
            super._ensureAttributes();
        }
        ready() {
            super.ready(), e.ready && e.ready.call(this);
        }
        attached() {
            super.attached(), e.attached && e.attached.call(this);
        }
        detached() {
            super.detached(), e.detached && e.detached.call(this);
        }
        attributeChanged(t, i, n) {
            super.attributeChanged(t, i, n), e.attributeChanged && e.attributeChanged.call(this, t, i, n);
        }
    }
    i.generatedFrom = e;
    for (let t in e) if (!(t in metaProps)) {
        let n = Object.getOwnPropertyDescriptor(e, t);
        n && Object.defineProperty(i.prototype, t, n);
    }
    return i;
}

const Class = function(e, t) {
    e || console.warn("Polymer's Class function requires `info` argument");
    const i = e.behaviors ? mixinBehaviors(e.behaviors, HTMLElement) : LegacyElementMixin(HTMLElement), n = GenerateClassFromInfo(e, t ? t(i) : i);
    return n.is = e.is, n;
};

var _class = {
    mixinBehaviors: mixinBehaviors,
    Class: Class
};

const Polymer = function(e) {
    let t;
    return t = "function" == typeof e ? e : Polymer.Class(e), customElements.define(t.is, t), 
    t;
};

Polymer.Class = Class;

var polymerFn = {
    Polymer: Polymer
};

function mutablePropertyChange(e, t, i, n, s) {
    let r;
    s && (r = "object" == typeof i && null !== i) && (n = e.__dataTemp[t]);
    let o = n !== i && (n == n || i == i);
    return r && o && (e.__dataTemp[t] = i), o;
}

const MutableData = dedupingMixin(e => {
    return class extends e {
        _shouldPropertyChange(e, t, i) {
            return mutablePropertyChange(this, e, t, i, !0);
        }
    };
}), OptionalMutableData = dedupingMixin(e => {
    return class extends e {
        static get properties() {
            return {
                mutableData: Boolean
            };
        }
        _shouldPropertyChange(e, t, i) {
            return mutablePropertyChange(this, e, t, i, this.mutableData);
        }
    };
});

MutableData._mutablePropertyChange = mutablePropertyChange;

var mutableData = {
    MutableData: MutableData,
    OptionalMutableData: OptionalMutableData
};

let newInstance = null;

function HTMLTemplateElementExtension() {
    return newInstance;
}

HTMLTemplateElementExtension.prototype = Object.create(HTMLTemplateElement.prototype, {
    constructor: {
        value: HTMLTemplateElementExtension,
        writable: !0
    }
});

const DataTemplate = PropertyEffects(HTMLTemplateElementExtension), MutableDataTemplate = MutableData(DataTemplate);

function upgradeTemplate(e, t) {
    newInstance = e, Object.setPrototypeOf(e, t.prototype), new t(), newInstance = null;
}

const base = PropertyEffects(class {});

class TemplateInstanceBase extends base {
    constructor(e) {
        super(), this._configureProperties(e), this.root = this._stampTemplate(this.__dataHost);
        let t = this.children = [];
        for (let e = this.root.firstChild; e; e = e.nextSibling) t.push(e), e.__templatizeInstance = this;
        this.__templatizeOwner && this.__templatizeOwner.__hideTemplateChildren__ && this._showHideChildren(!0);
        let i = this.__templatizeOptions;
        (e && i.instanceProps || !i.instanceProps) && this._enableProperties();
    }
    _configureProperties(e) {
        if (this.__templatizeOptions.forwardHostProp) for (let e in this.__hostProps) this._setPendingProperty(e, this.__dataHost["_host_" + e]);
        for (let t in e) this._setPendingProperty(t, e[t]);
    }
    forwardHostProp(e, t) {
        this._setPendingPropertyOrPath(e, t, !1, !0) && this.__dataHost._enqueueClient(this);
    }
    _addEventListenerToNode(e, t, i) {
        if (this._methodHost && this.__templatizeOptions.parentModel) this._methodHost._addEventListenerToNode(e, t, e => {
            e.model = this, i(e);
        }); else {
            let n = this.__dataHost.__dataHost;
            n && n._addEventListenerToNode(e, t, i);
        }
    }
    _showHideChildren(e) {
        let t = this.children;
        for (let i = 0; i < t.length; i++) {
            let n = t[i];
            if (Boolean(e) != Boolean(n.__hideTemplateChildren__)) if (n.nodeType === Node.TEXT_NODE) e ? (n.__polymerTextContent__ = n.textContent, 
            n.textContent = "") : n.textContent = n.__polymerTextContent__; else if ("slot" === n.localName) if (e) n.__polymerReplaced__ = document.createComment("hidden-slot"), 
            n.parentNode.replaceChild(n.__polymerReplaced__, n); else {
                const e = n.__polymerReplaced__;
                e && e.parentNode.replaceChild(n, e);
            } else n.style && (e ? (n.__polymerDisplay__ = n.style.display, n.style.display = "none") : n.style.display = n.__polymerDisplay__);
            n.__hideTemplateChildren__ = e, n._showHideChildren && n._showHideChildren(e);
        }
    }
    _setUnmanagedPropertyToNode(e, t, i) {
        e.__hideTemplateChildren__ && e.nodeType == Node.TEXT_NODE && "textContent" == t ? e.__polymerTextContent__ = i : super._setUnmanagedPropertyToNode(e, t, i);
    }
    get parentModel() {
        let e = this.__parentModel;
        if (!e) {
            let t;
            e = this;
            do {
                e = e.__dataHost.__dataHost;
            } while ((t = e.__templatizeOptions) && !t.parentModel);
            this.__parentModel = e;
        }
        return e;
    }
    dispatchEvent(e) {
        return !0;
    }
}

TemplateInstanceBase.prototype.__dataHost, TemplateInstanceBase.prototype.__templatizeOptions, 
TemplateInstanceBase.prototype._methodHost, TemplateInstanceBase.prototype.__templatizeOwner, 
TemplateInstanceBase.prototype.__hostProps;

const MutableTemplateInstanceBase = MutableData(TemplateInstanceBase);

function findMethodHost(e) {
    let t = e.__dataHost;
    return t && t._methodHost || t;
}

function createTemplatizerClass(e, t, i) {
    let n = i.mutableData ? MutableTemplateInstanceBase : TemplateInstanceBase, s = class extends n {};
    return s.prototype.__templatizeOptions = i, s.prototype._bindTemplate(e), addNotifyEffects(s, e, t, i), 
    s;
}

function addPropagateEffects(e, t, i) {
    let n = i.forwardHostProp;
    if (n) {
        let s = t.templatizeTemplateClass;
        if (!s) {
            let e = i.mutableData ? MutableDataTemplate : DataTemplate;
            s = t.templatizeTemplateClass = class extends e {};
            let r = t.hostProps;
            for (let e in r) s.prototype._addPropertyEffect("_host_" + e, s.prototype.PROPERTY_EFFECT_TYPES.PROPAGATE, {
                fn: createForwardHostPropEffect(e, n)
            }), s.prototype._createNotifyingProperty("_host_" + e);
        }
        upgradeTemplate(e, s), e.__dataProto && Object.assign(e.__data, e.__dataProto), 
        e.__dataTemp = {}, e.__dataPending = null, e.__dataOld = null, e._enableProperties();
    }
}

function createForwardHostPropEffect(e, t) {
    return function(e, i, n) {
        t.call(e.__templatizeOwner, i.substring("_host_".length), n[i]);
    };
}

function addNotifyEffects(e, t, i, n) {
    let s = i.hostProps || {};
    for (let t in n.instanceProps) {
        delete s[t];
        let i = n.notifyInstanceProp;
        i && e.prototype._addPropertyEffect(t, e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY, {
            fn: createNotifyInstancePropEffect(t, i)
        });
    }
    if (n.forwardHostProp && t.__dataHost) for (let t in s) e.prototype._addPropertyEffect(t, e.prototype.PROPERTY_EFFECT_TYPES.NOTIFY, {
        fn: createNotifyHostPropEffect()
    });
}

function createNotifyInstancePropEffect(e, t) {
    return function(e, i, n) {
        t.call(e.__templatizeOwner, e, i, n[i]);
    };
}

function createNotifyHostPropEffect() {
    return function(e, t, i) {
        e.__dataHost._setPendingPropertyOrPath("_host_" + t, i[t], !0, !0);
    };
}

function templatize(e, t, i) {
    if (strictTemplatePolicy && !findMethodHost(e)) throw new Error("strictTemplatePolicy: template owner not trusted");
    if (i = i || {}, e.__templatizeOwner) throw new Error("A <template> can only be templatized once");
    e.__templatizeOwner = t;
    let n = (t ? t.constructor : TemplateInstanceBase)._parseTemplate(e), s = n.templatizeInstanceClass;
    s || (s = createTemplatizerClass(e, n, i), n.templatizeInstanceClass = s), addPropagateEffects(e, n, i);
    let r = class extends s {};
    return r.prototype._methodHost = findMethodHost(e), r.prototype.__dataHost = e, 
    r.prototype.__templatizeOwner = t, r.prototype.__hostProps = n.hostProps, r = r;
}

function modelForElement(e, t) {
    let i;
    for (;t; ) if (i = t.__templatizeInstance) {
        if (i.__dataHost == e) return i;
        t = i.__dataHost;
    } else t = t.parentNode;
    return null;
}

var templatize$1 = {
    templatize: templatize,
    modelForElement: modelForElement,
    TemplateInstanceBase: TemplateInstanceBase
};

let TemplatizerUser;

const Templatizer = {
    templatize(e, t) {
        this._templatizerTemplate = e, this.ctor = templatize(e, this, {
            mutableData: Boolean(t),
            parentModel: this._parentModel,
            instanceProps: this._instanceProps,
            forwardHostProp: this._forwardHostPropV2,
            notifyInstanceProp: this._notifyInstancePropV2
        });
    },
    stamp(e) {
        return new this.ctor(e);
    },
    modelForElement(e) {
        return modelForElement(this._templatizerTemplate, e);
    }
};

var templatizerBehavior = {
    Templatizer: Templatizer
};

const domBindBase = GestureEventListeners(OptionalMutableData(PropertyEffects(HTMLElement)));

class DomBind extends domBindBase {
    static get observedAttributes() {
        return [ "mutable-data" ];
    }
    constructor() {
        if (super(), strictTemplatePolicy) throw new Error("strictTemplatePolicy: dom-bind not allowed");
        this.root = null, this.$ = null, this.__children = null;
    }
    attributeChangedCallback() {
        this.mutableData = !0;
    }
    connectedCallback() {
        this.style.display = "none", this.render();
    }
    disconnectedCallback() {
        this.__removeChildren();
    }
    __insertChildren() {
        this.parentNode.insertBefore(this.root, this);
    }
    __removeChildren() {
        if (this.__children) for (let e = 0; e < this.__children.length; e++) this.root.appendChild(this.__children[e]);
    }
    render() {
        let e;
        if (!this.__children) {
            if (!(e = e || this.querySelector("template"))) {
                let t = new MutationObserver(() => {
                    if (!(e = this.querySelector("template"))) throw new Error("dom-bind requires a <template> child");
                    t.disconnect(), this.render();
                });
                return void t.observe(this, {
                    childList: !0
                });
            }
            this.root = this._stampTemplate(e), this.$ = this.root.$, this.__children = [];
            for (let e = this.root.firstChild; e; e = e.nextSibling) this.__children[this.__children.length] = e;
            this._enableProperties();
        }
        this.__insertChildren(), this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        }));
    }
}

customElements.define("dom-bind", DomBind);

var domBind = {
    DomBind: DomBind
};

class LiteralString {
    constructor(e) {
        this.value = e.toString();
    }
    toString() {
        return this.value;
    }
}

function literalValue(e) {
    if (e instanceof LiteralString) return e.value;
    throw new Error(`non-literal value passed to Polymer's htmlLiteral function: ${e}`);
}

function htmlValue(e) {
    if (e instanceof HTMLTemplateElement) return e.innerHTML;
    if (e instanceof LiteralString) return literalValue(e);
    throw new Error(`non-template value passed to Polymer's html function: ${e}`);
}

const html = function(e, ...t) {
    const i = document.createElement("template");
    return i.innerHTML = t.reduce((t, i, n) => t + htmlValue(i) + e[n + 1], e[0]), i;
}, htmlLiteral = function(e, ...t) {
    return new LiteralString(t.reduce((t, i, n) => t + literalValue(i) + e[n + 1], e[0]));
};

var htmlTag = {
    html: html,
    htmlLiteral: htmlLiteral
};

const PolymerElement = ElementMixin(HTMLElement);

var polymerElement = {
    version: version,
    PolymerElement: PolymerElement,
    html: html
};

const domRepeatBase = OptionalMutableData(PolymerElement);

class DomRepeat extends domRepeatBase {
    static get is() {
        return "dom-repeat";
    }
    static get template() {
        return null;
    }
    static get properties() {
        return {
            items: {
                type: Array
            },
            as: {
                type: String,
                value: "item"
            },
            indexAs: {
                type: String,
                value: "index"
            },
            itemsIndexAs: {
                type: String,
                value: "itemsIndex"
            },
            sort: {
                type: Function,
                observer: "__sortChanged"
            },
            filter: {
                type: Function,
                observer: "__filterChanged"
            },
            observe: {
                type: String,
                observer: "__observeChanged"
            },
            delay: Number,
            renderedItemCount: {
                type: Number,
                notify: !0,
                readOnly: !0
            },
            initialCount: {
                type: Number,
                observer: "__initializeChunking"
            },
            targetFramerate: {
                type: Number,
                value: 20
            },
            _targetFrameTime: {
                type: Number,
                computed: "__computeFrameTime(targetFramerate)"
            }
        };
    }
    static get observers() {
        return [ "__itemsChanged(items.*)" ];
    }
    constructor() {
        super(), this.__instances = [], this.__limit = 1 / 0, this.__pool = [], this.__renderDebouncer = null, 
        this.__itemsIdxToInstIdx = {}, this.__chunkCount = null, this.__lastChunkTime = null, 
        this.__sortFn = null, this.__filterFn = null, this.__observePaths = null, this.__ctor = null, 
        this.__isDetached = !0, this.template = null;
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this.__isDetached = !0;
        for (let e = 0; e < this.__instances.length; e++) this.__detachInstance(e);
    }
    connectedCallback() {
        if (super.connectedCallback(), this.style.display = "none", this.__isDetached) {
            this.__isDetached = !1;
            let e = this.parentNode;
            for (let t = 0; t < this.__instances.length; t++) this.__attachInstance(t, e);
        }
    }
    __ensureTemplatized() {
        if (!this.__ctor) {
            let e = this.template = this.querySelector("template");
            if (!e) {
                let e = new MutationObserver(() => {
                    if (!this.querySelector("template")) throw new Error("dom-repeat requires a <template> child");
                    e.disconnect(), this.__render();
                });
                return e.observe(this, {
                    childList: !0
                }), !1;
            }
            let t = {};
            t[this.as] = !0, t[this.indexAs] = !0, t[this.itemsIndexAs] = !0, this.__ctor = templatize(e, this, {
                mutableData: this.mutableData,
                parentModel: !0,
                instanceProps: t,
                forwardHostProp: function(e, t) {
                    let i = this.__instances;
                    for (let n, s = 0; s < i.length && (n = i[s]); s++) n.forwardHostProp(e, t);
                },
                notifyInstanceProp: function(e, t, i) {
                    if (matches(this.as, t)) {
                        let n = e[this.itemsIndexAs];
                        t == this.as && (this.items[n] = i);
                        let s = translate(this.as, "items." + n, t);
                        this.notifyPath(s, i);
                    }
                }
            });
        }
        return !0;
    }
    __getMethodHost() {
        return this.__dataHost._methodHost || this.__dataHost;
    }
    __functionFromPropertyValue(e) {
        if ("string" == typeof e) {
            let t = e, i = this.__getMethodHost();
            return function() {
                return i[t].apply(i, arguments);
            };
        }
        return e;
    }
    __sortChanged(e) {
        this.__sortFn = this.__functionFromPropertyValue(e), this.items && this.__debounceRender(this.__render);
    }
    __filterChanged(e) {
        this.__filterFn = this.__functionFromPropertyValue(e), this.items && this.__debounceRender(this.__render);
    }
    __computeFrameTime(e) {
        return Math.ceil(1e3 / e);
    }
    __initializeChunking() {
        this.initialCount && (this.__limit = this.initialCount, this.__chunkCount = this.initialCount, 
        this.__lastChunkTime = performance.now());
    }
    __tryRenderChunk() {
        this.items && this.__limit < this.items.length && this.__debounceRender(this.__requestRenderChunk);
    }
    __requestRenderChunk() {
        requestAnimationFrame(() => this.__renderChunk());
    }
    __renderChunk() {
        let e = performance.now(), t = this._targetFrameTime / (e - this.__lastChunkTime);
        this.__chunkCount = Math.round(this.__chunkCount * t) || 1, this.__limit += this.__chunkCount, 
        this.__lastChunkTime = e, this.__debounceRender(this.__render);
    }
    __observeChanged() {
        this.__observePaths = this.observe && this.observe.replace(".*", ".").split(" ");
    }
    __itemsChanged(e) {
        this.items && !Array.isArray(this.items) && console.warn("dom-repeat expected array for `items`, found", this.items), 
        this.__handleItemPath(e.path, e.value) || (this.__initializeChunking(), this.__debounceRender(this.__render));
    }
    __handleObservedPaths(e) {
        if (this.__sortFn || this.__filterFn) if (e) {
            if (this.__observePaths) {
                let t = this.__observePaths;
                for (let i = 0; i < t.length; i++) 0 === e.indexOf(t[i]) && this.__debounceRender(this.__render, this.delay);
            }
        } else this.__debounceRender(this.__render, this.delay);
    }
    __debounceRender(e, t = 0) {
        this.__renderDebouncer = Debouncer.debounce(this.__renderDebouncer, t > 0 ? timeOut.after(t) : microTask, e.bind(this)), 
        enqueueDebouncer(this.__renderDebouncer);
    }
    render() {
        this.__debounceRender(this.__render), flush$1();
    }
    __render() {
        this.__ensureTemplatized() && (this.__applyFullRefresh(), this.__pool.length = 0, 
        this._setRenderedItemCount(this.__instances.length), this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        })), this.__tryRenderChunk());
    }
    __applyFullRefresh() {
        let e = this.items || [], t = new Array(e.length);
        for (let i = 0; i < e.length; i++) t[i] = i;
        this.__filterFn && (t = t.filter((t, i, n) => this.__filterFn(e[t], i, n))), this.__sortFn && t.sort((t, i) => this.__sortFn(e[t], e[i]));
        const i = this.__itemsIdxToInstIdx = {};
        let n = 0;
        const s = Math.min(t.length, this.__limit);
        for (;n < s; n++) {
            let s = this.__instances[n], r = t[n], o = e[r];
            i[r] = n, s ? (s._setPendingProperty(this.as, o), s._setPendingProperty(this.indexAs, n), 
            s._setPendingProperty(this.itemsIndexAs, r), s._flushProperties()) : this.__insertInstance(o, n, r);
        }
        for (let e = this.__instances.length - 1; e >= n; e--) this.__detachAndRemoveInstance(e);
    }
    __detachInstance(e) {
        let t = this.__instances[e];
        for (let e = 0; e < t.children.length; e++) {
            let i = t.children[e];
            t.root.appendChild(i);
        }
        return t;
    }
    __attachInstance(e, t) {
        let i = this.__instances[e];
        t.insertBefore(i.root, this);
    }
    __detachAndRemoveInstance(e) {
        let t = this.__detachInstance(e);
        t && this.__pool.push(t), this.__instances.splice(e, 1);
    }
    __stampInstance(e, t, i) {
        let n = {};
        return n[this.as] = e, n[this.indexAs] = t, n[this.itemsIndexAs] = i, new this.__ctor(n);
    }
    __insertInstance(e, t, i) {
        let n = this.__pool.pop();
        n ? (n._setPendingProperty(this.as, e), n._setPendingProperty(this.indexAs, t), 
        n._setPendingProperty(this.itemsIndexAs, i), n._flushProperties()) : n = this.__stampInstance(e, t, i);
        let s = this.__instances[t + 1], r = s ? s.children[0] : this;
        return this.parentNode.insertBefore(n.root, r), this.__instances[t] = n, n;
    }
    _showHideChildren(e) {
        for (let t = 0; t < this.__instances.length; t++) this.__instances[t]._showHideChildren(e);
    }
    __handleItemPath(e, t) {
        let i = e.slice(6), n = i.indexOf("."), s = n < 0 ? i : i.substring(0, n);
        if (s == parseInt(s, 10)) {
            let e = n < 0 ? "" : i.substring(n + 1);
            this.__handleObservedPaths(e);
            let r = this.__itemsIdxToInstIdx[s], o = this.__instances[r];
            if (o) {
                let i = this.as + (e ? "." + e : "");
                o._setPendingPropertyOrPath(i, t, !1, !0), o._flushProperties();
            }
            return !0;
        }
    }
    itemForElement(e) {
        let t = this.modelForElement(e);
        return t && t[this.as];
    }
    indexForElement(e) {
        let t = this.modelForElement(e);
        return t && t[this.indexAs];
    }
    modelForElement(e) {
        return modelForElement(this.template, e);
    }
}

customElements.define(DomRepeat.is, DomRepeat);

var domRepeat = {
    DomRepeat: DomRepeat
};

class DomIf extends PolymerElement {
    static get is() {
        return "dom-if";
    }
    static get template() {
        return null;
    }
    static get properties() {
        return {
            if: {
                type: Boolean,
                observer: "__debounceRender"
            },
            restamp: {
                type: Boolean,
                observer: "__debounceRender"
            }
        };
    }
    constructor() {
        super(), this.__renderDebouncer = null, this.__invalidProps = null, this.__instance = null, 
        this._lastIf = !1, this.__ctor = null, this.__hideTemplateChildren__ = !1;
    }
    __debounceRender() {
        this.__renderDebouncer = Debouncer.debounce(this.__renderDebouncer, microTask, () => this.__render()), 
        enqueueDebouncer(this.__renderDebouncer);
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this.parentNode && (this.parentNode.nodeType != Node.DOCUMENT_FRAGMENT_NODE || this.parentNode.host) || this.__teardownInstance();
    }
    connectedCallback() {
        super.connectedCallback(), this.style.display = "none", this.if && this.__debounceRender();
    }
    render() {
        flush$1();
    }
    __render() {
        if (this.if) {
            if (!this.__ensureInstance()) return;
            this._showHideChildren();
        } else this.restamp && this.__teardownInstance();
        !this.restamp && this.__instance && this._showHideChildren(), this.if != this._lastIf && (this.dispatchEvent(new CustomEvent("dom-change", {
            bubbles: !0,
            composed: !0
        })), this._lastIf = this.if);
    }
    __ensureInstance() {
        let e = this.parentNode;
        if (e) {
            if (!this.__ctor) {
                let e = this.querySelector("template");
                if (!e) {
                    let e = new MutationObserver(() => {
                        if (!this.querySelector("template")) throw new Error("dom-if requires a <template> child");
                        e.disconnect(), this.__render();
                    });
                    return e.observe(this, {
                        childList: !0
                    }), !1;
                }
                this.__ctor = templatize(e, this, {
                    mutableData: !0,
                    forwardHostProp: function(e, t) {
                        this.__instance && (this.if ? this.__instance.forwardHostProp(e, t) : (this.__invalidProps = this.__invalidProps || Object.create(null), 
                        this.__invalidProps[root(e)] = !0));
                    }
                });
            }
            if (this.__instance) {
                this.__syncHostProperties();
                let t = this.__instance.children;
                if (t && t.length) {
                    if (this.previousSibling !== t[t.length - 1]) for (let i, n = 0; n < t.length && (i = t[n]); n++) e.insertBefore(i, this);
                }
            } else this.__instance = new this.__ctor(), e.insertBefore(this.__instance.root, this);
        }
        return !0;
    }
    __syncHostProperties() {
        let e = this.__invalidProps;
        if (e) {
            for (let t in e) this.__instance._setPendingProperty(t, this.__dataHost[t]);
            this.__invalidProps = null, this.__instance._flushProperties();
        }
    }
    __teardownInstance() {
        if (this.__instance) {
            let e = this.__instance.children;
            if (e && e.length) {
                let t = e[0].parentNode;
                if (t) for (let i, n = 0; n < e.length && (i = e[n]); n++) t.removeChild(i);
            }
            this.__instance = null, this.__invalidProps = null;
        }
    }
    _showHideChildren() {
        let e = this.__hideTemplateChildren__ || !this.if;
        this.__instance && this.__instance._showHideChildren(e);
    }
}

customElements.define(DomIf.is, DomIf);

var domIf = {
    DomIf: DomIf
};

let ArraySelectorMixin = dedupingMixin(e => {
    let t = ElementMixin(e);
    return class extends t {
        static get properties() {
            return {
                items: {
                    type: Array
                },
                multi: {
                    type: Boolean,
                    value: !1
                },
                selected: {
                    type: Object,
                    notify: !0
                },
                selectedItem: {
                    type: Object,
                    notify: !0
                },
                toggle: {
                    type: Boolean,
                    value: !1
                }
            };
        }
        static get observers() {
            return [ "__updateSelection(multi, items.*)" ];
        }
        constructor() {
            super(), this.__lastItems = null, this.__lastMulti = null, this.__selectedMap = null;
        }
        __updateSelection(e, t) {
            let i = t.path;
            if ("items" == i) {
                let i = t.base || [], n = this.__lastItems;
                if (e !== this.__lastMulti && this.clearSelection(), n) {
                    let e = calculateSplices(i, n);
                    this.__applySplices(e);
                }
                this.__lastItems = i, this.__lastMulti = e;
            } else if ("items.splices" == t.path) this.__applySplices(t.value.indexSplices); else {
                let e = i.slice("items.".length), t = parseInt(e, 10);
                e.indexOf(".") < 0 && e == t && this.__deselectChangedIdx(t);
            }
        }
        __applySplices(e) {
            let t = this.__selectedMap;
            for (let i = 0; i < e.length; i++) {
                let n = e[i];
                t.forEach((e, i) => {
                    e < n.index || (e >= n.index + n.removed.length ? t.set(i, e + n.addedCount - n.removed.length) : t.set(i, -1));
                });
                for (let e = 0; e < n.addedCount; e++) {
                    let i = n.index + e;
                    t.has(this.items[i]) && t.set(this.items[i], i);
                }
            }
            this.__updateLinks();
            let i = 0;
            t.forEach((e, n) => {
                e < 0 ? (this.multi ? this.splice("selected", i, 1) : this.selected = this.selectedItem = null, 
                t.delete(n)) : i++;
            });
        }
        __updateLinks() {
            if (this.__dataLinkedPaths = {}, this.multi) {
                let e = 0;
                this.__selectedMap.forEach(t => {
                    t >= 0 && this.linkPaths("items." + t, "selected." + e++);
                });
            } else this.__selectedMap.forEach(e => {
                this.linkPaths("selected", "items." + e), this.linkPaths("selectedItem", "items." + e);
            });
        }
        clearSelection() {
            this.__dataLinkedPaths = {}, this.__selectedMap = new Map(), this.selected = this.multi ? [] : null, 
            this.selectedItem = null;
        }
        isSelected(e) {
            return this.__selectedMap.has(e);
        }
        isIndexSelected(e) {
            return this.isSelected(this.items[e]);
        }
        __deselectChangedIdx(e) {
            let t = this.__selectedIndexForItemIndex(e);
            if (t >= 0) {
                let e = 0;
                this.__selectedMap.forEach((i, n) => {
                    t == e++ && this.deselect(n);
                });
            }
        }
        __selectedIndexForItemIndex(e) {
            let t = this.__dataLinkedPaths["items." + e];
            if (t) return parseInt(t.slice("selected.".length), 10);
        }
        deselect(e) {
            let t = this.__selectedMap.get(e);
            if (t >= 0) {
                let i;
                this.__selectedMap.delete(e), this.multi && (i = this.__selectedIndexForItemIndex(t)), 
                this.__updateLinks(), this.multi ? this.splice("selected", i, 1) : this.selected = this.selectedItem = null;
            }
        }
        deselectIndex(e) {
            this.deselect(this.items[e]);
        }
        select(e) {
            this.selectIndex(this.items.indexOf(e));
        }
        selectIndex(e) {
            let t = this.items[e];
            this.isSelected(t) ? this.toggle && this.deselectIndex(e) : (this.multi || this.__selectedMap.clear(), 
            this.__selectedMap.set(t, e), this.__updateLinks(), this.multi ? this.push("selected", t) : this.selected = this.selectedItem = t);
        }
    };
}), baseArraySelector = ArraySelectorMixin(PolymerElement);

class ArraySelector extends baseArraySelector {
    static get is() {
        return "array-selector";
    }
}

customElements.define(ArraySelector.is, ArraySelector);

var arraySelector = {
    ArraySelectorMixin: ArraySelectorMixin,
    ArraySelector: ArraySelector
};

/**
   @license
   Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   Code distributed by Google as part of the polymer project is also
   subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   */ const customStyleInterface$1 = new CustomStyleInterface();

window.ShadyCSS || (window.ShadyCSS = {
    prepareTemplate(e, t, i) {},
    prepareTemplateDom(e, t) {},
    prepareTemplateStyles(e, t, i) {},
    styleSubtree(e, t) {
        customStyleInterface$1.processStyles(), updateNativeProperties(e, t);
    },
    styleElement(e) {
        customStyleInterface$1.processStyles();
    },
    styleDocument(e) {
        customStyleInterface$1.processStyles(), updateNativeProperties(document.body, e);
    },
    getComputedStyleValue: (e, t) => getComputedStyleValue(e, t),
    flushCustomStyles() {},
    nativeCss: nativeCssVariables,
    nativeShadow: nativeShadow,
    cssBuild: cssBuild,
    disableRuntime: disableRuntime
}), window.ShadyCSS.CustomStyleInterface = customStyleInterface$1;

const attr = "include", CustomStyleInterface$1 = window.ShadyCSS.CustomStyleInterface;

class CustomStyle extends HTMLElement {
    constructor() {
        super(), this._style = null, CustomStyleInterface$1.addCustomStyle(this);
    }
    getStyle() {
        if (this._style) return this._style;
        const e = this.querySelector("style");
        if (!e) return null;
        this._style = e;
        const t = e.getAttribute(attr);
        return t && (e.removeAttribute(attr), e.textContent = cssFromModules(t) + e.textContent), 
        this.ownerDocument !== window.document && window.document.head.appendChild(this), 
        this._style;
    }
}

window.customElements.define("custom-style", CustomStyle);

var customStyle = {
    CustomStyle: CustomStyle
};

let mutablePropertyChange$1;

mutablePropertyChange$1 = MutableData._mutablePropertyChange;

const MutableDataBehavior = {
    _shouldPropertyChange(e, t, i) {
        return mutablePropertyChange$1(this, e, t, i, !0);
    }
}, OptionalMutableDataBehavior = {
    properties: {
        mutableData: Boolean
    },
    _shouldPropertyChange(e, t, i) {
        return mutablePropertyChange$1(this, e, t, i, this.mutableData);
    }
};

var mutableDataBehavior = {
    MutableDataBehavior: MutableDataBehavior,
    OptionalMutableDataBehavior: OptionalMutableDataBehavior
};

const Base = LegacyElementMixin(HTMLElement).prototype;

var polymerLegacy = {
    Base: Base,
    Polymer: Polymer,
    html: html
};

const template = html`
/* Most common used flex styles*/
<dom-module id="iron-flex">
  <template>
    <style>
      .layout.horizontal,
      .layout.vertical {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.inline {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      }

      .layout.horizontal {
        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      }

      .layout.vertical {
        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      }

      .layout.wrap {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      }

      .layout.no-wrap {
        -ms-flex-wrap: nowrap;
        -webkit-flex-wrap: nowrap;
        flex-wrap: nowrap;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .flex {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-auto {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      }

      .flex-none {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      }
    </style>
  </template>
</dom-module>
/* Basic flexbox reverse styles */
<dom-module id="iron-flex-reverse">
  <template>
    <style>
      .layout.horizontal-reverse,
      .layout.vertical-reverse {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.horizontal-reverse {
        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      }

      .layout.vertical-reverse {
        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      }

      .layout.wrap-reverse {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      }
    </style>
  </template>
</dom-module>
/* Flexbox alignment */
<dom-module id="iron-flex-alignment">
  <template>
    <style>
      /**
       * Alignment in cross axis.
       */
      .layout.start {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.end {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      }

      .layout.baseline {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      }

      /**
       * Alignment in main axis.
       */
      .layout.start-justified {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .layout.end-justified {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      }

      .layout.around-justified {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      }

      .layout.justified {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      }

      /**
       * Self alignment.
       */
      .self-start {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      }

      .self-center {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      }

      .self-end {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      }

      .self-stretch {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      }

      .self-baseline {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      }

      /**
       * multi-line alignment in main axis.
       */
      .layout.start-aligned {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      }

      .layout.end-aligned {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      }

      .layout.center-aligned {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      }

      .layout.between-aligned {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      }

      .layout.around-aligned {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      }
    </style>
  </template>
</dom-module>
/* Non-flexbox positioning helper styles */
<dom-module id="iron-flex-factors">
  <template>
    <style>
      .flex,
      .flex-1 {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-2 {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      }

      .flex-3 {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      }

      .flex-4 {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      }

      .flex-5 {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      }

      .flex-6 {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      }

      .flex-7 {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      }

      .flex-8 {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      }

      .flex-9 {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      }

      .flex-10 {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      }

      .flex-11 {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      }

      .flex-12 {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      }
    </style>
  </template>
</dom-module>
<dom-module id="iron-positioning">
  <template>
    <style>
      .block {
        display: block;
      }

      [hidden] {
        display: none !important;
      }

      .invisible {
        visibility: hidden !important;
      }

      .relative {
        position: relative;
      }

      .fit {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      }

      body.fullbleed {
        margin: 0;
        height: 100vh;
      }

      .scroll {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      }

      /* fixed position */
      .fixed-bottom,
      .fixed-left,
      .fixed-right,
      .fixed-top {
        position: fixed;
      }

      .fixed-top {
        top: 0;
        left: 0;
        right: 0;
      }

      .fixed-right {
        top: 0;
        right: 0;
        bottom: 0;
      }

      .fixed-bottom {
        right: 0;
        bottom: 0;
        left: 0;
      }

      .fixed-left {
        top: 0;
        bottom: 0;
        left: 0;
      }
    </style>
  </template>
</dom-module>
`;

template.setAttribute("style", "display: none;"), document.head.appendChild(template.content), 
Polymer({
    _template: html`
    <style>
      :host {
        display: inline-block;
        overflow: hidden;
        position: relative;
      }

      #baseURIAnchor {
        display: none;
      }

      #sizedImgDiv {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        display: none;
      }

      #img {
        display: block;
        width: var(--iron-image-width, auto);
        height: var(--iron-image-height, auto);
      }

      :host([sizing]) #sizedImgDiv {
        display: block;
      }

      :host([sizing]) #img {
        display: none;
      }

      #placeholder {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        background-color: inherit;
        opacity: 1;

        @apply --iron-image-placeholder;
      }

      #placeholder.faded-out {
        transition: opacity 0.5s linear;
        opacity: 0;
      }
    </style>

    <a id="baseURIAnchor" href="#"></a>
    <div id="sizedImgDiv" role="img" hidden\$="[[_computeImgDivHidden(sizing)]]" aria-hidden\$="[[_computeImgDivARIAHidden(alt)]]" aria-label\$="[[_computeImgDivARIALabel(alt, src)]]"></div>
    <img id="img" alt\$="[[alt]]" hidden\$="[[_computeImgHidden(sizing)]]" crossorigin\$="[[crossorigin]]" on-load="_imgOnLoad" on-error="_imgOnError">
    <div id="placeholder" hidden\$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]" class\$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>
`,
    is: "iron-image",
    properties: {
        src: {
            type: String,
            value: ""
        },
        alt: {
            type: String,
            value: null
        },
        crossorigin: {
            type: String,
            value: null
        },
        preventLoad: {
            type: Boolean,
            value: !1
        },
        sizing: {
            type: String,
            value: null,
            reflectToAttribute: !0
        },
        position: {
            type: String,
            value: "center"
        },
        preload: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: String,
            value: null,
            observer: "_placeholderChanged"
        },
        fade: {
            type: Boolean,
            value: !1
        },
        loaded: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        loading: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        error: {
            notify: !0,
            readOnly: !0,
            type: Boolean,
            value: !1
        },
        width: {
            observer: "_widthChanged",
            type: Number,
            value: null
        },
        height: {
            observer: "_heightChanged",
            type: Number,
            value: null
        }
    },
    observers: [ "_transformChanged(sizing, position)", "_loadStateObserver(src, preventLoad)" ],
    created: function() {
        this._resolvedSrc = "";
    },
    _imgOnLoad: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this._setLoading(!1), this._setLoaded(!0), 
        this._setError(!1));
    },
    _imgOnError: function() {
        this.$.img.src === this._resolveSrc(this.src) && (this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", this._setLoading(!1), this._setLoaded(!1), 
        this._setError(!0));
    },
    _computePlaceholderHidden: function() {
        return !this.preload || !this.fade && !this.loading && this.loaded;
    },
    _computePlaceholderClassName: function() {
        return this.preload && this.fade && !this.loading && this.loaded ? "faded-out" : "";
    },
    _computeImgDivHidden: function() {
        return !this.sizing;
    },
    _computeImgDivARIAHidden: function() {
        return "" === this.alt ? "true" : void 0;
    },
    _computeImgDivARIALabel: function() {
        return null !== this.alt ? this.alt : "" === this.src ? "" : this._resolveSrc(this.src).replace(/[?|#].*/g, "").split("/").pop();
    },
    _computeImgHidden: function() {
        return !!this.sizing;
    },
    _widthChanged: function() {
        this.style.width = isNaN(this.width) ? this.width : this.width + "px";
    },
    _heightChanged: function() {
        this.style.height = isNaN(this.height) ? this.height : this.height + "px";
    },
    _loadStateObserver: function(e, t) {
        var i = this._resolveSrc(e);
        i !== this._resolvedSrc && (this._resolvedSrc = "", this.$.img.removeAttribute("src"), 
        this.$.sizedImgDiv.style.backgroundImage = "", "" === e || t ? (this._setLoading(!1), 
        this._setLoaded(!1), this._setError(!1)) : (this._resolvedSrc = i, this.$.img.src = this._resolvedSrc, 
        this.$.sizedImgDiv.style.backgroundImage = 'url("' + this._resolvedSrc + '")', this._setLoading(!0), 
        this._setLoaded(!1), this._setError(!1)));
    },
    _placeholderChanged: function() {
        this.$.placeholder.style.backgroundImage = this.placeholder ? 'url("' + this.placeholder + '")' : "";
    },
    _transformChanged: function() {
        var e = this.$.sizedImgDiv.style, t = this.$.placeholder.style;
        e.backgroundSize = t.backgroundSize = this.sizing, e.backgroundPosition = t.backgroundPosition = this.sizing ? this.position : "", 
        e.backgroundRepeat = t.backgroundRepeat = this.sizing ? "no-repeat" : "";
    },
    _resolveSrc: function(e) {
        var t = resolveUrl(e, this.$.baseURIAnchor.href);
        return "/" === t[0] && (t = (location.origin || location.protocol + "//" + location.host) + t), 
        t;
    }
});

var ORPHANS = new Set();

const IronResizableBehavior = {
    properties: {
        _parentResizable: {
            type: Object,
            observer: "_parentResizableChanged"
        },
        _notifyingDescendant: {
            type: Boolean,
            value: !1
        }
    },
    listeners: {
        "iron-request-resize-notifications": "_onIronRequestResizeNotifications"
    },
    created: function() {
        this._interestedResizables = [], this._boundNotifyResize = this.notifyResize.bind(this), 
        this._boundOnDescendantIronResize = this._onDescendantIronResize.bind(this);
    },
    attached: function() {
        this._requestResizeNotifications();
    },
    detached: function() {
        this._parentResizable ? this._parentResizable.stopResizeNotificationsFor(this) : (ORPHANS.delete(this), 
        window.removeEventListener("resize", this._boundNotifyResize)), this._parentResizable = null;
    },
    notifyResize: function() {
        this.isAttached && (this._interestedResizables.forEach(function(e) {
            this.resizerShouldNotify(e) && this._notifyDescendant(e);
        }, this), this._fireResize());
    },
    assignParentResizable: function(e) {
        this._parentResizable && this._parentResizable.stopResizeNotificationsFor(this), 
        this._parentResizable = e, e && -1 === e._interestedResizables.indexOf(this) && (e._interestedResizables.push(this), 
        e._subscribeIronResize(this));
    },
    stopResizeNotificationsFor: function(e) {
        var t = this._interestedResizables.indexOf(e);
        t > -1 && (this._interestedResizables.splice(t, 1), this._unsubscribeIronResize(e));
    },
    _subscribeIronResize: function(e) {
        e.addEventListener("iron-resize", this._boundOnDescendantIronResize);
    },
    _unsubscribeIronResize: function(e) {
        e.removeEventListener("iron-resize", this._boundOnDescendantIronResize);
    },
    resizerShouldNotify: function(e) {
        return !0;
    },
    _onDescendantIronResize: function(e) {
        this._notifyingDescendant ? e.stopPropagation() : useShadow || this._fireResize();
    },
    _fireResize: function() {
        this.fire("iron-resize", null, {
            node: this,
            bubbles: !1
        });
    },
    _onIronRequestResizeNotifications: function(e) {
        var t = dom(e).rootTarget;
        t !== this && (t.assignParentResizable(this), this._notifyDescendant(t), e.stopPropagation());
    },
    _parentResizableChanged: function(e) {
        e && window.removeEventListener("resize", this._boundNotifyResize);
    },
    _notifyDescendant: function(e) {
        this.isAttached && (this._notifyingDescendant = !0, e.notifyResize(), this._notifyingDescendant = !1);
    },
    _requestResizeNotifications: function() {
        if (this.isAttached) if ("loading" === document.readyState) {
            var e = this._requestResizeNotifications.bind(this);
            document.addEventListener("readystatechange", function t() {
                document.removeEventListener("readystatechange", t), e();
            });
        } else this._findParent(), this._parentResizable ? this._parentResizable._interestedResizables.forEach(function(e) {
            e !== this && e._findParent();
        }, this) : (ORPHANS.forEach(function(e) {
            e !== this && e._findParent();
        }, this), window.addEventListener("resize", this._boundNotifyResize), this.notifyResize());
    },
    _findParent: function() {
        this.assignParentResizable(null), this.fire("iron-request-resize-notifications", null, {
            node: this,
            bubbles: !0,
            cancelable: !0
        }), this._parentResizable ? ORPHANS.delete(this) : ORPHANS.add(this);
    }
};

var ironResizableBehavior = {
    IronResizableBehavior: IronResizableBehavior
};

class IronSelection {
    constructor(e) {
        this.selection = [], this.selectCallback = e;
    }
    get() {
        return this.multi ? this.selection.slice() : this.selection[0];
    }
    clear(e) {
        this.selection.slice().forEach(function(t) {
            (!e || e.indexOf(t) < 0) && this.setItemSelected(t, !1);
        }, this);
    }
    isSelected(e) {
        return this.selection.indexOf(e) >= 0;
    }
    setItemSelected(e, t) {
        if (null != e && t !== this.isSelected(e)) {
            if (t) this.selection.push(e); else {
                var i = this.selection.indexOf(e);
                i >= 0 && this.selection.splice(i, 1);
            }
            this.selectCallback && this.selectCallback(e, t);
        }
    }
    select(e) {
        this.multi ? this.toggle(e) : this.get() !== e && (this.setItemSelected(this.get(), !1), 
        this.setItemSelected(e, !0));
    }
    toggle(e) {
        this.setItemSelected(e, !this.isSelected(e));
    }
}

var ironSelection = {
    IronSelection: IronSelection
};

const IronSelectableBehavior = {
    properties: {
        attrForSelected: {
            type: String,
            value: null
        },
        selected: {
            type: String,
            notify: !0
        },
        selectedItem: {
            type: Object,
            readOnly: !0,
            notify: !0
        },
        activateEvent: {
            type: String,
            value: "tap",
            observer: "_activateEventChanged"
        },
        selectable: String,
        selectedClass: {
            type: String,
            value: "iron-selected"
        },
        selectedAttribute: {
            type: String,
            value: null
        },
        fallbackSelection: {
            type: String,
            value: null
        },
        items: {
            type: Array,
            readOnly: !0,
            notify: !0,
            value: function() {
                return [];
            }
        },
        _excludedLocalNames: {
            type: Object,
            value: function() {
                return {
                    template: 1,
                    "dom-bind": 1,
                    "dom-if": 1,
                    "dom-repeat": 1
                };
            }
        }
    },
    observers: [ "_updateAttrForSelected(attrForSelected)", "_updateSelected(selected)", "_checkFallback(fallbackSelection)" ],
    created: function() {
        this._bindFilterItem = this._filterItem.bind(this), this._selection = new IronSelection(this._applySelection.bind(this));
    },
    attached: function() {
        this._observer = this._observeItems(this), this._addListener(this.activateEvent);
    },
    detached: function() {
        this._observer && dom(this).unobserveNodes(this._observer), this._removeListener(this.activateEvent);
    },
    indexOf: function(e) {
        return this.items ? this.items.indexOf(e) : -1;
    },
    select: function(e) {
        this.selected = e;
    },
    selectPrevious: function() {
        var e = this.items.length, t = e - 1;
        void 0 !== this.selected && (t = (Number(this._valueToIndex(this.selected)) - 1 + e) % e), 
        this.selected = this._indexToValue(t);
    },
    selectNext: function() {
        var e = 0;
        void 0 !== this.selected && (e = (Number(this._valueToIndex(this.selected)) + 1) % this.items.length), 
        this.selected = this._indexToValue(e);
    },
    selectIndex: function(e) {
        this.select(this._indexToValue(e));
    },
    forceSynchronousItemUpdate: function() {
        this._observer && "function" == typeof this._observer.flush ? this._observer.flush() : this._updateItems();
    },
    get _shouldUpdateSelection() {
        return null != this.selected;
    },
    _checkFallback: function() {
        this._updateSelected();
    },
    _addListener: function(e) {
        this.listen(this, e, "_activateHandler");
    },
    _removeListener: function(e) {
        this.unlisten(this, e, "_activateHandler");
    },
    _activateEventChanged: function(e, t) {
        this._removeListener(t), this._addListener(e);
    },
    _updateItems: function() {
        var e = dom(this).queryDistributedElements(this.selectable || "*");
        e = Array.prototype.filter.call(e, this._bindFilterItem), this._setItems(e);
    },
    _updateAttrForSelected: function() {
        this.selectedItem && (this.selected = this._valueForItem(this.selectedItem));
    },
    _updateSelected: function() {
        this._selectSelected(this.selected);
    },
    _selectSelected: function(e) {
        if (this.items) {
            var t = this._valueToItem(this.selected);
            t ? this._selection.select(t) : this._selection.clear(), this.fallbackSelection && this.items.length && void 0 === this._selection.get() && (this.selected = this.fallbackSelection);
        }
    },
    _filterItem: function(e) {
        return !this._excludedLocalNames[e.localName];
    },
    _valueToItem: function(e) {
        return null == e ? null : this.items[this._valueToIndex(e)];
    },
    _valueToIndex: function(e) {
        if (!this.attrForSelected) return Number(e);
        for (var t, i = 0; t = this.items[i]; i++) if (this._valueForItem(t) == e) return i;
    },
    _indexToValue: function(e) {
        if (!this.attrForSelected) return e;
        var t = this.items[e];
        return t ? this._valueForItem(t) : void 0;
    },
    _valueForItem: function(e) {
        if (!e) return null;
        if (!this.attrForSelected) {
            var t = this.indexOf(e);
            return -1 === t ? null : t;
        }
        var i = e[dashToCamelCase(this.attrForSelected)];
        return null != i ? i : e.getAttribute(this.attrForSelected);
    },
    _applySelection: function(e, t) {
        this.selectedClass && this.toggleClass(this.selectedClass, t, e), this.selectedAttribute && this.toggleAttribute(this.selectedAttribute, t, e), 
        this._selectionChange(), this.fire("iron-" + (t ? "select" : "deselect"), {
            item: e
        });
    },
    _selectionChange: function() {
        this._setSelectedItem(this._selection.get());
    },
    _observeItems: function(e) {
        return dom(e).observeNodes(function(e) {
            this._updateItems(), this._updateSelected(), this.fire("iron-items-changed", e, {
                bubbles: !1,
                cancelable: !1
            });
        });
    },
    _activateHandler: function(e) {
        for (var t = e.target, i = this.items; t && t != this; ) {
            var n = i.indexOf(t);
            if (n >= 0) {
                var s = this._indexToValue(n);
                return void this._itemActivate(s, t);
            }
            t = t.parentNode;
        }
    },
    _itemActivate: function(e, t) {
        this.fire("iron-activate", {
            selected: e,
            item: t
        }, {
            cancelable: !0
        }).defaultPrevented || this.select(e);
    }
};

var ironSelectable = {
    IronSelectableBehavior: IronSelectableBehavior
};

const NeonAnimationBehavior = {
    properties: {
        animationTiming: {
            type: Object,
            value: function() {
                return {
                    duration: 500,
                    easing: "cubic-bezier(0.4, 0, 0.2, 1)",
                    fill: "both"
                };
            }
        }
    },
    isNeonAnimation: !0,
    created: function() {
        document.body.animate || console.warn("No web animations detected. This element will not function without a web animations polyfill.");
    },
    timingFromConfig: function(e) {
        if (e.timing) for (var t in e.timing) this.animationTiming[t] = e.timing[t];
        return this.animationTiming;
    },
    setPrefixedProperty: function(e, t, i) {
        for (var n, s = {
            transform: [ "webkitTransform" ],
            transformOrigin: [ "mozTransformOrigin", "webkitTransformOrigin" ]
        }[t], r = 0; n = s[r]; r++) e.style[n] = i;
        e.style[t] = i;
    },
    complete: function(e) {}
};

var neonAnimationBehavior = {
    NeonAnimationBehavior: NeonAnimationBehavior
};

Polymer({
    is: "cascaded-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        this._animations = [];
        var t = e.nodes, i = [], n = e.nodeDelay || 50;
        e.timing = e.timing || {}, e.timing.delay = e.timing.delay || 0;
        for (var s, r, o = e.timing.delay, a = 0; r = t[a]; a++) {
            e.timing.delay += n, e.node = r;
            var l = document.createElement(e.animation);
            if (!l.isNeonAnimation) {
                console.warn(this.is + ":", e.animation, "not found!"), s = !0;
                break;
            }
            var c = l.configure(e);
            this._animations.push(l), i.push(c);
        }
        if (e.timing.delay = o, e.node = null, !s) return this._effect = new GroupEffect(i), 
        this._effect;
    },
    complete: function() {
        for (var e, t = 0; e = this._animations[t]; t++) e.complete(e.config);
    }
}), Polymer({
    is: "fade-in-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "0"
        }, {
            opacity: "1"
        } ], this.timingFromConfig(e)), this._effect;
    }
}), Polymer({
    is: "fade-out-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "1"
        }, {
            opacity: "0"
        } ], this.timingFromConfig(e)), this._effect;
    }
});

const NeonSharedElementAnimationBehaviorImpl = {
    properties: {
        sharedElements: {
            type: Object
        }
    },
    findSharedElements: function(e) {
        var t = e.fromPage, i = e.toPage;
        if (!t || !i) return console.warn(this.is + ":", t ? "toPage" : "fromPage", "is undefined!"), 
        null;
        if (!t.sharedElements || !i.sharedElements) return console.warn(this.is + ":", "sharedElements are undefined for", t.sharedElements ? i : t), 
        null;
        var n = t.sharedElements[e.id], s = i.sharedElements[e.id];
        return n && s ? (this.sharedElements = {
            from: n,
            to: s
        }, this.sharedElements) : (console.warn(this.is + ":", "sharedElement with id", e.id, "not found in", n ? i : t), 
        null);
    }
}, NeonSharedElementAnimationBehavior = [ NeonAnimationBehavior, NeonSharedElementAnimationBehaviorImpl ];

var neonSharedElementAnimationBehavior = {
    NeonSharedElementAnimationBehaviorImpl: NeonSharedElementAnimationBehaviorImpl,
    NeonSharedElementAnimationBehavior: NeonSharedElementAnimationBehavior
};

Polymer({
    is: "hero-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t = this.findSharedElements(e);
        if (t) {
            var i = t.from.getBoundingClientRect(), n = t.to.getBoundingClientRect(), s = i.left - n.left, r = i.top - n.top, o = i.width / n.width, a = i.height / n.height;
            return this._effect = new KeyframeEffect(t.to, [ {
                transform: "translate(" + s + "px," + r + "px) scale(" + o + "," + a + ")"
            }, {
                transform: "none"
            } ], this.timingFromConfig(e)), this.setPrefixedProperty(t.to, "transformOrigin", "0 0"), 
            t.to.style.zIndex = 1e4, t.from.style.visibility = "hidden", this._effect;
        }
    },
    complete: function(e) {
        var t = this.findSharedElements(e);
        if (!t) return null;
        t.to.style.zIndex = "", t.from.style.visibility = "";
    }
}), Polymer({
    is: "opaque-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            opacity: "1"
        }, {
            opacity: "1"
        } ], this.timingFromConfig(e)), t.style.opacity = "0", this._effect;
    },
    complete: function(e) {
        e.node.style.opacity = "";
    }
}), Polymer({
    is: "reverse-ripple-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t, i, n = this.findSharedElements(e);
        if (!n) return null;
        var s = n.from.getBoundingClientRect();
        if (e.gesture) t = e.gesture.x - (s.left + s.width / 2), i = e.gesture.y - (s.top + s.height / 2); else {
            var r = n.to.getBoundingClientRect();
            t = r.left + r.width / 2 - (s.left + s.width / 2), i = r.top + r.height / 2 - (s.top + s.height / 2);
        }
        var o = "translate(" + t + "px," + i + "px)", a = Math.max(s.width + 2 * Math.abs(t), s.height + 2 * Math.abs(i)), l = Math.sqrt(2 * a * a), c = "scale(" + l / s.width + "," + l / s.height + ")";
        return this._effect = new KeyframeEffect(n.from, [ {
            transform: o + " " + c
        }, {
            transform: o + " scale(0)"
        } ], this.timingFromConfig(e)), this.setPrefixedProperty(n.from, "transformOrigin", "50% 50%"), 
        n.from.style.borderRadius = "50%", this._effect;
    },
    complete: function() {
        this.sharedElements && (this.setPrefixedProperty(this.sharedElements.from, "transformOrigin", ""), 
        this.sharedElements.from.style.borderRadius = "");
    }
}), Polymer({
    is: "ripple-animation",
    behaviors: [ NeonSharedElementAnimationBehavior ],
    configure: function(e) {
        var t, i, n = this.findSharedElements(e);
        if (!n) return null;
        var s = n.to.getBoundingClientRect();
        if (e.gesture) t = e.gesture.x - (s.left + s.width / 2), i = e.gesture.y - (s.top + s.height / 2); else {
            var r = n.from.getBoundingClientRect();
            t = r.left + r.width / 2 - (s.left + s.width / 2), i = r.top + r.height / 2 - (s.top + s.height / 2);
        }
        var o = "translate(" + t + "px," + i + "px)", a = Math.max(s.width + 2 * Math.abs(t), s.height + 2 * Math.abs(i)), l = Math.sqrt(2 * a * a), c = "scale(" + l / s.width + "," + l / s.height + ")";
        return this._effect = new KeyframeEffect(n.to, [ {
            transform: o + " scale(0)"
        }, {
            transform: o + " " + c
        } ], this.timingFromConfig(e)), this.setPrefixedProperty(n.to, "transformOrigin", "50% 50%"), 
        n.to.style.borderRadius = "50%", this._effect;
    },
    complete: function() {
        this.sharedElements && (this.setPrefixedProperty(this.sharedElements.to, "transformOrigin", ""), 
        this.sharedElements.to.style.borderRadius = "");
    }
}), Polymer({
    is: "scale-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = "scale(0, 0)";
        return "x" === e.axis ? i = "scale(0, 1)" : "y" === e.axis && (i = "scale(1, 0)"), 
        this._effect = new KeyframeEffect(t, [ {
            transform: "scale(1,1)"
        }, {
            transform: i
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
}), Polymer({
    is: "scale-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = "scale(0)";
        return "x" === e.axis ? i = "scale(0, 1)" : "y" === e.axis && (i = "scale(1, 0)"), 
        this._effect = new KeyframeEffect(t, [ {
            transform: i
        }, {
            transform: "scale(1, 1)"
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
}), Polymer({
    is: "slide-down-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(0%)"
        }, {
            transform: "translateY(100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-bottom-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(100%)"
        }, {
            transform: "translateY(0)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-left-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateX(-100%)"
        }, {
            transform: "none"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-right-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateX(100%)"
        }, {
            transform: "none"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-from-top-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translateY(-100%)"
        }, {
            transform: "translateY(0%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "slide-left-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "none"
        }, {
            transform: "translateX(-100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-right-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "none"
        }, {
            transform: "translateX(100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "0 50%"), 
        this._effect;
    }
}), Polymer({
    is: "slide-up-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node;
        return this._effect = new KeyframeEffect(t, [ {
            transform: "translate(0)"
        }, {
            transform: "translateY(-100%)"
        } ], this.timingFromConfig(e)), e.transformOrigin ? this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin) : this.setPrefixedProperty(t, "transformOrigin", "50% 0"), 
        this._effect;
    }
}), Polymer({
    is: "transform-animation",
    behaviors: [ NeonAnimationBehavior ],
    configure: function(e) {
        var t = e.node, i = e.transformFrom || "none", n = e.transformTo || "none";
        return this._effect = new KeyframeEffect(t, [ {
            transform: i
        }, {
            transform: n
        } ], this.timingFromConfig(e)), e.transformOrigin && this.setPrefixedProperty(t, "transformOrigin", e.transformOrigin), 
        this._effect;
    }
});

const NeonAnimatableBehavior = {
    properties: {
        animationConfig: {
            type: Object
        },
        entryAnimation: {
            observer: "_entryAnimationChanged",
            type: String
        },
        exitAnimation: {
            observer: "_exitAnimationChanged",
            type: String
        }
    },
    _entryAnimationChanged: function() {
        this.animationConfig = this.animationConfig || {}, this.animationConfig.entry = [ {
            name: this.entryAnimation,
            node: this
        } ];
    },
    _exitAnimationChanged: function() {
        this.animationConfig = this.animationConfig || {}, this.animationConfig.exit = [ {
            name: this.exitAnimation,
            node: this
        } ];
    },
    _copyProperties: function(e, t) {
        for (var i in t) e[i] = t[i];
    },
    _cloneConfig: function(e) {
        var t = {
            isClone: !0
        };
        return this._copyProperties(t, e), t;
    },
    _getAnimationConfigRecursive: function(e, t, i) {
        var n;
        if (this.animationConfig) if (this.animationConfig.value && "function" == typeof this.animationConfig.value) this._warn(this._logf("playAnimation", "Please put 'animationConfig' inside of your components 'properties' object instead of outside of it.")); else if (n = e ? this.animationConfig[e] : this.animationConfig, 
        Array.isArray(n) || (n = [ n ]), n) for (var s, r = 0; s = n[r]; r++) if (s.animatable) s.animatable._getAnimationConfigRecursive(s.type || e, t, i); else if (s.id) {
            var o = t[s.id];
            o ? (o.isClone || (t[s.id] = this._cloneConfig(o), o = t[s.id]), this._copyProperties(o, s)) : t[s.id] = s;
        } else i.push(s);
    },
    getAnimationConfig: function(e) {
        var t = {}, i = [];
        for (var n in this._getAnimationConfigRecursive(e, t, i), t) i.push(t[n]);
        return i;
    }
};

var neonAnimatableBehavior = {
    NeonAnimatableBehavior: NeonAnimatableBehavior
};

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
      }
    </style>

    <slot></slot>
  `,
    is: "neon-animatable",
    behaviors: [ NeonAnimatableBehavior, IronResizableBehavior ]
});

const NeonAnimationRunnerBehaviorImpl = {
    _configureAnimations: function(e) {
        var t = [], i = [];
        if (e.length > 0) for (let t, n = 0; t = e[n]; n++) {
            let e = document.createElement(t.name);
            if (e.isNeonAnimation) {
                let n = null;
                e.configure || (e.configure = function(e) {
                    return null;
                }), n = e.configure(t), i.push({
                    result: n,
                    config: t,
                    neonAnimation: e
                });
            } else console.warn(this.is + ":", t.name, "not found!");
        }
        for (var n = 0; n < i.length; n++) {
            let e = i[n].result, s = i[n].config, r = i[n].neonAnimation;
            try {
                "function" != typeof e.cancel && (e = document.timeline.play(e));
            } catch (t) {
                e = null, console.warn("Couldnt play", "(", s.name, ").", t);
            }
            e && t.push({
                neonAnimation: r,
                config: s,
                animation: e
            });
        }
        return t;
    },
    _shouldComplete: function(e) {
        for (var t = !0, i = 0; i < e.length; i++) if ("finished" != e[i].animation.playState) {
            t = !1;
            break;
        }
        return t;
    },
    _complete: function(e) {
        for (var t = 0; t < e.length; t++) e[t].neonAnimation.complete(e[t].config);
        for (t = 0; t < e.length; t++) e[t].animation.cancel();
    },
    playAnimation: function(e, t) {
        var i = this.getAnimationConfig(e);
        if (i) {
            this._active = this._active || {}, this._active[e] && (this._complete(this._active[e]), 
            delete this._active[e]);
            var n = this._configureAnimations(i);
            if (0 != n.length) {
                this._active[e] = n;
                for (var s = 0; s < n.length; s++) n[s].animation.onfinish = function() {
                    this._shouldComplete(n) && (this._complete(n), delete this._active[e], this.fire("neon-animation-finish", t, {
                        bubbles: !1
                    }));
                }.bind(this);
            } else this.fire("neon-animation-finish", t, {
                bubbles: !1
            });
        }
    },
    cancelAnimation: function() {
        for (var e in this._active) {
            var t = this._active[e];
            for (var i in t) t[i].animation.cancel();
        }
        this._active = {};
    }
}, NeonAnimationRunnerBehavior = [ NeonAnimatableBehavior, NeonAnimationRunnerBehaviorImpl ];

var neonAnimationRunnerBehavior = {
    NeonAnimationRunnerBehaviorImpl: NeonAnimationRunnerBehaviorImpl,
    NeonAnimationRunnerBehavior: NeonAnimationRunnerBehavior
};

function localize(e, t = "") {
    let i = chrome.i18n.getMessage(e);
    return void 0 !== i && "" !== i || (i = t || ""), i;
}

function getLocale() {
    return chrome.i18n.getMessage("@@ui_locale");
}

Polymer({
    _template: html`
    <style>
      :host {
        display: block;
        position: relative;
      }

      :host > ::slotted(*) {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
      }

      :host > ::slotted(:not(.iron-selected):not(.neon-animating))
       {
        display: none !important;
      }

      :host > ::slotted(.neon-animating) {
        pointer-events: none;
      }
    </style>

    <slot id="content"></slot>
  `,
    is: "neon-animated-pages",
    behaviors: [ IronResizableBehavior, IronSelectableBehavior, NeonAnimationRunnerBehavior ],
    properties: {
        activateEvent: {
            type: String,
            value: ""
        },
        animateInitialSelection: {
            type: Boolean,
            value: !1
        }
    },
    listeners: {
        "iron-select": "_onIronSelect",
        "neon-animation-finish": "_onNeonAnimationFinish"
    },
    _onIronSelect: function(e) {
        var t = e.detail.item;
        if (!(this.items.indexOf(t) < 0)) {
            var i = this._valueToItem(this._prevSelected) || !1;
            this._prevSelected = this.selected, i || this.animateInitialSelection ? (this.animationConfig = [], 
            this.entryAnimation ? this.animationConfig.push({
                name: this.entryAnimation,
                node: t
            }) : t.getAnimationConfig && this.animationConfig.push({
                animatable: t,
                type: "entry"
            }), i && (i.classList.contains("neon-animating") && (this._squelchNextFinishEvent = !0, 
            this.cancelAnimation(), this._completeSelectedChanged(), this._squelchNextFinishEvent = !1), 
            this.exitAnimation ? this.animationConfig.push({
                name: this.exitAnimation,
                node: i
            }) : i.getAnimationConfig && this.animationConfig.push({
                animatable: i,
                type: "exit"
            }), i.classList.add("neon-animating")), t.classList.add("neon-animating"), this.animationConfig.length >= 1 ? this.isAttached ? this.playAnimation(void 0, {
                fromPage: i,
                toPage: t
            }) : this.async(function() {
                this.playAnimation(void 0, {
                    fromPage: null,
                    toPage: t
                });
            }) : this._completeSelectedChanged(i, t)) : this._completeSelectedChanged();
        }
    },
    _completeSelectedChanged: function(e, t) {
        if (t && t.classList.remove("neon-animating"), e && e.classList.remove("neon-animating"), 
        !t || !e) for (var i, n = dom(this.$.content).getDistributedNodes(), s = 0; i = n[s]; s++) i.classList && i.classList.remove("neon-animating");
        this.async(this._notifyPageResize);
    },
    _onNeonAnimationFinish: function(e) {
        this._squelchNextFinishEvent ? this._squelchNextFinishEvent = !1 : this._completeSelectedChanged(e.detail.fromPage, e.detail.toPage);
    },
    _notifyPageResize: function() {
        var e = this.selectedItem || this._valueToItem(this.selected);
        this.resizerShouldNotify = function(t) {
            return t == e;
        }, this.notifyResize();
    }
});

var locales = {
    localize: localize,
    getLocale: getLocale
};

const chromep = new ChromePromise();

class ChromeLastError extends Error {
    constructor(e = "An error occurred", ...t) {
        super(...t), Error.captureStackTrace && Error.captureStackTrace(this, ChromeLastError), 
        this.title = e;
    }
    static load() {
        return chromep.storage.local.get("lastError").then(e => {
            const t = e.lastError;
            if (t) {
                const e = new ChromeLastError(t.title, t.message);
                return e.stack = t.stack, e;
            }
            return new ChromeLastError();
        });
    }
    static save(e) {
        const t = {
            title: e.title || "",
            message: e.message || "",
            stack: e.stack || ""
        };
        return chromep.storage.local.set({
            lastError: t
        });
    }
    static reset() {
        return chromep.storage.local.set({
            lastError: new ChromeLastError()
        });
    }
}

var last_error = {
    default: ChromeLastError
};

const chromep$1 = new ChromePromise(), _DEBUG = !1;

function _isOS(e) {
    return chromep$1.runtime.getPlatformInfo().then(t => Promise.resolve(t.os === e)).catch(() => Promise.resolve(!1));
}

const DEBUG = !1;

function getExtensionName() {
    return `chrome-extension://${chrome.runtime.id}`;
}

function getVersion() {
    return chrome.runtime.getManifest().version;
}

function getChromeVersion() {
    const e = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
    return !!e && parseInt(e[2], 10);
}

function getFullChromeVersion() {
    const e = navigator.userAgent;
    return e || "Unknown";
}

function getPlatformOS() {
    let e = "Unknown";
    return chromep$1.runtime.getPlatformInfo().then(t => {
        switch (t.os) {
          case "win":
            e = "MS Windows";
            break;

          case "mac":
            e = "Mac";
            break;

          case "android":
            e = "Android";
            break;

          case "cros":
            e = "Chrome OS";
            break;

          case "linux":
            e = "Linux";
            break;

          case "openbsd":
            e = "OpenBSD";
        }
        return Promise.resolve(e);
    }).catch(() => Promise.resolve(e));
}

function isWindows() {
    return _isOS("win");
}

function isChromeOS() {
    return _isOS("cros");
}

function isMac() {
    return _isOS("mac");
}

function noop() {}

function isWhiteSpace(e) {
    return !e || 0 === e.length || /^\s*$/.test(e);
}

function getRandomString(e = 8) {
    const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let i = "";
    for (let n = 0; n < e; n++) i += t.charAt(Math.floor(Math.random() * t.length));
    return i;
}

function getRandomInt(e, t) {
    return Math.floor(Math.random() * (t - e + 1)) + e;
}

function shuffleArray(e) {
    for (let t = (e ? e.length : 0) - 1; t > 0; t--) {
        const i = Math.floor(Math.random() * (t + 1)), n = e[t];
        e[t] = e[i], e[i] = n;
    }
}

var utils = {
    DEBUG: DEBUG,
    getExtensionName: getExtensionName,
    getVersion: getVersion,
    getChromeVersion: getChromeVersion,
    getFullChromeVersion: getFullChromeVersion,
    getPlatformOS: getPlatformOS,
    isWindows: isWindows,
    isChromeOS: isChromeOS,
    isMac: isMac,
    noop: noop,
    isWhiteSpace: isWhiteSpace,
    getRandomString: getRandomString,
    getRandomInt: getRandomInt,
    shuffleArray: shuffleArray
};

function error(e = null, t = null, i = null, n = null) {
    e = e || localize("err_unknown", "unknown"), t = t || localize("err_unknownMethod", "unknownMethod"), 
    i = i || localize("err_error", "An error occurred");
    const s = n ? `${e} ${n}` : e;
    ChromeLastError.save(new ChromeLastError(i, e)).catch(() => {}), error$1(s, t);
}

function exception(e, t = null, i = !1, n = null) {
    try {
        let s = t;
        !s && e && e.message && (s = e.message), n = n || localize("err_exception", "An exception occurred"), 
        ChromeLastError.save(new ChromeLastError(n, s)).catch(() => {}), exception$1(e, t, i);
    } catch (e) {
        noop();
    }
}

var ChromeLog = {
    error: error,
    exception: exception
};

class ExHandler {
    constructor() {
        "object" == typeof window.onerror && (window.onerror = function(e, t, i, n, s) {
            ChromeLog && s && exception(s, null, !0);
        });
    }
}

new ExHandler();

var ex_handler = {
    ExHandler: ExHandler
};

function parse$1(e) {
    let t = null;
    try {
        t = JSON.parse(e);
    } catch (e) {
        exception$1(`Caught: JSONUtils.parse: ${e.message}`, e.stack, !1);
    }
    return t;
}

function shallowCopy(e) {
    let t = null;
    const i = JSON.stringify(e);
    return void 0 !== i && (t = parse$1(i)), t;
}

var json = {
    parse: parse$1,
    shallowCopy: shallowCopy
};

const EVENT = {
    INSTALLED: {
        eventCategory: "extension",
        eventAction: "installed",
        eventLabel: ""
    },
    UPDATED: {
        eventCategory: "extension",
        eventAction: "updated",
        eventLabel: ""
    },
    ALARM: {
        eventCategory: "alarm",
        eventAction: "triggered",
        eventLabel: ""
    },
    MENU: {
        eventCategory: "ui",
        eventAction: "menuSelect",
        eventLabel: ""
    },
    TOGGLE: {
        eventCategory: "ui",
        eventAction: "toggle",
        eventLabel: ""
    },
    LINK: {
        eventCategory: "ui",
        eventAction: "linkSelect",
        eventLabel: ""
    },
    TEXT: {
        eventCategory: "ui",
        eventAction: "textChanged",
        eventLabel: ""
    },
    SLIDER_VALUE: {
        eventCategory: "ui",
        eventAction: "sliderValueChanged",
        eventLabel: ""
    },
    SLIDER_UNITS: {
        eventCategory: "ui",
        eventAction: "sliderUnitsChanged",
        eventLabel: ""
    },
    BUTTON: {
        eventCategory: "ui",
        eventAction: "buttonClicked",
        eventLabel: ""
    },
    ICON: {
        eventCategory: "ui",
        eventAction: "toolbarIconClicked",
        eventLabel: ""
    },
    CHECK: {
        eventCategory: "ui",
        eventAction: "checkBoxClicked",
        eventLabel: ""
    },
    KEY_COMMAND: {
        eventCategory: "ui",
        eventAction: "keyCommand",
        eventLabel: ""
    }
};

function initialize(e, t, i, n) {
    ga("create", e, "auto"), ga("set", "checkProtocolTask", function() {}), ga("set", "appName", t), 
    ga("set", "appId", i), ga("set", "appVersion", n), ga("require", "displayfeatures");
}

function page(e) {
    e && (DEBUG || ga("send", "pageview", e));
}

function event(e, t = null, i = null) {
    if (e) {
        const n = shallowCopy(e);
        n.hitType = "event", n.eventLabel = t || n.eventLabel, n.eventAction = i || n.eventAction, 
        DEBUG ? console.log(n) : ga("send", n);
    }
}

function error$1(e = "unknown", t = "unknownMethod") {
    const i = {
        hitType: "event",
        eventCategory: "error",
        eventAction: t,
        eventLabel: `Err: ${e}`
    };
    DEBUG ? console.error(i) : ga("send", i);
}

function exception$1(e, t = null, i = !1) {
    try {
        let n = "Unknown";
        t ? n = t : e.message && (n = e.message), e.stack && (n += `\n\n${e.stack}`);
        const s = {
            hitType: "exception",
            exDescription: n,
            exFatal: i
        };
        DEBUG ? console.error(s) : ga("send", s);
    } catch (e) {
        noop();
    }
}

function _onLoad() {
    var e, t, i, n, s, r;
    e = window, t = document, i = "script", n = "ga", e.GoogleAnalyticsObject = n, e.ga = e.ga || function() {
        (e.ga.q = e.ga.q || []).push(arguments);
    }, e.ga.l = 1 * new Date(), s = t.createElement(i), r = t.getElementsByTagName(i)[0], 
    s.async = 1, s.src = "https://www.google-analytics.com/analytics.js", r.parentNode.insertBefore(s, r);
}

window.addEventListener("load", _onLoad);

var analytics = {
    EVENT: EVENT,
    initialize: initialize,
    page: page,
    event: event,
    error: error$1,
    exception: exception$1
};

const chromep$2 = new ChromePromise();

function getToken(e = !1, t = null) {
    const i = {
        interactive: e
    };
    return t && t.length && (i.scopes = t), chromep$2.identity.getAuthToken(i).then(e => Promise.resolve(e));
}

function removeCachedToken(e = !1, t = null, i = null) {
    let n = null;
    return null === t ? getToken(e, i).then(e => (n = e, chromep$2.identity.removeCachedAuthToken({
        token: e
    }))).then(() => Promise.resolve(n)) : (n = t, chromep$2.identity.removeCachedAuthToken({
        token: t
    }).then(() => Promise.resolve(n)));
}

function isSignedIn() {
    let e = !0;
    return chromep$2.identity.getAuthToken({
        interactive: !1
    }).then(() => Promise.resolve(e)).catch(t => (t.message.match(/not signed in/) && (e = !1), 
    Promise.resolve(e)));
}

function isRevoked() {
    let e = !1;
    return chromep$2.identity.getAuthToken({
        interactive: !1
    }).then(() => Promise.resolve(e)).catch(t => (t.message.match(/OAuth2 not granted or revoked/) && (e = !0), 
    Promise.resolve(e)));
}

var auth = {
    getToken: getToken,
    removeCachedToken: removeCachedToken,
    isSignedIn: isSignedIn,
    isRevoked: isRevoked
};

const _AUTH_HEADER = "Authorization", _BEARER = "Bearer", _MAX_RETRIES = 4, _DELAY = 1e3, CONFIG = {
    isAuth: !1,
    retryToken: !1,
    interactive: !1,
    token: null,
    backoff: !0,
    maxRetries: 4
};

function doGet(e, t = null) {
    return _doIt(e, {
        method: "GET",
        headers: new Headers({})
    }, t);
}

function doPost(e, t = null) {
    return _doIt(e, {
        method: "POST",
        headers: new Headers({})
    }, t);
}

function _processResponse(e, t, i, n, s) {
    if (e.ok) return e.json();
    if (s >= n.maxRetries) return Promise.reject(_getError(e));
    const r = e.status;
    return n.backoff && r >= 500 && r < 600 ? _retry(t, i, n, s) : n.isAuth && n.token && n.retryToken && 401 === r ? _retryToken(t, i, n, s) : n.isAuth && n.interactive && n.token && n.retryToken && 403 === r ? _retryToken(t, i, n, s) : Promise.reject(_getError(e));
}

function _getError(e) {
    let t = "Unknown error.";
    if (e && e.status && void 0 !== e.statusText) {
        t = `${localize("err_status", "Status")}: ${e.status}`, t += `\n${e.statusText}`;
    }
    return new Error(t);
}

function _getAuthToken(e, t) {
    return e ? getToken(t).then(e => Promise.resolve(e)).catch(e => t && (e.message.includes("revoked") || e.message.includes("Authorization page could not be loaded")) ? getToken(!1) : Promise.reject(e)) : Promise.resolve(null);
}

function _retry(e, t, i, n) {
    return n++, new Promise((s, r) => {
        const o = (Math.pow(2, n) - 1) * _DELAY;
        setTimeout(() => _fetch(e, t, i, n).then(s, r), o);
    });
}

function _retryToken(e, t, i, n) {
    return error$1("Refreshed auth token.", "Http._retryToken"), removeCachedToken(i.interactive, i.token, null).then(() => (i.token = null, 
    i.retryToken = !1, _fetch(e, t, i, n)));
}

function _fetch(e, t, i, n) {
    return _getAuthToken(i.isAuth, i.interactive).then(n => (i.isAuth && (i.token = n, 
    t.headers.set(_AUTH_HEADER, `${_BEARER} ${i.token}`)), i.body && (t.body = JSON.stringify(i.body)), 
    fetch(e, t))).then(s => _processResponse(s, e, t, i, n)).catch(e => {
        let t = e.message;
        return "Failed to fetch" === t && (void 0 !== (t = localize("err_network")) && "" !== t || (t = "Network error")), 
        Promise.reject(new Error(t));
    });
}

function _doIt(e, t, i) {
    (i = null === i ? CONFIG : i).isAuth && t.headers.set(_AUTH_HEADER, `${_BEARER} unknown`);
    return _fetch(e, t, i, 0);
}

var http = {
    CONFIG: CONFIG,
    doGet: doGet,
    doPost: doPost
};

const _MSG = {
    HIGHLIGHT: {
        message: "highlightTab"
    },
    RESTORE_DEFAULTS: {
        message: "restoreDefaults"
    },
    STORAGE_EXCEEDED: {
        message: "storageExceeded"
    },
    STORE: {
        message: "store",
        key: "",
        value: ""
    }
}, HIGHLIGHT = _MSG.HIGHLIGHT, RESTORE_DEFAULTS = _MSG.RESTORE_DEFAULTS, STORAGE_EXCEEDED = _MSG.STORAGE_EXCEEDED, STORE = _MSG.STORE;

function send(e) {
    return new ChromePromise().runtime.sendMessage(e, null).then(e => Promise.resolve(e)).catch(t => {
        if (t.message && !t.message.includes("port closed") && !t.message.includes("Receiving end does not exist")) {
            error$1(`type: ${e.message}, ${t.message}`, "Msg.send");
        }
        return Promise.reject(t);
    });
}

function listen(e) {
    chrome.runtime.onMessage.addListener(e);
}

var msg = {
    HIGHLIGHT: HIGHLIGHT,
    RESTORE_DEFAULTS: RESTORE_DEFAULTS,
    STORAGE_EXCEEDED: STORAGE_EXCEEDED,
    STORE: STORE,
    send: send,
    listen: listen
};

function get$1(e, t = null) {
    let i = t, n = localStorage.getItem(e);
    return null !== n && (i = parse$1(n)), i;
}

function getInt(e, t = null) {
    let i = localStorage.getItem(e), n = parseInt(i, 10);
    return Number.isNaN(n) && (n = null === t ? n : t, null === t && error$1(`NaN value for: ${e} equals ${i}`, "Storage.getInt")), 
    n;
}

function getBool(e, t = null) {
    return get$1(e, t);
}

function set$1(e, t = null) {
    if (null === t) localStorage.removeItem(e); else {
        const i = JSON.stringify(t);
        localStorage.setItem(e, i);
    }
}

function safeSet(e, t, i = null) {
    let n = !0;
    const s = get$1(e);
    try {
        set$1(e, t);
    } catch (t) {
        n = !1, s && set$1(e, s), i && (s && s.length ? set$1(i, !0) : set$1(i, !1)), send(STORAGE_EXCEEDED).catch(() => {});
    }
    return n;
}

async function asyncGet(e, t = null) {
    let i = null;
    const n = new ChromePromise();
    try {
        i = (await n.storage.local.get([ e ]))[e];
    } catch (e) {
        t && (i = t);
    }
    return void 0 === i && (i = t), i;
}

async function asyncSet(e, t, i = null) {
    let n = !0;
    const s = new ChromePromise(), r = {
        [e]: t
    };
    try {
        await s.storage.local.set(r);
    } catch (e) {
        send(STORAGE_EXCEEDED).catch(() => {}), n = !1;
    }
    return n;
}

var storage = {
    get: get$1,
    getInt: getInt,
    getBool: getBool,
    set: set$1,
    safeSet: safeSet,
    asyncGet: asyncGet,
    asyncSet: asyncSet
};

class ChromeTime {
    constructor(e = null) {
        this._parse(e);
    }
    static get MSEC_IN_MIN() {
        return 6e4;
    }
    static get MIN_IN_HOUR() {
        return 60;
    }
    static get MSEC_IN_HOUR() {
        return 60 * ChromeTime.MIN_IN_HOUR * 1e3;
    }
    static get MIN_IN_DAY() {
        return 1440;
    }
    static get MSEC_IN_DAY() {
        return 60 * ChromeTime.MIN_IN_DAY * 1e3;
    }
    static _is24Hr(e = null) {
        let t = !1, i = getInt("showTime", 0);
        null !== e && (i = e);
        const n = localize("time_format");
        return 2 === i ? t = !0 : 0 === i && "24" === n && (t = !0), t;
    }
    static getTime(e) {
        const t = new Date(), i = new ChromeTime(e);
        return t.setHours(i._hr), t.setMinutes(i._min), t.setSeconds(0), t.setMilliseconds(0), 
        t.getTime();
    }
    static getTimeDelta(e) {
        const t = Date.now();
        let i = (ChromeTime.getTime(e) - t) / 1e3 / 60;
        return i < 0 && (i = ChromeTime.MIN_IN_DAY + i), i;
    }
    static isInRange(e, t) {
        const i = Date.now(), n = ChromeTime.getTime(e), s = ChromeTime.getTime(t);
        let r = !1;
        return e === t ? r = !0 : s > n ? i >= n && i <= s && (r = !0) : (i >= n || i <= s) && (r = !0), 
        r;
    }
    static getStringFull(e, t = null) {
        return new ChromeTime(e).toString(t);
    }
    static getStringShort() {
        let e = new ChromeTime().toString();
        return e = (e = e.replace(/[^\d:]/g, "")).replace(/(.*?:.*?):.*/g, "$1");
    }
    _parse(e) {
        if (null === e) {
            const e = new Date();
            this._hr = e.getHours(), this._min = e.getMinutes();
        } else this._hr = parseInt(e.substr(0, 2), 10), this._min = parseInt(e.substr(3, 2), 10);
    }
    toString(e = null) {
        const t = new Date();
        t.setHours(this._hr, this._min), t.setSeconds(0), t.setMilliseconds(0);
        let i = t.toTimeString();
        const n = [];
        void 0 !== navigator.language && n.push(navigator.language), n.push("en-US");
        const s = {
            hour: "numeric",
            minute: "2-digit",
            hour12: !ChromeTime._is24Hr(e)
        };
        try {
            i = t.toLocaleTimeString(n, s);
        } catch (e) {
            noop();
        }
        return i;
    }
}

var time = {
    default: ChromeTime
};

const _TRACKING_ID = "UA-61314754-1", EVENT$1 = {
    CHROME_SIGN_OUT: {
        eventCategory: "user",
        eventAction: "chromeSignOut",
        eventLabel: ""
    },
    LOAD_ALBUM_LIST: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadAlbumList",
        eventLabel: ""
    },
    SELECT_ALBUM: {
        eventCategory: "googlePhotosAPI",
        eventAction: "selectAlbum",
        eventLabel: ""
    },
    LOAD_ALBUM: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadAlbum",
        eventLabel: ""
    },
    LOAD_PHOTO: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadPhoto",
        eventLabel: ""
    },
    LOAD_PHOTOS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "loadPhotos",
        eventLabel: ""
    },
    FETCH_ALBUMS: {
        eventCategory: "googlePhotosAPI",
        eventAction: "fetchAlbums",
        eventLabel: ""
    },
    PHOTOS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedAlbumPhotos",
        eventLabel: ""
    },
    ALBUMS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedAlbums",
        eventLabel: ""
    },
    PHOTO_SELECTIONS_LIMITED: {
        eventCategory: "googlePhotosAPI",
        eventAction: "limitedTotalPhotos",
        eventLabel: ""
    },
    VIEW_PHOTO: {
        eventCategory: "ui",
        eventAction: "viewPhoto",
        eventLabel: ""
    }
};

function _onLoad$1() {
    initialize(_TRACKING_ID, "Photo Screensaver", "screensaver", getVersion());
}

window.addEventListener("load", _onLoad$1);

var my_analytics = {
    EVENT: EVENT$1
};

const _MSG$1 = {
    SS_SHOW: {
        message: "showScreensaver"
    },
    SS_CLOSE: {
        message: "closeScreensaver"
    },
    SS_IS_SHOWING: {
        message: "isScreensaverShowing"
    },
    PHOTO_SOURCE_FAILED: {
        message: "photoSourceFailed",
        key: "",
        error: ""
    }
}, SS_SHOW = _MSG$1.SS_SHOW, SS_CLOSE = _MSG$1.SS_CLOSE, SS_IS_SHOWING = _MSG$1.SS_IS_SHOWING, PHOTO_SOURCE_FAILED = _MSG$1.PHOTO_SOURCE_FAILED;

var my_msg = {
    SS_SHOW: SS_SHOW,
    SS_CLOSE: SS_CLOSE,
    SS_IS_SHOWING: SS_IS_SHOWING,
    PHOTO_SOURCE_FAILED: PHOTO_SOURCE_FAILED
};

const _DEBUG$1 = !1, DEBUG$1 = !1;

function getEmail() {
    return "photoscreensaver@gmail.com";
}

function getEmailBody() {
    return `Extension version: ${getVersion()}\n` + `Chrome version: ${getFullChromeVersion()}\n` + `OS: ${get$1("os")}\n\n\n`;
}

function getEmailUrl(e, t) {
    return `mailto:${encodeURIComponent(getEmail())}?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(t)}`;
}

function getGithubPath() {
    return "https://github.com/opus1269/screensaver/";
}

function getGithubPagesPath() {
    return "https://opus1269.github.io/screensaver/";
}

var my_utils = {
    DEBUG: !1,
    getEmail: getEmail,
    getEmailBody: getEmailBody,
    getEmailUrl: getEmailUrl,
    getGithubPath: getGithubPath,
    getGithubPagesPath: getGithubPagesPath
};

class PhotoSource {
    constructor(e, t, i, n, s, r, o = null) {
        this._useKey = e, this._photosKey = t, this._type = i, this._desc = n, this._isDaily = s, 
        this._isArray = r, this._loadArg = o;
    }
    static addPhoto(e, t, i, n, s, r = "") {
        const o = {
            url: t,
            author: i,
            asp: n.toPrecision(3)
        };
        s && (o.ex = s), r && !isWhiteSpace(r) && (o.point = r), e.push(o);
    }
    static createPoint(e, t) {
        return "number" == typeof e && "number" == typeof t ? `${e.toFixed(6)} ${t.toFixed(6)}` : `${e} ${t}`;
    }
    fetchPhotos() {}
    getType() {
        return this._type;
    }
    getPhotosKey() {
        return this._photosKey;
    }
    getDesc() {
        return this._desc;
    }
    isDaily() {
        return this._isDaily;
    }
    async getPhotos() {
        let e = {
            type: this._type,
            photos: []
        };
        if (this.use()) {
            let t = [];
            if (this._isArray) {
                let e = await asyncGet(this._photosKey);
                e = e || [];
                for (const i of e) t = t.concat(i.photos);
            } else t = (t = await asyncGet(this._photosKey)) || [];
            e.photos = t;
        }
        return Promise.resolve(e);
    }
    use() {
        return getBool(this._useKey);
    }
    process() {
        if (this.use()) return this.fetchPhotos().then(e => this._savePhotos(e)).then(e => isWhiteSpace(e) ? null : Promise.reject(new Error(e))).catch(e => {
            let t = localize("err_photo_source_title");
            return t += `: ${this._desc}`, error(e.message, "PhotoSource.process", t, `source: ${this._useKey}`), 
            Promise.reject(e);
        });
        {
            const e = getBool("useGoogle");
            if ("albumSelections" !== this._photosKey || e) {
                new ChromePromise().storage.local.remove(this._photosKey).catch(() => {});
            }
            return null;
        }
    }
    async _savePhotos(e) {
        let t = null;
        const i = this._useKey;
        if (e && e.length) {
            await asyncSet(this._photosKey, e, i) || (t = "Exceeded storage capacity.");
        }
        return t;
    }
}

var photo_source = {
    default: PhotoSource
};

class CCSource extends PhotoSource {
    constructor(e, t, i, n, s, r, o = null) {
        super(e, t, i, n, s, r, o);
    }
    fetchPhotos() {
        return doGet("/assets/chromecast.json").then(e => {
            e = e || [];
            for (const t of e) t.asp = 1.78;
            return Promise.resolve(e);
        });
    }
}

var photo_source_chromecast = {
    default: CCSource
};

const _URL_BASE = "https://api.flickr.com/services/rest/", _KEY = "1edd9926740f0e0d01d4ecd42de60ac6", _MAX_PHOTOS = 250;

class FlickrSource extends PhotoSource {
    constructor(e, t, i, n, s, r, o = null) {
        super(e, t, i, n, s, r, o);
    }
    static _processPhotos(e) {
        if (!e.photos || !e.photos.photo) {
            const e = new Error(localize("err_photo_source_title"));
            return Promise.reject(e);
        }
        const t = [];
        for (const i of e.photos.photo) {
            let e, n, s = null;
            if (i && "photo" === i.media && "0" !== i.isfriend && "0" !== i.isfamily && (s = i.url_k || s, 
            s = i.url_o || s)) {
                i.url_o ? (e = parseInt(i.width_o, 10), n = parseInt(i.height_o, 10)) : (e = parseInt(i.width_k, 10), 
                n = parseInt(i.height_k, 10));
                const r = e / n;
                let o = null;
                i.latitude && i.longitude && (o = PhotoSource.createPoint(i.latitude, i.longitude)), 
                PhotoSource.addPhoto(t, s, i.ownername, r, i.owner, o);
            }
        }
        return Promise.resolve(t);
    }
    fetchPhotos() {
        let e;
        if (this._loadArg) {
            e = `${_URL_BASE}?method=flickr.people.getPublicPhotos` + `&api_key=${_KEY}&user_id=${"86149994@N06"}` + `&extras=owner_name,url_o,media,geo&per_page=${_MAX_PHOTOS}` + "&format=json&nojsoncallback=1";
        } else e = `${_URL_BASE}?method=flickr.interestingness.getList` + `&api_key=${_KEY}&extras=owner_name,url_k,media,geo` + `&per_page=${_MAX_PHOTOS}` + "&format=json&nojsoncallback=1";
        return doGet(e).then(e => "ok" !== e.stat ? Promise.reject(new Error(e.message)) : FlickrSource._processPhotos(e));
    }
}

var photo_source_flickr = {
    default: FlickrSource
};

const _URL_BASE$1 = "https://photoslibrary.googleapis.com/v1/", _ALBUMS_QUERY = "?pageSize=50";

class GoogleSource extends PhotoSource {
    constructor(e, t, i, n, s, r, o = null) {
        super(e, t, i, n, s, r, o);
    }
    static get MAX_ALBUMS() {
        return 30;
    }
    static get MAX_ALBUM_PHOTOS() {
        return 1e3;
    }
    static get MAX_PHOTOS() {
        return 1e4;
    }
    static isQuotaError(e, t) {
        let i = !1;
        const n = `${localize("err_status")}: 429`;
        return e.message.includes(n) && (error(e.message, t, localize("err_google_quota")), 
        i = !0), i;
    }
    static isAuthRevokedError(e, t) {
        let i = !1;
        return e.message.includes("OAuth2 not granted or revoked") && (asyncSet("albumSelections", []).catch(() => {}), 
        error(e.message, t, localize("err_auth_revoked")), i = !0), i;
    }
    static _isImage(e) {
        return e && e.mimeType && e.mimeType.startsWith("image/") && e.mediaMetadata && e.mediaMetadata.width && e.mediaMetadata.height;
    }
    static _getImageSize(e) {
        const t = {};
        if (t.width = parseInt(e.width), t.height = parseInt(e.height), !getBool("fullResGoogle")) {
            const e = Math.max(1600, t.width, t.height);
            e > 1600 && (t.width === e ? (t.width = 1600, t.height = Math.round(t.height * (1600 / e))) : (t.height = 1600, 
            t.width = Math.round(t.width * (1600 / e))));
        }
        return t;
    }
    static _processPhoto(e, t) {
        let i = null;
        if (e && e.mediaMetadata && this._isImage(e)) {
            const n = e.mediaMetadata, s = this._getImageSize(n), r = s.width, o = s.height;
            (i = {}).url = `${e.baseUrl}=w${r}-h${o}`, i.asp = r / o, i.author = t, i.ex = {
                id: e.id,
                url: e.productUrl
            }, i.point = null;
        }
        return i;
    }
    static _processPhotos(e, t) {
        const i = [];
        if (!e) return i;
        for (const n of e) {
            const e = this._processPhoto(n, t);
            e && this.addPhoto(i, e.url, e.author, e.asp, e.ex, e.point);
        }
        return i;
    }
    static async loadPhotos(e) {
        const t = "GoogleSource.loadPhotos";
        let i = [];
        if (0 === (e = e || []).length) return i;
        const n = shallowCopy(CONFIG);
        n.isAuth = !0, n.retryToken = !0, n.interactive = !1;
        let s = !1, r = 0, o = Math.min(50, e.length), a = 0;
        do {
            let l = `${_URL_BASE$1}mediaItems:batchGet`, c = "?mediaItemIds=", h = !0;
            for (let t = r; t < o; t++) h ? (c = c.concat(e[t]), h = !1) : c = c.concat(`&mediaItemIds=${e[t]}`);
            l = l.concat(c);
            try {
                const e = await doGet(l, n);
                a++;
                const s = [];
                for (const t of e.mediaItemResults) t.status || s.push(t.mediaItem);
                const r = this._processPhotos(s, "");
                i = i.concat(r);
            } catch (e) {
                throw this.isQuotaError(e, t) || this.isAuthRevokedError(e, t) || error(e.message, t), 
                e;
            }
            o === e.length ? s = !0 : (r = o, o = Math.min(o + 50, e.length));
        } while (!s);
        return event(EVENT$1.LOAD_PHOTOS, `nPhotos: ${i.length}, nCalls: ${a}`), i;
    }
    static async loadAlbum(e, t, i = !0) {
        const n = `${_URL_BASE$1}mediaItems:search`, s = {
            pageSize: 100
        };
        s.albumId = e;
        const r = shallowCopy(CONFIG);
        let o;
        r.isAuth = !0, r.retryToken = !0, r.interactive = i, r.body = s;
        let a = [], l = 0;
        do {
            const e = await doPost(n, r);
            o = e.nextPageToken, r.body.pageToken = o;
            const i = e.mediaItems;
            if (i) {
                const e = this._processPhotos(i, t);
                a = a.concat(e), l += e.length;
            }
            l >= GoogleSource.MAX_ALBUM_PHOTOS && event(EVENT$1.PHOTOS_LIMITED, `nPhotos: ${GoogleSource.MAX_ALBUM_PHOTOS}`);
        } while (o && !(l >= GoogleSource.MAX_ALBUM_PHOTOS));
        const c = {
            index: 0,
            uid: "album0"
        };
        return c.name = t, c.id = e, c.thumb = "", c.checked = !0, c.photos = a, c.ct = a.length, 
        event(EVENT$1.LOAD_ALBUM, `nPhotos: ${c.ct}`), c;
    }
    static async loadAlbumList() {
        let e, t = [], i = [], n = 0;
        const s = `${_URL_BASE$1}albums/${_ALBUMS_QUERY}`;
        let r = s;
        const o = shallowCopy(CONFIG);
        o.isAuth = !0, o.retryToken = !0, o.interactive = !0;
        do {
            let i = await doGet(r, o);
            if (e = (i = i || {}).nextPageToken, !(i.albums && 0 !== i.albums.length || 0 !== t.length || e)) throw new Error(localize("err_no_albums"));
            r = `${s}&pageToken=${e}`, i.albums && i.albums.length > 0 && (t = t.concat(i.albums));
        } while (e);
        for (const e of t) if (e && e.mediaItemsCount && e.mediaItemsCount > 0) {
            const t = {};
            t.index = n, t.uid = "album" + n, t.name = e.title, t.id = e.id, t.ct = e.mediaItemsCount, 
            t.thumb = `${e.coverPhotoBaseUrl}=w76-h76`, t.checked = !1, t.photos = [], i.push(t), 
            n++;
        }
        return event(EVENT$1.LOAD_ALBUM_LIST, `nAlbums: ${i.length}`), i;
    }
    static async updateBaseUrls(e) {
        let t = !0;
        if (0 === (e = e || []).length) return t;
        const i = await asyncGet("albumSelections", []);
        if (0 === i.length) return t;
        for (const t of e) for (const e of i) {
            const i = e.photos, n = i.findIndex(e => e.ex.id === t.ex.id);
            n >= 0 && (i[n].url = t.url);
        }
        return await asyncSet("albumSelections", i, null) || (t = !1, error(localize("err_storage_title"), "GoogleSource.updateBaseUrls")), 
        t;
    }
    static _isFetchAlbums() {
        const e = "allowed" === get$1("permPicasa", "notSet"), t = getBool("enabled", !0), i = getBool("useGoogle", !0), n = getBool("useGoogleAlbums", !0);
        return e && t && i && n;
    }
    static async _fetchAlbums() {
        const e = await asyncGet("albumSelections", []);
        if (!this._isFetchAlbums() || 0 === e.length) return Promise.resolve(e);
        let t = 0;
        const i = [];
        for (let n = 0; n < e.length; n++) {
            const s = e[n] || [], r = await GoogleSource.loadAlbum(s.id, s.name, !1), o = r.photos || [];
            if (o.length && (i.push({
                id: r.id,
                name: r.name,
                photos: o
            }), (t += o.length) > GoogleSource.MAX_PHOTOS)) {
                event(EVENT$1.PHOTO_SELECTIONS_LIMITED, `limit: ${t}`), error(localize("err_max_photos"), "GoogleSource._fetchAlbums");
                break;
            }
        }
        return event(EVENT$1.FETCH_ALBUMS, `nAlbums: ${i.length} nPhotos: ${t}`), Promise.resolve(i);
    }
    fetchPhotos() {
        const e = "GoogleSource.fetchPhotos";
        return GoogleSource._fetchAlbums().catch(t => (GoogleSource.isQuotaError(t, e) || GoogleSource.isAuthRevokedError(t, e) || error(t.message, e), 
        Promise.resolve([])));
    }
}

var photo_source_google = {
    default: GoogleSource
};

const _REDIRECT_URI = `https://${chrome.runtime.id}.chromiumapp.org/reddit`, _KEY$1 = "bATkDOUNW_tOlg", _MAX_PHOTOS$1 = 100, _MIN_SIZE = 750, _MAX_SIZE = 3500;

let _snoocore;

class RedditSource extends PhotoSource {
    constructor(e, t, i, n, s, r, o = null) {
        super(e, t, i, n, s, r, o);
    }
    static _waitForLib() {
        let e = 0;
        return new Promise(function(t, i) {
            !function n() {
                if (100 === e) i(new Error("snoocore library timed out")); else {
                    if (_snoocore) return t();
                    if (window.Snoocore) {
                        const e = window.Snoocore;
                        return _snoocore = new e({
                            userAgent: "photo-screen-saver",
                            throttle: 0,
                            oauth: {
                                type: "implicit",
                                key: _KEY$1,
                                redirectUri: _REDIRECT_URI,
                                scope: [ "read" ]
                            }
                        }), t();
                    }
                    e++;
                }
                setTimeout(n, 100);
            }();
        });
    }
    static _getSize(e) {
        const t = {
            width: -1,
            height: -1
        }, i = e.match(/\[(\d*)\D*(\d*)\]/);
        return i && (t.width = parseInt(i[1], 10), t.height = parseInt(i[2], 10)), t;
    }
    static _processChildren(e) {
        const t = [];
        let i, n = 1, s = 1;
        for (const r of e) {
            const e = r.data;
            if (!e.over_18) if (e.preview && e.preview.images) {
                let t = e.preview.images[0];
                i = t.source.url.replace(/&amp;/g, "&"), n = parseInt(t.source.width, 10), s = parseInt(t.source.height, 10), 
                Math.max(n, s) > _MAX_SIZE && (i = (t = t.resolutions[t.resolutions.length - 1]).url.replace(/&amp;/g, "&"), 
                n = parseInt(t.width, 10), s = parseInt(t.height, 10));
            } else if (e.title) {
                const t = RedditSource._getSize(e.title);
                i = e.url, n = t.width, s = t.height;
            }
            const o = n / s, a = e.author;
            o && !isNaN(o) && Math.max(n, s) >= _MIN_SIZE && Math.max(n, s) <= _MAX_SIZE && PhotoSource.addPhoto(t, i, a, o, e.url);
        }
        return t;
    }
    fetchPhotos() {
        let e = [];
        return RedditSource._waitForLib().then(() => _snoocore(`${this._loadArg}hot`).listing({
            limit: _MAX_PHOTOS$1
        })).then(t => (e = e.concat(RedditSource._processChildren(t.children)), t.next())).then(t => (e = e.concat(RedditSource._processChildren(t.children)), 
        Promise.resolve(e))).catch(e => {
            let t = e.message;
            if (t) {
                const e = t.indexOf(".");
                -1 !== e && (t = t.substring(0, e + 1));
            } else t = "Unknown Error";
            return Promise.reject(new Error(t));
        });
    }
}

var photo_source_reddit = {
    default: RedditSource
};

function getSelectedSources() {
    let e = [];
    for (const t in UseKey) if (UseKey.hasOwnProperty(t)) {
        const i = UseKey[t];
        if (getBool(i)) try {
            const t = create(i);
            t && e.push(t);
        } catch (e) {
            exception$1(e, `${i} failed to load`, !1);
        }
    }
    return e;
}

window.app = window.app || {};

const UseKey = {
    ALBUMS_GOOGLE: "useGoogleAlbums",
    PHOTOS_GOOGLE: "useGooglePhotos",
    CHROMECAST: "useChromecast",
    SPACE_RED: "useSpaceReddit",
    EARTH_RED: "useEarthReddit",
    ANIMAL_RED: "useAnimalReddit",
    INT_FLICKR: "useInterestingFlickr",
    AUTHOR: "useAuthors"
};

function getUseKeys() {
    let e = [];
    for (const t in UseKey) UseKey.hasOwnProperty(t) && e.push(UseKey[t]);
    return e;
}

function isUseKey(e) {
    let t = !1;
    for (const i in UseKey) if (UseKey.hasOwnProperty(i) && UseKey[i] === e) {
        t = !0;
        break;
    }
    return t;
}

function process(e) {
    try {
        const t = create(e);
        if (t) return t.process();
    } catch (t) {
        return exception$1(t, `${e} failed to load`, !1), Promise.reject(t);
    }
}

async function getSelectedPhotos() {
    const e = getSelectedSources();
    let t = [];
    for (const i of e) {
        const e = await i.getPhotos();
        t.push(e);
    }
    return Promise.resolve(t);
}

function processAll(e = !1) {
    const t = getSelectedSources();
    for (const i of t) {
        let t = !1;
        "Google User" === i.getType() && (t = !e), t || i.process().catch(() => {});
    }
}

function processDaily() {
    const e = getSelectedSources();
    for (const t of e) t.isDaily() && t.process().catch(() => {});
}

var photo_sources = {
    getSelectedSources: getSelectedSources,
    UseKey: UseKey,
    getUseKeys: getUseKeys,
    isUseKey: isUseKey,
    process: process,
    getSelectedPhotos: getSelectedPhotos,
    processAll: processAll,
    processDaily: processDaily
};

function create(e) {
    switch (e) {
      case UseKey.ALBUMS_GOOGLE:
        return new GoogleSource(e, "albumSelections", "Google User", localize("google_title_photos"), !0, !0, null);

      case UseKey.PHOTOS_GOOGLE:
        return new GoogleSource(e, "googleImages", "Google User", "NOT IMPLEMENTED", !0, !1, null);

      case UseKey.CHROMECAST:
        return new CCSource(e, "ccImages", "Google", localize("setting_chromecast"), !1, !1, null);

      case UseKey.INT_FLICKR:
        return new FlickrSource(e, "flickrInterestingImages", "flickr", localize("setting_flickr_int"), !0, !1, !1);

      case UseKey.AUTHOR:
        return new FlickrSource(e, "authorImages", "flickr", localize("setting_mine"), !1, !1, !0);

      case UseKey.SPACE_RED:
        return new RedditSource(e, "spaceRedditImages", "reddit", localize("setting_reddit_space"), !0, !1, "r/spaceporn/");

      case UseKey.EARTH_RED:
        return new RedditSource(e, "earthRedditImages", "reddit", localize("setting_reddit_earth"), !0, !1, "r/EarthPorn/");

      case UseKey.ANIMAL_RED:
        return new RedditSource(e, "animalRedditImages", "reddit", localize("setting_reddit_animal"), !0, !1, "r/animalporn/");

      default:
        return error(`Bad PhotoSource type: ${e}`, "PhotoSourceFactory.create"), null;
    }
}

var photo_source_factory = {
    create: create
};

export { ironResizableBehavior as $ironResizableBehavior, ironSelectable as $ironSelectable, ironSelection as $ironSelection, neonAnimatableBehavior as $neonAnimatableBehavior, neonAnimationBehavior as $neonAnimationBehavior, neonAnimationRunnerBehavior as $neonAnimationRunnerBehavior, neonSharedElementAnimationBehavior as $neonSharedElementAnimationBehavior, arraySelector as $arraySelector, customStyle as $customStyle, domBind as $domBind, domIf as $domIf, domModule as $domModule, domRepeat as $domRepeat, _class as $class, legacyElementMixin as $legacyElementMixin, mutableDataBehavior as $mutableDataBehavior, polymerFn as $polymerFn, polymer_dom as $polymerDom, templatizerBehavior as $templatizerBehavior, dirMixin as $dirMixin, elementMixin as $elementMixin, gestureEventListeners as $gestureEventListeners, mutableData as $mutableData, propertiesChanged as $propertiesChanged, propertiesMixin as $propertiesMixin, propertyAccessors as $propertyAccessors, propertyEffects as $propertyEffects, templateStamp as $templateStamp, arraySplice as $arraySplice, async as $async, caseMap$1 as $caseMap, debounce as $debounce, flattenedNodesObserver as $flattenedNodesObserver, flush$2 as $flush, gestures$1 as $gestures, htmlTag as $htmlTag, mixin as $mixin, path as $path, renderStatus as $renderStatus, resolveUrl$1 as $resolveUrl, settings as $settings, styleGather as $styleGather, templatize$1 as $templatize, polymerElement as $polymerElement, polymerLegacy as $polymerLegacy, applyShimUtils as $applyShimUtils, applyShim as $applyShim$1, commonRegex as $commonRegex, commonUtils as $commonUtils, cssParse as $cssParse, customStyleInterface as $customStyleInterface$1, documentWait$1 as $documentWait, styleSettings as $styleSettings, styleUtil as $styleUtil, templateMap$1 as $templateMap, unscopedStyleHandler as $unscopedStyleHandler, analytics as $analytics, auth as $auth, ex_handler as $exHandler, http as $http, json as $json, last_error as $lastError, locales as $locales, ChromeLog as $log, msg as $msg, storage as $storage, time as $time, utils as $utils, my_analytics as $myAnalytics, my_msg as $myMsg, my_utils as $myUtils, photo_source as $photoSource, photo_source_chromecast as $photoSourceChromecast, photo_source_factory as $photoSourceFactory, photo_source_flickr as $photoSourceFlickr, photo_source_google as $photoSourceGoogle, photo_source_reddit as $photoSourceReddit, photo_sources as $photoSources, IronResizableBehavior, IronSelectableBehavior, IronSelection, NeonAnimatableBehavior, NeonAnimationBehavior, NeonAnimationRunnerBehaviorImpl, NeonAnimationRunnerBehavior, NeonSharedElementAnimationBehaviorImpl, NeonSharedElementAnimationBehavior, ArraySelectorMixin, ArraySelector, CustomStyle, DomBind, DomIf, DomModule, DomRepeat, mixinBehaviors, Class, LegacyElementMixin, MutableDataBehavior, OptionalMutableDataBehavior, Polymer, flush$1 as flush, enqueueDebouncer as addDebouncer, matchesSelector, DomApi, EventApi, dom, Templatizer, DirMixin, version, ElementMixin, instanceCount, registrations, register, dumpRegistrations, updateStyles, GestureEventListeners, MutableData, OptionalMutableData, PropertiesChanged, PropertiesMixin, PropertyAccessors, PropertyEffects, TemplateStamp, calculateSplices, timeOut, animationFrame, idlePeriod, microTask, dashToCamelCase, camelToDashCase, Debouncer, FlattenedNodesObserver, enqueueDebouncer, flush$1, gestures, recognizers, deepTargetFind, addListener, removeListener, register$1, setTouchAction, prevent, resetMouseCanceller, findOriginalTarget, add, remove, html as html$1, htmlLiteral, dedupingMixin, isPath, root, isAncestor, isDescendant, translate, matches, normalize, split, get as get$1, set as set$1, isDeep, flush as flush$2, beforeNextRender, afterNextRender, resolveUrl, resolveCss, pathFromUrl, useShadow, useNativeCSSProperties, useNativeCustomElements, rootPath, setRootPath, sanitizeDOMValue, setSanitizeDOMValue, passiveTouchGestures, setPassiveTouchGestures, strictTemplatePolicy, setStrictTemplatePolicy, allowTemplateFromDomModule, setAllowTemplateFromDomModule, stylesFromModules, stylesFromModule, stylesFromTemplate, stylesFromModuleImports, cssFromModules, cssFromModule, cssFromTemplate, cssFromModuleImports, templatize, modelForElement, TemplateInstanceBase, html as html$2, version as version$1, PolymerElement, Polymer as Polymer$1, html, Base, invalidate, invalidateTemplate, isValid, templateIsValid, isValidating, templateIsValidating, startValidating, startValidatingTemplate, elementsAreInvalid, ApplyShim as $applyShimDefault, VAR_ASSIGN, MIXIN_MATCH, VAR_CONSUMED, ANIMATION_MATCH, MEDIA_MATCH, IS_VAR, BRACKETED, HOST_PREFIX, HOST_SUFFIX, updateNativeProperties, getComputedStyleValue, detectMixin, StyleNode, parse, stringify, removeCustomPropAssignment, types, CustomStyleProvider, CustomStyleInterface as $customStyleInterfaceDefault, CustomStyleInterfaceInterface, documentWait as $documentWaitDefault, nativeShadow, cssBuild, disableRuntime, nativeCssVariables, toCssText, rulesForStyle, isKeyframesSelector, forEachRule, applyCss, createScopeStyle, applyStylePlaceHolder, applyStyle, isTargetedBuild, findMatchingParen, processVariableAndFallback, setElementClassRaw, wrap, getIsExtends, gatherStyleText, splitSelectorList, getCssBuild, elementHasBuiltCss, getBuildComment, isOptimalCssBuild, templateMap as $templateMapDefault, scopingAttribute, processUnscopedStyle, isUnscopedStyle, EVENT, initialize, page, event, error$1 as error, exception$1 as exception, getToken, removeCachedToken, isSignedIn, isRevoked, ExHandler, CONFIG, doGet, doPost, parse$1, shallowCopy, ChromeLastError as $lastErrorDefault, localize, getLocale, error as error$1, exception as exception$1, HIGHLIGHT, RESTORE_DEFAULTS, STORAGE_EXCEEDED, STORE, send, listen, get$1 as get, getInt, getBool, set$1 as set, safeSet, asyncGet, asyncSet, ChromeTime as $timeDefault, DEBUG as DEBUG$1, getExtensionName, getVersion, getChromeVersion, getFullChromeVersion, getPlatformOS, isWindows, isChromeOS, isMac, noop, isWhiteSpace, getRandomString, getRandomInt, shuffleArray, EVENT$1, SS_SHOW, SS_CLOSE, SS_IS_SHOWING, PHOTO_SOURCE_FAILED, DEBUG$1 as DEBUG, getEmail, getEmailBody, getEmailUrl, getGithubPath, getGithubPagesPath, PhotoSource as $photoSourceDefault, CCSource as $photoSourceChromecastDefault, create, FlickrSource as $photoSourceFlickrDefault, GoogleSource as $photoSourceGoogleDefault, RedditSource as $photoSourceRedditDefault, getSelectedSources, UseKey, getUseKeys, isUseKey, process, getSelectedPhotos, processAll, processDaily };