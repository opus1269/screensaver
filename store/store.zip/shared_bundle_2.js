import { PHOTO_SOURCE_FAILED, SS_CLOSE, SS_IS_SHOWING, SS_SHOW, processDaily, processAll, isUseKey, process, EVENT, DEBUG } from "./shared_bundle_4.js";

const chromep = new ChromePromise(), _DATA_VERSION = 20, _DEF_VALUES = {
    version: _DATA_VERSION,
    enabled: !0,
    isAlbumMode: !0,
    permPicasa: "notSet",
    permBackground: "notSet",
    allowBackground: !1,
    idleTime: {
        base: 5,
        display: 5,
        unit: 0
    },
    transitionTime: {
        base: 30,
        display: 30,
        unit: 0
    },
    skip: !0,
    shuffle: !0,
    photoSizing: 0,
    photoTransition: 1,
    interactive: !1,
    showTime: 2,
    largeTime: !1,
    fullResGoogle: !1,
    showPhotog: !0,
    showLocation: !0,
    background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
    keepAwake: !1,
    chromeFullscreen: !0,
    allDisplays: !1,
    activeStart: "00:00",
    activeStop: "00:00",
    allowSuspend: !1,
    allowPhotoClicks: !0,
    useSpaceReddit: !1,
    useEarthReddit: !1,
    useAnimalReddit: !1,
    useInterestingFlickr: !1,
    useChromecast: !0,
    useAuthors: !1,
    useGoogle: !0,
    useGoogleAlbums: !0,
    albumSelections: [],
    useGooglePhotos: !1,
    gPhotosNeedsUpdate: !1,
    gPhotosMaxAlbums: 10,
    isAwake: !0,
    isShowing: !1,
    signedInToChrome: !0
};

function _processEnabled() {
    const e = Chrome.Storage.getBool("enabled") ? Chrome.Locale.localize("disable") : Chrome.Locale.localize("enable");
    updateBadgeText(), chromep.contextMenus.update("ENABLE_MENU", {
        title: e
    }).catch(() => {});
}

function _processKeepAwake() {
    const e = Chrome.Storage.getBool("keepAwake", !0);
    e ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
    e || Chrome.Storage.set("isAwake", !0), updateRepeatingAlarms(), updateBadgeText();
}

function _processIdleTime() {
    const e = getIdleSeconds();
    e ? chrome.idle.setDetectionInterval(e) : Chrome.Log.Error("idleTime is null", "Data._processIdleTime");
}

function _getTimeFormat() {
    let e = 2;
    const o = Chrome.Locale.localize("time_format");
    return o && "12" === o && (e = 1), e;
}

function _setOS() {
    return chromep.runtime.getPlatformInfo().then(e => (Chrome.Storage.set("os", e.os), 
    null)).catch(() => (Chrome.Storage.set("os", "unknown"), null));
}

function _addDefaults() {
    Object.keys(_DEF_VALUES).forEach(function(e) {
        null === Chrome.Storage.get(e) && Chrome.Storage.set(e, _DEF_VALUES[e]);
    });
}

function _convertSliderValue(e) {
    const o = Chrome.Storage.get(e);
    if (o) {
        const t = {
            base: o,
            display: o,
            unit: 0
        };
        Chrome.Storage.set(e, t);
    }
}

function initialize() {
    _addDefaults(), _setOS().catch(() => {}), Chrome.Auth.isSignedIn().then(e => (Chrome.Storage.set("signedInToChrome", e), 
    null)).catch(() => {}), Chrome.Storage.clearLastError().catch(e => {
        Chrome.GA.error(e.message, "Data.initialize");
    }), Chrome.Storage.set("showTime", _getTimeFormat()), processState();
}

function update() {
    const e = Chrome.Storage.getInt("version");
    if ((Number.isNaN(e) || _DATA_VERSION > e) && Chrome.Storage.set("version", _DATA_VERSION), 
    !Number.isNaN(e)) {
        if (e < 8 && (_convertSliderValue("transitionTime"), _convertSliderValue("idleTime")), 
        e < 10) {
            const e = localStorage.getItem("os");
            e && Chrome.Storage.set("os", e);
        }
        e < 12 && Chrome.Storage.set("permPicasa", "allowed"), e < 14 && (Chrome.Storage.set("permBackground", "allowed"), 
        Chrome.Storage.set("allowBackground", !0)), e < 18 && (Chrome.Storage.set("permPicasa", "notSet"), 
        Chrome.Auth.removeCachedToken(!1, null, null).catch(() => null), Chrome.Storage.set("albumSelections", []));
    }
    if (e < 19 && (Chrome.Storage.set("useEditors500px", null), Chrome.Storage.set("usePopular500px", null), 
    Chrome.Storage.set("useYesterday500px", null), Chrome.Storage.set("editors500pxImages", null), 
    Chrome.Storage.set("popular500pxImages", null), Chrome.Storage.set("yesterday500pxImages", null)), 
    e < 20) {
        Chrome.Auth.isSignedIn().then(e => (Chrome.Storage.set("signedInToChrome", e), null)).catch(() => {});
        const e = Chrome.Storage.get("transitionTime", {
            base: 30,
            display: 30,
            unit: 0
        });
        0 === e.unit && (e.base = Math.max(10, e.base), e.display = e.base, Chrome.Storage.set("transitionTime", e));
    }
    _addDefaults(), processState();
}

function restoreDefaults() {
    Object.keys(_DEF_VALUES).forEach(function(e) {
        e.includes("useGoogle") || "googlePhotosSelections" === e || "albumSelections" === e || Chrome.Storage.set(e, _DEF_VALUES[e]);
    }), Chrome.Storage.set("showTime", _getTimeFormat()), processState();
}

function processState(e = "all", o = !1) {
    const t = {
        enabled: _processEnabled,
        keepAwake: _processKeepAwake,
        activeStart: _processKeepAwake,
        activeStop: _processKeepAwake,
        allowSuspend: _processKeepAwake,
        idleTime: _processIdleTime
    };
    if ("all" === e) Object.keys(t).forEach(function(e) {
        (0, t[e])();
    }), processAll(o), Chrome.Storage.set("isShowing", !1), Chrome.Storage.get("os") || _setOS().catch(() => {}); else if (isUseKey(e) || "fullResGoogle" === e) {
        const o = "fullResGoogle" === e ? "useGoogleAlbums" : e;
        process(o).catch(e => {
            const t = PHOTO_SOURCE_FAILED;
            return t.key = o, t.error = e.message, Chrome.Msg.send(t);
        }).catch(() => {});
    } else {
        const o = t[e];
        void 0 !== o && o();
    }
}

function getIdleSeconds() {
    return 60 * Chrome.Storage.get("idleTime", {
        base: 5,
        display: 5,
        unit: 0
    }).base;
}

var data = {
    initialize: initialize,
    update: update,
    restoreDefaults: restoreDefaults,
    processState: processState,
    getIdleSeconds: getIdleSeconds
};

const chromep$1 = new ChromePromise(), _SS_URL = "/html/screensaver.html", _ERR_SHOW = Chrome.Locale.localize("err_show_ss");

function isActive() {
    const e = Chrome.Storage.getBool("enabled"), o = Chrome.Storage.getBool("keepAwake"), t = Chrome.Storage.get("activeStart"), r = Chrome.Storage.get("activeStop"), a = Chrome.Time.isInRange(t, r);
    return !(!e || o && !a);
}

function display(e) {
    Chrome.Storage.set("isShowing", !0), !e && Chrome.Storage.getBool("allDisplays") ? _openOnAllDisplays() : _open(null);
}

function close() {
    Chrome.Storage.set("isShowing", !1), Chrome.Msg.send(SS_CLOSE).catch(() => {});
}

function _hasFullscreen(e) {
    return Chrome.Storage.getBool("chromeFullscreen") ? chromep$1.windows.getAll({
        populate: !1
    }).then(o => {
        let t = !1;
        const r = e ? e.bounds.left : 0, a = e ? e.bounds.top : 0;
        for (let s = 0; s < o.length; s++) {
            const n = o[s];
            if ("fullscreen" === n.state && (!e || n.top === a && n.left === r)) {
                t = !0;
                break;
            }
        }
        return Promise.resolve(t);
    }) : Promise.resolve(!1);
}

function _isShowing() {
    return Chrome.Msg.send(SS_IS_SHOWING).then(() => Promise.resolve(!0)).catch(() => Promise.resolve(!1));
}

function _open(e) {
    const o = {
        url: _SS_URL,
        type: "popup"
    };
    _hasFullscreen(e).then(t => {
        if (t) return null;
        if (Chrome.Utils.getChromeVersion() >= 44 && !e) o.state = "fullscreen"; else {
            const t = e ? e.bounds.left : 0, r = e ? e.bounds.top : 0;
            o.left = t, o.top = r, o.width = 1, o.height = 1;
        }
        return chromep$1.windows.create(o);
    }).then(e => (e && "fullscreen" !== o.state && chrome.windows.update(e.id, {
        state: "fullscreen"
    }), e)).then(e => (e && chrome.windows.update(e.id, {
        focused: !0
    }), null)).catch(e => {
        Chrome.Log.error(e.message, "SSControl._open", _ERR_SHOW);
    });
}

function _openOnAllDisplays() {
    chromep$1.system.display.getInfo().then(e => {
        if (1 === e.length) _open(null); else for (const o of e) _open(o);
        return null;
    }).catch(e => {
        Chrome.Log.error(e.message, "SSControl._openOnAllDisplays", _ERR_SHOW);
    });
}

function _onIdleStateChanged(e) {
    _isShowing().then(o => {
        if ("idle" === e) isActive() && !o && display(!1); else {
            if ("locked" !== e) return Chrome.Utils.isWindows().then(e => (e || close(), null));
            close();
        }
        return null;
    }).catch(e => {
        Chrome.Log.error(e.message, "SSControl._isShowing", _ERR_SHOW);
    });
}

function _onChromeMessage(e, o, t) {
    return e.message === SS_SHOW.message && display(!0), !1;
}

function _onLoad() {
    chrome.idle.onStateChanged.addListener(_onIdleStateChanged), Chrome.Msg.listen(_onChromeMessage);
}

window.addEventListener("load", _onLoad);

var ss_controller = {
    isActive: isActive,
    display: display,
    close: close
};

const chromep$2 = new ChromePromise(), _ALARMS = {
    ACTIVATE: "ACTIVATE",
    DEACTIVATE: "DEACTIVATE",
    UPDATE_PHOTOS: "UPDATE_PHOTOS",
    BADGE_TEXT: "BADGE_TEXT"
};

function updateRepeatingAlarms() {
    const e = Chrome.Storage.getBool("keepAwake"), o = Chrome.Storage.get("activeStart", "00:00"), t = Chrome.Storage.get("activeStop", "00:00");
    if (e && o !== t) {
        const e = Chrome.Time.getTimeDelta(o), r = Chrome.Time.getTimeDelta(t);
        chrome.alarms.create(_ALARMS.ACTIVATE, {
            delayInMinutes: e,
            periodInMinutes: Chrome.Time.MIN_IN_DAY
        }), chrome.alarms.create(_ALARMS.DEACTIVATE, {
            delayInMinutes: r,
            periodInMinutes: Chrome.Time.MIN_IN_DAY
        }), Chrome.Time.isInRange(o, t) ? Chrome.Storage.set("isAwake", !0) : _setInactiveState();
    } else chrome.alarms.clear(_ALARMS.ACTIVATE), chrome.alarms.clear(_ALARMS.DEACTIVATE);
    chromep$2.alarms.get(_ALARMS.UPDATE_PHOTOS).then(e => (e || chrome.alarms.create(_ALARMS.UPDATE_PHOTOS, {
        when: Date.now() + Chrome.Time.MSEC_IN_DAY,
        periodInMinutes: Chrome.Time.MIN_IN_DAY
    }), null)).catch(e => {
        Chrome.Log.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
    });
}

function updateBadgeText() {
    chrome.alarms.create(_ALARMS.BADGE_TEXT, {
        when: Date.now() + 1e3
    });
}

function _setActiveState() {
    Chrome.Storage.set("isAwake", !0), Chrome.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
    const e = getIdleSeconds();
    chromep$2.idle.queryState(e).then(e => (Chrome.Storage.getBool("enabled") && "idle" === e && display(!1), 
    null)).catch(e => {
        Chrome.Log.error(e.message, "Alarm._setActiveState");
    }), updateBadgeText();
}

function _setInactiveState() {
    Chrome.Storage.set("isAwake", !1), Chrome.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
    close(), updateBadgeText();
}

function _setBadgeText() {
    let e = "";
    e = Chrome.Storage.getBool("enabled") ? isActive() ? "" : Chrome.Locale.localize("sleep_abbrev") : Chrome.Storage.getBool("keepAwake") ? Chrome.Locale.localize("power_abbrev") : Chrome.Locale.localize("off_abbrev"), 
    chrome.browserAction.setBadgeText({
        text: e
    });
}

function _onAlarm(e) {
    switch (e.name) {
      case _ALARMS.ACTIVATE:
        _setActiveState();
        break;

      case _ALARMS.DEACTIVATE:
        _setInactiveState();
        break;

      case _ALARMS.UPDATE_PHOTOS:
        processDaily();
        break;

      case _ALARMS.BADGE_TEXT:
        _setBadgeText();
    }
}

function _onLoad$1() {
    chrome.alarms.onAlarm.addListener(_onAlarm);
}

window.addEventListener("load", _onLoad$1);

var alarm = {
    updateRepeatingAlarms: updateRepeatingAlarms,
    updateBadgeText: updateBadgeText
};

const _DISPLAY_MENU = "DISPLAY_MENU", _ENABLE_MENU = "ENABLE_MENU";

function _toggleEnabled() {
    const e = Chrome.Storage.getBool("enabled", !0);
    Chrome.Storage.set("enabled", !e), processState("enabled");
}

function _onInstalled(e) {
    const o = new ChromePromise();
    o.contextMenus.create({
        type: "normal",
        id: _DISPLAY_MENU,
        title: Chrome.Locale.localize("display_now"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    }), o.contextMenus.create({
        type: "normal",
        id: _ENABLE_MENU,
        title: Chrome.Locale.localize("disable"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    }), o.contextMenus.create({
        type: "separator",
        id: "SEP_MENU",
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    });
}

function _onMenuClicked(e) {
    if (e.menuItemId === _DISPLAY_MENU) Chrome.GA.event(Chrome.GA.EVENT.MENU, `${e.menuItemId}`), 
    display(!1); else if (e.menuItemId === _ENABLE_MENU) {
        const o = Chrome.Storage.getBool("enabled");
        Chrome.GA.event(Chrome.GA.EVENT.MENU, `${e.menuItemId}: ${o}`), _toggleEnabled();
    }
}

function _onKeyCommand(e) {
    "toggle-enabled" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    _toggleEnabled()) : "show-screensaver" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    display(!1));
}

function _onLoad$2() {
    chrome.runtime.onInstalled.addListener(_onInstalled), chrome.contextMenus.onClicked.addListener(_onMenuClicked), 
    chrome.commands.onCommand.addListener(_onKeyCommand);
}

function _onSignInChanged(e, o) {
    if (Chrome.Storage.set("signedInToChrome", o), !o) {
        Chrome.GA.event(EVENT.CHROME_SIGN_OUT), Chrome.Storage.set("albumSelections", []), 
        "allowed" === Chrome.Storage.getBool("permPicasa") && Chrome.Log.error(Chrome.Locale.localize("err_chrome_signout"), "User._onSignInChanged");
    }
}

function _onLoad$3() {
    chrome.identity.onSignInChanged.addListener(_onSignInChanged);
}

function _showOptionsTab() {
    Chrome.Msg.send(Chrome.Msg.HIGHLIGHT).catch(() => {
        chrome.tabs.create({
            url: "/html/options.html"
        });
    });
}

function _onInstalled$1(e) {
    if ("install" === e.reason) Chrome.GA.event(Chrome.GA.EVENT.INSTALLED, Chrome.Utils.getVersion()), 
    initialize(), Chrome.Storage.set("isShowing", !1), _showOptionsTab(); else if ("update" === e.reason) {
        if (!DEBUG) {
            const o = e.previousVersion;
            if (Chrome.Utils.getVersion() === o) return;
            let t = !1;
            o && !o.startsWith("3") && (t = !0), t && chrome.tabs.create({
                url: "/html/update3.html"
            });
        }
        update(), Chrome.Storage.set("isShowing", !1);
    }
}

function _onStartup() {
    Chrome.GA.page("/background.html"), processState(), Chrome.Storage.set("isShowing", !1);
}

function _onIconClicked() {
    _showOptionsTab();
}

function _onStorageChanged(e) {
    processState(e.key);
}

function _onChromeMessage$1(e, o, t) {
    return e.message === Chrome.Msg.RESTORE_DEFAULTS.message ? restoreDefaults() : e.message === Chrome.Msg.STORE.message && Chrome.Storage.set(e.key, e.value), 
    !1;
}

function _onLoad$4() {
    chrome.runtime.onInstalled.addListener(_onInstalled$1), chrome.runtime.onStartup.addListener(_onStartup), 
    chrome.browserAction.onClicked.addListener(_onIconClicked), addEventListener("storage", _onStorageChanged, !1), 
    Chrome.Msg.listen(_onChromeMessage$1);
}

window.addEventListener("load", _onLoad$2), window.addEventListener("load", _onLoad$3), 
window.addEventListener("load", _onLoad$4);

export { alarm as $alarm, data as $data, ss_controller as $ssController, updateRepeatingAlarms, updateBadgeText, initialize, update, restoreDefaults, processState, getIdleSeconds, isActive, display, close };