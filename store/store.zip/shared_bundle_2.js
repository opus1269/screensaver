import { error, event, EVENT, page, localize, send, addListener, TYPE as TYPE$1, set, getInt, get, getBool, asyncSet, ChromeTime, TYPE$1 as TYPE, process, processAll, isUseKey, getSelectedSources, processDaily, DEF_WEATHER, updateUnits, update as update$1, isSignedIn, removeCachedToken, ChromeLastError, error$1, STATE, UseKey, GoogleSource, isWindows, getVersion, initialize as initialize$2, DEBUG } from "./shared_bundle_4.js";

const chromep = new ChromePromise(), DATA_VERSION = 25, DEFS = {
    version: DATA_VERSION,
    enabled: !0,
    permPicasa: STATE.notSet,
    permBackground: STATE.notSet,
    permWeather: STATE.notSet,
    allowBackground: !1,
    idleTime: {
        base: 5,
        display: 5,
        unit: 0
    },
    transitionTime: {
        base: 30,
        display: 30,
        unit: 0
    },
    skip: !0,
    shuffle: !0,
    photoSizing: 0,
    photoTransition: 1,
    interactive: !1,
    showTime: 2,
    largeTime: !1,
    showPhotog: !0,
    showLocation: !0,
    background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
    keepAwake: !1,
    chromeFullscreen: !0,
    allDisplays: !1,
    activeStart: "00:00",
    activeStop: "00:00",
    allowSuspend: !1,
    allowPhotoClicks: !0,
    useSpaceReddit: !1,
    useEarthReddit: !1,
    useAnimalReddit: !1,
    useInterestingFlickr: !1,
    useChromecast: !0,
    useAuthors: !1,
    fullResGoogle: !1,
    isAlbumMode: !0,
    useGoogle: !0,
    useGoogleAlbums: !0,
    useGooglePhotos: !1,
    signedInToChrome: !0,
    googlePhotosNoFilter: !0,
    googlePhotosFilter: GoogleSource.DEF_FILTER,
    location: {
        lat: 0,
        lon: 0
    },
    showCurrentWeather: !1,
    weatherTempUnit: 0,
    currentWeather: DEF_WEATHER,
    panAndScan: !1
};

async function initialize() {
    try {
        addDefaults(), await setOS();
        const e = await isSignedIn();
        set("signedInToChrome", e), await ChromeLastError.reset(), set("showTime", getTimeFormat()), 
        set("weatherTempUnit", getTempUnit()), await processState();
    } catch (e) {
        error(e.message, "AppData.initialize");
    }
}

async function update() {
    const e = getInt("version");
    if ((Number.isNaN(e) || DATA_VERSION > e) && set("version", DATA_VERSION), !Number.isNaN(e)) {
        if (e < 8 && (convertSliderValue("transitionTime"), convertSliderValue("idleTime")), 
        e < 10) {
            const e = localStorage.getItem("os");
            e && set("os", e);
        }
        if (e < 12 && set("permPicasa", "allowed"), e < 14 && (set("permBackground", "allowed"), 
        set("allowBackground", !0)), e < 18) {
            set("permPicasa", "notSet");
            try {
                await removeCachedToken(!1);
            } catch (e) {}
            set("albumSelections", []);
        }
    }
    if (e < 19 && (set("useEditors500px", null), set("usePopular500px", null), set("useYesterday500px", null), 
    set("editors500pxImages", null), set("popular500pxImages", null), set("yesterday500pxImages", null)), 
    e < 20) {
        try {
            const e = await isSignedIn();
            set("signedInToChrome", e);
        } catch (e) {}
        const e = get("transitionTime", DEFS.transitionTime);
        0 === e.unit && (e.base = Math.max(10, e.base), e.display = e.base, set("transitionTime", e));
    }
    if (e < 21) try {
        await updateToChromeLocaleStorage();
    } catch (e) {}
    if (e < 22 && (set("gPhotosNeedsUpdate", null), set("gPhotosMaxAlbums", null), set("isAwake", null), 
    set("isShowing", null), set("albumSelections", null)), e < 23 && set("googleImages", null), 
    e < 25) {
        const e = UseKey.CHROMECAST;
        if (getBool(e, DEFS[e])) try {
            await process(e);
        } catch (t) {
            set(e, !1);
            try {
                await chromep.storage.local.remove(this._photosKey);
            } catch (e) {}
        }
    }
    addDefaults();
    try {
        await processState();
    } catch (e) {}
}

async function restoreDefaults() {
    for (const e of Object.keys(DEFS)) e.includes("useGoogle") || "useGoogleAlbums" === e || "useGooglePhotos" === e || "signedInToChrome" === e || "isAlbumMode" === e || "googlePhotosFilter" === e || "permPicasa" === e || set(e, DEFS[e]);
    set("showTime", getTimeFormat()), set("weatherTempUnit", getTempUnit());
    try {
        await processState();
    } catch (e) {}
}

async function processState(e = "all") {
    try {
        if ("all" === e) {
            await processEnabled(), processKeepAwake(), processIdleTime(), await updatePhotoAlarm(), 
            await updateWeatherAlarm();
            try {
                await processAll(!1);
            } catch (e) {}
            get("os") || await setOS();
        } else if (isUseKey(e) || "fullResGoogle" === e) {
            if ("fullResGoogle" === e) {
                if (getBool(UseKey.ALBUMS_GOOGLE, DEFS.useGoogleAlbums)) {
                    const e = UseKey.ALBUMS_GOOGLE;
                    try {
                        await process(e);
                    } catch (t) {
                        const a = TYPE.PHOTO_SOURCE_FAILED;
                        a.key = e, a.error = t.message, send(a).catch(() => {});
                    }
                }
                if (getBool(UseKey.PHOTOS_GOOGLE, DEFS.useGooglePhotos)) {
                    const e = UseKey.PHOTOS_GOOGLE;
                    try {
                        await process(e);
                    } catch (t) {
                        const a = TYPE.PHOTO_SOURCE_FAILED;
                        a.key = e, a.error = t.message, send(a).catch(() => {});
                    }
                }
            } else if (e !== UseKey.ALBUMS_GOOGLE && e !== UseKey.PHOTOS_GOOGLE) try {
                await process(e);
            } catch (t) {
                const a = TYPE.PHOTO_SOURCE_FAILED;
                a.key = e, a.error = t.message, send(a).catch(() => {});
            }
        } else switch (e) {
          case "enabled":
            await processEnabled();
            break;

          case "idleTime":
            processIdleTime();
            break;

          case "keepAwake":
          case "activeStart":
          case "activeStop":
          case "allowSuspend":
            processKeepAwake();
            break;

          case "weatherTempUnit":
            await updateUnits();
        }
    } catch (e) {
        error(e.message, "AppData.processState");
    }
}

function getIdleSeconds() {
    return 60 * get("idleTime", DEFS.idleTime).base;
}

async function updateToChromeLocaleStorage() {
    const e = getSelectedSources();
    for (const t of e) {
        const e = t.getPhotosKey(), a = get(e);
        if (a) {
            if (!await asyncSet(e, a)) {
                const e = t.getDesc();
                error$1(`Failed to move source: ${e} to chrome.storage`, "AppData.updateToChromeLocaleStorage");
            }
            set(e, null);
        }
    }
}

async function processEnabled() {
    updateBadgeText();
    const e = getBool("enabled", DEFS.enabled);
    try {
        const t = localize(e ? "disable" : "enable");
        await chromep.contextMenus.update("ENABLE_MENU", {
            title: t
        });
    } catch (e) {}
}

function processKeepAwake() {
    getBool("keepAwake", DEFS.keepAwake) ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
    updateKeepAwakeAlarm();
}

function processIdleTime() {
    chrome.idle.setDetectionInterval(getIdleSeconds());
}

function getTimeFormat() {
    return "12" === localize("time_format", "12") ? 1 : 2;
}

function getTempUnit() {
    return "C" === localize("temp_unit", "C") ? 0 : 1;
}

async function setOS() {
    try {
        const e = await chromep.runtime.getPlatformInfo();
        set("os", e.os);
    } catch (e) {
        set("os", "unknown"), error(e.message, "AppData.setOS");
    }
}

function addDefaults() {
    for (const e of Object.keys(DEFS)) null === get(e) && set(e, DEFS[e]);
}

function convertSliderValue(e) {
    const t = get(e);
    if (t) {
        set(e, {
            base: t,
            display: t,
            unit: 0
        });
    }
}

var data = {
    DEFS: DEFS,
    initialize: initialize,
    update: update,
    restoreDefaults: restoreDefaults,
    processState: processState,
    getIdleSeconds: getIdleSeconds
};

const chromep$1 = new ChromePromise(), SS_URL = "/html/screensaver.html", ERR_SHOW = localize("err_show_ss");

function isActive() {
    const e = getBool("enabled"), t = getBool("keepAwake"), a = get("activeStart"), s = get("activeStop"), o = ChromeTime.isInRange(a, s);
    return !(!e || t && !o);
}

async function display(e) {
    try {
        const t = getBool("allDisplays", DEFS.allDisplays);
        !e && t ? await openOnAllDisplays() : await open(null);
    } catch (e) {
        error$1(e.message, "SSControl.display");
    }
}

function close() {
    send(TYPE.SS_CLOSE).catch(() => {});
}

async function hasFullscreen(e) {
    let t = !1;
    const a = getBool("chromeFullscreen", DEFS.chromeFullscreen);
    try {
        if (a) {
            const a = await chromep$1.windows.getAll({
                populate: !1
            }), s = e ? e.bounds.left : 0, o = e ? e.bounds.top : 0;
            for (const n of a) if ("fullscreen" === n.state && (!e || n.top === o && n.left === s)) {
                t = !0;
                break;
            }
        }
    } catch (e) {
        error(e.message, "SSController.hasFullscreen");
    }
    return t;
}

async function isShowing() {
    try {
        return await send(TYPE.SS_IS_SHOWING), !0;
    } catch (e) {
        return !1;
    }
}

async function open(e) {
    const t = {
        url: SS_URL,
        type: "popup"
    };
    try {
        if (await hasFullscreen(e)) return;
        e ? (t.left = e.bounds.left, t.top = e.bounds.top, t.width = e.bounds.width, t.height = e.bounds.height) : t.state = "fullscreen";
        const a = await chromep$1.windows.create(t);
        a && (e && await chromep$1.windows.update(a.id, {
            state: "fullscreen"
        }), await chromep$1.windows.update(a.id, {
            focused: !0
        }));
    } catch (e) {
        error$1(e.message, "SSControl._open", ERR_SHOW);
    }
}

async function openOnAllDisplays() {
    try {
        const e = await chromep$1.system.display.getInfo();
        if (1 === e.length) await open(null); else for (const t of e) await open(t);
    } catch (e) {
        error$1(e.message, "SSControl.openOnAllDisplays", ERR_SHOW);
    }
}

async function onIdleStateChanged(e) {
    try {
        const t = await isShowing();
        if ("idle" === e) isActive() && !t && await display(!1); else if ("locked" === e) close(); else {
            await isWindows() || close();
        }
    } catch (e) {
        error(e.message, "SSControl.onIdleStateChanged");
    }
}

function onChromeMessage(e, t, a) {
    let s = !1;
    return e.message === TYPE.SS_SHOW.message && (s = !0, display(!1).catch(() => {})), 
    s;
}

chrome.idle.onStateChanged.addListener(onIdleStateChanged), addListener(onChromeMessage);

var ss_controller = {
    isActive: isActive,
    display: display,
    close: close
};

const chromep$2 = new ChromePromise(), ALARMS = {
    ACTIVATE: "ACTIVATE",
    DEACTIVATE: "DEACTIVATE",
    UPDATE_PHOTOS: "UPDATE_PHOTOS",
    BADGE_TEXT: "BADGE_TEXT",
    WEATHER: "WEATHER"
};

function updateKeepAwakeAlarm() {
    const e = getBool("keepAwake", DEFS.keepAwake), t = get("activeStart", DEFS.activeStart), a = get("activeStop", DEFS.activeStop);
    if (e && t !== a) {
        const e = ChromeTime.getTimeDelta(t), s = ChromeTime.getTimeDelta(a);
        chrome.alarms.create(ALARMS.ACTIVATE, {
            delayInMinutes: e,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), chrome.alarms.create(ALARMS.DEACTIVATE, {
            delayInMinutes: s,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        }), ChromeTime.isInRange(t, a) || setInactiveState();
    } else chrome.alarms.clear(ALARMS.ACTIVATE), chrome.alarms.clear(ALARMS.DEACTIVATE);
    updateBadgeText();
}

async function updatePhotoAlarm() {
    try {
        await chromep$2.alarms.get(ALARMS.UPDATE_PHOTOS) || chrome.alarms.create(ALARMS.UPDATE_PHOTOS, {
            when: Date.now() + ChromeTime.MSEC_IN_DAY,
            periodInMinutes: ChromeTime.MIN_IN_DAY
        });
    } catch (e) {
        error(e.message, "Alarm.updatePhotoAlarm");
    }
}

async function updateWeatherAlarm() {
    if (getBool("showCurrentWeather", DEFS.showCurrentWeather)) try {
        await chromep$2.alarms.get(ALARMS.WEATHER) || chrome.alarms.create(ALARMS.WEATHER, {
            when: Date.now(),
            periodInMinutes: 10
        });
    } catch (e) {
        error(e.message, "Alarm.updateWeatherAlarm");
    } else chrome.alarms.clear(ALARMS.WEATHER);
}

function updateBadgeText() {
    chrome.alarms.create(ALARMS.BADGE_TEXT, {
        when: Date.now() + 1e3
    });
}

async function setActiveState() {
    const e = getBool("keepAwake", DEFS.keepAwake), t = getBool("enabled", DEFS.enabled);
    e && chrome.power.requestKeepAwake("display");
    const a = getIdleSeconds();
    try {
        const e = await chromep$2.idle.queryState(a);
        t && "idle" === e && await display(!1);
    } catch (e) {
        error(e.message, "Alarm.setActiveState");
    }
    updateBadgeText();
}

function setInactiveState() {
    getBool("allowSuspend", DEFS.allowSuspend) ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
    close(), updateBadgeText();
}

function setBadgeText() {
    const e = getBool("enabled", DEFS.enabled), t = getBool("keepAwake", DEFS.keepAwake);
    let a = "";
    a = e ? isActive() ? "" : localize("sleep_abbrev") : localize(t ? "power_abbrev" : "off_abbrev"), 
    chrome.browserAction.setBadgeText({
        text: a
    });
}

async function updateWeather() {
    let e = null;
    try {
        e = await send(TYPE.SS_IS_SHOWING);
    } catch (e) {}
    e && await update$1();
}

async function onAlarm(e) {
    try {
        switch (e.name) {
          case ALARMS.ACTIVATE:
            await setActiveState();
            break;

          case ALARMS.DEACTIVATE:
            setInactiveState();
            break;

          case ALARMS.UPDATE_PHOTOS:
            try {
                await processDaily();
            } catch (e) {
                error(e.message, "Alarm.onAlarm");
            }
            break;

          case ALARMS.BADGE_TEXT:
            setBadgeText();
            break;

          case ALARMS.WEATHER:
            try {
                await updateWeather();
            } catch (e) {
                error(e.message, "Alarm.onAlarm");
            }
        }
    } catch (e) {
        error(e.message, "Alarm.onAlarm");
    }
}

chrome.alarms.onAlarm.addListener(onAlarm);

var alarm = {
    updateKeepAwakeAlarm: updateKeepAwakeAlarm,
    updatePhotoAlarm: updatePhotoAlarm,
    updateWeatherAlarm: updateWeatherAlarm,
    updateBadgeText: updateBadgeText
};

const DISPLAY_MENU = "DISPLAY_MENU", ENABLE_MENU = "ENABLE_MENU";

async function initialize$1() {
    const e = new ChromePromise();
    try {
        await e.contextMenus.create({
            type: "normal",
            id: DISPLAY_MENU,
            title: localize("display_now"),
            contexts: [ "browser_action" ]
        });
    } catch (e) {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    }
    try {
        await e.contextMenus.create({
            type: "normal",
            id: ENABLE_MENU,
            title: localize("disable"),
            contexts: [ "browser_action" ]
        });
    } catch (e) {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    }
    try {
        await e.contextMenus.create({
            type: "separator",
            id: "SEP_MENU",
            contexts: [ "browser_action" ]
        });
    } catch (e) {
        e.message.includes("duplicate id") || error(e.message, "chromep.contextMenus.create");
    }
}

async function toggleEnabled() {
    const e = getBool("enabled", !0);
    set("enabled", !e);
    try {
        await processState("enabled");
    } catch (e) {
        error(e.message, "ContextMenus.toggleEnabled");
    }
}

async function onMenuClicked(e) {
    try {
        if (e.menuItemId === DISPLAY_MENU) event(EVENT.MENU, `${e.menuItemId}`), await display(!1); else if (e.menuItemId === ENABLE_MENU) {
            const t = getBool("enabled");
            event(EVENT.MENU, `${e.menuItemId}: ${t}`), await toggleEnabled();
        }
    } catch (e) {
        error(e.message, "ContextMenus.onMenuClicked");
    }
}

async function onKeyCommand(e) {
    try {
        "toggle-enabled" === e ? (event(EVENT.KEY_COMMAND, `${e}`), await toggleEnabled()) : "show-screensaver" === e && (event(EVENT.KEY_COMMAND, `${e}`), 
        await display(!1));
    } catch (e) {
        error(e.message, "ContextMenus.onKeyCommand");
    }
}

chrome.contextMenus.onClicked.addListener(onMenuClicked), chrome.commands.onCommand.addListener(onKeyCommand);

var context_menus = {
    initialize: initialize$1
};

async function onSignInChanged(e, t) {
    if (t) set("signedInToChrome", t); else {
        if (await isSignedIn()) return;
        set("signedInToChrome", t);
        try {
            await asyncSet("albumSelections", []), await asyncSet("googleImages", []);
        } catch (e) {
            error(e.message, "User.onSignInChanged");
        }
        "allowed" === get("permPicasa", "notSet") && error$1(localize("err_chrome_signout"), "User.onSignInChanged");
    }
}

async function showOptionsTab() {
    try {
        await send(TYPE$1.HIGHLIGHT);
    } catch (e) {
        chrome.tabs.create({
            url: "/html/options.html"
        });
    }
}

async function onInstalled(e) {
    try {
        await initialize$1();
    } catch (e) {
        error(e, "BG.onInstalled");
    }
    if ("install" === e.reason) {
        event(EVENT.INSTALLED, getVersion());
        try {
            await initialize(), await showOptionsTab();
        } catch (e) {
            error(e.message, "Bg.onInstalled");
        }
    } else if ("update" === e.reason) {
        if (!DEBUG) {
            const t = e.previousVersion;
            if (getVersion() === t) return;
            let a = !1;
            t && !t.startsWith("3") && (a = !0), a && chrome.tabs.create({
                url: "/html/update3.html"
            });
        }
        try {
            await update();
        } catch (e) {
            error(e.message, "Bg.onUpdated");
        }
    }
}

async function onStartup() {
    page("/background.html");
    try {
        await processState();
    } catch (e) {
        error(e.message, "Bg.onStartup");
    }
}

async function onIconClicked() {
    try {
        await showOptionsTab();
    } catch (e) {
        error(e.message, "Bg.onIconClicked");
    }
}

async function onStorageChanged(e) {
    try {
        await processState(e.key);
    } catch (e) {
        error(e.message, "Bg.onStorageChanged");
    }
}

function onChromeMessage$1(e, t, a) {
    let s = !1;
    return e.message === TYPE$1.RESTORE_DEFAULTS.message ? (s = !0, restoreDefaults().catch(() => {})) : e.message === TYPE$1.STORE.message ? set(e.key, e.value) : e.message === TYPE.LOAD_FILTERED_PHOTOS.message ? (s = !0, 
    GoogleSource.loadFilteredPhotos(!0, !0).then(e => (a(e), null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === TYPE.LOAD_ALBUM.message ? (s = !0, GoogleSource.loadAlbum(e.id, e.name, !0, !0).then(e => (a(e), 
    null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === TYPE.LOAD_ALBUMS.message ? (s = !0, GoogleSource.loadAlbums(!0, !0).then(e => (a(e), 
    null)).catch(e => {
        a({
            message: e.message
        });
    })) : e.message === TYPE.UPDATE_WEATHER_ALARM.message ? (s = !0, updateWeatherAlarm().then(() => (a({
        message: "OK"
    }), null)).catch(e => {
        a({
            errorMessage: e.message
        });
    })) : e.message === TYPE.UPDATE_WEATHER.message && (s = !0, update$1().then(() => (a({
        message: "OK"
    }), null)).catch(e => {
        a({
            errorMessage: e.message
        });
    })), s;
}

chrome.identity.onSignInChanged.addListener(onSignInChanged), initialize$2(), chrome.runtime.onInstalled.addListener(onInstalled), 
chrome.runtime.onStartup.addListener(onStartup), chrome.browserAction.onClicked.addListener(onIconClicked), 
window.addEventListener("storage", onStorageChanged, !1), addListener(onChromeMessage$1);

export { alarm as $alarm, context_menus as $contextMenus, data as $data, ss_controller as $ssController, DEFS, close, display, getIdleSeconds, initialize$1 as initialize, initialize as initialize$1, isActive, processState, restoreDefaults, update, updateBadgeText, updateKeepAwakeAlarm, updatePhotoAlarm, updateWeatherAlarm };