/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const e = "https://api.flickr.com/services/rest/", o = "1edd9926740f0e0d01d4ecd42de60ac6";
    app.FlickrSource = class extends app.PhotoSource {
        constructor(e, o, t, r, s, n, i = null) {
            super(e, o, t, r, s, n, i);
        }
        static _processPhotos(e) {
            if (!e.photos || !e.photos.photo) {
                const e = new Error(Chrome.Locale.localize("err_photo_source_title"));
                return Promise.reject(e);
            }
            const o = [];
            for (const t of e.photos.photo) {
                let e, r, s = null;
                if (t && "photo" === t.media && "0" !== t.isfriend && "0" !== t.isfamily && (s = t.url_k || s, 
                s = t.url_o || s)) {
                    t.url_o ? (e = parseInt(t.width_o, 10), r = parseInt(t.height_o, 10)) : (e = parseInt(t.width_k, 10), 
                    r = parseInt(t.height_k, 10));
                    const n = e / r;
                    let i = null;
                    t.latitude && t.longitude && (i = app.PhotoSource.createPoint(t.latitude, t.longitude)), 
                    app.PhotoSource.addPhoto(o, s, t.ownername, n, t.owner, i);
                }
            }
            return Promise.resolve(o);
        }
        fetchPhotos() {
            let t;
            if (this._loadArg) {
                t = `${e}?method=flickr.people.getPublicPhotos` + `&api_key=${o}&user_id=${"86149994@N06"}` + "&extras=owner_name,url_o,media,geo&per_page=250&format=json&nojsoncallback=1";
            } else t = `${e}?method=flickr.interestingness.getList` + `&api_key=${o}&extras=owner_name,url_k,media,geo` + "&per_page=250&format=json&nojsoncallback=1";
            return Chrome.Http.doGet(t).then(e => "ok" !== e.stat ? Promise.reject(new Error(e.message)) : app.FlickrSource._processPhotos(e));
        }
    };
}();