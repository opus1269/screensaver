/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.PhotoSource = class {
        constructor(e, o, t, r, s, i, a = null) {
            this._useKey = e, this._photosKey = o, this._type = t, this._desc = r, this._isDaily = s, 
            this._isArray = i, this._loadArg = a;
        }
        static createSource(e) {
            switch (e) {
              case app.PhotoSources.UseKey.ALBUMS_GOOGLE:
                return new app.GoogleSource(e, "albumSelections", "Google User", Chrome.Locale.localize("google_title_photos"), !0, !0, null);

              case app.PhotoSources.UseKey.PHOTOS_GOOGLE:
                return new app.GoogleSource(e, "googleImages", "Google User", "NOT IMPLEMENTED", !0, !1, null);

              case app.PhotoSources.UseKey.CHROMECAST:
                return new app.CCSource(e, "ccImages", "Google", Chrome.Locale.localize("setting_chromecast"), !1, !1, null);

              case app.PhotoSources.UseKey.INT_FLICKR:
                return new app.FlickrSource(e, "flickrInterestingImages", "flickr", Chrome.Locale.localize("setting_flickr_int"), !0, !1, !1);

              case app.PhotoSources.UseKey.AUTHOR:
                return new app.FlickrSource(e, "authorImages", "flickr", Chrome.Locale.localize("setting_mine"), !1, !1, !0);

              case app.PhotoSources.UseKey.SPACE_RED:
                return new app.RedditSource(e, "spaceRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_space"), !0, !1, "r/spaceporn/");

              case app.PhotoSources.UseKey.EARTH_RED:
                return new app.RedditSource(e, "earthRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_earth"), !0, !1, "r/EarthPorn/");

              case app.PhotoSources.UseKey.ANIMAL_RED:
                return new app.RedditSource(e, "animalRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_animal"), !0, !1, "r/animalporn/");

              default:
                return Chrome.Log.error(`Bad PhotoSource type: ${e}`, "SSView.createView"), null;
            }
        }
        static addPhoto(e, o, t, r, s, i = "") {
            const a = {
                url: o,
                author: t,
                asp: r.toPrecision(3)
            };
            s && (a.ex = s), i && !Chrome.Utils.isWhiteSpace(i) && (a.point = i), e.push(a);
        }
        static createPoint(e, o) {
            return "number" == typeof e && "number" == typeof o ? `${e.toFixed(6)} ${o.toFixed(6)}` : `${e} ${o}`;
        }
        fetchPhotos() {}
        getType() {
            return this._type;
        }
        isDaily() {
            return this._isDaily;
        }
        getPhotos() {
            let e = {
                type: this._type,
                photos: []
            };
            if (this.use()) {
                let o = [];
                if (this._isArray) {
                    let e = Chrome.Storage.get(this._photosKey);
                    e = e || [];
                    for (const t of e) o = o.concat(t.photos);
                } else o = (o = Chrome.Storage.get(this._photosKey)) || [];
                e.photos = o;
            }
            return e;
        }
        use() {
            return Chrome.Storage.getBool(this._useKey);
        }
        process() {
            if (this.use()) return this.fetchPhotos().then(e => {
                const o = this._savePhotos(e);
                return Chrome.Utils.isWhiteSpace(o) ? Promise.resolve() : Promise.reject(new Error(o));
            }).catch(e => {
                let o = Chrome.Locale.localize("err_photo_source_title");
                return o += `: ${this._desc}`, Chrome.Log.error(e.message, "PhotoSource.process", o), 
                Promise.reject(e);
            });
            {
                const e = Chrome.Storage.getBool("useGoogle");
                return ("albumSelections" !== this._photosKey || e) && localStorage.removeItem(this._photosKey), 
                Promise.resolve();
            }
        }
        _savePhotos(e) {
            let o = null;
            const t = this._useKey;
            if (e && e.length) {
                Chrome.Storage.safeSet(this._photosKey, e, t) || (o = "Exceeded storage capacity.");
            }
            return o;
        }
    };
}();