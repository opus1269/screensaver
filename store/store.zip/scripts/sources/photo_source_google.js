/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler();
    const t = "https://photoslibrary.googleapis.com/v1/";
    app.GoogleSource = class extends app.PhotoSource {
        constructor(t, e, o, s, a, r, n = null) {
            super(t, e, o, s, a, r, n);
        }
        static isQuotaError(t, e) {
            let o = !1;
            const s = `${Chrome.Locale.localize("err_status")}: 429`;
            return t.message.includes(s) && (Chrome.Log.error(t.message, e, Chrome.Locale.localize("err_google_quota")), 
            o = !0), o;
        }
        static _isImage(t) {
            return t && t.mimeType && t.mimeType.startsWith("image/") && t.mediaMetadata && t.mediaMetadata.width && t.mediaMetadata.height;
        }
        static _getImageSize(t) {
            const e = {};
            if (e.width = parseInt(t.width), e.height = parseInt(t.height), !Chrome.Storage.getBool("fullResGoogle")) {
                const t = Math.max(1600, e.width, e.height);
                t > 1600 && (e.width === t ? (e.width = 1600, e.height = Math.round(e.height * (1600 / t))) : (e.height = 1600, 
                e.width = Math.round(e.width * (1600 / t))));
            }
            return e;
        }
        static _processPhoto(t, e) {
            let o = null;
            if (t && t.mediaMetadata && this._isImage(t)) {
                const s = t.mediaMetadata, a = this._getImageSize(s), r = a.width, n = a.height;
                (o = {}).url = `${t.baseUrl}=w${r}-h${n}`, o.asp = r / n, o.author = e, o.ex = {
                    id: t.id,
                    url: t.productUrl
                }, o.point = null;
            }
            return o;
        }
        static _processPhotos(t, e) {
            const o = [];
            if (!t) return o;
            for (const s of t) {
                const t = this._processPhoto(s, e);
                t && this.addPhoto(o, t.url, t.author, t.asp, t.ex, t.point);
            }
            return o;
        }
        static async loadPhotos(e) {
            let o = [];
            if (0 === (e = e || []).length) return o;
            const s = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            s.isAuth = !0, s.retryToken = !0, s.interactive = !1;
            let a = !1, r = 0, n = Math.min(50, e.length), h = 0;
            do {
                let l = `${t}mediaItems:batchGet`, i = "?mediaItemIds=", c = !0;
                for (let t = r; t < n; t++) c ? (i = i.concat(e[t]), c = !1) : i = i.concat(`&mediaItemIds=${e[t]}`);
                l = l.concat(i);
                try {
                    const t = await Chrome.Http.doGet(l, s);
                    h++;
                    const e = [];
                    for (const o of t.mediaItemResults) o.status || e.push(o.mediaItem);
                    const a = this._processPhotos(e, "");
                    o = o.concat(a);
                } catch (t) {
                    throw this.isQuotaError(t, "GoogleSource.loadPhotos") || Chrome.Log.error(t.message, "GoogleSource.loadPhotos"), 
                    t;
                }
                n === e.length ? a = !0 : (r = n, n = Math.min(n + 50, e.length));
            } while (!a);
            return Chrome.GA.event(app.GA.EVENT.LOAD_PHOTOS, `nPhotos: ${o.length}, nCalls: ${h}`), 
            o;
        }
        static async loadAlbum(e, o, s = !0) {
            const a = `${t}mediaItems:search`, r = {
                pageSize: 100
            };
            r.albumId = e;
            const n = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            let h;
            n.isAuth = !0, n.retryToken = !0, n.interactive = s, n.body = r;
            let l = [];
            try {
                let t = 0;
                do {
                    const e = await Chrome.Http.doPost(a, n);
                    h = e.nextPageToken, n.body.pageToken = h;
                    const s = e.mediaItems;
                    if (s) {
                        const e = this._processPhotos(s, o);
                        l = l.concat(e), t += e.length;
                    }
                    t >= 500 && Chrome.GA.event(app.GA.EVENT.PHOTOS_LIMITED, "nPhotos: 500");
                } while (h && !(t >= 500));
                const s = {
                    index: 0,
                    uid: "album0"
                };
                return s.name = o, s.id = e, s.thumb = "", s.checked = !0, s.photos = l, s.ct = l.length, 
                Chrome.GA.event(app.GA.EVENT.LOAD_ALBUM, `nPhotos: ${s.ct}`), s;
            } catch (t) {
                throw t;
            }
        }
        static async loadAlbumList() {
            let e, o = [], s = [], a = 0;
            const r = `${t}albums/?pageSize=50`;
            let n = r;
            const h = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            h.isAuth = !0, h.retryToken = !0, h.interactive = !0;
            try {
                do {
                    let t = await Chrome.Http.doGet(n, h);
                    if (e = (t = t || {}).nextPageToken, !(t.albums && 0 !== t.albums.length || 0 !== o.length || e)) throw new Error(Chrome.Locale.localize("err_no_albums"));
                    n = `${r}&pageToken=${e}`, t.albums && t.albums.length > 0 && (o = o.concat(t.albums));
                } while (e);
            } catch (t) {
                throw t;
            }
            for (const t of o) if (t && t.mediaItemsCount && t.mediaItemsCount > 0) {
                const e = {};
                e.index = a, e.uid = "album" + a, e.name = t.title, e.id = t.id, e.ct = t.mediaItemsCount, 
                e.thumb = `${t.coverPhotoBaseUrl}=w76-h76`, e.checked = !1, e.photos = [], s.push(e), 
                a++;
            }
            return Chrome.GA.event(app.GA.EVENT.LOAD_ALBUM_LIST, `nAlbums: ${s.length}`), s;
        }
        static updateBaseUrls(t) {
            let e = !0;
            if (0 === (t = t || []).length) return e;
            const o = Chrome.Storage.get("albumSelections", []);
            if (0 === o.length) return e;
            let s = 0;
            for (const e of t) for (const t of o) {
                const o = t.photos, a = o.findIndex(t => t.ex.id === e.ex.id);
                a >= 0 && (o[a].url = e.url, s++);
            }
            return Chrome.Storage.safeSet("albumSelections", o, null) ? Chrome.GA.event(app.GA.EVENT.UPDATE_BASE_URLS, `nUpdated: ${s}`) : (e = !1, 
            Chrome.Log.error("Exceed storage limits", "GoogleSource.updateBaseUrls")), e;
        }
        static _isFetchAlbums() {
            const t = "allowed" === Chrome.Storage.get("permPicasa", "notSet"), e = Chrome.Storage.getBool("enabled", !0), o = Chrome.Storage.getBool("useGoogle", !0), s = Chrome.Storage.getBool("useGoogleAlbums", !0);
            return t && e && o && s;
        }
        static _fetchAlbums() {
            const t = Chrome.Storage.get("albumSelections", []);
            if (!this._isFetchAlbums() || 0 === t.length) return Promise.resolve(t);
            const e = [];
            for (const o of t) e.push(app.GoogleSource.loadAlbum(o.id, o.name, !1));
            return Promise.all(e).then(t => {
                let e = 0;
                const o = [];
                for (const s of t) {
                    const t = s.photos;
                    t && t.length && (o.push({
                        id: s.id,
                        name: s.name,
                        photos: t
                    }), e += t.length);
                }
                return Chrome.GA.event(app.GA.EVENT.FETCH_ALBUMS, `nAlbums: ${o.length} nPhotos: ${e}`), 
                Promise.resolve(o);
            });
        }
        fetchPhotos() {
            return app.GoogleSource._fetchAlbums();
        }
    };
}();