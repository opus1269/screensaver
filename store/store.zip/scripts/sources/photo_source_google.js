/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler();
    const e = "https://photoslibrary.googleapis.com/v1/";
    app.GoogleSource = class extends app.PhotoSource {
        constructor(e, t, o, s, r, a, h = null) {
            super(e, t, o, s, r, a, h);
        }
        static isQuotaError(e, t) {
            let o = !1;
            const s = `${Chrome.Locale.localize("err_status")}: 429`;
            return e.message.includes(s) && (Chrome.Log.error(e.message, t, Chrome.Locale.localize("err_google_quota")), 
            o = !0), o;
        }
        static _isImage(e) {
            return e && e.mimeType && e.mimeType.startsWith("image/") && e.mediaMetadata && e.mediaMetadata.width && e.mediaMetadata.height;
        }
        static _getImageSize(e) {
            const t = {};
            if (t.width = parseInt(e.width), t.height = parseInt(e.height), !Chrome.Storage.getBool("fullResGoogle")) {
                const e = Math.max(1600, t.width, t.height);
                e > 1600 && (t.width === e ? (t.width = 1600, t.height = Math.round(t.height * (1600 / e))) : (t.height = 1600, 
                t.width = Math.round(t.width * (1600 / e))));
            }
            return t;
        }
        static _processPhoto(e, t) {
            let o = null;
            if (e && e.mediaMetadata && this._isImage(e)) {
                const s = e.mediaMetadata, r = this._getImageSize(s), a = r.width, h = r.height;
                (o = {}).url = `${e.baseUrl}=w${a}-h${h}`, o.asp = a / h, o.author = t, o.ex = {
                    id: e.id,
                    url: e.productUrl
                }, o.point = null;
            }
            return o;
        }
        static _processPhotos(e, t) {
            const o = [];
            if (!e) return o;
            for (const s of e) {
                const e = this._processPhoto(s, t);
                e && this.addPhoto(o, e.url, e.author, e.asp, e.ex, e.point);
            }
            return o;
        }
        static async loadPhoto(t, o = !1) {
            const s = `${e}mediaItems/${t}`, r = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            r.isAuth = !0, r.retryToken = !0, r.interactive = o;
            try {
                Chrome.GA.event(app.GA.EVENT.LOAD_PHOTO);
                const e = await Chrome.Http.doGet(s, r);
                if (e) return this._processPhoto(e, "");
            } catch (e) {
                this.isQuotaError(e, "GoogleSource.loadPhoto") || Chrome.Log.error(e.message, "GoogleSource.loadPhoto");
            }
            return null;
        }
        static async loadAlbum(t, o, s = !0) {
            const r = `${e}mediaItems:search`, a = {
                pageSize: "100"
            };
            a.albumId = t;
            const h = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            let i;
            h.isAuth = !0, h.retryToken = !0, h.interactive = s, h.body = a;
            const n = {};
            let l = [];
            try {
                Chrome.GA.event(app.GA.EVENT.LOAD_ALBUM);
                let e = 0;
                do {
                    const t = await Chrome.Http.doPost(r, h);
                    i = t.nextPageToken, h.body.pageToken = i;
                    const s = t.mediaItems;
                    if (s) {
                        const t = this._processPhotos(s, o);
                        l = l.concat(t), e += t.length;
                    }
                    e >= 500 && Chrome.GA.event(app.GA.EVENT.PHOTOS_LIMITED);
                } while (i && !(e >= 500));
                return n.index = 0, n.uid = "album0", n.name = o, n.id = t, n.thumb = "", n.checked = !0, 
                n.photos = l, n.ct = l.length, n;
            } catch (e) {
                throw e;
            }
        }
        static async loadAlbumList() {
            let t, o = [], s = [], r = 0;
            const a = `${e}albums/?pageSize=50`;
            let h = a;
            const i = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            i.isAuth = !0, i.retryToken = !0, i.interactive = !0;
            try {
                Chrome.GA.event(app.GA.EVENT.LOAD_ALBUM_LIST);
                do {
                    let e = await Chrome.Http.doGet(h, i);
                    if (t = (e = e || {}).nextPageToken, !(e.albums && 0 !== e.albums.length || 0 !== o.length || t)) throw new Error(Chrome.Locale.localize("err_no_albums"));
                    h = `${a}&pageToken=${t}`, e.albums && e.albums.length > 0 && (o = o.concat(e.albums));
                } while (t);
            } catch (e) {
                throw e;
            }
            for (const e of o) if (e && e.mediaItemsCount && e.mediaItemsCount > 0) {
                const t = `${e.coverPhotoBaseUrl}=w76-h76`, o = {};
                o.index = r, o.uid = "album" + r, o.name = e.title, o.id = e.id, o.ct = e.mediaItemsCount, 
                o.thumb = t, o.checked = !1, o.photos = [], s.push(o), r++;
            }
            return s;
        }
        static async updatePhotos(t = !1) {
            let o = !1;
            const s = Chrome.Storage.get("albumSelections", []);
            if (!(t || this._isUpdateAlbums() && 0 !== s.length)) return o;
            let r = [];
            const a = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            a.isAuth = !0, a.retryToken = !0, a.interactive = !1;
            for (const t of s) {
                const s = t.photos, h = Chrome.JSONUtils.shallowCopy(t);
                h.photos = [];
                let i = !1, n = 0, l = Math.min(50, s.length);
                do {
                    let r, c = `${e}mediaItems:batchGet`, m = "?mediaItemIds=", u = !0;
                    for (let e = n; e < l; e++) r = s[e], u ? (m = m.concat(`${r.ex.id}`), u = !1) : m = m.concat(`&mediaItemIds=${r.ex.id}`);
                    c = c.concat(m);
                    try {
                        const e = await Chrome.Http.doGet(c, a), s = [];
                        for (const t of e.mediaItemResults) t.status || s.push(t.mediaItem);
                        const r = this._processPhotos(s, t.name);
                        h.photos = h.photos.concat(r);
                    } catch (e) {
                        return this.isQuotaError(e, "GoogleSource.updatePhotos") || Chrome.Log.error(e.message, "GoogleSource.updatePhotos"), 
                        o;
                    }
                    l === s.length ? i = !0 : (n = l, l = Math.min(l + 50, s.length));
                } while (!i);
                r.push(h);
            }
            return Chrome.Storage.safeSet("albumSelections", r, null) ? (o = !0, Chrome.GA.event(app.GA.EVENT.UPDATE_PHOTOS), 
            Chrome.Storage.set("gPhotosNeedsUpdate", !1)) : Chrome.Log.error("Exceed storage limits", "GoogleSource.updatePhotos"), 
            o;
        }
        static _isUpdateAlbums() {
            const e = "allowed" === Chrome.Storage.get("permPicasa", "notSet"), t = !Chrome.Storage.getBool("isShowing", !0), o = Chrome.Storage.getBool("isAwake", !0), s = Chrome.Storage.getBool("enabled", !0), r = Chrome.Storage.getBool("useGoogle", !0), a = Chrome.Storage.getBool("useGoogleAlbums", !0), h = e && t && o && s && r && a;
            return h || Chrome.Storage.set("gPhotosNeedsUpdate", !0), h;
        }
        static _isFetchAlbums() {
            const e = "allowed" === Chrome.Storage.get("permPicasa", "notSet"), t = Chrome.Storage.getBool("enabled", !0), o = Chrome.Storage.getBool("useGoogle", !0), s = Chrome.Storage.getBool("useGoogleAlbums", !0);
            return e && t && o && s;
        }
        static _fetchAlbums() {
            const e = Chrome.Storage.get("albumSelections", []);
            if (!this._isFetchAlbums() || 0 === e.length) return Promise.resolve(e);
            Chrome.GA.event(app.GA.EVENT.FETCH_ALBUMS), Chrome.Storage.set("gPhotosNeedsUpdate", !1);
            const t = [];
            for (const o of e) t.push(app.GoogleSource.loadAlbum(o.id, o.name, !1));
            return Promise.all(t).then(e => {
                const t = [];
                for (const o of e) {
                    const e = o.photos;
                    e && e.length && t.push({
                        id: o.id,
                        name: o.name,
                        photos: e
                    });
                }
                return Promise.resolve(t);
            });
        }
        fetchPhotos() {
            return app.GoogleSource._fetchAlbums();
        }
    };
}();