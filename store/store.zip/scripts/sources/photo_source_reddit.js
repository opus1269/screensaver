/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const e = `https://${chrome.runtime.id}.chromiumapp.org/reddit`;
    let t;
    app.RedditSource = class extends app.PhotoSource {
        constructor(e, t, r, o, i, n, s = null) {
            super(e, t, r, o, i, n, s);
        }
        static _waitForLib() {
            let r = 0;
            return new Promise(function(o, i) {
                !function n() {
                    if (100 === r) i(new Error("snoocore library timed out")); else {
                        if (t) return o();
                        if (window.Snoocore) {
                            const r = window.Snoocore;
                            return t = new r({
                                userAgent: "screensaver",
                                throttle: 0,
                                oauth: {
                                    type: "implicit",
                                    key: "bATkDOUNW_tOlg",
                                    redirectUri: e,
                                    scope: [ "read" ]
                                }
                            }), o();
                        }
                        r++;
                    }
                    setTimeout(n, 100);
                }();
            });
        }
        static _getSize(e) {
            const t = {
                width: -1,
                height: -1
            }, r = e.match(/\[(\d*)\D*(\d*)\]/);
            return r && (t.width = parseInt(r[1], 10), t.height = parseInt(r[2], 10)), t;
        }
        static _processChildren(e) {
            const t = [];
            let r, o = 1, i = 1;
            for (const n of e) {
                const e = n.data;
                if (!e.over_18) if (e.preview && e.preview.images) {
                    let t = e.preview.images[0];
                    r = t.source.url.replace(/&amp;/g, "&"), o = parseInt(t.source.width, 10), i = parseInt(t.source.height, 10), 
                    Math.max(o, i) > 3500 && (r = (t = t.resolutions[t.resolutions.length - 1]).url.replace(/&amp;/g, "&"), 
                    o = parseInt(t.width, 10), i = parseInt(t.height, 10));
                } else if (e.title) {
                    const t = app.RedditSource._getSize(e.title);
                    r = e.url, o = t.width, i = t.height;
                }
                const s = o / i, c = e.author;
                s && !isNaN(s) && Math.max(o, i) >= 750 && Math.max(o, i) <= 3500 && app.PhotoSource.addPhoto(t, r, c, s, e.url);
            }
            return t;
        }
        fetchPhotos() {
            let e = [];
            return app.RedditSource._waitForLib().then(() => t(`${this._loadArg}hot`).listing({
                limit: 100
            })).then(t => (e = e.concat(app.RedditSource._processChildren(t.children)), t.next())).then(t => (e = e.concat(app.RedditSource._processChildren(t.children)), 
            Promise.resolve(e))).catch(e => {
                let t = e.message;
                if (t) {
                    const e = t.indexOf(".");
                    -1 !== e && (t = t.substring(0, e + 1));
                } else t = "Unknown Error";
                return Promise.reject(new Error(t));
            });
        }
    };
}(window);