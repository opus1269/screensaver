/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.PhotoSources = function() {
    "use strict";
    new ExceptionHandler();
    const e = {
        ALBUMS_GOOGLE: "useGoogleAlbums",
        PHOTOS_GOOGLE: "useGooglePhotos",
        CHROMECAST: "useChromecast",
        SPACE_RED: "useSpaceReddit",
        EARTH_RED: "useEarthReddit",
        ANIMAL_RED: "useAnimalReddit",
        INT_FLICKR: "useInterestingFlickr",
        AUTHOR: "useAuthors"
    };
    function o() {
        let o = [];
        for (const t in e) if (e.hasOwnProperty(t)) {
            const s = e[t];
            if (Chrome.Storage.getBool(s)) try {
                const e = app.PhotoSource.createSource(s);
                e && o.push(e);
            } catch (e) {
                Chrome.GA.exception(e, `${s} failed to load`, !1);
            }
        }
        return o;
    }
    return {
        UseKey: e,
        getUseKeys: function() {
            let o = [];
            for (const t in e) e.hasOwnProperty(t) && o.push(e[t]);
            return o;
        },
        isUseKey: function(o) {
            let t = !1;
            for (const s in e) if (e.hasOwnProperty(s) && e[s] === o) {
                t = !0;
                break;
            }
            return t;
        },
        process: function(e) {
            try {
                const o = app.PhotoSource.createSource(e);
                if (o) return o.process();
            } catch (o) {
                return Chrome.GA.exception(o, `${e} failed to load`, !1), Promise.reject(o);
            }
        },
        getSelectedPhotos: function() {
            const e = o();
            let t = [];
            for (const o of e) t.push(o.getPhotos());
            return t;
        },
        processAll: function(e = !1) {
            const t = o();
            for (const o of t) {
                let t = !1;
                "Google User" === o.getType() && (t = !e), t || o.process().catch(() => {});
            }
        },
        processDaily: function() {
            const e = o();
            for (const o of e) o.isDaily() && o.process().catch(() => {});
        }
    };
}();