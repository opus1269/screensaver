/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSEvents = function() {
    "use strict";
    new ExceptionHandler();
    const e = {
        x: null,
        y: null
    };
    function n() {
        Chrome.Storage.set("isShowing", !1), Chrome.Msg.send(app.Msg.SS_CLOSE).catch(() => {}), 
        setTimeout(() => {
            window.close();
        }, 750);
    }
    function t(e) {
        app.SSRunner.isInteractive() && ("ss-toggle-paused" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.togglePaused()) : "ss-forward" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.forward()) : "ss-back" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.back()));
    }
    function s(e, t, s) {
        return e.message === app.Msg.SS_CLOSE.message ? n() : e.message === app.Msg.SS_IS_SHOWING.message && s({
            message: "OK"
        }), !1;
    }
    function o(e) {
        const t = e.key;
        if (app.SSRunner.isStarted()) switch (t) {
          case "Alt":
          case "Shift":
          case " ":
          case "ArrowLeft":
          case "ArrowRight":
            app.SSRunner.isInteractive() || n();
            break;

          default:
            n();
        } else n();
    }
    function a(t) {
        if (e.x && e.y) {
            const s = Math.abs(t.clientX - e.x), o = Math.abs(t.clientY - e.y);
            Math.max(s, o) > 10 && n();
        } else e.x = t.clientX, e.y = t.clientY;
    }
    function i() {
        if (app.SSRunner.isStarted()) {
            const e = app.SSViews.getSelectedIndex();
            if (Chrome.Storage.getBool("allowPhotoClicks") && void 0 !== e) {
                app.SSViews.get(e).photo.showSource();
            }
        }
        n();
    }
    window.addEventListener("load", function() {
        Chrome.Msg.listen(s), window.addEventListener("keydown", o, !1), window.addEventListener("mousemove", a, !1), 
        window.addEventListener("click", i, !1), chrome.commands.onCommand.addListener(t);
    });
}();