/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSRunner = function() {
    "use strict";
    new ExceptionHandler();
    const e = {
        started: !1,
        replaceIdx: -1,
        lastSelected: -1,
        waitTime: 3e4,
        interactive: !1,
        paused: !1,
        timeOutId: 0
    };
    function t() {
        window.clearTimeout(e.timeOutId);
    }
    function n(e = null) {
        const t = Chrome.Storage.get("transitionTime");
        t && app.SSRunner.setWaitTime(1e3 * t.base), i(e);
    }
    function a(e = null) {
        app.SSRunner.isPaused() ? (app.SSRunner.togglePaused(e), app.SSRunner.togglePaused()) : (t(), 
        n(e));
    }
    function i(t = null) {
        if (app.Screensaver.noPhotos()) return;
        const n = app.SSViews.getSelectedIndex(), a = app.SSViews.getCount();
        let r = null === t ? n : t, s = (r = app.SSRunner.isStarted() ? r : 0) === a - 1 ? 0 : r + 1;
        if (app.SSRunner.isStarted() || (s = 0), -1 !== (s = app.SSFinder.getNext(s))) {
            app.SSRunner.isStarted() || (e.started = !0, app.SSTime.setTime()), app.SSViews.get(s).render(), 
            app.SSHistory.add(t, s, e.replaceIdx), e.lastSelected = n, app.SSViews.setSelectedIndex(s), 
            null === t && (app.SSFinder.replacePhoto(e.replaceIdx), e.replaceIdx = e.lastSelected);
        }
        e.timeOutId = window.setTimeout(() => {
            i();
        }, e.waitTime);
    }
    return {
        start: function(t = 2e3) {
            const n = Chrome.Storage.get("transitionTime");
            n && app.SSRunner.setWaitTime(1e3 * n.base), e.interactive = Chrome.Storage.getBool("interactive"), 
            app.SSHistory.initialize(), window.setTimeout(i, t);
        },
        getWaitTime: function() {
            return e.waitTime;
        },
        setWaitTime: function(t) {
            e.waitTime = t, e.waitTime = Math.min(2147483647, t);
        },
        setLastSelected: function(t) {
            e.lastSelected = t;
        },
        setReplaceIdx: function(t) {
            e.replaceIdx = t;
        },
        isStarted: function() {
            return e.started;
        },
        isInteractive: function() {
            return e.interactive;
        },
        isPaused: function() {
            return e.paused;
        },
        isCurrentPair: function(t) {
            return t === app.SSViews.getSelectedIndex() || t === e.lastSelected;
        },
        togglePaused: function(a = null) {
            e.started && (e.paused = !e.paused, app.Screensaver.setPaused(e.paused), e.paused ? t() : n(a));
        },
        forward: function() {
            e.started && a();
        },
        back: function() {
            if (e.started) {
                const e = app.SSHistory.back();
                null !== e && a(e);
            }
        }
    };
}();