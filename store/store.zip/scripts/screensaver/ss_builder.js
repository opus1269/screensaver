/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.SSBuilder=function(){"use strict";return new ExceptionHandler,{build:function(){const e=function(){let e=app.PhotoSources.getSelectedPhotos();e=e||[];for(const o of e)app.SSPhotos.addFromSource(o);return app.SSPhotos.getCount()?(Chrome.Storage.getBool("shuffle")&&app.SSPhotos.shuffle(),!0):(app.Screensaver.setNoPhotos(),!1)}();return e&&(app.Screensaver.createPages(),app.SSFinder.initialize()),e}}}();