/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.SSFinder=function(){"use strict";new ExceptionHandler;let e=3e4;return{initialize:function(){const t=Chrome.Storage.get("transitionTime");t&&(e=1e3*t.base)},getNext:function(t){let n=app.SSViews.findLoadedPhoto(t);return-1===n?app.SSRunner.setWaitTime(500):app.SSRunner.setWaitTime(e),n},replacePhoto:function(e){e>=0&&function(e){if(app.SSViews.isSelectedIndex(e))return;const t=app.SSViews.getCount();if(app.SSPhotos.getCount()<=t)return;const n=app.SSPhotos.getNextUsable();n&&app.SSViews.get(e).setPhoto(n)}(e)}}}();