/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSViews = function() {
    "use strict";
    new ExceptionHandler();
    const e = [];
    let t = null;
    const n = {
        UNDEFINED: -1,
        LETTERBOX: 0,
        ZOOM: 1,
        FRAME: 2,
        FULL: 3,
        RANDOM: 4
    };
    let o = n.UNDEFINED;
    function r() {
        (o = Chrome.Storage.getInt("photoSizing", 0)) === n.RANDOM && (o = Chrome.Utils.getRandomInt(0, 3));
        let e = "contain";
        switch (o) {
          case n.LETTERBOX:
            e = "contain";
            break;

          case n.ZOOM:
            e = "cover";
            break;

          case n.FRAME:
          case n.FULL:
            e = null;
        }
        app.Screensaver.setSizingType(e);
    }
    return {
        Type: n,
        create: function(n) {
            t = n.$.pages, r();
            const a = Math.min(app.SSPhotos.getCount(), 20);
            for (let t = 0; t < a; t++) {
                const n = app.SSPhotos.get(t), r = app.SSView.createView(n, o);
                e.push(r);
            }
            app.SSPhotos.setCurrentIndex(a), n.set("_views", e), n.$.repeatTemplate.render(), 
            e.forEach((e, o) => {
                const r = t.querySelector("#view" + o), a = r.querySelector(".image"), i = r.querySelector(".author"), s = r.querySelector(".time"), c = r.querySelector(".location"), p = n.$.repeatTemplate.modelForElement(r);
                e.setElements(a, i, s, c, p);
            });
        },
        getType: function() {
            return o === n.UNDEFINED && r(), o;
        },
        getCount: function() {
            return e.length;
        },
        get: function(t) {
            return e[t];
        },
        getSelectedIndex: function() {
            if (t) return t.selected;
        },
        setSelectedIndex: function(e) {
            t.selected = e;
        },
        isSelectedIndex: function(e) {
            let n = !1;
            return t && e === t.selected && (n = !0), n;
        },
        hasPhoto: function(t) {
            let n = !1;
            for (const o of e) if (o.photo.getId() === t.getId()) {
                n = !0;
                break;
            }
            return n;
        },
        hasUsable: function() {
            let t = !1;
            for (let n = 0; n < e.length; n++) {
                const o = e[n];
                if (!app.SSRunner.isCurrentPair(n) && !o.photo.isBad()) {
                    t = !0;
                    break;
                }
            }
            return t;
        },
        replaceAll: function() {
            for (let t = 0; t < e.length; t++) {
                if (app.SSRunner.isCurrentPair(t)) continue;
                const n = e[t], o = app.SSPhotos.getNextUsable();
                if (!o) break;
                n.setPhoto(o);
            }
            app.SSHistory.clear();
        },
        findLoadedPhoto: function(t) {
            if (app.SSViews.hasUsable() || app.SSViews.replaceAll(), e[t].isLoaded()) return t;
            for (let n = 0; n < e.length; n++) {
                const o = (n + t) % e.length, r = e[o];
                if (!app.SSRunner.isCurrentPair(o)) {
                    if (r.isLoaded()) return o;
                    if (r.isError() && !r.photo.isBad() && (r.photo.markBad(), !app.SSPhotos.hasUsable())) return app.Screensaver.setNoPhotos(), 
                    -1;
                }
            }
            return -1;
        }
    };
}();