/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler();
    const t = screen.width / screen.height;
    app.SSViewLetterbox = class extends app.SSView {
        constructor(t) {
            super(t);
        }
        render() {
            super.render();
            const e = this.photo.getAspectRatio(), i = this.author.style, h = this.location.style, o = this.time.style;
            let s = e / t * 100, n = (100 - (s = Math.min(s, 100))) / 2, w = t / e * 100, a = (100 - (w = Math.min(w, 100))) / 2;
            i.textAlign = "right", h.textAlign = "left", i.right = n + 1 + "vw", i.bottom = a + 1 + "vh", 
            i.width = s - .5 + "vw", h.left = n + 1 + "vw", h.bottom = a + 1 + "vh", h.width = s - .5 + "vw", 
            o.right = n + 1 + "vw", o.bottom = a + 3.5 + "vh", app.SSView.showTime() && (i.textOverflow = "ellipsis", 
            i.whiteSpace = "nowrap");
            let r = s / 2;
            this._hasLocationLabel() && (i.maxWidth = r - 1.1 + "vw"), this._hasAuthorLabel() && (h.maxWidth = r - 1.1 + "vw");
        }
    };
}();