/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const t = screen.width / screen.height;
    app.SSView = class e {
        constructor(t) {
            this.photo = t, this.image = null, this.author = null, this.time = null, this.location = null, 
            this.model = null, this.url = t.getUrl(), this.authorLabel = "", this.locationLabel = "";
        }
        static createView(t, e) {
            switch (e) {
              case app.SSViews.Type.LETTERBOX:
                return new app.SSViewLetterbox(t);

              case app.SSViews.Type.ZOOM:
                return new app.SSView(t);

              case app.SSViews.Type.FRAME:
                return new app.SSViewFrame(t);

              case app.SSViews.Type.FULL:
                return new app.SSViewFull(t);

              default:
                return Chrome.Log.error(`Bad SSView type: ${e}`, "SSView.createView"), new app.SSViewLetterbox(t);
            }
        }
        static _dirtySet(t, e, o) {
            t.set(e, o), t.notifyPath(e);
        }
        static _isBadAspect(e) {
            return e < t - .5 || e > t + .5;
        }
        static ignore(t, e) {
            let o = !1;
            const i = Chrome.Storage.getBool("skip");
            return (!t || isNaN(t) || i && (1 === e || 3 === e) && app.SSView._isBadAspect(t)) && (o = !0), 
            o;
        }
        static _showLocation() {
            return Chrome.Storage.getBool("showLocation");
        }
        static showTime() {
            return Chrome.Storage.getBool("showTime");
        }
        _hasAuthor() {
            const t = this.photo.getPhotographer();
            return !Chrome.Utils.isWhiteSpace(t);
        }
        _hasAuthorLabel() {
            return !Chrome.Utils.isWhiteSpace(this.authorLabel);
        }
        _hasLocation() {
            return !!this.photo.getPoint();
        }
        _hasLocationLabel() {
            return !Chrome.Utils.isWhiteSpace(this.locationLabel);
        }
        _setTimeStyle() {
            Chrome.Storage.getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
        }
        setUrl(t = null) {
            this.url = t || this.photo.getUrl(), e._dirtySet(this.model, "view.url", this.url);
        }
        markPhotoBad() {
            this.photo && this.photo.markBad();
        }
        _setAuthorLabel() {
            this.authorLabel = "", e._dirtySet(this.model, "view.authorLabel", this.authorLabel);
            const t = this.photo.getType(), o = this.photo.getPhotographer();
            let i = t;
            const s = t.search("User");
            (Chrome.Storage.getBool("showPhotog") || -1 === s) && (-1 !== s && (i = t.substring(0, s - 1)), 
            this._hasAuthor() ? this.authorLabel = `${o} / ${i}` : this.authorLabel = `${Chrome.Locale.localize("photo_from")} ${i}`, 
            e._dirtySet(this.model, "view.authorLabel", this.authorLabel));
        }
        _setLocationLabel() {
            if (this.locationLabel = "", e._dirtySet(this.model, "view.locationLabel", this.locationLabel), 
            app.SSView._showLocation() && this._hasLocation()) {
                const t = this.photo.getPoint();
                app.Geo.get(t).then(t => (t && this.model && (t = t.replace("Unnamed Road, ", ""), 
                this.locationLabel = t, e._dirtySet(this.model, "view.locationLabel", this.locationLabel)), 
                Promise.resolve())).catch(e => {
                    const o = Chrome.Locale.localize("err_network");
                    e.message.includes(o) || Chrome.GA.error(`${e.message}, point: ${t}`, "SSView._setLocationLabel");
                });
            }
        }
        setElements(t, e, o, i, s) {
            this.image = t, this.author = e, this.time = o, this.location = i, this.model = s, 
            this._setTimeStyle(), this.setPhoto(this.photo);
        }
        setPhoto(t) {
            this.photo = t, this.setUrl(), this._setAuthorLabel(!1), this._setLocationLabel();
        }
        render() {}
        isError() {
            return !this.image || this.image.error;
        }
        isLoaded() {
            return !!this.image && this.image.loaded;
        }
    };
}();