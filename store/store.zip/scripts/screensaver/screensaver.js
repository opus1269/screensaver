/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Screensaver = function() {
    "use strict";
    const e = document.querySelector("#t");
    e.sizingType = null, e.screenWidth = screen.width, e.screenHeight = screen.height, 
    e.aniType = 0, e.paused = !1, e.noPhotos = !1, e.noPhotosLabel = "", e.timeLabel = "";
    let o = 0, t = !1;
    return e._onErrorChanged = async function(n) {
        const s = n.detail.value;
        if (!t && s) {
            t = !0;
            const s = n.model.index, a = e._views[s].photo;
            if ("Google User" === a.getType()) {
                if (++o >= 168) return void (t = !1);
                const n = app.SSRunner.getWaitTime();
                let s = Math.round(Chrome.Time.MSEC_IN_HOUR / n);
                s = Math.max(s, 50), s = 1 === o ? Math.min(s, 50) : Math.min(s, 300);
                const r = app.SSPhotos.getNextGooglePhotos(s, a.getId()), i = [];
                for (const e of r) {
                    const o = e.getEx().id;
                    -1 === i.indexOf(o) && i.push(o);
                }
                let l = [];
                try {
                    l = await app.GoogleSource.loadPhotos(i);
                } catch (e) {
                    return Chrome.Log.error("Failed to load new photos", "Screensaver._onErrorChanged"), 
                    o = 169, void (t = !0);
                }
                app.SSPhotos.updateGooglePhotoUrls(l);
                for (let o = 0; o < e._views.length; o++) {
                    const t = e._views[o], n = t.photo;
                    if ("Google User" === n.getType()) {
                        const e = l.findIndex(e => e.ex.id === n.getEx().id);
                        e >= 0 && t.setUrl(l[e].url);
                    }
                }
                if (!app.GoogleSource.updateBaseUrls(l)) return Chrome.Log.error("Failed to save baseUrl's", "Screensaver._onErrorChanged"), 
                o = 169, void (t = !0);
                t = !1;
            }
        }
    }, window.addEventListener("load", function() {
        document.body.style.background = Chrome.Storage.get("background").substring(11), 
        Chrome.GA.page("/screensaver.html"), Chrome.Utils.getChromeVersion() >= 42 && new ChromePromise().tabs.getZoom().then(e => ((e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1), 
        null)).catch(e => {
            Chrome.Log.error(e.message, "chromep.tabs.getZoom");
        }), function() {
            let o = Chrome.Storage.getInt("photoTransition", 0);
            8 === o && (o = Chrome.Utils.getRandomInt(0, 7)), e.set("aniType", o), app.SSTime.initialize();
        }(), app.SSBuilder.build() && app.SSRunner.start(1e3);
    }), {
        createPages: function() {
            app.SSViews.create(e);
        },
        setSizingType: function(o) {
            e.set("sizingType", o);
        },
        noPhotos: function() {
            return e.noPhotos;
        },
        setNoPhotos: function() {
            e.set("noPhotos", !0), e.noPhotosLabel = Chrome.Locale.localize("no_photos");
        },
        setTimeLabel: function(o) {
            e.timeLabel = o;
        },
        setPaused: function(o) {
            e.paused = o, o ? (e.$.pauseImage.classList.add("fadeOut"), e.$.playImage.classList.remove("fadeOut")) : (e.$.playImage.classList.add("fadeOut"), 
            e.$.pauseImage.classList.remove("fadeOut"));
        }
    };
}();