/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.SSTime=function(){"use strict";return new ExceptionHandler,{initialize:function(){Chrome.Storage.getInt("showTime",0)>0&&setInterval(app.SSTime.setTime,61e3)},setTime:function(){let e="";0!==Chrome.Storage.getInt("showTime",0)&&app.SSRunner.isStarted()&&(e=Chrome.Time.getStringShort()),app.Screensaver.setTimeLabel(e)}}}();