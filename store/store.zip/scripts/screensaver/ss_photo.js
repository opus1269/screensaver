/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function(){"use strict";window.app=window.app||{},new ExceptionHandler,app.SSPhoto=class{constructor(t,e,s){this._id=t,this._url=e.url,this._photographer=e.author?e.author:"",this._type=s,this._aspectRatio=e.asp,this._ex=e.ex,this._point=e.point,this._isBad=!1}getId(){return this._id}setId(t){this._id=t}isBad(){return this._isBad}markBad(){this._isBad=!0}getUrl(){return this._url}setUrl(t){this._url=t,this._isBad=!1}getType(){return this._type}getPhotographer(){return this._photographer}getAspectRatio(){return this._aspectRatio}getPoint(){return this._point}getEx(){return this._ex}showSource(){let t,e,s=null;switch(this._type){case"flickr":this._ex&&(t=/(\/[^/]*){4}(_.*_)/,e=this._url.match(t),s=`https://www.flickr.com/photos/${this._ex}${e[1]}`);break;case"reddit":this._ex&&(s=this._ex);break;case"Google User":this._ex&&this._ex.url&&(s=this._ex.url);break;default:s=this._url}null!==s&&chrome.tabs.create({url:s})}}}();