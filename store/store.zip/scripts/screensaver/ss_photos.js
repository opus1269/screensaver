/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSPhotos = function() {
    "use strict";
    new ExceptionHandler();
    const e = [];
    let t = 0;
    return {
        addFromSource: function(t) {
            const n = t.type, o = app.SSViews.getType();
            let r = 0;
            for (const u of t.photos) if (!app.SSView.ignore(u.asp, o)) {
                const t = new app.SSPhoto(r, u, n);
                e.push(t), r++;
            }
        },
        getCount: function() {
            return e.length;
        },
        hasUsable: function() {
            return !e.every(e => e.isBad());
        },
        get: function(t) {
            return e[t];
        },
        getNextUsable: function() {
            for (let n = 0; n < e.length; n++) {
                const o = (n + t) % e.length, r = e[o];
                if (!r.isBad() && !app.SSViews.hasPhoto(r)) return t = o, app.SSPhotos.incCurrentIndex(), 
                r;
            }
            return null;
        },
        getCurrentIndex: function() {
            return t;
        },
        getNextGooglePhotos: function(t, n) {
            const o = [];
            let r = 0;
            for (let u = 0; u < e.length; u++) {
                const s = (u + n) % e.length, i = e[s];
                if (r >= t) break;
                "Google User" === i.getType() && (o.push(i), r++);
            }
            return o;
        },
        updateGooglePhotoUrls: function(t) {
            for (let n = e.length - 1; n >= 0; n--) {
                if ("Google User" !== e[n].getType()) continue;
                const o = t.findIndex(t => t.ex.id === e[n].getEx().id);
                o >= 0 && e[n].setUrl(t[o].url);
            }
        },
        setCurrentIndex: function(e) {
            t = e;
        },
        incCurrentIndex: function() {
            return t = t === e.length - 1 ? 0 : t + 1;
        },
        shuffle: function() {
            Chrome.Utils.shuffleArray(e), e.forEach((e, t) => {
                e.setId(t);
            });
        }
    };
}();