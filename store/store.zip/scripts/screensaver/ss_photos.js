/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSPhotos = function() {
    "use strict";
    new ExceptionHandler();
    const t = [];
    let n = 0;
    return {
        addFromSource: function(n) {
            const e = n.type, o = app.SSViews.getType();
            let r = 0;
            for (const i of n.photos) if (!app.SSView.ignore(i.asp, o)) {
                const n = new app.SSPhoto(r, i, e);
                t.push(n), r++;
            }
        },
        getCount: function() {
            return t.length;
        },
        hasUsable: function() {
            return !t.every(t => t.isBad());
        },
        get: function(n) {
            return t[n];
        },
        getNextUsable: function() {
            for (let e = 0; e < t.length; e++) {
                const o = (e + n) % t.length, r = t[o];
                if (!r.isBad() && !app.SSViews.hasPhoto(r)) return n = o, app.SSPhotos.incCurrentIndex(), 
                r;
            }
            return null;
        },
        getCurrentIndex: function() {
            return n;
        },
        updateGooglePhotoUrls: function(e) {
            const o = e.photos || [];
            for (let r = t.length - 1; r >= 0; r--) {
                if (t[r].getType() !== e.type) continue;
                const i = o.findIndex(n => n.ex.id === t[r].getEx().id);
                i >= 0 ? t[r].setUrl(o[i].url) : t.splice(r, 1), n = Math.min(n, t.length - 1);
            }
        },
        setCurrentIndex: function(t) {
            n = t;
        },
        incCurrentIndex: function() {
            return n = n === t.length - 1 ? 0 : n + 1;
        },
        shuffle: function() {
            Chrome.Utils.shuffleArray(t), t.forEach((t, n) => {
                t.setId(n);
            });
        }
    };
}();