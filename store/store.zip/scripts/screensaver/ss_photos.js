/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.SSPhotos=function(){"use strict";new ExceptionHandler;const n=[];let t=0;return{addFromSource:function(t){const e=t.type,o=app.SSViews.getType();let r=0;for(const u of t.photos)if(!app.SSView.ignore(u.asp,o)){const t=new app.SSPhoto(r,u,e);n.push(t),r++}},getCount:function(){return n.length},hasUsable:function(){return!n.every(n=>n.isBad())},get:function(t){return n[t]},getNextUsable:function(){for(let e=0;e<n.length;e++){const o=(e+t)%n.length,r=n[o];if(!r.isBad()&&!app.SSViews.hasPhoto(r))return t=o,app.SSPhotos.incCurrentIndex(),r}return null},getCurrentIndex:function(){return t},updatePhotoUrl:function(t,e){t>n.length-1||n[t].setUrl(e)},setCurrentIndex:function(n){t=n},incCurrentIndex:function(){return t=t===n.length-1?0:t+1},shuffle:function(){Chrome.Utils.shuffleArray(n),n.forEach((n,t)=>{n.setId(t)})}}}();