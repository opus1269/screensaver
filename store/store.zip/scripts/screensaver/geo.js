/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    new ExceptionHandler();
    const e = {
        entries: [],
        maxSize: 100
    };
    return {
        get: function(t) {
            if (!Chrome.Storage.getBool("showLocation")) return Promise.reject(new Error("showLocation is off"));
            if (Chrome.Utils.isWhiteSpace(t)) return Promise.reject(new Error("point is empty or null"));
            const o = function(e) {
                let t = e;
                try {
                    const o = e.split(" ");
                    2 === o.length && (t = `${parseFloat(o[0]).toFixed(8)},${parseFloat(o[1]).toFixed(8)}`);
                } catch (e) {
                    Chrome.Utils.noop();
                }
                return t;
            }(t), r = function(t) {
                return e.entries.find(e => e.point === t);
            }(o);
            if (r) return Promise.resolve(r.loc);
            const n = `http://maps.googleapis.com/maps/api/geocode/json?latlng=${o}`, s = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return s.maxRetries = 2, Chrome.Http.doGet(n, s).then(t => {
                let r = "";
                return "OK" === t.status && t.results && t.results.length > 0 && (r = t.results[0].formatted_address, 
                function(t, o) {
                    e.entries.push({
                        loc: o,
                        point: t
                    }), e.entries.length > e.maxSize && e.entries.shift();
                }(o, r)), Promise.resolve(r);
            });
        }
    };
}();