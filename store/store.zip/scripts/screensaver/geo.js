/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
import "../../scripts/chrome-extension-utils/scripts/ex_handler.js";

const _GEOCODE_API = "http://maps.googleapis.com/maps/api/geocode/json", _LOC_CACHE = {
    entries: [],
    maxSize: 100
};

export function get(e) {
    if (!Chrome.Storage.getBool("showLocation")) return Promise.reject(new Error("showLocation is off"));
    if (Chrome.Utils.isWhiteSpace(e)) return Promise.reject(new Error("point is empty or null"));
    const t = _cleanPoint(e), o = _getFromCache(t);
    if (o) return Promise.resolve(o.loc);
    const r = `${_GEOCODE_API}?latlng=${t}`, s = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
    return s.maxRetries = 2, Chrome.Http.doGet(r, s).then(e => {
        let o = "";
        return "OK" === e.status && e.results && e.results.length > 0 && (o = e.results[0].formatted_address, 
        _addToCache(t, o)), Promise.resolve(o);
    });
};

function _getFromCache(e) {
    return _LOC_CACHE.entries.find(t => t.point === e);
}

function _addToCache(e, t) {
    _LOC_CACHE.entries.push({
        loc: t,
        point: e
    }), _LOC_CACHE.entries.length > _LOC_CACHE.maxSize && _LOC_CACHE.entries.shift();
}

function _cleanPoint(e) {
    let t = e;
    try {
        const o = e.split(" ");
        if (2 === o.length) {
            t = `${parseFloat(o[0]).toFixed(8)},${parseFloat(o[1]).toFixed(8)}`;
        }
    } catch (e) {
        Chrome.Utils.noop();
    }
    return t;
}