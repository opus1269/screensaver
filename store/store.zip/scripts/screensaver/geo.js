/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
import * as ChromeHttp from "../../scripts/chrome-extension-utils/scripts/http.js";

import * as ChromeJSON from "../../scripts/chrome-extension-utils/scripts/json.js";

import * as ChromeStorage from "../../scripts/chrome-extension-utils/scripts/storage.js";

import * as ChromeUtils from "../../scripts/chrome-extension-utils/scripts/utils.js";

import "../../scripts/chrome-extension-utils/scripts/ex_handler.js";

const _GEOCODE_API = "http://maps.googleapis.com/maps/api/geocode/json", _LOC_CACHE = {
    entries: [],
    maxSize: 100
};

export function get(t) {
    if (!ChromeStorage.getBool("showLocation")) return Promise.reject(new Error("showLocation is off"));
    if (ChromeUtils.isWhiteSpace(t)) return Promise.reject(new Error("point is empty or null"));
    const e = _cleanPoint(t), o = _getFromCache(e);
    if (o) return Promise.resolve(o.loc);
    const s = `${_GEOCODE_API}?latlng=${e}`, r = ChromeJSON.shallowCopy(ChromeHttp.CONFIG);
    return r.maxRetries = 2, ChromeHttp.doGet(s, r).then(t => {
        let o = "";
        return "OK" === t.status && t.results && t.results.length > 0 && (o = t.results[0].formatted_address, 
        _addToCache(e, o)), Promise.resolve(o);
    });
};

function _getFromCache(t) {
    return _LOC_CACHE.entries.find(e => e.point === t);
}

function _addToCache(t, e) {
    _LOC_CACHE.entries.push({
        loc: e,
        point: t
    }), _LOC_CACHE.entries.length > _LOC_CACHE.maxSize && _LOC_CACHE.entries.shift();
}

function _cleanPoint(t) {
    let e = t;
    try {
        const o = t.split(" ");
        if (2 === o.length) {
            e = `${parseFloat(o[0]).toFixed(8)},${parseFloat(o[1]).toFixed(8)}`;
        }
    } catch (t) {
        ChromeUtils.noop();
    }
    return e;
}