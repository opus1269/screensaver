/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    new ExceptionHandler();
    const e = new ChromePromise(), s = "notSet", n = "allowed", o = "denied";
    function r(e, s) {
        const n = Chrome.JSONUtils.shallowCopy(Chrome.Msg.STORE);
        n.key = e.name, n.value = s, Chrome.Msg.send(n).catch(() => {});
    }
    function i(s) {
        return e.permissions.contains({
            permissions: s.permissions,
            origins: s.origins
        });
    }
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://photoslibrary.googleapis.com/" ]
        },
        BACKGROUND: {
            name: "permBackground",
            permissions: [ "background" ],
            origins: []
        },
        notSet: function(e) {
            return Chrome.Storage.get(e.name) === s;
        },
        isAllowed: function(e) {
            return Chrome.Storage.get(e.name) === n;
        },
        isDenied: function(e) {
            return Chrome.Storage.get(e.name) === o;
        },
        request: function(s) {
            let i;
            return e.permissions.request({
                permissions: s.permissions,
                origins: s.origins
            }).then(e => (i = e, e ? (r(s, n), Promise.resolve()) : (r(s, o), app.Permissions.remove(s)))).then(() => Promise.resolve(i));
        },
        remove: function(n) {
            return i(n).then(s => s ? e.permissions.remove({
                permissions: n.permissions,
                origins: n.origins
            }) : Promise.resolve(!1)).then(e => (e && r(n, s), Promise.resolve(e)));
        },
        deny: function(s) {
            return i(s).then(n => n ? e.permissions.remove({
                permissions: s.permissions,
                origins: s.origins
            }) : Promise.resolve(!1)).then(() => (r(s, o), Promise.resolve(!0)));
        },
        removeGooglePhotos: function() {
            return app.Permissions.deny(app.Permissions.PICASA).then(() => (Chrome.Storage.set("albumSelections", []), 
            Chrome.Auth.removeCachedToken(!1, null, null).catch(() => null), null));
        }
    };
}();