/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    new ExceptionHandler();
    const e = new ChromePromise(), s = "notSet", o = "allowed", n = "denied";
    function i(e, s) {
        const o = Chrome.JSONUtils.shallowCopy(Chrome.Msg.STORE);
        o.key = e.name, o.value = s, Chrome.Msg.send(o).catch(() => {});
    }
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://photoslibrary.googleapis.com/" ]
        },
        BACKGROUND: {
            name: "permBackground",
            permissions: [ "background" ],
            origins: []
        },
        notSet: function(e) {
            return Chrome.Storage.get(e.name) === s;
        },
        isAllowed: function(e) {
            return Chrome.Storage.get(e.name) === o;
        },
        request: function(s) {
            let r;
            return e.permissions.request({
                permissions: s.permissions,
                origins: s.origins
            }).then(e => (r = e, e ? (i(s, o), Promise.resolve()) : (i(s, n), app.Permissions.remove(s)))).then(() => Promise.resolve(r));
        },
        remove: function(o) {
            return function(s) {
                return e.permissions.contains({
                    permissions: s.permissions,
                    origins: s.origins
                });
            }(o).then(s => s ? e.permissions.remove({
                permissions: o.permissions,
                origins: o.origins
            }) : Promise.resolve(!1)).then(e => (e && i(o, s), Promise.resolve(e)));
        }
    };
}();