/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    new ExceptionHandler();
    const e = "https://chrome.google.com/webstore/detail/screensaver/" + chrome.runtime.id + "/", o = document.querySelector("#t");
    function r(e) {
        return o.pages.map(function(e) {
            return e.route;
        }).indexOf(e);
    }
    function t() {
        Chrome.Storage.getLastError().then(e => {
            const t = r("page-error"), a = document.getElementById(o.pages[t].route);
            return a && !Chrome.Utils.isWhiteSpace(e.message) ? a.removeAttribute("disabled") : a && a.setAttribute("disabled", "true"), 
            Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "Options._setErrorMenuState");
        });
    }
    function a(e, r, t) {
        if (e.message === Chrome.Msg.HIGHLIGHT.message) {
            new ChromePromise().tabs.getCurrent().then(e => (chrome.tabs.update(e.id, {
                highlighted: !0
            }), null)).catch(e => {
                Chrome.Log.error(e.message, "chromep.tabs.getCurrent");
            }), t(JSON.stringify({
                message: "OK"
            }));
        } else e.message === Chrome.Msg.STORAGE_EXCEEDED.message ? (o.dialogTitle = Chrome.Locale.localize("err_storage_title"), 
        o.dialogText = Chrome.Locale.localize("err_storage_desc"), o.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (o.$.settingsPage.deselectPhotoSource(e.key), 
        o.dialogTitle = Chrome.Locale.localize("err_photo_source_title"), o.dialogText = e.error, 
        o.$.errorDialog.open());
        return !1;
    }
    o.pages = [ {
        label: Chrome.Locale.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: function(e) {
            o.pages[e].ready ? Chrome.Storage.getBool("isAlbumMode") && o.gPhotosPage.loadAlbumList() : (o.pages[e].ready = !0, 
            o.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), o.$.googlePhotosInsertion.appendChild(o.gPhotosPage));
            o.route = o.pages[e].route;
        },
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: function(e, r) {
            setTimeout(() => o.$.mainMenu.select(r), 500), Chrome.Msg.send(app.Msg.SS_SHOW).catch(() => {});
        },
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_error"),
        route: "page-error",
        icon: "myicons:error",
        obj: function(e) {
            if (!o.pages[e].ready) {
                o.pages[e].ready = !0;
                const r = new app.ErrorPageFactory();
                o.$.errorInsertion.appendChild(r);
            }
            o.route = o.pages[e].route;
        },
        ready: !1,
        disabled: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: function(e) {
            if (!o.pages[e].ready) {
                o.pages[e].ready = !0;
                const r = new app.HelpPageFactory();
                o.$.helpInsertion.appendChild(r);
            }
            o.route = o.pages[e].route;
        },
        ready: !1,
        divider: !0
    }, {
        label: Chrome.Locale.localize("help_faq"),
        route: "page-faq",
        icon: "myicons:help",
        obj: "https://opus1269.github.io/screensaver/faq.html",
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${e}support`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${e}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], o.dialogTitle = "", o.dialogText = "", o.route = "page-settings", o._onNavMenuItemTapped = function(e) {
        const t = document.querySelector("#appDrawerLayout"), a = document.querySelector("#appDrawer");
        a && t && t.narrow && a.close();
        const n = r(e.currentTarget.id);
        Chrome.GA.event(Chrome.GA.EVENT.MENU, o.pages[n].route);
        const s = o.route;
        o.pages[n].obj ? "string" == typeof o.pages[n].obj ? (o.$.mainMenu.select(s), chrome.tabs.create({
            url: o.pages[n].obj
        })) : o.pages[n].obj(n, s) : o.route = o.pages[n].route;
    }, o._computeTitle = function() {
        return Chrome.Locale.localize("chrome_extension_name");
    }, o._computeMenu = function() {
        return Chrome.Locale.localize("menu");
    }, window.addEventListener("load", function() {
        Chrome.GA.page("/options.html"), Chrome.Msg.listen(a), t(), chrome.storage.onChanged.addListener(function(e) {
            for (const o in e) if (e.hasOwnProperty(o) && "lastError" === o) {
                t();
                break;
            }
        });
    });
}();