/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Options = function() {
    "use strict";
    new ExceptionHandler();
    const e = "https://chrome.google.com/webstore/detail/screensaver/" + chrome.runtime.id + "/", o = document.querySelector("#t");
    function r(e) {
        return o.pages.map(function(e) {
            return e.route;
        }).indexOf(e);
    }
    function t() {
        o.permission = Chrome.Storage.get("permPicasa", "notSet");
        const e = r("page-google-photos"), t = document.getElementById(o.pages[e].route);
        t ? "allowed" !== o.permission ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled") : Chrome.GA.error("no element found", "Options._setGooglePhotosMenuState");
    }
    function i() {
        Chrome.Storage.getLastError().then(e => {
            const t = r("page-error"), i = document.getElementById(o.pages[t].route);
            return i && !Chrome.Utils.isWhiteSpace(e.message) ? i.removeAttribute("disabled") : i && i.setAttribute("disabled", "true"), 
            Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "Options._setErrorMenuState");
        });
    }
    function s(e, r, t) {
        if (e.message === Chrome.Msg.HIGHLIGHT.message) {
            new ChromePromise().tabs.getCurrent().then(e => (chrome.tabs.update(e.id, {
                highlighted: !0
            }), null)).catch(e => {
                Chrome.Log.error(e.message, "chromep.tabs.getCurrent");
            }), t(JSON.stringify({
                message: "OK"
            }));
        } else e.message === Chrome.Msg.STORAGE_EXCEEDED.message ? (o.dialogTitle = Chrome.Locale.localize("err_storage_title"), 
        o.dialogText = Chrome.Locale.localize("err_storage_desc"), o.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (o.$.settingsPage.deselectPhotoSource(e.key), 
        o.dialogTitle = Chrome.Locale.localize("err_photo_source_title"), o.dialogText = e.error, 
        o.$.errorDialog.open());
        return !1;
    }
    return o.pages = [ {
        label: Chrome.Locale.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: function(e, r) {
            setTimeout(() => o.$.mainMenu.select(r), 500), Chrome.Msg.send(app.Msg.SS_SHOW).catch(() => {});
        },
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: function(e) {
            if (!o.signedInToChrome) return o.dialogTitle = Chrome.Locale.localize("err_chrome_signin_title"), 
            o.dialogText = Chrome.Locale.localize("err_chrome_signin"), void o.$.errorDialog.open();
            o.pages[e].ready ? Chrome.Storage.getBool("isAlbumMode") && o.gPhotosPage.loadAlbumList().catch(e => {}) : (o.pages[e].ready = !0, 
            o.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), o.$.googlePhotosInsertion.appendChild(o.gPhotosPage));
            o.route = o.pages[e].route;
        },
        ready: !1,
        divider: !0
    }, {
        label: Chrome.Locale.localize("menu_permission"),
        route: "page-permission",
        icon: "myicons:perm-data-setting",
        obj: function() {
            o.$.permissionsDialog.open();
        },
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_error"),
        route: "page-error",
        icon: "myicons:error",
        obj: function(e) {
            if (!o.pages[e].ready) {
                o.pages[e].ready = !0;
                const r = new app.ErrorPageFactory();
                o.$.errorInsertion.appendChild(r);
            }
            o.route = o.pages[e].route;
        },
        ready: !1,
        disabled: !1,
        divider: !0
    }, {
        label: Chrome.Locale.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: function(e) {
            if (!o.pages[e].ready) {
                o.pages[e].ready = !0;
                const r = new app.HelpPageFactory();
                o.$.helpInsertion.appendChild(r);
            }
            o.route = o.pages[e].route;
        },
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("help_faq"),
        route: "page-faq",
        icon: "myicons:help",
        obj: "https://opus1269.github.io/screensaver/faq.html",
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${e}support`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${e}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], o.dialogTitle = "", o.dialogText = "", o.route = "page-settings", o.permission = Chrome.Storage.get("permPicasa"), 
    o.signedInToChrome = Chrome.Storage.getBool("signedInToChrome", !0), o._onNavMenuItemTapped = function(e) {
        const t = document.querySelector("#appDrawerLayout"), i = document.querySelector("#appDrawer");
        i && t && t.narrow && i.close();
        const s = r(e.currentTarget.id);
        Chrome.GA.event(Chrome.GA.EVENT.MENU, o.pages[s].route);
        const a = o.route;
        o.pages[s].obj ? "string" == typeof o.pages[s].obj ? (o.$.mainMenu.select(a), chrome.tabs.create({
            url: o.pages[s].obj
        })) : o.pages[s].obj(s, a) : o.route = o.pages[s].route;
    }, o._onAcceptPermissionsClicked = function() {
        const e = app.Permissions.PICASA;
        app.Permissions.request(e).then(e => e ? null : app.Permissions.removeGooglePhotos()).catch(e => {
            Chrome.Log.error(e.message, "Options._onAcceptPermissionsClicked");
        });
    }, o._onDenyPermissionsClicked = function() {
        app.Permissions.removeGooglePhotos().catch(e => {
            Chrome.Log.error(e.message, "Options._onDenyPermissionsClicked");
        });
    }, o._computeTitle = function() {
        return Chrome.Locale.localize("chrome_extension_name");
    }, o._computeMenu = function() {
        return Chrome.Locale.localize("menu");
    }, o._computePermDialogTitle = function() {
        return Chrome.Locale.localize("menu_permission");
    }, o._computePermissionsMessage = function() {
        return Chrome.Locale.localize("permission_message");
    }, o._computePermissionsMessage1 = function() {
        return Chrome.Locale.localize("permission_message1");
    }, o._computePermissionsMessage2 = function() {
        return Chrome.Locale.localize("permission_message2");
    }, o._computePermissionsStatus = function(e) {
        return `${Chrome.Locale.localize("permission_status")} ${Chrome.Locale.localize(e)}`;
    }, window.addEventListener("load", function() {
        Chrome.GA.page("/options.html"), Chrome.Msg.listen(s), i(), t(), chrome.storage.onChanged.addListener(function(e) {
            for (const o in e) if (e.hasOwnProperty(o) && "lastError" === o) {
                i();
                break;
            }
        }), window.addEventListener("storage", e => {
            "permPicasa" === e.key ? t() : "signedInToChrome" === e.key && (o.signedInToChrome = Chrome.Storage.getBool("signedInToChrome", !0));
        }, !1);
    }), {
        showErrorDialog: function(e, r) {
            o.dialogTitle = e, o.dialogText = r, o.$.errorDialog.open();
        }
    };
}();