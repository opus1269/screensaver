/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Utils=function(){"use strict";new ExceptionHandler;return{DEBUG:!1,getEmail:function(){return"photoscreensaver@gmail.com"},getEmailBody:function(){return`Extension version: ${Chrome.Utils.getVersion()}\n`+`Chrome version: ${Chrome.Utils.getFullChromeVersion()}\n`+`OS: ${Chrome.Storage.get("os")}\n\n\n`},getEmailUrl:function(e,t){return`mailto:${encodeURIComponent(app.Utils.getEmail())}?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(t)}`},getGithubPath:function(){return"https://github.com/opus1269/photo-screen-saver/"},getGithubPagesPath:function(){return"https://opus1269.github.io/photo-screen-saver/"}}}();