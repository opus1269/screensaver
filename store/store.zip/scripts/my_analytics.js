/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.GA=function(){"use strict";const e="UA-61314754-1";window.addEventListener("load",function(){Chrome.GA.initialize(e,"Photo Screensaver","photo-screen-saver",Chrome.Utils.getVersion())})}();