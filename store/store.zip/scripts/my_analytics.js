/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.GA = function() {
    "use strict";
    const e = "UA-61314754-1";
    return window.addEventListener("load", function() {
        Chrome.GA.initialize(e, "Photo Screensaver", "screensaver", Chrome.Utils.getVersion());
    }), {
        EVENT: {
            LOAD_ALBUM_LIST: {
                eventCategory: "googlePhotosAPI",
                eventAction: "loadAlbumList",
                eventLabel: ""
            },
            LOAD_ALBUM: {
                eventCategory: "googlePhotosAPI",
                eventAction: "loadAlbum",
                eventLabel: ""
            },
            LOAD_PHOTO: {
                eventCategory: "googlePhotosAPI",
                eventAction: "loadPhoto",
                eventLabel: ""
            },
            FETCH_ALBUMS: {
                eventCategory: "googlePhotosAPI",
                eventAction: "fetchAlbums",
                eventLabel: ""
            },
            UPDATE_PHOTOS: {
                eventCategory: "googlePhotosAPI",
                eventAction: "updatePhotos",
                eventLabel: ""
            },
            PHOTOS_LIMITED: {
                eventCategory: "googlePhotosAPI",
                eventAction: "limitedAlbumPhotos",
                eventLabel: ""
            },
            ALBUMS_LIMITED: {
                eventCategory: "googlePhotosAPI",
                eventAction: "limitedAlbums",
                eventLabel: ""
            }
        }
    };
}();