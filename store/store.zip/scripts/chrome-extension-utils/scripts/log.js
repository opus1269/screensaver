/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome=window.Chrome||{},Chrome.Log=function(){"use strict";return{error:function(r="unknown",o="unknownMethod",e=null){const n=e||"An error occurred";Chrome.Storage.setLastError(new Chrome.Storage.LastError(r,n)),Chrome.GA.error(r,o)},exception:function(r,o=null,e=!1,n="An exception was caught"){try{Chrome.Storage.setLastError(new Chrome.Storage.LastError(o,n)),Chrome.GA.exception(r,o,e)}catch(r){Chrome.Utils.noop()}}}}();