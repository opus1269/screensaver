/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Log = function() {
    "use strict";
    return {
        error: function(r = "unknown", o = "unknownMethod", e = null) {
            const n = e || "An error occurred";
            Chrome.Storage.setLastError(new Chrome.Storage.LastError(r, n)), Chrome.GA.error(r, o);
        },
        exception: function(r, o = null, e = !1, n = "An exception was caught") {
            try {
                Chrome.Storage.setLastError(new Chrome.Storage.LastError(o, n)), Chrome.GA.exception(r, o, e);
            } catch (r) {
                Chrome.Utils.noop();
            }
        }
    };
}();