/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.JSONUtils = function() {
    "use strict";
    return new ExceptionHandler(), {
        parse: function(e) {
            let t = null;
            try {
                t = JSON.parse(e);
            } catch (e) {
                Chrome.GA.exception(`Caught: JSONUtils.parse: ${e.message}`, e.stack, !1);
            }
            return t;
        },
        shallowCopy: function(e) {
            let t = null;
            const n = JSON.stringify(e);
            return void 0 !== n && (t = Chrome.JSONUtils.parse(n)), t;
        }
    };
}();