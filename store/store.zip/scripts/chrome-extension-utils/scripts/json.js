/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.JSONUtils = function() {
    "use strict";
    return new ExceptionHandler(), {
        parse: function(e) {
            let t = null;
            try {
                t = JSON.parse(e);
            } catch (e) {
                Chrome.GA.exception(`Caught: JSONUtils.parse: ${e.message}`, e.stack, !1);
            }
            return t;
        },
        shallowCopy: function(e) {
            let t = null;
            const n = JSON.stringify(e);
            return void 0 !== n && (t = Chrome.JSONUtils.parse(n)), t;
        }
    };
}();