/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.GA = function() {
    "use strict";
    window.addEventListener("load", function() {
        var e, t, n, o, a, i;
        e = window, t = document, n = "script", o = "ga", e.GoogleAnalyticsObject = o, e.ga = e.ga || function() {
            (e.ga.q = e.ga.q || []).push(arguments);
        }, e.ga.l = 1 * new Date(), a = t.createElement(n), i = t.getElementsByTagName(n)[0], 
        a.async = 1, a.src = "https://www.google-analytics.com/analytics.js", i.parentNode.insertBefore(a, i);
    });
    return {
        EVENT: {
            INSTALLED: {
                eventCategory: "extension",
                eventAction: "installed",
                eventLabel: ""
            },
            UPDATED: {
                eventCategory: "extension",
                eventAction: "updated",
                eventLabel: ""
            },
            ALARM: {
                eventCategory: "alarm",
                eventAction: "triggered",
                eventLabel: ""
            },
            MENU: {
                eventCategory: "ui",
                eventAction: "menuSelect",
                eventLabel: ""
            },
            TOGGLE: {
                eventCategory: "ui",
                eventAction: "toggle",
                eventLabel: ""
            },
            LINK: {
                eventCategory: "ui",
                eventAction: "linkSelect",
                eventLabel: ""
            },
            TEXT: {
                eventCategory: "ui",
                eventAction: "textChanged",
                eventLabel: ""
            },
            SLIDER_VALUE: {
                eventCategory: "ui",
                eventAction: "sliderValueChanged",
                eventLabel: ""
            },
            SLIDER_UNITS: {
                eventCategory: "ui",
                eventAction: "sliderUnitsChanged",
                eventLabel: ""
            },
            BUTTON: {
                eventCategory: "ui",
                eventAction: "buttonClicked",
                eventLabel: ""
            },
            ICON: {
                eventCategory: "ui",
                eventAction: "toolbarIconClicked",
                eventLabel: ""
            },
            CHECK: {
                eventCategory: "ui",
                eventAction: "checkBoxClicked",
                eventLabel: ""
            },
            KEY_COMMAND: {
                eventCategory: "ui",
                eventAction: "keyCommand",
                eventLabel: ""
            }
        },
        initialize: function(e, t, n, o) {
            ga("create", e, "auto"), ga("set", "checkProtocolTask", function() {}), ga("set", "appName", t), 
            ga("set", "appId", n), ga("set", "appVersion", o), ga("require", "displayfeatures");
        },
        page: function(e) {
            e && (Chrome.Utils.DEBUG || ga("send", "pageview", e));
        },
        event: function(e, t = null, n = null) {
            if (e) {
                const o = Chrome.JSONUtils.shallowCopy(e);
                o.hitType = "event", o.eventLabel = t || o.eventLabel, o.eventAction = n || o.eventAction, 
                Chrome.Utils.DEBUG ? console.log(o) : ga("send", o);
            }
        },
        error: function(e = "unknown", t = "unknownMethod") {
            const n = {
                hitType: "event",
                eventCategory: "error",
                eventAction: t,
                eventLabel: `Err: ${e}`
            };
            Chrome.Utils.DEBUG ? console.error(n) : ga("send", n);
        },
        exception: function(e, t = null, n = !1) {
            try {
                let o = "Unknown";
                t ? o = t : e.message && (o = e.message), e.stack && (o += `\n\n${e.stack}`);
                const a = {
                    hitType: "exception",
                    exDescription: o,
                    exFatal: n
                };
                Chrome.Utils.DEBUG ? console.error(a) : ga("send", a);
            } catch (e) {
                Chrome.Utils.noop();
            }
        }
    };
}();