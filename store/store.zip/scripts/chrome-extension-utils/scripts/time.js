/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
new ExceptionHandler(), window.Chrome = window.Chrome || {}, Chrome.Time = class t {
    constructor(t = null) {
        this._parse(t);
    }
    static get MSEC_IN_MIN() {
        return 6e4;
    }
    static get MIN_IN_HOUR() {
        return 60;
    }
    static get MSEC_IN_HOUR() {
        return 60 * Chrome.Time.MIN_IN_HOUR * 1e3;
    }
    static get MIN_IN_DAY() {
        return 1440;
    }
    static get MSEC_IN_DAY() {
        return 60 * Chrome.Time.MIN_IN_DAY * 1e3;
    }
    static _is24Hr(t = null) {
        let e = !1, r = Chrome.Storage.getInt("showTime", 0);
        null !== t && (r = t);
        const n = Chrome.Locale.localize("time_format");
        return 2 === r ? e = !0 : 0 === r && "24" === n && (e = !0), e;
    }
    static getTime(e) {
        const r = new Date(), n = new t(e);
        return r.setHours(n._hr), r.setMinutes(n._min), r.setSeconds(0), r.setMilliseconds(0), 
        r.getTime();
    }
    static getTimeDelta(t) {
        const e = Date.now();
        let r = (Chrome.Time.getTime(t) - e) / 1e3 / 60;
        return r < 0 && (r = Chrome.Time.MIN_IN_DAY + r), r;
    }
    static isInRange(t, e) {
        const r = Date.now(), n = Chrome.Time.getTime(t), i = Chrome.Time.getTime(e);
        let s = !1;
        return t === e ? s = !0 : i > n ? r >= n && r <= i && (s = !0) : (r >= n || r <= i) && (s = !0), 
        s;
    }
    static getStringFull(e, r = null) {
        return new t(e).toString(r);
    }
    static getStringShort() {
        let e = new t().toString();
        return e = (e = e.replace(/[^\d:]/g, "")).replace(/(.*?:.*?):.*/g, "$1");
    }
    _parse(t) {
        if (null === t) {
            const t = new Date();
            this._hr = t.getHours(), this._min = t.getMinutes();
        } else this._hr = parseInt(t.substr(0, 2), 10), this._min = parseInt(t.substr(3, 2), 10);
    }
    toString(e = null) {
        const r = new Date();
        r.setHours(this._hr, this._min), r.setSeconds(0), r.setMilliseconds(0);
        let n = r.toTimeString();
        const i = [];
        void 0 !== navigator.language && i.push(navigator.language), i.push("en-US");
        const s = {
            hour: "numeric",
            minute: "2-digit",
            hour12: !t._is24Hr(e)
        };
        try {
            n = r.toLocaleTimeString(i, s);
        } catch (t) {
            Chrome.Utils.noop();
        }
        return n;
    }
};