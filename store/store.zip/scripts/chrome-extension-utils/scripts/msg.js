/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Msg = function() {
    "use strict";
    new ExceptionHandler();
    const e = {
        HIGHLIGHT: {
            message: "highlightTab"
        },
        RESTORE_DEFAULTS: {
            message: "restoreDefaults"
        },
        STORAGE_EXCEEDED: {
            message: "storageExceeded"
        },
        STORE: {
            message: "store",
            key: "",
            value: ""
        }
    };
    return {
        HIGHLIGHT: e.HIGHLIGHT,
        RESTORE_DEFAULTS: e.RESTORE_DEFAULTS,
        STORAGE_EXCEEDED: e.STORAGE_EXCEEDED,
        STORE: e.STORE,
        send: function(e) {
            return new ChromePromise().runtime.sendMessage(e, null).then(e => Promise.resolve(e)).catch(s => {
                if (s.message && !s.message.includes("port closed") && !s.message.includes("Receiving end does not exist")) {
                    const n = `type: ${e.message}, ${s.message}`;
                    Chrome.GA.error(n, "Msg.send");
                }
                return Promise.reject(s);
            });
        },
        listen: function(e) {
            chrome.runtime.onMessage.addListener(e);
        }
    };
}();