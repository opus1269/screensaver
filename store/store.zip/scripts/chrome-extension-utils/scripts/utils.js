/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Utils = function() {
    "use strict";
    new ExceptionHandler();
    const n = new ChromePromise();
    return {
        DEBUG: !1,
        getExtensionName: function() {
            return `chrome-extension://${chrome.runtime.id}`;
        },
        getVersion: function() {
            return chrome.runtime.getManifest().version;
        },
        getChromeVersion: function() {
            const n = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
            return !!n && parseInt(n[2], 10);
        },
        getFullChromeVersion: function() {
            const n = navigator.userAgent;
            return n || "Unknown";
        },
        getPlatformOS: function() {
            return n.runtime.getPlatformInfo().then(n => {
                let e = "Unknown";
                switch (n.os) {
                  case "win":
                    e = "MS Windows";
                    break;

                  case "mac":
                    e = "Mac";
                    break;

                  case "android":
                    e = "Android";
                    break;

                  case "cros":
                    e = "Chrome OS";
                    break;

                  case "linux":
                    e = "Linux";
                    break;

                  case "openbsd":
                    e = "OpenBSD";
                }
                return Promise.resolve(e);
            });
        },
        isWindows: function() {
            return n.runtime.getPlatformInfo().then(n => Promise.resolve("win" === n.os));
        },
        isChromeOS: function() {
            return n.runtime.getPlatformInfo().then(n => Promise.resolve("cros" === n.os));
        },
        isMac: function() {
            return n.runtime.getPlatformInfo().then(n => Promise.resolve("mac" === n.os));
        },
        noop: function() {},
        isWhiteSpace: function(n) {
            return !n || 0 === n.length || /^\s*$/.test(n);
        },
        getRandomString: function(n = 8) {
            const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            let t = "";
            for (let r = 0; r < n; r++) t += e.charAt(Math.floor(Math.random() * e.length));
            return t;
        },
        getRandomInt: function(n, e) {
            return Math.floor(Math.random() * (e - n + 1)) + n;
        },
        shuffleArray: function(n) {
            for (let e = (n ? n.length : 0) - 1; e > 0; e--) {
                const t = Math.floor(Math.random() * (e + 1)), r = n[e];
                n[e] = n[t], n[t] = r;
            }
        }
    };
}();