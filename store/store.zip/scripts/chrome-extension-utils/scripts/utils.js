/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Utils = function() {
    "use strict";
    new ExceptionHandler();
    const n = new ChromePromise();
    function e(e) {
        return n.runtime.getPlatformInfo().then(n => Promise.resolve(n.os === e)).catch(() => Promise.resolve(!1));
    }
    return {
        DEBUG: !1,
        getExtensionName: function() {
            return `chrome-extension://${chrome.runtime.id}`;
        },
        getVersion: function() {
            return chrome.runtime.getManifest().version;
        },
        getChromeVersion: function() {
            const n = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
            return !!n && parseInt(n[2], 10);
        },
        getFullChromeVersion: function() {
            const n = navigator.userAgent;
            return n || "Unknown";
        },
        getPlatformOS: function() {
            let e = "Unknown";
            return n.runtime.getPlatformInfo().then(n => {
                switch (n.os) {
                  case "win":
                    e = "MS Windows";
                    break;

                  case "mac":
                    e = "Mac";
                    break;

                  case "android":
                    e = "Android";
                    break;

                  case "cros":
                    e = "Chrome OS";
                    break;

                  case "linux":
                    e = "Linux";
                    break;

                  case "openbsd":
                    e = "OpenBSD";
                }
                return Promise.resolve(e);
            }).catch(() => Promise.resolve(e));
        },
        isWindows: function() {
            return e("win");
        },
        isChromeOS: function() {
            return e("cros");
        },
        isMac: function() {
            return e("mac");
        },
        noop: function() {},
        isWhiteSpace: function(n) {
            return !n || 0 === n.length || /^\s*$/.test(n);
        },
        getRandomString: function(n = 8) {
            const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            let r = "";
            for (let t = 0; t < n; t++) r += e.charAt(Math.floor(Math.random() * e.length));
            return r;
        },
        getRandomInt: function(n, e) {
            return Math.floor(Math.random() * (e - n + 1)) + n;
        },
        shuffleArray: function(n) {
            for (let e = (n ? n.length : 0) - 1; e > 0; e--) {
                const r = Math.floor(Math.random() * (e + 1)), t = n[e];
                n[e] = n[r], n[r] = t;
            }
        }
    };
}();