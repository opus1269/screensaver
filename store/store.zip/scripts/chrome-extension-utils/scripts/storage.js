/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Storage = function() {
    "use strict";
    new ExceptionHandler();
    const r = new ChromePromise();
    return {
        get: function(r, e = null) {
            let t = e, o = localStorage.getItem(r);
            return null !== o && (t = Chrome.JSONUtils.parse(o)), t;
        },
        getInt: function(r, e = null) {
            let t = localStorage.getItem(r), o = parseInt(t, 10);
            return Number.isNaN(o) && (o = null === e ? o : e, null === e && Chrome.GA.error(`NaN value for: ${r} equals ${t}`, "Storage.getInt")), 
            o;
        },
        getBool: function(r, e = null) {
            return Chrome.Storage.get(r, e);
        },
        set: function(r, e = null) {
            if (null === e) localStorage.removeItem(r); else {
                const t = JSON.stringify(e);
                localStorage.setItem(r, t);
            }
        },
        safeSet: function(r, e, t) {
            let o = !0;
            const n = Chrome.Storage.get(r);
            try {
                Chrome.Storage.set(r, e);
            } catch (e) {
                o = !1, n && Chrome.Storage.set(r, n), t && (n && n.length ? Chrome.Storage.set(t, !0) : Chrome.Storage.set(t, !1)), 
                Chrome.Msg.send(Chrome.Msg.STORAGE_EXCEEDED).catch(() => {});
            }
            return o;
        },
        LastError: function(r = "", e = "An error occurred") {
            this.name = "LastError", this.message = r, this.title = e, this.stack = new Error().stack, 
            Chrome.Storage.LastError.prototype = Object.create(Error.prototype), Chrome.Storage.LastError.prototype.constructor = Chrome.Storage.LastError;
        },
        getLastError: function() {
            return r.storage.local.get("lastError").then(r => r.lastError ? Promise.resolve(r.lastError) : new Chrome.Storage.LastError());
        },
        setLastError: function(e) {
            return r.storage.local.set({
                lastError: e
            });
        },
        clearLastError: function() {
            return Chrome.Storage.setLastError(new Chrome.Storage.LastError());
        }
    };
}();