/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Locale = function() {
    "use strict";
    return new ExceptionHandler(), {
        localize: function(e) {
            return chrome.i18n.getMessage(e);
        },
        getLocale: function() {
            return chrome.i18n.getMessage("@@ui_locale");
        }
    };
}();