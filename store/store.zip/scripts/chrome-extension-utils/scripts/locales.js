/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Locale = function() {
    "use strict";
    return new ExceptionHandler(), {
        localize: function(e) {
            return chrome.i18n.getMessage(e);
        },
        getLocale: function() {
            return chrome.i18n.getMessage("@@ui_locale");
        }
    };
}();