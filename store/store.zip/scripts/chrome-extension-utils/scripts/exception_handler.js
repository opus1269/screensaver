/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
!function(o, n) {
    o.ExceptionHandler = function(o) {
        "use strict";
        return function() {
            "object" == typeof o.onerror && (o.onerror = function(o, n, e, r, t) {
                Chrome && Chrome.Log && t && Chrome.Log.exception(t, null, !0);
            });
        };
    }(o);
}(this);