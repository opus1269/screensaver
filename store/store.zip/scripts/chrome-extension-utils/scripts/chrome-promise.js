/**
 * chrome-promise 2.0.2
 * https://github.com/tfoxy/chrome-promise
 *
 * Copyright 2015 Tomás Fox
 * Released under the MIT license
 * Simplified by Mike Updike 2017
 */
!function(e, n) {
    if ("object" == typeof exports) module.exports = n(this || e); else if ("function" == typeof define && define.amd) define([], n.bind(null, this || e)); else {
        e.ChromePromise = n(e);
        var r = document.currentScript;
        if (r) {
            var t = r.dataset.instance;
            t && (e[t] = new e.ChromePromise());
        }
    }
}("undefined" != typeof self ? self : this, function(e) {
    "use strict";
    var n = Array.prototype.slice, r = Object.prototype.hasOwnProperty;
    return t.default = t, t;
    function t(i) {
        var o = (i = i || {}).chrome || e.chrome, s = i.Promise || e.Promise, c = o.runtime, f = this;
        if (!f) throw new Error("ChromePromise must be called with new keyword");
        function a(e, r) {
            return function() {
                var t = n.call(arguments);
                return new s(function(i, o) {
                    t.push(function() {
                        var e = c.lastError, r = n.call(arguments);
                        if (e) o(e); else switch (r.length) {
                          case 0:
                            i();
                            break;

                          case 1:
                            i(r[0]);
                            break;

                          default:
                            i(r);
                        }
                    }), e.apply(r, t);
                });
            };
        }
        function u(e, n) {
            for (var i in e) if (r.call(e, i)) {
                var o;
                try {
                    o = e[i];
                } catch (e) {
                    continue;
                }
                var s = typeof o;
                "object" !== s || o instanceof t ? n[i] = "function" === s ? a(o, e) : o : (n[i] = {}, 
                u(o, n[i]));
            }
        }
        u(o, f), o.permissions && o.permissions.onAdded.addListener(function(e) {
            if (e.permissions && e.permissions.length) {
                var n = {};
                e.permissions.forEach(function(e) {
                    var r = /^[^.]+/.exec(e);
                    r in o && (n[r] = o[r]);
                }), u(n, f);
            }
        });
    }
});