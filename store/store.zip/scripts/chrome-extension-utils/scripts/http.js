/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Http = function() {
    "use strict";
    new ExceptionHandler();
    const e = "Authorization", t = "Bearer", r = 1e3, n = {
        isAuth: !1,
        retryToken: !1,
        interactive: !1,
        token: null,
        backoff: !0,
        maxRetries: 4
    };
    function o(e, t, n, o, a) {
        if (e.ok) return e.json();
        if (a >= o.maxRetries) return Promise.reject(s(e));
        const c = e.status;
        return o.backoff && c >= 500 && c < 600 ? function(e, t, n, o) {
            return o++, new Promise((s, i) => {
                const a = (Math.pow(2, o) - 1) * r;
                setTimeout(() => u(e, t, n, o).then(s, i), a);
            });
        }(t, n, o, a) : o.isAuth && o.token && o.retryToken && 401 === c ? i(t, n, o, a) : o.isAuth && o.interactive && o.token && o.retryToken && 403 === c ? i(t, n, o, a) : Promise.reject(s(e));
    }
    function s(e) {
        let t = "Unknown error.";
        if (e && e.status && void 0 !== e.statusText) {
            let r = Chrome.Locale.localize("err_status");
            void 0 !== r && "" !== r || (r = "Status"), t = `${r}: ${e.status}`, t += `\n${e.statusText}`;
        }
        return new Error(t);
    }
    function i(e, t, r, n) {
        return Chrome.GA.error("Refreshed auth token.", "Http._retryToken"), Chrome.Auth.removeCachedToken(r.interactive, r.token, null).then(() => (r.token = null, 
        r.retryToken = !1, u(e, t, r, n)));
    }
    function u(r, n, s, i) {
        return (u = s.isAuth, a = s.interactive, u ? Chrome.Auth.getToken(a).then(e => Promise.resolve(e)).catch(e => a && (e.message.includes("revoked") || e.message.includes("Authorization page could not be loaded")) ? Chrome.Auth.getToken(!1) : Promise.reject(e)) : Promise.resolve(null)).then(o => (s.isAuth && (s.token = o, 
        n.headers.set(e, `${t} ${s.token}`)), s.body && (n.body = JSON.stringify(s.body)), 
        fetch(r, n))).then(e => o(e, r, n, s, i)).catch(e => {
            let t = e.message;
            return "Failed to fetch" === t && (void 0 !== (t = Chrome.Locale.localize("err_network")) && "" !== t || (t = "Network error")), 
            Promise.reject(new Error(t));
        });
        var u, a;
    }
    function a(r, o, s) {
        (s = null === s ? n : s).isAuth && o.headers.set(e, `${t} unknown`);
        return u(r, o, s, 0);
    }
    return {
        conf: n,
        doGet: function(e, t = null) {
            return a(e, {
                method: "GET",
                headers: new Headers({})
            }, t);
        },
        doPost: function(e, t = null) {
            return a(e, {
                method: "POST",
                headers: new Headers({})
            }, t);
        }
    };
}(window);