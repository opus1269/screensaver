/*
 * Copyright (c) 2016-2017, Michael A. Updike All rights reserved.
 * Licensed under Apache 2.0
 * https://opensource.org/licenses/Apache-2.0
 * https://github.com/opus1269/chrome-extension-utils/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Auth = function() {
    "use strict";
    new ExceptionHandler();
    const e = new ChromePromise();
    return {
        getToken: function(n = !1, t = null) {
            const o = {
                interactive: n
            };
            return t && t.length && (o.scopes = t), e.identity.getAuthToken(o).then(e => Promise.resolve(e));
        },
        removeCachedToken: function(n = !1, t = null, o = null) {
            let r = null;
            return null === t ? this.getToken(n, o).then(n => (r = n, e.identity.removeCachedAuthToken({
                token: n
            }))).then(() => Promise.resolve(r)) : (r = t, e.identity.removeCachedAuthToken({
                token: t
            }).then(() => Promise.resolve(r)));
        }
    };
}();