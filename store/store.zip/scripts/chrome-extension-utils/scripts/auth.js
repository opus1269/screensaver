/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
window.Chrome = window.Chrome || {}, Chrome.Auth = function() {
    "use strict";
    new ExceptionHandler();
    const e = new ChromePromise();
    return {
        getToken: function(t = !1, n = null) {
            const o = {
                interactive: t
            };
            return n && n.length && (o.scopes = n), e.identity.getAuthToken(o).then(e => Promise.resolve(e));
        },
        removeCachedToken: function(t = !1, n = null, o = null) {
            let r = null;
            return null === n ? this.getToken(t, o).then(t => (r = t, e.identity.removeCachedAuthToken({
                token: t
            }))).then(() => Promise.resolve(r)) : (r = n, e.identity.removeCachedAuthToken({
                token: n
            }).then(() => Promise.resolve(r)));
        },
        isSignedIn: function() {
            let t = !0;
            return e.identity.getAuthToken({
                interactive: !1
            }).then(() => Promise.resolve(t)).catch(e => (e.message.match(/not signed in/) && (t = !1), 
            Promise.resolve(t)));
        },
        isRevoked: function() {
            let t = !1;
            return e.identity.getAuthToken({
                interactive: !1
            }).then(() => Promise.resolve(t)).catch(e => (e.message.match(/OAuth2 not granted or revoked/) && (t = !0), 
            Promise.resolve(t)));
        }
    };
}();