import { display } from "./shared_bundle_12.js";

const _DISPLAY_MENU = "DISPLAY_MENU", _ENABLE_MENU = "ENABLE_MENU";

function _toggleEnabled() {
    const e = Chrome.Storage.getBool("enabled");
    Chrome.Storage.set("enabled", !e), app.Data.processState("enabled"), e || app.PhotoSources.process("useGoogleAlbums").catch(e => {
        Chrome.Log.error(e.message, "ContextMenus._toggleEnabled");
    });
}

function _onInstalled(e) {
    const o = new ChromePromise();
    o.contextMenus.create({
        type: "normal",
        id: _DISPLAY_MENU,
        title: Chrome.Locale.localize("display_now"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    }), o.contextMenus.create({
        type: "normal",
        id: _ENABLE_MENU,
        title: Chrome.Locale.localize("disable"),
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    }), o.contextMenus.create({
        type: "separator",
        id: "SEP_MENU",
        contexts: [ "browser_action" ]
    }).catch(e => {
        e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
    });
}

function _onMenuClicked(e) {
    if (e.menuItemId === _DISPLAY_MENU) Chrome.GA.event(Chrome.GA.EVENT.MENU, `${e.menuItemId}`), 
    display(); else if (e.menuItemId === _ENABLE_MENU) {
        const o = Chrome.Storage.getBool("enabled");
        Chrome.GA.event(Chrome.GA.EVENT.MENU, `${e.menuItemId}: ${o}`), _toggleEnabled();
    }
}

function _onKeyCommand(e) {
    "toggle-enabled" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    _toggleEnabled()) : "show-screensaver" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
    display());
}

chrome.runtime.onInstalled.addListener(_onInstalled), chrome.contextMenus.onClicked.addListener(_onMenuClicked), 
chrome.commands.onCommand.addListener(_onKeyCommand);