import "./shared_bundle_12.js";

function _showOptionsTab() {
    Chrome.Msg.send(Chrome.Msg.HIGHLIGHT).catch(() => {
        chrome.tabs.create({
            url: "/html/options.html"
        });
    });
}

function _onInstalled(e) {
    if ("install" === e.reason) Chrome.GA.event(Chrome.GA.EVENT.INSTALLED, Chrome.Utils.getVersion()), 
    app.Data.initialize(), Chrome.Storage.set("isShowing", !1), _showOptionsTab(); else if ("update" === e.reason) {
        if (!app.Utils.DEBUG) {
            const t = e.previousVersion;
            if (Chrome.Utils.getVersion() === t) return;
            let o = !1;
            t && !t.startsWith("3") && (o = !0), o && chrome.tabs.create({
                url: "/html/update3.html"
            });
        }
        app.Data.update(), Chrome.Storage.set("isShowing", !1);
    }
}

function _onStartup() {
    Chrome.GA.page("/background.html"), app.Data.processState(), Chrome.Storage.set("isShowing", !1);
}

function _onIconClicked() {
    _showOptionsTab();
}

function _onStorageChanged(e) {
    app.Data.processState(e.key);
}

function _onChromeMessage(e, t, o) {
    return e.message === Chrome.Msg.RESTORE_DEFAULTS.message ? app.Data.restoreDefaults() : e.message === Chrome.Msg.STORE.message && Chrome.Storage.set(e.key, e.value), 
    !1;
}

function _onLoad() {
    chrome.runtime.onInstalled.addListener(_onInstalled), chrome.runtime.onStartup.addListener(_onStartup), 
    chrome.browserAction.onClicked.addListener(_onIconClicked), addEventListener("storage", _onStorageChanged, !1), 
    Chrome.Msg.listen(_onChromeMessage);
}

window.addEventListener("load", _onLoad);