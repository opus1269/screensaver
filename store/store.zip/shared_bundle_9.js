import { updateBadgeText, updateRepeatingAlarms, isSignedInToChrome } from "./shared_bundle_11.js";

window.app = window.app || {}, app.Data = function() {
    const e = new ChromePromise(), o = {
        version: 20,
        enabled: !0,
        isAlbumMode: !0,
        permPicasa: "notSet",
        permBackground: "notSet",
        allowBackground: !1,
        idleTime: {
            base: 5,
            display: 5,
            unit: 0
        },
        transitionTime: {
            base: 30,
            display: 30,
            unit: 0
        },
        skip: !0,
        shuffle: !0,
        photoSizing: 0,
        photoTransition: 1,
        interactive: !1,
        showTime: 2,
        largeTime: !1,
        fullResGoogle: !1,
        showPhotog: !0,
        showLocation: !0,
        background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
        keepAwake: !1,
        chromeFullscreen: !0,
        allDisplays: !1,
        activeStart: "00:00",
        activeStop: "00:00",
        allowSuspend: !1,
        allowPhotoClicks: !0,
        useSpaceReddit: !1,
        useEarthReddit: !1,
        useAnimalReddit: !1,
        useInterestingFlickr: !1,
        useChromecast: !0,
        useAuthors: !1,
        useGoogle: !0,
        useGoogleAlbums: !0,
        albumSelections: [],
        useGooglePhotos: !1,
        gPhotosNeedsUpdate: !1,
        gPhotosMaxAlbums: 10,
        isAwake: !0,
        isShowing: !1,
        signedInToChrome: !0
    };
    function t() {
        const o = Chrome.Storage.getBool("enabled") ? Chrome.Locale.localize("disable") : Chrome.Locale.localize("enable");
        updateBadgeText(), e.contextMenus.update("ENABLE_MENU", {
            title: o
        }).catch(() => {});
    }
    function a() {
        const e = Chrome.Storage.getBool("keepAwake", !0);
        e ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
        e || Chrome.Storage.set("isAwake", !0), updateRepeatingAlarms(), updateBadgeText();
    }
    function s() {
        const e = app.Data.getIdleSeconds();
        e ? chrome.idle.setDetectionInterval(e) : Chrome.Log.Error("idleTime is null", "Data._processIdleTime");
    }
    function r() {
        let e = 2;
        const o = Chrome.Locale.localize("time_format");
        return o && "12" === o && (e = 1), e;
    }
    function n() {
        return e.runtime.getPlatformInfo().then(e => (Chrome.Storage.set("os", e.os), Promise.resolve()));
    }
    function i() {
        Object.keys(o).forEach(function(e) {
            null === Chrome.Storage.get(e) && Chrome.Storage.set(e, o[e]);
        });
    }
    function l(e) {
        const o = Chrome.Storage.get(e);
        if (o) {
            const t = {
                base: o,
                display: o,
                unit: 0
            };
            Chrome.Storage.set(e, t);
        }
    }
    return {
        initialize: function() {
            i(), n().catch(() => {}), isSignedInToChrome().then(e => (Chrome.Storage.set("signedInToChrome", e), 
            null)).catch(() => {}), Chrome.Storage.clearLastError().catch(e => {
                Chrome.GA.error(e.message, "Data.initialize");
            }), Chrome.Storage.set("showTime", r()), app.Data.processState();
        },
        update: function() {
            const e = Chrome.Storage.getInt("version");
            if ((Number.isNaN(e) || 20 > e) && Chrome.Storage.set("version", 20), !Number.isNaN(e)) {
                if (e < 8 && (l("transitionTime"), l("idleTime")), e < 10) {
                    const e = localStorage.getItem("os");
                    e && Chrome.Storage.set("os", e);
                }
                e < 12 && Chrome.Storage.set("permPicasa", "allowed"), e < 14 && (Chrome.Storage.set("permBackground", "allowed"), 
                Chrome.Storage.set("allowBackground", !0)), e < 18 && (Chrome.Storage.set("permPicasa", "notSet"), 
                Chrome.Auth.removeCachedToken(!1, null, null).catch(e => null), Chrome.Storage.set("albumSelections", []));
            }
            if (e < 19 && (Chrome.Storage.set("useEditors500px", null), Chrome.Storage.set("usePopular500px", null), 
            Chrome.Storage.set("useYesterday500px", null), Chrome.Storage.set("editors500pxImages", null), 
            Chrome.Storage.set("popular500pxImages", null), Chrome.Storage.set("yesterday500pxImages", null)), 
            e < 20) {
                isSignedInToChrome().then(e => (Chrome.Storage.set("signedInToChrome", e), null)).catch(() => {});
                const e = Chrome.Storage.get("transitionTime", {
                    base: 30,
                    display: 30,
                    unit: 0
                });
                0 === e.unit && (e.base = Math.max(10, e.base), e.display = e.base, Chrome.Storage.set("transitionTime", e));
            }
            i(), app.Data.processState();
        },
        restoreDefaults: function() {
            Object.keys(o).forEach(function(e) {
                e.includes("useGoogle") || "googlePhotosSelections" === e || "albumSelections" === e || Chrome.Storage.set(e, o[e]);
            }), Chrome.Storage.set("showTime", r()), app.Data.processState();
        },
        processState: function(e = "all", o = !1) {
            const r = {
                enabled: t,
                keepAwake: a,
                activeStart: a,
                activeStop: a,
                allowSuspend: a,
                idleTime: s
            };
            if ("all" === e) Object.keys(r).forEach(function(e) {
                (0, r[e])();
            }), app.PhotoSources.processAll(o), Chrome.Storage.set("isShowing", !1), Chrome.Storage.get("os") || n().catch(() => {}); else if (app.PhotoSources.isUseKey(e) || "fullResGoogle" === e) {
                const o = "fullResGoogle" === e ? "useGoogleAlbums" : e;
                app.PhotoSources.process(o).catch(e => {
                    const t = app.Msg.PHOTO_SOURCE_FAILED;
                    return t.key = o, t.error = e.message, Chrome.Msg.send(t);
                }).catch(() => {});
            } else {
                const o = r[e];
                void 0 !== o && o();
            }
        },
        getIdleSeconds: function() {
            return 60 * Chrome.Storage.get("idleTime", {
                base: 5,
                display: 5,
                unit: 0
            }).base;
        }
    };
}();